package androidx.cardview;

public final class R {
  public static final class attr {
    public static int cardBackgroundColor = 2130968730;
    
    public static int cardCornerRadius = 2130968732;
    
    public static int cardElevation = 2130968733;
    
    public static int cardMaxElevation = 2130968735;
    
    public static int cardPreventCornerOverlap = 2130968736;
    
    public static int cardUseCompatPadding = 2130968737;
    
    public static int cardViewStyle = 2130968738;
    
    public static int contentPadding = 2130968878;
    
    public static int contentPaddingBottom = 2130968879;
    
    public static int contentPaddingLeft = 2130968881;
    
    public static int contentPaddingRight = 2130968882;
    
    public static int contentPaddingTop = 2130968884;
  }
  
  public static final class color {
    public static int cardview_dark_background = 2131099715;
    
    public static int cardview_light_background = 2131099716;
    
    public static int cardview_shadow_end_color = 2131099717;
    
    public static int cardview_shadow_start_color = 2131099718;
  }
  
  public static final class dimen {
    public static int cardview_compat_inset_shadow = 2131165293;
    
    public static int cardview_default_elevation = 2131165294;
    
    public static int cardview_default_radius = 2131165295;
  }
  
  public static final class style {
    public static int Base_CardView = 2131886108;
    
    public static int CardView = 2131886368;
    
    public static int CardView_Dark = 2131886369;
    
    public static int CardView_Light = 2131886370;
  }
  
  public static final class styleable {
    public static int[] CardView = new int[] { 
        16843071, 16843072, 2130968730, 2130968732, 2130968733, 2130968735, 2130968736, 2130968737, 2130968878, 2130968879, 
        2130968881, 2130968882, 2130968884 };
    
    public static int CardView_android_minHeight = 1;
    
    public static int CardView_android_minWidth = 0;
    
    public static int CardView_cardBackgroundColor = 2;
    
    public static int CardView_cardCornerRadius = 3;
    
    public static int CardView_cardElevation = 4;
    
    public static int CardView_cardMaxElevation = 5;
    
    public static int CardView_cardPreventCornerOverlap = 6;
    
    public static int CardView_cardUseCompatPadding = 7;
    
    public static int CardView_contentPadding = 8;
    
    public static int CardView_contentPaddingBottom = 9;
    
    public static int CardView_contentPaddingLeft = 10;
    
    public static int CardView_contentPaddingRight = 11;
    
    public static int CardView_contentPaddingTop = 12;
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\cardview\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */