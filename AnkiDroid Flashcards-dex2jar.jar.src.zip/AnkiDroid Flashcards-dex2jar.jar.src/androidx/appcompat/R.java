package androidx.appcompat;

public final class R {
  public static final class anim {
    public static int abc_fade_in = 2130771968;
    
    public static int abc_fade_out = 2130771969;
    
    public static int abc_grow_fade_in_from_bottom = 2130771970;
    
    public static int abc_popup_enter = 2130771971;
    
    public static int abc_popup_exit = 2130771972;
    
    public static int abc_shrink_fade_out_from_bottom = 2130771973;
    
    public static int abc_slide_in_bottom = 2130771974;
    
    public static int abc_slide_in_top = 2130771975;
    
    public static int abc_slide_out_bottom = 2130771976;
    
    public static int abc_slide_out_top = 2130771977;
    
    public static int abc_tooltip_enter = 2130771978;
    
    public static int abc_tooltip_exit = 2130771979;
    
    public static int btn_checkbox_to_checked_box_inner_merged_animation = 2130771981;
    
    public static int btn_checkbox_to_checked_box_outer_merged_animation = 2130771982;
    
    public static int btn_checkbox_to_checked_icon_null_animation = 2130771983;
    
    public static int btn_checkbox_to_unchecked_box_inner_merged_animation = 2130771984;
    
    public static int btn_checkbox_to_unchecked_check_path_merged_animation = 2130771985;
    
    public static int btn_checkbox_to_unchecked_icon_null_animation = 2130771986;
    
    public static int btn_radio_to_off_mtrl_dot_group_animation = 2130771987;
    
    public static int btn_radio_to_off_mtrl_ring_outer_animation = 2130771988;
    
    public static int btn_radio_to_off_mtrl_ring_outer_path_animation = 2130771989;
    
    public static int btn_radio_to_on_mtrl_dot_group_animation = 2130771990;
    
    public static int btn_radio_to_on_mtrl_ring_outer_animation = 2130771991;
    
    public static int btn_radio_to_on_mtrl_ring_outer_path_animation = 2130771992;
  }
  
  public static final class attr {
    public static int actionBarDivider = 2130968579;
    
    public static int actionBarItemBackground = 2130968580;
    
    public static int actionBarPopupTheme = 2130968582;
    
    public static int actionBarSize = 2130968583;
    
    public static int actionBarSplitStyle = 2130968584;
    
    public static int actionBarStyle = 2130968585;
    
    public static int actionBarTabBarStyle = 2130968586;
    
    public static int actionBarTabStyle = 2130968587;
    
    public static int actionBarTabTextStyle = 2130968588;
    
    public static int actionBarTheme = 2130968590;
    
    public static int actionBarWidgetTheme = 2130968591;
    
    public static int actionButtonStyle = 2130968592;
    
    public static int actionDropDownStyle = 2130968593;
    
    public static int actionLayout = 2130968594;
    
    public static int actionMenuTextAppearance = 2130968595;
    
    public static int actionMenuTextColor = 2130968596;
    
    public static int actionModeBackground = 2130968597;
    
    public static int actionModeCloseButtonStyle = 2130968598;
    
    public static int actionModeCloseContentDescription = 2130968599;
    
    public static int actionModeCloseDrawable = 2130968600;
    
    public static int actionModeCopyDrawable = 2130968601;
    
    public static int actionModeCutDrawable = 2130968602;
    
    public static int actionModeFindDrawable = 2130968603;
    
    public static int actionModePasteDrawable = 2130968604;
    
    public static int actionModePopupWindowStyle = 2130968605;
    
    public static int actionModeSelectAllDrawable = 2130968606;
    
    public static int actionModeShareDrawable = 2130968607;
    
    public static int actionModeSplitBackground = 2130968608;
    
    public static int actionModeStyle = 2130968609;
    
    public static int actionModeTheme = 2130968610;
    
    public static int actionModeWebSearchDrawable = 2130968611;
    
    public static int actionOverflowButtonStyle = 2130968612;
    
    public static int actionOverflowMenuStyle = 2130968613;
    
    public static int actionProviderClass = 2130968614;
    
    public static int actionViewClass = 2130968616;
    
    public static int activityChooserViewStyle = 2130968618;
    
    public static int alertDialogButtonGroupStyle = 2130968624;
    
    public static int alertDialogCenterButtons = 2130968625;
    
    public static int alertDialogStyle = 2130968626;
    
    public static int alertDialogTheme = 2130968627;
    
    public static int allowStacking = 2130968632;
    
    public static int alphabeticModifiers = 2130968634;
    
    public static int arrowHeadLength = 2130968644;
    
    public static int arrowShaftLength = 2130968645;
    
    public static int autoCompleteTextViewStyle = 2130968649;
    
    public static int autoSizeMaxTextSize = 2130968650;
    
    public static int autoSizeMinTextSize = 2130968651;
    
    public static int autoSizePresetSizes = 2130968652;
    
    public static int autoSizeStepGranularity = 2130968653;
    
    public static int autoSizeTextType = 2130968654;
    
    public static int background = 2130968656;
    
    public static int backgroundSplit = 2130968663;
    
    public static int backgroundStacked = 2130968664;
    
    public static int backgroundTint = 2130968665;
    
    public static int backgroundTintMode = 2130968666;
    
    public static int barLength = 2130968673;
    
    public static int borderlessButtonStyle = 2130968692;
    
    public static int buttonBarButtonStyle = 2130968711;
    
    public static int buttonBarNegativeButtonStyle = 2130968712;
    
    public static int buttonBarNeutralButtonStyle = 2130968713;
    
    public static int buttonBarPositiveButtonStyle = 2130968714;
    
    public static int buttonBarStyle = 2130968715;
    
    public static int buttonCompat = 2130968716;
    
    public static int buttonGravity = 2130968718;
    
    public static int buttonIconDimen = 2130968720;
    
    public static int buttonPanelSideLayout = 2130968723;
    
    public static int buttonStyle = 2130968726;
    
    public static int buttonStyleSmall = 2130968727;
    
    public static int buttonTint = 2130968728;
    
    public static int buttonTintMode = 2130968729;
    
    public static int checkMarkCompat = 2130968752;
    
    public static int checkMarkTint = 2130968753;
    
    public static int checkMarkTintMode = 2130968754;
    
    public static int checkboxStyle = 2130968755;
    
    public static int checkedTextViewStyle = 2130968766;
    
    public static int closeIcon = 2130968801;
    
    public static int closeItemLayout = 2130968808;
    
    public static int collapseContentDescription = 2130968809;
    
    public static int collapseIcon = 2130968810;
    
    public static int color = 2130968821;
    
    public static int colorAccent = 2130968822;
    
    public static int colorBackgroundFloating = 2130968823;
    
    public static int colorButtonNormal = 2130968824;
    
    public static int colorControlActivated = 2130968826;
    
    public static int colorControlHighlight = 2130968827;
    
    public static int colorControlNormal = 2130968828;
    
    public static int colorError = 2130968829;
    
    public static int colorPrimary = 2130968847;
    
    public static int colorPrimaryDark = 2130968849;
    
    public static int colorSwitchThumbNormal = 2130968859;
    
    public static int commitIcon = 2130968862;
    
    public static int contentDescription = 2130968871;
    
    public static int contentInsetEnd = 2130968872;
    
    public static int contentInsetEndWithActions = 2130968873;
    
    public static int contentInsetLeft = 2130968874;
    
    public static int contentInsetRight = 2130968875;
    
    public static int contentInsetStart = 2130968876;
    
    public static int contentInsetStartWithNavigation = 2130968877;
    
    public static int controlBackground = 2130968887;
    
    public static int customNavigationLayout = 2130968957;
    
    public static int defaultQueryHint = 2130968970;
    
    public static int dialogCornerRadius = 2130968977;
    
    public static int dialogPreferredPadding = 2130968983;
    
    public static int dialogTheme = 2130968986;
    
    public static int displayOptions = 2130968990;
    
    public static int divider = 2130968992;
    
    public static int dividerHorizontal = 2130968994;
    
    public static int dividerPadding = 2130968997;
    
    public static int dividerVertical = 2130968999;
    
    public static int drawableBottomCompat = 2130969004;
    
    public static int drawableEndCompat = 2130969005;
    
    public static int drawableLeftCompat = 2130969006;
    
    public static int drawableRightCompat = 2130969007;
    
    public static int drawableSize = 2130969008;
    
    public static int drawableStartCompat = 2130969009;
    
    public static int drawableTint = 2130969010;
    
    public static int drawableTintMode = 2130969011;
    
    public static int drawableTopCompat = 2130969012;
    
    public static int drawerArrowStyle = 2130969013;
    
    public static int dropDownListViewStyle = 2130969016;
    
    public static int dropdownListPreferredItemHeight = 2130969017;
    
    public static int editTextBackground = 2130969026;
    
    public static int editTextColor = 2130969028;
    
    public static int editTextStyle = 2130969031;
    
    public static int elevation = 2130969032;
    
    public static int emojiCompatEnabled = 2130969036;
    
    public static int expandActivityOverflowButtonDrawable = 2130969060;
    
    public static int firstBaselineToTopHeight = 2130969105;
    
    public static int fontFamily = 2130969148;
    
    public static int fontVariationSettings = 2130969157;
    
    public static int gapBetweenBars = 2130969163;
    
    public static int goIcon = 2130969165;
    
    public static int height = 2130969176;
    
    public static int hideOnContentScroll = 2130969183;
    
    public static int homeAsUpIndicator = 2130969189;
    
    public static int homeLayout = 2130969190;
    
    public static int icon = 2130969194;
    
    public static int iconTint = 2130969202;
    
    public static int iconTintMode = 2130969203;
    
    public static int iconifiedByDefault = 2130969204;
    
    public static int imageButtonStyle = 2130969207;
    
    public static int indeterminateProgressStyle = 2130969213;
    
    public static int initialActivityCount = 2130969219;
    
    public static int isLightTheme = 2130969223;
    
    public static int itemPadding = 2130969238;
    
    public static int lastBaselineToBottomHeight = 2130969273;
    
    public static int layout = 2130969275;
    
    public static int lineHeight = 2130969353;
    
    public static int listChoiceBackgroundIndicator = 2130969356;
    
    public static int listChoiceIndicatorMultipleAnimated = 2130969357;
    
    public static int listChoiceIndicatorSingleAnimated = 2130969358;
    
    public static int listDividerAlertDialog = 2130969359;
    
    public static int listItemLayout = 2130969360;
    
    public static int listLayout = 2130969361;
    
    public static int listMenuViewStyle = 2130969362;
    
    public static int listPopupWindowStyle = 2130969363;
    
    public static int listPreferredItemHeight = 2130969364;
    
    public static int listPreferredItemHeightLarge = 2130969365;
    
    public static int listPreferredItemHeightSmall = 2130969366;
    
    public static int listPreferredItemPaddingEnd = 2130969367;
    
    public static int listPreferredItemPaddingLeft = 2130969368;
    
    public static int listPreferredItemPaddingRight = 2130969369;
    
    public static int listPreferredItemPaddingStart = 2130969370;
    
    public static int logo = 2130969371;
    
    public static int logoDescription = 2130969373;
    
    public static int maxButtonHeight = 2130969424;
    
    public static int measureWithLargestChild = 2130969449;
    
    public static int menu = 2130969450;
    
    public static int multiChoiceItemLayout = 2130969540;
    
    public static int navigationContentDescription = 2130969544;
    
    public static int navigationIcon = 2130969545;
    
    public static int navigationMode = 2130969547;
    
    public static int numericModifiers = 2130969556;
    
    public static int overlapAnchor = 2130969567;
    
    public static int paddingBottomNoButtons = 2130969569;
    
    public static int paddingEnd = 2130969571;
    
    public static int paddingStart = 2130969574;
    
    public static int paddingTopNoTitle = 2130969575;
    
    public static int panelBackground = 2130969577;
    
    public static int panelMenuListTheme = 2130969578;
    
    public static int panelMenuListWidth = 2130969579;
    
    public static int popupMenuStyle = 2130969602;
    
    public static int popupTheme = 2130969603;
    
    public static int popupWindowStyle = 2130969604;
    
    public static int preserveIconSpacing = 2130969619;
    
    public static int progressBarPadding = 2130969622;
    
    public static int progressBarStyle = 2130969623;
    
    public static int queryBackground = 2130969627;
    
    public static int queryHint = 2130969628;
    
    public static int radioButtonStyle = 2130969630;
    
    public static int ratingBarStyle = 2130969632;
    
    public static int ratingBarStyleIndicator = 2130969633;
    
    public static int ratingBarStyleSmall = 2130969634;
    
    public static int searchHintIcon = 2130969656;
    
    public static int searchIcon = 2130969657;
    
    public static int searchViewStyle = 2130969658;
    
    public static int seekBarStyle = 2130969663;
    
    public static int selectableItemBackground = 2130969665;
    
    public static int selectableItemBackgroundBorderless = 2130969666;
    
    public static int showAsAction = 2130969685;
    
    public static int showDividers = 2130969687;
    
    public static int showText = 2130969691;
    
    public static int showTitle = 2130969692;
    
    public static int singleChoiceItemLayout = 2130969698;
    
    public static int spinBars = 2130969711;
    
    public static int spinnerDropDownItemStyle = 2130969712;
    
    public static int spinnerStyle = 2130969713;
    
    public static int splitTrack = 2130969718;
    
    public static int srcCompat = 2130969724;
    
    public static int state_above_anchor = 2130969732;
    
    public static int subMenuArrow = 2130969758;
    
    public static int submitBackground = 2130969763;
    
    public static int subtitle = 2130969767;
    
    public static int subtitleTextAppearance = 2130969769;
    
    public static int subtitleTextColor = 2130969770;
    
    public static int subtitleTextStyle = 2130969771;
    
    public static int suggestionRowLayout = 2130969775;
    
    public static int switchMinWidth = 2130969783;
    
    public static int switchPadding = 2130969784;
    
    public static int switchStyle = 2130969787;
    
    public static int switchTextAppearance = 2130969788;
    
    public static int textAllCaps = 2130969824;
    
    public static int textAppearanceLargePopupMenu = 2130969847;
    
    public static int textAppearanceListItem = 2130969849;
    
    public static int textAppearanceListItemSecondary = 2130969850;
    
    public static int textAppearanceListItemSmall = 2130969851;
    
    public static int textAppearancePopupMenuHeader = 2130969853;
    
    public static int textAppearanceSearchResultSubtitle = 2130969854;
    
    public static int textAppearanceSearchResultTitle = 2130969855;
    
    public static int textAppearanceSmallPopupMenu = 2130969856;
    
    public static int textColorAlertDialogListItem = 2130969868;
    
    public static int textColorSearchUrl = 2130969869;
    
    public static int textLocale = 2130969881;
    
    public static int theme = 2130969892;
    
    public static int thickness = 2130969893;
    
    public static int thumbTextPadding = 2130969902;
    
    public static int thumbTint = 2130969903;
    
    public static int thumbTintMode = 2130969904;
    
    public static int tickMark = 2130969908;
    
    public static int tickMarkTint = 2130969909;
    
    public static int tickMarkTintMode = 2130969910;
    
    public static int tint = 2130969912;
    
    public static int tintMode = 2130969913;
    
    public static int title = 2130969914;
    
    public static int titleMargin = 2130969918;
    
    public static int titleMarginBottom = 2130969919;
    
    public static int titleMarginEnd = 2130969920;
    
    public static int titleMarginStart = 2130969921;
    
    public static int titleMarginTop = 2130969922;
    
    public static int titleMargins = 2130969923;
    
    public static int titleTextAppearance = 2130969925;
    
    public static int titleTextColor = 2130969926;
    
    public static int titleTextStyle = 2130969928;
    
    public static int toolbarNavigationButtonStyle = 2130969934;
    
    public static int toolbarStyle = 2130969935;
    
    public static int tooltipForegroundColor = 2130969937;
    
    public static int tooltipFrameBackground = 2130969938;
    
    public static int tooltipText = 2130969940;
    
    public static int track = 2130969946;
    
    public static int trackTint = 2130969956;
    
    public static int trackTintMode = 2130969957;
    
    public static int viewInflaterClass = 2130969977;
    
    public static int voiceIcon = 2130969983;
    
    public static int windowActionBar = 2130969993;
    
    public static int windowActionBarOverlay = 2130969994;
    
    public static int windowActionModeOverlay = 2130969995;
    
    public static int windowFixedHeightMajor = 2130969996;
    
    public static int windowFixedHeightMinor = 2130969997;
    
    public static int windowFixedWidthMajor = 2130969998;
    
    public static int windowFixedWidthMinor = 2130969999;
    
    public static int windowMinWidthMajor = 2130970000;
    
    public static int windowMinWidthMinor = 2130970001;
    
    public static int windowNoTitle = 2130970002;
  }
  
  public static final class bool {
    public static int abc_action_bar_embed_tabs = 2131034112;
    
    public static int abc_config_actionMenuItemAllCaps = 2131034113;
  }
  
  public static final class color {
    public static int abc_background_cache_hint_selector_material_dark = 2131099648;
    
    public static int abc_background_cache_hint_selector_material_light = 2131099649;
    
    public static int abc_btn_colored_borderless_text_material = 2131099650;
    
    public static int abc_btn_colored_text_material = 2131099651;
    
    public static int abc_color_highlight_material = 2131099652;
    
    public static int abc_decor_view_status_guard = 2131099653;
    
    public static int abc_decor_view_status_guard_light = 2131099654;
    
    public static int abc_hint_foreground_material_dark = 2131099655;
    
    public static int abc_hint_foreground_material_light = 2131099656;
    
    public static int abc_primary_text_disable_only_material_dark = 2131099657;
    
    public static int abc_primary_text_disable_only_material_light = 2131099658;
    
    public static int abc_primary_text_material_dark = 2131099659;
    
    public static int abc_primary_text_material_light = 2131099660;
    
    public static int abc_search_url_text = 2131099661;
    
    public static int abc_search_url_text_normal = 2131099662;
    
    public static int abc_search_url_text_pressed = 2131099663;
    
    public static int abc_search_url_text_selected = 2131099664;
    
    public static int abc_secondary_text_material_dark = 2131099665;
    
    public static int abc_secondary_text_material_light = 2131099666;
    
    public static int abc_tint_btn_checkable = 2131099667;
    
    public static int abc_tint_default = 2131099668;
    
    public static int abc_tint_edittext = 2131099669;
    
    public static int abc_tint_seek_thumb = 2131099670;
    
    public static int abc_tint_spinner = 2131099671;
    
    public static int abc_tint_switch_track = 2131099672;
    
    public static int accent_material_dark = 2131099673;
    
    public static int accent_material_light = 2131099674;
    
    public static int background_floating_material_dark = 2131099693;
    
    public static int background_floating_material_light = 2131099694;
    
    public static int background_material_dark = 2131099695;
    
    public static int background_material_light = 2131099696;
    
    public static int bright_foreground_disabled_material_dark = 2131099701;
    
    public static int bright_foreground_disabled_material_light = 2131099702;
    
    public static int bright_foreground_inverse_material_dark = 2131099703;
    
    public static int bright_foreground_inverse_material_light = 2131099704;
    
    public static int bright_foreground_material_dark = 2131099705;
    
    public static int bright_foreground_material_light = 2131099706;
    
    public static int button_material_dark = 2131099711;
    
    public static int button_material_light = 2131099712;
    
    public static int dim_foreground_disabled_material_dark = 2131099773;
    
    public static int dim_foreground_disabled_material_light = 2131099774;
    
    public static int dim_foreground_material_dark = 2131099775;
    
    public static int dim_foreground_material_light = 2131099776;
    
    public static int error_color_material_dark = 2131099780;
    
    public static int error_color_material_light = 2131099781;
    
    public static int foreground_material_dark = 2131099804;
    
    public static int foreground_material_light = 2131099805;
    
    public static int highlighted_text_material_dark = 2131099806;
    
    public static int highlighted_text_material_light = 2131099807;
    
    public static int material_blue_grey_800 = 2131100188;
    
    public static int material_blue_grey_900 = 2131100189;
    
    public static int material_blue_grey_950 = 2131100190;
    
    public static int material_deep_teal_200 = 2131100196;
    
    public static int material_deep_teal_500 = 2131100197;
    
    public static int material_grey_100 = 2131100272;
    
    public static int material_grey_300 = 2131100273;
    
    public static int material_grey_50 = 2131100274;
    
    public static int material_grey_600 = 2131100276;
    
    public static int material_grey_800 = 2131100278;
    
    public static int material_grey_850 = 2131100279;
    
    public static int material_grey_900 = 2131100280;
    
    public static int primary_dark_material_dark = 2131100402;
    
    public static int primary_dark_material_light = 2131100403;
    
    public static int primary_material_dark = 2131100404;
    
    public static int primary_material_light = 2131100405;
    
    public static int primary_text_default_material_dark = 2131100406;
    
    public static int primary_text_default_material_light = 2131100407;
    
    public static int primary_text_disabled_material_dark = 2131100408;
    
    public static int primary_text_disabled_material_light = 2131100409;
    
    public static int ripple_material_dark = 2131100410;
    
    public static int ripple_material_light = 2131100411;
    
    public static int secondary_text_default_material_dark = 2131100412;
    
    public static int secondary_text_default_material_light = 2131100413;
    
    public static int secondary_text_disabled_material_dark = 2131100414;
    
    public static int secondary_text_disabled_material_light = 2131100415;
    
    public static int switch_thumb_disabled_material_dark = 2131100433;
    
    public static int switch_thumb_disabled_material_light = 2131100434;
    
    public static int switch_thumb_material_dark = 2131100435;
    
    public static int switch_thumb_material_light = 2131100436;
    
    public static int switch_thumb_normal_material_dark = 2131100437;
    
    public static int switch_thumb_normal_material_light = 2131100438;
    
    public static int tooltip_background_dark = 2131100472;
    
    public static int tooltip_background_light = 2131100473;
  }
  
  public static final class dimen {
    public static int abc_action_bar_content_inset_material = 2131165184;
    
    public static int abc_action_bar_content_inset_with_nav = 2131165185;
    
    public static int abc_action_bar_default_height_material = 2131165186;
    
    public static int abc_action_bar_default_padding_end_material = 2131165187;
    
    public static int abc_action_bar_default_padding_start_material = 2131165188;
    
    public static int abc_action_bar_elevation_material = 2131165189;
    
    public static int abc_action_bar_icon_vertical_padding_material = 2131165190;
    
    public static int abc_action_bar_overflow_padding_end_material = 2131165191;
    
    public static int abc_action_bar_overflow_padding_start_material = 2131165192;
    
    public static int abc_action_bar_stacked_max_height = 2131165193;
    
    public static int abc_action_bar_stacked_tab_max_width = 2131165194;
    
    public static int abc_action_bar_subtitle_bottom_margin_material = 2131165195;
    
    public static int abc_action_bar_subtitle_top_margin_material = 2131165196;
    
    public static int abc_action_button_min_height_material = 2131165197;
    
    public static int abc_action_button_min_width_material = 2131165198;
    
    public static int abc_action_button_min_width_overflow_material = 2131165199;
    
    public static int abc_alert_dialog_button_bar_height = 2131165200;
    
    public static int abc_alert_dialog_button_dimen = 2131165201;
    
    public static int abc_button_inset_horizontal_material = 2131165202;
    
    public static int abc_button_inset_vertical_material = 2131165203;
    
    public static int abc_button_padding_horizontal_material = 2131165204;
    
    public static int abc_button_padding_vertical_material = 2131165205;
    
    public static int abc_cascading_menus_min_smallest_width = 2131165206;
    
    public static int abc_config_prefDialogWidth = 2131165207;
    
    public static int abc_control_corner_material = 2131165208;
    
    public static int abc_control_inset_material = 2131165209;
    
    public static int abc_control_padding_material = 2131165210;
    
    public static int abc_dialog_corner_radius_material = 2131165211;
    
    public static int abc_dialog_fixed_height_major = 2131165212;
    
    public static int abc_dialog_fixed_height_minor = 2131165213;
    
    public static int abc_dialog_fixed_width_major = 2131165214;
    
    public static int abc_dialog_fixed_width_minor = 2131165215;
    
    public static int abc_dialog_list_padding_bottom_no_buttons = 2131165216;
    
    public static int abc_dialog_list_padding_top_no_title = 2131165217;
    
    public static int abc_dialog_min_width_major = 2131165218;
    
    public static int abc_dialog_min_width_minor = 2131165219;
    
    public static int abc_dialog_padding_material = 2131165220;
    
    public static int abc_dialog_padding_top_material = 2131165221;
    
    public static int abc_dialog_title_divider_material = 2131165222;
    
    public static int abc_disabled_alpha_material_dark = 2131165223;
    
    public static int abc_disabled_alpha_material_light = 2131165224;
    
    public static int abc_dropdownitem_icon_width = 2131165225;
    
    public static int abc_dropdownitem_text_padding_left = 2131165226;
    
    public static int abc_dropdownitem_text_padding_right = 2131165227;
    
    public static int abc_edit_text_inset_bottom_material = 2131165228;
    
    public static int abc_edit_text_inset_horizontal_material = 2131165229;
    
    public static int abc_edit_text_inset_top_material = 2131165230;
    
    public static int abc_floating_window_z = 2131165231;
    
    public static int abc_list_item_height_large_material = 2131165232;
    
    public static int abc_list_item_height_material = 2131165233;
    
    public static int abc_list_item_height_small_material = 2131165234;
    
    public static int abc_list_item_padding_horizontal_material = 2131165235;
    
    public static int abc_panel_menu_list_width = 2131165236;
    
    public static int abc_progress_bar_height_material = 2131165237;
    
    public static int abc_search_view_preferred_height = 2131165238;
    
    public static int abc_search_view_preferred_width = 2131165239;
    
    public static int abc_seekbar_track_background_height_material = 2131165240;
    
    public static int abc_seekbar_track_progress_height_material = 2131165241;
    
    public static int abc_select_dialog_padding_start_material = 2131165242;
    
    public static int abc_star_big = 2131165243;
    
    public static int abc_star_medium = 2131165244;
    
    public static int abc_star_small = 2131165245;
    
    public static int abc_switch_padding = 2131165246;
    
    public static int abc_text_size_body_1_material = 2131165247;
    
    public static int abc_text_size_body_2_material = 2131165248;
    
    public static int abc_text_size_button_material = 2131165249;
    
    public static int abc_text_size_caption_material = 2131165250;
    
    public static int abc_text_size_display_1_material = 2131165251;
    
    public static int abc_text_size_display_2_material = 2131165252;
    
    public static int abc_text_size_display_3_material = 2131165253;
    
    public static int abc_text_size_display_4_material = 2131165254;
    
    public static int abc_text_size_headline_material = 2131165255;
    
    public static int abc_text_size_large_material = 2131165256;
    
    public static int abc_text_size_medium_material = 2131165257;
    
    public static int abc_text_size_menu_header_material = 2131165258;
    
    public static int abc_text_size_menu_material = 2131165259;
    
    public static int abc_text_size_small_material = 2131165260;
    
    public static int abc_text_size_subhead_material = 2131165261;
    
    public static int abc_text_size_subtitle_material_toolbar = 2131165262;
    
    public static int abc_text_size_title_material = 2131165263;
    
    public static int abc_text_size_title_material_toolbar = 2131165264;
    
    public static int disabled_alpha_material_dark = 2131165367;
    
    public static int disabled_alpha_material_light = 2131165368;
    
    public static int highlight_alpha_material_colored = 2131165372;
    
    public static int highlight_alpha_material_dark = 2131165373;
    
    public static int highlight_alpha_material_light = 2131165374;
    
    public static int hint_alpha_material_dark = 2131165375;
    
    public static int hint_alpha_material_light = 2131165376;
    
    public static int hint_pressed_alpha_material_dark = 2131165377;
    
    public static int hint_pressed_alpha_material_light = 2131165378;
    
    public static int tooltip_corner_radius = 2131165908;
    
    public static int tooltip_horizontal_padding = 2131165909;
    
    public static int tooltip_margin = 2131165910;
    
    public static int tooltip_precise_anchor_extra_offset = 2131165911;
    
    public static int tooltip_precise_anchor_threshold = 2131165912;
    
    public static int tooltip_vertical_padding = 2131165913;
    
    public static int tooltip_y_offset_non_touch = 2131165914;
    
    public static int tooltip_y_offset_touch = 2131165915;
  }
  
  public static final class drawable {
    public static int abc_ab_share_pack_mtrl_alpha = 2131230779;
    
    public static int abc_action_bar_item_background_material = 2131230780;
    
    public static int abc_btn_borderless_material = 2131230781;
    
    public static int abc_btn_check_material = 2131230782;
    
    public static int abc_btn_check_material_anim = 2131230783;
    
    public static int abc_btn_check_to_on_mtrl_000 = 2131230784;
    
    public static int abc_btn_check_to_on_mtrl_015 = 2131230785;
    
    public static int abc_btn_colored_material = 2131230786;
    
    public static int abc_btn_default_mtrl_shape = 2131230787;
    
    public static int abc_btn_radio_material = 2131230788;
    
    public static int abc_btn_radio_material_anim = 2131230789;
    
    public static int abc_btn_radio_to_on_mtrl_000 = 2131230790;
    
    public static int abc_btn_radio_to_on_mtrl_015 = 2131230791;
    
    public static int abc_btn_switch_to_on_mtrl_00001 = 2131230792;
    
    public static int abc_btn_switch_to_on_mtrl_00012 = 2131230793;
    
    public static int abc_cab_background_internal_bg = 2131230794;
    
    public static int abc_cab_background_top_material = 2131230795;
    
    public static int abc_cab_background_top_mtrl_alpha = 2131230796;
    
    public static int abc_control_background_material = 2131230797;
    
    public static int abc_dialog_material_background = 2131230798;
    
    public static int abc_edit_text_material = 2131230799;
    
    public static int abc_ic_ab_back_material = 2131230800;
    
    public static int abc_ic_arrow_drop_right_black_24dp = 2131230801;
    
    public static int abc_ic_clear_material = 2131230802;
    
    public static int abc_ic_commit_search_api_mtrl_alpha = 2131230803;
    
    public static int abc_ic_go_search_api_material = 2131230804;
    
    public static int abc_ic_menu_copy_mtrl_am_alpha = 2131230805;
    
    public static int abc_ic_menu_cut_mtrl_alpha = 2131230806;
    
    public static int abc_ic_menu_overflow_material = 2131230807;
    
    public static int abc_ic_menu_paste_mtrl_am_alpha = 2131230808;
    
    public static int abc_ic_menu_selectall_mtrl_alpha = 2131230809;
    
    public static int abc_ic_menu_share_mtrl_alpha = 2131230810;
    
    public static int abc_ic_search_api_material = 2131230811;
    
    public static int abc_ic_voice_search_api_material = 2131230812;
    
    public static int abc_item_background_holo_dark = 2131230813;
    
    public static int abc_item_background_holo_light = 2131230814;
    
    public static int abc_list_divider_material = 2131230815;
    
    public static int abc_list_divider_mtrl_alpha = 2131230816;
    
    public static int abc_list_focused_holo = 2131230817;
    
    public static int abc_list_longpressed_holo = 2131230818;
    
    public static int abc_list_pressed_holo_dark = 2131230819;
    
    public static int abc_list_pressed_holo_light = 2131230820;
    
    public static int abc_list_selector_background_transition_holo_dark = 2131230821;
    
    public static int abc_list_selector_background_transition_holo_light = 2131230822;
    
    public static int abc_list_selector_disabled_holo_dark = 2131230823;
    
    public static int abc_list_selector_disabled_holo_light = 2131230824;
    
    public static int abc_list_selector_holo_dark = 2131230825;
    
    public static int abc_list_selector_holo_light = 2131230826;
    
    public static int abc_menu_hardkey_panel_mtrl_mult = 2131230827;
    
    public static int abc_popup_background_mtrl_mult = 2131230828;
    
    public static int abc_ratingbar_indicator_material = 2131230829;
    
    public static int abc_ratingbar_material = 2131230830;
    
    public static int abc_ratingbar_small_material = 2131230831;
    
    public static int abc_scrubber_control_off_mtrl_alpha = 2131230832;
    
    public static int abc_scrubber_control_to_pressed_mtrl_000 = 2131230833;
    
    public static int abc_scrubber_control_to_pressed_mtrl_005 = 2131230834;
    
    public static int abc_scrubber_primary_mtrl_alpha = 2131230835;
    
    public static int abc_scrubber_track_mtrl_alpha = 2131230836;
    
    public static int abc_seekbar_thumb_material = 2131230837;
    
    public static int abc_seekbar_tick_mark_material = 2131230838;
    
    public static int abc_seekbar_track_material = 2131230839;
    
    public static int abc_spinner_mtrl_am_alpha = 2131230840;
    
    public static int abc_spinner_textfield_background_material = 2131230841;
    
    public static int abc_star_black_48dp = 2131230842;
    
    public static int abc_star_half_black_48dp = 2131230843;
    
    public static int abc_switch_thumb_material = 2131230844;
    
    public static int abc_switch_track_mtrl_alpha = 2131230845;
    
    public static int abc_tab_indicator_material = 2131230846;
    
    public static int abc_tab_indicator_mtrl_alpha = 2131230847;
    
    public static int abc_text_cursor_material = 2131230848;
    
    public static int abc_text_select_handle_left_mtrl = 2131230849;
    
    public static int abc_text_select_handle_middle_mtrl = 2131230850;
    
    public static int abc_text_select_handle_right_mtrl = 2131230851;
    
    public static int abc_textfield_activated_mtrl_alpha = 2131230852;
    
    public static int abc_textfield_default_mtrl_alpha = 2131230853;
    
    public static int abc_textfield_search_activated_mtrl_alpha = 2131230854;
    
    public static int abc_textfield_search_default_mtrl_alpha = 2131230855;
    
    public static int abc_textfield_search_material = 2131230856;
    
    public static int btn_checkbox_checked_mtrl = 2131230868;
    
    public static int btn_checkbox_checked_to_unchecked_mtrl_animation = 2131230869;
    
    public static int btn_checkbox_unchecked_mtrl = 2131230870;
    
    public static int btn_checkbox_unchecked_to_checked_mtrl_animation = 2131230871;
    
    public static int btn_radio_off_mtrl = 2131230872;
    
    public static int btn_radio_off_to_on_mtrl_animation = 2131230873;
    
    public static int btn_radio_on_mtrl = 2131230874;
    
    public static int btn_radio_on_to_off_mtrl_animation = 2131230875;
    
    public static int test_level_drawable = 2131231219;
    
    public static int tooltip_frame_dark = 2131231220;
    
    public static int tooltip_frame_light = 2131231221;
  }
  
  public static final class id {
    public static int action_bar = 2131296346;
    
    public static int action_bar_activity_content = 2131296347;
    
    public static int action_bar_container = 2131296348;
    
    public static int action_bar_root = 2131296349;
    
    public static int action_bar_spinner = 2131296350;
    
    public static int action_bar_subtitle = 2131296351;
    
    public static int action_bar_title = 2131296352;
    
    public static int action_context_bar = 2131296366;
    
    public static int action_menu_divider = 2131296396;
    
    public static int action_menu_presenter = 2131296397;
    
    public static int action_mode_bar = 2131296399;
    
    public static int action_mode_bar_stub = 2131296400;
    
    public static int action_mode_close_button = 2131296401;
    
    public static int activity_chooser_view_content = 2131296456;
    
    public static int add = 2131296457;
    
    public static int alertTitle = 2131296465;
    
    public static int buttonPanel = 2131296526;
    
    public static int checkbox = 2131296587;
    
    public static int checked = 2131296588;
    
    public static int content = 2131296613;
    
    public static int contentPanel = 2131296614;
    
    public static int custom = 2131296628;
    
    public static int customPanel = 2131296629;
    
    public static int decor_content_parent = 2131296654;
    
    public static int default_activity_button = 2131296655;
    
    public static int edit_query = 2131296700;
    
    public static int expand_activities_button = 2131296712;
    
    public static int expanded_menu = 2131296713;
    
    public static int group_divider = 2131296768;
    
    public static int home = 2131296775;
    
    public static int icon = 2131296785;
    
    public static int image = 2131296796;
    
    public static int listMode = 2131296873;
    
    public static int list_item = 2131296874;
    
    public static int message = 2131296938;
    
    public static int multiply = 2131296984;
    
    public static int none = 2131297014;
    
    public static int normal = 2131297015;
    
    public static int off = 2131297045;
    
    public static int on = 2131297046;
    
    public static int parentPanel = 2131297059;
    
    public static int progress_circular = 2131297097;
    
    public static int progress_horizontal = 2131297098;
    
    public static int radio = 2131297102;
    
    public static int screen = 2131297130;
    
    public static int scrollIndicatorDown = 2131297132;
    
    public static int scrollIndicatorUp = 2131297133;
    
    public static int scrollView = 2131297134;
    
    public static int search_badge = 2131297138;
    
    public static int search_bar = 2131297139;
    
    public static int search_button = 2131297140;
    
    public static int search_close_btn = 2131297142;
    
    public static int search_edit_frame = 2131297143;
    
    public static int search_go_btn = 2131297144;
    
    public static int search_mag_icon = 2131297145;
    
    public static int search_plate = 2131297146;
    
    public static int search_src_text = 2131297147;
    
    public static int search_voice_btn = 2131297148;
    
    public static int select_dialog_listview = 2131297153;
    
    public static int shortcut = 2131297163;
    
    public static int spacer = 2131297180;
    
    public static int split_action_bar = 2131297185;
    
    public static int src_atop = 2131297190;
    
    public static int src_in = 2131297191;
    
    public static int src_over = 2131297192;
    
    public static int submenuarrow = 2131297224;
    
    public static int submit_area = 2131297225;
    
    public static int tabMode = 2131297234;
    
    public static int textSpacerNoButtons = 2131297263;
    
    public static int textSpacerNoTitle = 2131297264;
    
    public static int title = 2131297277;
    
    public static int titleDividerNoCustom = 2131297278;
    
    public static int title_template = 2131297281;
    
    public static int topPanel = 2131297290;
    
    public static int unchecked = 2131297309;
    
    public static int uniform = 2131297310;
    
    public static int up = 2131297312;
    
    public static int wrap_content = 2131297345;
  }
  
  public static final class integer {
    public static int abc_config_activityDefaultDur = 2131361792;
    
    public static int abc_config_activityShortDur = 2131361793;
    
    public static int cancel_button_image_alpha = 2131361796;
    
    public static int config_tooltipAnimTime = 2131361797;
  }
  
  public static final class interpolator {
    public static int btn_checkbox_checked_mtrl_animation_interpolator_0 = 2131427328;
    
    public static int btn_checkbox_checked_mtrl_animation_interpolator_1 = 2131427329;
    
    public static int btn_checkbox_unchecked_mtrl_animation_interpolator_0 = 2131427330;
    
    public static int btn_checkbox_unchecked_mtrl_animation_interpolator_1 = 2131427331;
    
    public static int btn_radio_to_off_mtrl_animation_interpolator_0 = 2131427332;
    
    public static int btn_radio_to_on_mtrl_animation_interpolator_0 = 2131427333;
    
    public static int fast_out_slow_in = 2131427334;
  }
  
  public static final class layout {
    public static int abc_action_bar_title_item = 2131492864;
    
    public static int abc_action_bar_up_container = 2131492865;
    
    public static int abc_action_menu_item_layout = 2131492866;
    
    public static int abc_action_menu_layout = 2131492867;
    
    public static int abc_action_mode_bar = 2131492868;
    
    public static int abc_action_mode_close_item_material = 2131492869;
    
    public static int abc_activity_chooser_view = 2131492870;
    
    public static int abc_activity_chooser_view_list_item = 2131492871;
    
    public static int abc_alert_dialog_button_bar_material = 2131492872;
    
    public static int abc_alert_dialog_material = 2131492873;
    
    public static int abc_alert_dialog_title_material = 2131492874;
    
    public static int abc_cascading_menu_item_layout = 2131492875;
    
    public static int abc_dialog_title_material = 2131492876;
    
    public static int abc_expanded_menu_layout = 2131492877;
    
    public static int abc_list_menu_item_checkbox = 2131492878;
    
    public static int abc_list_menu_item_icon = 2131492879;
    
    public static int abc_list_menu_item_layout = 2131492880;
    
    public static int abc_list_menu_item_radio = 2131492881;
    
    public static int abc_popup_menu_header_item_layout = 2131492882;
    
    public static int abc_popup_menu_item_layout = 2131492883;
    
    public static int abc_screen_content_include = 2131492884;
    
    public static int abc_screen_simple = 2131492885;
    
    public static int abc_screen_simple_overlay_action_mode = 2131492886;
    
    public static int abc_screen_toolbar = 2131492887;
    
    public static int abc_search_dropdown_item_icons_2line = 2131492888;
    
    public static int abc_search_view = 2131492889;
    
    public static int abc_select_dialog_material = 2131492890;
    
    public static int abc_tooltip = 2131492891;
    
    public static int select_dialog_item_material = 2131493100;
    
    public static int select_dialog_multichoice_material = 2131493101;
    
    public static int select_dialog_singlechoice_material = 2131493102;
    
    public static int support_simple_spinner_dropdown_item = 2131493108;
  }
  
  public static final class string {
    public static int abc_action_bar_home_description = 2131820549;
    
    public static int abc_action_bar_up_description = 2131820550;
    
    public static int abc_action_menu_overflow_description = 2131820551;
    
    public static int abc_action_mode_done = 2131820552;
    
    public static int abc_activity_chooser_view_see_all = 2131820553;
    
    public static int abc_activitychooserview_choose_application = 2131820554;
    
    public static int abc_capital_off = 2131820555;
    
    public static int abc_capital_on = 2131820556;
    
    public static int abc_menu_alt_shortcut_label = 2131820557;
    
    public static int abc_menu_ctrl_shortcut_label = 2131820558;
    
    public static int abc_menu_delete_shortcut_label = 2131820559;
    
    public static int abc_menu_enter_shortcut_label = 2131820560;
    
    public static int abc_menu_function_shortcut_label = 2131820561;
    
    public static int abc_menu_meta_shortcut_label = 2131820562;
    
    public static int abc_menu_shift_shortcut_label = 2131820563;
    
    public static int abc_menu_space_shortcut_label = 2131820564;
    
    public static int abc_menu_sym_shortcut_label = 2131820565;
    
    public static int abc_prepend_shortcut_label = 2131820566;
    
    public static int abc_search_hint = 2131820567;
    
    public static int abc_searchview_description_clear = 2131820568;
    
    public static int abc_searchview_description_query = 2131820569;
    
    public static int abc_searchview_description_search = 2131820570;
    
    public static int abc_searchview_description_submit = 2131820571;
    
    public static int abc_searchview_description_voice = 2131820572;
    
    public static int abc_shareactionprovider_share_with = 2131820573;
    
    public static int abc_shareactionprovider_share_with_application = 2131820574;
    
    public static int abc_toolbar_collapse_description = 2131820575;
    
    public static int search_menu_title = 2131821990;
  }
  
  public static final class style {
    public static int AlertDialog_AppCompat = 2131886084;
    
    public static int AlertDialog_AppCompat_Light = 2131886085;
    
    public static int Animation_AppCompat_Dialog = 2131886086;
    
    public static int Animation_AppCompat_DropDownUp = 2131886087;
    
    public static int Animation_AppCompat_Tooltip = 2131886088;
    
    public static int Base_AlertDialog_AppCompat = 2131886103;
    
    public static int Base_AlertDialog_AppCompat_Light = 2131886104;
    
    public static int Base_Animation_AppCompat_Dialog = 2131886105;
    
    public static int Base_Animation_AppCompat_DropDownUp = 2131886106;
    
    public static int Base_Animation_AppCompat_Tooltip = 2131886107;
    
    public static int Base_DialogWindowTitleBackground_AppCompat = 2131886110;
    
    public static int Base_DialogWindowTitle_AppCompat = 2131886109;
    
    public static int Base_TextAppearance_AppCompat = 2131886114;
    
    public static int Base_TextAppearance_AppCompat_Body1 = 2131886115;
    
    public static int Base_TextAppearance_AppCompat_Body2 = 2131886116;
    
    public static int Base_TextAppearance_AppCompat_Button = 2131886117;
    
    public static int Base_TextAppearance_AppCompat_Caption = 2131886118;
    
    public static int Base_TextAppearance_AppCompat_Display1 = 2131886119;
    
    public static int Base_TextAppearance_AppCompat_Display2 = 2131886120;
    
    public static int Base_TextAppearance_AppCompat_Display3 = 2131886121;
    
    public static int Base_TextAppearance_AppCompat_Display4 = 2131886122;
    
    public static int Base_TextAppearance_AppCompat_Headline = 2131886123;
    
    public static int Base_TextAppearance_AppCompat_Inverse = 2131886124;
    
    public static int Base_TextAppearance_AppCompat_Large = 2131886125;
    
    public static int Base_TextAppearance_AppCompat_Large_Inverse = 2131886126;
    
    public static int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131886127;
    
    public static int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131886128;
    
    public static int Base_TextAppearance_AppCompat_Medium = 2131886129;
    
    public static int Base_TextAppearance_AppCompat_Medium_Inverse = 2131886130;
    
    public static int Base_TextAppearance_AppCompat_Menu = 2131886131;
    
    public static int Base_TextAppearance_AppCompat_SearchResult = 2131886132;
    
    public static int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 2131886133;
    
    public static int Base_TextAppearance_AppCompat_SearchResult_Title = 2131886134;
    
    public static int Base_TextAppearance_AppCompat_Small = 2131886135;
    
    public static int Base_TextAppearance_AppCompat_Small_Inverse = 2131886136;
    
    public static int Base_TextAppearance_AppCompat_Subhead = 2131886137;
    
    public static int Base_TextAppearance_AppCompat_Subhead_Inverse = 2131886138;
    
    public static int Base_TextAppearance_AppCompat_Title = 2131886139;
    
    public static int Base_TextAppearance_AppCompat_Title_Inverse = 2131886140;
    
    public static int Base_TextAppearance_AppCompat_Tooltip = 2131886141;
    
    public static int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131886142;
    
    public static int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131886143;
    
    public static int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131886144;
    
    public static int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 2131886145;
    
    public static int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131886146;
    
    public static int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131886147;
    
    public static int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 2131886148;
    
    public static int Base_TextAppearance_AppCompat_Widget_Button = 2131886149;
    
    public static int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131886150;
    
    public static int Base_TextAppearance_AppCompat_Widget_Button_Colored = 2131886151;
    
    public static int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 2131886152;
    
    public static int Base_TextAppearance_AppCompat_Widget_DropDownItem = 2131886153;
    
    public static int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131886154;
    
    public static int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131886155;
    
    public static int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131886156;
    
    public static int Base_TextAppearance_AppCompat_Widget_Switch = 2131886157;
    
    public static int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131886158;
    
    public static int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131886163;
    
    public static int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131886164;
    
    public static int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 2131886165;
    
    public static int Base_ThemeOverlay_AppCompat = 2131886205;
    
    public static int Base_ThemeOverlay_AppCompat_ActionBar = 2131886206;
    
    public static int Base_ThemeOverlay_AppCompat_Dark = 2131886207;
    
    public static int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 2131886208;
    
    public static int Base_ThemeOverlay_AppCompat_Dialog = 2131886209;
    
    public static int Base_ThemeOverlay_AppCompat_Dialog_Alert = 2131886210;
    
    public static int Base_ThemeOverlay_AppCompat_Light = 2131886211;
    
    public static int Base_Theme_AppCompat = 2131886166;
    
    public static int Base_Theme_AppCompat_CompactMenu = 2131886167;
    
    public static int Base_Theme_AppCompat_Dialog = 2131886168;
    
    public static int Base_Theme_AppCompat_DialogWhenLarge = 2131886172;
    
    public static int Base_Theme_AppCompat_Dialog_Alert = 2131886169;
    
    public static int Base_Theme_AppCompat_Dialog_FixedSize = 2131886170;
    
    public static int Base_Theme_AppCompat_Dialog_MinWidth = 2131886171;
    
    public static int Base_Theme_AppCompat_Light = 2131886173;
    
    public static int Base_Theme_AppCompat_Light_DarkActionBar = 2131886174;
    
    public static int Base_Theme_AppCompat_Light_Dialog = 2131886175;
    
    public static int Base_Theme_AppCompat_Light_DialogWhenLarge = 2131886179;
    
    public static int Base_Theme_AppCompat_Light_Dialog_Alert = 2131886176;
    
    public static int Base_Theme_AppCompat_Light_Dialog_FixedSize = 2131886177;
    
    public static int Base_Theme_AppCompat_Light_Dialog_MinWidth = 2131886178;
    
    public static int Base_V21_ThemeOverlay_AppCompat_Dialog = 2131886250;
    
    public static int Base_V21_Theme_AppCompat = 2131886242;
    
    public static int Base_V21_Theme_AppCompat_Dialog = 2131886243;
    
    public static int Base_V21_Theme_AppCompat_Light = 2131886244;
    
    public static int Base_V21_Theme_AppCompat_Light_Dialog = 2131886245;
    
    public static int Base_V22_Theme_AppCompat = 2131886253;
    
    public static int Base_V22_Theme_AppCompat_Light = 2131886254;
    
    public static int Base_V23_Theme_AppCompat = 2131886255;
    
    public static int Base_V23_Theme_AppCompat_Light = 2131886256;
    
    public static int Base_V26_Theme_AppCompat = 2131886261;
    
    public static int Base_V26_Theme_AppCompat_Light = 2131886262;
    
    public static int Base_V26_Widget_AppCompat_Toolbar = 2131886263;
    
    public static int Base_V28_Theme_AppCompat = 2131886264;
    
    public static int Base_V28_Theme_AppCompat_Light = 2131886265;
    
    public static int Base_V7_ThemeOverlay_AppCompat_Dialog = 2131886270;
    
    public static int Base_V7_Theme_AppCompat = 2131886266;
    
    public static int Base_V7_Theme_AppCompat_Dialog = 2131886267;
    
    public static int Base_V7_Theme_AppCompat_Light = 2131886268;
    
    public static int Base_V7_Theme_AppCompat_Light_Dialog = 2131886269;
    
    public static int Base_V7_Widget_AppCompat_AutoCompleteTextView = 2131886271;
    
    public static int Base_V7_Widget_AppCompat_EditText = 2131886272;
    
    public static int Base_V7_Widget_AppCompat_Toolbar = 2131886273;
    
    public static int Base_Widget_AppCompat_ActionBar = 2131886274;
    
    public static int Base_Widget_AppCompat_ActionBar_Solid = 2131886275;
    
    public static int Base_Widget_AppCompat_ActionBar_TabBar = 2131886276;
    
    public static int Base_Widget_AppCompat_ActionBar_TabText = 2131886277;
    
    public static int Base_Widget_AppCompat_ActionBar_TabView = 2131886278;
    
    public static int Base_Widget_AppCompat_ActionButton = 2131886279;
    
    public static int Base_Widget_AppCompat_ActionButton_CloseMode = 2131886280;
    
    public static int Base_Widget_AppCompat_ActionButton_Overflow = 2131886281;
    
    public static int Base_Widget_AppCompat_ActionMode = 2131886282;
    
    public static int Base_Widget_AppCompat_ActivityChooserView = 2131886283;
    
    public static int Base_Widget_AppCompat_AutoCompleteTextView = 2131886284;
    
    public static int Base_Widget_AppCompat_Button = 2131886285;
    
    public static int Base_Widget_AppCompat_ButtonBar = 2131886291;
    
    public static int Base_Widget_AppCompat_ButtonBar_AlertDialog = 2131886292;
    
    public static int Base_Widget_AppCompat_Button_Borderless = 2131886286;
    
    public static int Base_Widget_AppCompat_Button_Borderless_Colored = 2131886287;
    
    public static int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131886288;
    
    public static int Base_Widget_AppCompat_Button_Colored = 2131886289;
    
    public static int Base_Widget_AppCompat_Button_Small = 2131886290;
    
    public static int Base_Widget_AppCompat_CompoundButton_CheckBox = 2131886293;
    
    public static int Base_Widget_AppCompat_CompoundButton_RadioButton = 2131886294;
    
    public static int Base_Widget_AppCompat_CompoundButton_Switch = 2131886295;
    
    public static int Base_Widget_AppCompat_DrawerArrowToggle = 2131886296;
    
    public static int Base_Widget_AppCompat_DrawerArrowToggle_Common = 2131886297;
    
    public static int Base_Widget_AppCompat_DropDownItem_Spinner = 2131886298;
    
    public static int Base_Widget_AppCompat_EditText = 2131886299;
    
    public static int Base_Widget_AppCompat_ImageButton = 2131886300;
    
    public static int Base_Widget_AppCompat_Light_ActionBar = 2131886301;
    
    public static int Base_Widget_AppCompat_Light_ActionBar_Solid = 2131886302;
    
    public static int Base_Widget_AppCompat_Light_ActionBar_TabBar = 2131886303;
    
    public static int Base_Widget_AppCompat_Light_ActionBar_TabText = 2131886304;
    
    public static int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131886305;
    
    public static int Base_Widget_AppCompat_Light_ActionBar_TabView = 2131886306;
    
    public static int Base_Widget_AppCompat_Light_PopupMenu = 2131886307;
    
    public static int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 2131886308;
    
    public static int Base_Widget_AppCompat_ListMenuView = 2131886309;
    
    public static int Base_Widget_AppCompat_ListPopupWindow = 2131886310;
    
    public static int Base_Widget_AppCompat_ListView = 2131886311;
    
    public static int Base_Widget_AppCompat_ListView_DropDown = 2131886312;
    
    public static int Base_Widget_AppCompat_ListView_Menu = 2131886313;
    
    public static int Base_Widget_AppCompat_PopupMenu = 2131886314;
    
    public static int Base_Widget_AppCompat_PopupMenu_Overflow = 2131886315;
    
    public static int Base_Widget_AppCompat_PopupWindow = 2131886316;
    
    public static int Base_Widget_AppCompat_ProgressBar = 2131886317;
    
    public static int Base_Widget_AppCompat_ProgressBar_Horizontal = 2131886318;
    
    public static int Base_Widget_AppCompat_RatingBar = 2131886319;
    
    public static int Base_Widget_AppCompat_RatingBar_Indicator = 2131886320;
    
    public static int Base_Widget_AppCompat_RatingBar_Small = 2131886321;
    
    public static int Base_Widget_AppCompat_SearchView = 2131886322;
    
    public static int Base_Widget_AppCompat_SearchView_ActionBar = 2131886323;
    
    public static int Base_Widget_AppCompat_SeekBar = 2131886324;
    
    public static int Base_Widget_AppCompat_SeekBar_Discrete = 2131886325;
    
    public static int Base_Widget_AppCompat_Spinner = 2131886326;
    
    public static int Base_Widget_AppCompat_Spinner_Underlined = 2131886327;
    
    public static int Base_Widget_AppCompat_TextView = 2131886328;
    
    public static int Base_Widget_AppCompat_TextView_SpinnerItem = 2131886329;
    
    public static int Base_Widget_AppCompat_Toolbar = 2131886330;
    
    public static int Base_Widget_AppCompat_Toolbar_Button_Navigation = 2131886331;
    
    public static int Platform_AppCompat = 2131886420;
    
    public static int Platform_AppCompat_Light = 2131886421;
    
    public static int Platform_ThemeOverlay_AppCompat = 2131886426;
    
    public static int Platform_ThemeOverlay_AppCompat_Dark = 2131886427;
    
    public static int Platform_ThemeOverlay_AppCompat_Light = 2131886428;
    
    public static int Platform_V21_AppCompat = 2131886429;
    
    public static int Platform_V21_AppCompat_Light = 2131886430;
    
    public static int Platform_V25_AppCompat = 2131886431;
    
    public static int Platform_V25_AppCompat_Light = 2131886432;
    
    public static int Platform_Widget_AppCompat_Spinner = 2131886433;
    
    public static int RtlOverlay_DialogWindowTitle_AppCompat = 2131886466;
    
    public static int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 2131886467;
    
    public static int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 2131886468;
    
    public static int RtlOverlay_Widget_AppCompat_PopupMenuItem = 2131886469;
    
    public static int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 2131886470;
    
    public static int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 2131886471;
    
    public static int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 2131886472;
    
    public static int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 2131886473;
    
    public static int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 2131886474;
    
    public static int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 2131886480;
    
    public static int RtlOverlay_Widget_AppCompat_Search_DropDown = 2131886475;
    
    public static int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 2131886476;
    
    public static int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 2131886477;
    
    public static int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 2131886478;
    
    public static int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 2131886479;
    
    public static int RtlUnderlay_Widget_AppCompat_ActionButton = 2131886481;
    
    public static int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 2131886482;
    
    public static int TextAppearance_AppCompat = 2131886535;
    
    public static int TextAppearance_AppCompat_Body1 = 2131886536;
    
    public static int TextAppearance_AppCompat_Body2 = 2131886537;
    
    public static int TextAppearance_AppCompat_Button = 2131886538;
    
    public static int TextAppearance_AppCompat_Caption = 2131886539;
    
    public static int TextAppearance_AppCompat_Display1 = 2131886540;
    
    public static int TextAppearance_AppCompat_Display2 = 2131886541;
    
    public static int TextAppearance_AppCompat_Display3 = 2131886542;
    
    public static int TextAppearance_AppCompat_Display4 = 2131886543;
    
    public static int TextAppearance_AppCompat_Headline = 2131886544;
    
    public static int TextAppearance_AppCompat_Inverse = 2131886545;
    
    public static int TextAppearance_AppCompat_Large = 2131886546;
    
    public static int TextAppearance_AppCompat_Large_Inverse = 2131886547;
    
    public static int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 2131886548;
    
    public static int TextAppearance_AppCompat_Light_SearchResult_Title = 2131886549;
    
    public static int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131886550;
    
    public static int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131886551;
    
    public static int TextAppearance_AppCompat_Medium = 2131886552;
    
    public static int TextAppearance_AppCompat_Medium_Inverse = 2131886553;
    
    public static int TextAppearance_AppCompat_Menu = 2131886554;
    
    public static int TextAppearance_AppCompat_SearchResult_Subtitle = 2131886555;
    
    public static int TextAppearance_AppCompat_SearchResult_Title = 2131886556;
    
    public static int TextAppearance_AppCompat_Small = 2131886557;
    
    public static int TextAppearance_AppCompat_Small_Inverse = 2131886558;
    
    public static int TextAppearance_AppCompat_Subhead = 2131886559;
    
    public static int TextAppearance_AppCompat_Subhead_Inverse = 2131886560;
    
    public static int TextAppearance_AppCompat_Title = 2131886561;
    
    public static int TextAppearance_AppCompat_Title_Inverse = 2131886562;
    
    public static int TextAppearance_AppCompat_Tooltip = 2131886563;
    
    public static int TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131886564;
    
    public static int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131886565;
    
    public static int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131886566;
    
    public static int TextAppearance_AppCompat_Widget_ActionBar_Title = 2131886567;
    
    public static int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131886568;
    
    public static int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131886569;
    
    public static int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 2131886570;
    
    public static int TextAppearance_AppCompat_Widget_ActionMode_Title = 2131886571;
    
    public static int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 2131886572;
    
    public static int TextAppearance_AppCompat_Widget_Button = 2131886573;
    
    public static int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131886574;
    
    public static int TextAppearance_AppCompat_Widget_Button_Colored = 2131886575;
    
    public static int TextAppearance_AppCompat_Widget_Button_Inverse = 2131886576;
    
    public static int TextAppearance_AppCompat_Widget_DropDownItem = 2131886577;
    
    public static int TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131886578;
    
    public static int TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131886579;
    
    public static int TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131886580;
    
    public static int TextAppearance_AppCompat_Widget_Switch = 2131886581;
    
    public static int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131886582;
    
    public static int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131886649;
    
    public static int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131886650;
    
    public static int TextAppearance_Widget_AppCompat_Toolbar_Title = 2131886651;
    
    public static int ThemeOverlay_AppCompat = 2131886755;
    
    public static int ThemeOverlay_AppCompat_ActionBar = 2131886756;
    
    public static int ThemeOverlay_AppCompat_Dark = 2131886757;
    
    public static int ThemeOverlay_AppCompat_Dark_ActionBar = 2131886758;
    
    public static int ThemeOverlay_AppCompat_DayNight = 2131886759;
    
    public static int ThemeOverlay_AppCompat_DayNight_ActionBar = 2131886760;
    
    public static int ThemeOverlay_AppCompat_Dialog = 2131886761;
    
    public static int ThemeOverlay_AppCompat_Dialog_Alert = 2131886762;
    
    public static int ThemeOverlay_AppCompat_Light = 2131886763;
    
    public static int Theme_AppCompat = 2131886653;
    
    public static int Theme_AppCompat_CompactMenu = 2131886654;
    
    public static int Theme_AppCompat_DayNight = 2131886655;
    
    public static int Theme_AppCompat_DayNight_DarkActionBar = 2131886656;
    
    public static int Theme_AppCompat_DayNight_Dialog = 2131886657;
    
    public static int Theme_AppCompat_DayNight_DialogWhenLarge = 2131886660;
    
    public static int Theme_AppCompat_DayNight_Dialog_Alert = 2131886658;
    
    public static int Theme_AppCompat_DayNight_Dialog_MinWidth = 2131886659;
    
    public static int Theme_AppCompat_DayNight_NoActionBar = 2131886661;
    
    public static int Theme_AppCompat_Dialog = 2131886662;
    
    public static int Theme_AppCompat_DialogWhenLarge = 2131886665;
    
    public static int Theme_AppCompat_Dialog_Alert = 2131886663;
    
    public static int Theme_AppCompat_Dialog_MinWidth = 2131886664;
    
    public static int Theme_AppCompat_Empty = 2131886666;
    
    public static int Theme_AppCompat_Light = 2131886667;
    
    public static int Theme_AppCompat_Light_DarkActionBar = 2131886668;
    
    public static int Theme_AppCompat_Light_Dialog = 2131886669;
    
    public static int Theme_AppCompat_Light_DialogWhenLarge = 2131886672;
    
    public static int Theme_AppCompat_Light_Dialog_Alert = 2131886670;
    
    public static int Theme_AppCompat_Light_Dialog_MinWidth = 2131886671;
    
    public static int Theme_AppCompat_Light_NoActionBar = 2131886673;
    
    public static int Theme_AppCompat_NoActionBar = 2131886674;
    
    public static int Widget_AppCompat_ActionBar = 2131886874;
    
    public static int Widget_AppCompat_ActionBar_Solid = 2131886875;
    
    public static int Widget_AppCompat_ActionBar_TabBar = 2131886876;
    
    public static int Widget_AppCompat_ActionBar_TabText = 2131886877;
    
    public static int Widget_AppCompat_ActionBar_TabView = 2131886878;
    
    public static int Widget_AppCompat_ActionButton = 2131886879;
    
    public static int Widget_AppCompat_ActionButton_CloseMode = 2131886880;
    
    public static int Widget_AppCompat_ActionButton_Overflow = 2131886881;
    
    public static int Widget_AppCompat_ActionMode = 2131886882;
    
    public static int Widget_AppCompat_ActivityChooserView = 2131886883;
    
    public static int Widget_AppCompat_AutoCompleteTextView = 2131886884;
    
    public static int Widget_AppCompat_Button = 2131886885;
    
    public static int Widget_AppCompat_ButtonBar = 2131886891;
    
    public static int Widget_AppCompat_ButtonBar_AlertDialog = 2131886892;
    
    public static int Widget_AppCompat_Button_Borderless = 2131886886;
    
    public static int Widget_AppCompat_Button_Borderless_Colored = 2131886887;
    
    public static int Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131886888;
    
    public static int Widget_AppCompat_Button_Colored = 2131886889;
    
    public static int Widget_AppCompat_Button_Small = 2131886890;
    
    public static int Widget_AppCompat_CompoundButton_CheckBox = 2131886893;
    
    public static int Widget_AppCompat_CompoundButton_RadioButton = 2131886894;
    
    public static int Widget_AppCompat_CompoundButton_Switch = 2131886895;
    
    public static int Widget_AppCompat_DrawerArrowToggle = 2131886896;
    
    public static int Widget_AppCompat_DropDownItem_Spinner = 2131886897;
    
    public static int Widget_AppCompat_EditText = 2131886898;
    
    public static int Widget_AppCompat_ImageButton = 2131886899;
    
    public static int Widget_AppCompat_Light_ActionBar = 2131886900;
    
    public static int Widget_AppCompat_Light_ActionBar_Solid = 2131886901;
    
    public static int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 2131886902;
    
    public static int Widget_AppCompat_Light_ActionBar_TabBar = 2131886903;
    
    public static int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 2131886904;
    
    public static int Widget_AppCompat_Light_ActionBar_TabText = 2131886905;
    
    public static int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131886906;
    
    public static int Widget_AppCompat_Light_ActionBar_TabView = 2131886907;
    
    public static int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 2131886908;
    
    public static int Widget_AppCompat_Light_ActionButton = 2131886909;
    
    public static int Widget_AppCompat_Light_ActionButton_CloseMode = 2131886910;
    
    public static int Widget_AppCompat_Light_ActionButton_Overflow = 2131886911;
    
    public static int Widget_AppCompat_Light_ActionMode_Inverse = 2131886912;
    
    public static int Widget_AppCompat_Light_ActivityChooserView = 2131886913;
    
    public static int Widget_AppCompat_Light_AutoCompleteTextView = 2131886914;
    
    public static int Widget_AppCompat_Light_DropDownItem_Spinner = 2131886915;
    
    public static int Widget_AppCompat_Light_ListPopupWindow = 2131886916;
    
    public static int Widget_AppCompat_Light_ListView_DropDown = 2131886917;
    
    public static int Widget_AppCompat_Light_PopupMenu = 2131886918;
    
    public static int Widget_AppCompat_Light_PopupMenu_Overflow = 2131886919;
    
    public static int Widget_AppCompat_Light_SearchView = 2131886920;
    
    public static int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 2131886921;
    
    public static int Widget_AppCompat_ListMenuView = 2131886922;
    
    public static int Widget_AppCompat_ListPopupWindow = 2131886923;
    
    public static int Widget_AppCompat_ListView = 2131886924;
    
    public static int Widget_AppCompat_ListView_DropDown = 2131886925;
    
    public static int Widget_AppCompat_ListView_Menu = 2131886926;
    
    public static int Widget_AppCompat_PopupMenu = 2131886927;
    
    public static int Widget_AppCompat_PopupMenu_Overflow = 2131886928;
    
    public static int Widget_AppCompat_PopupWindow = 2131886929;
    
    public static int Widget_AppCompat_ProgressBar = 2131886930;
    
    public static int Widget_AppCompat_ProgressBar_Horizontal = 2131886931;
    
    public static int Widget_AppCompat_RatingBar = 2131886932;
    
    public static int Widget_AppCompat_RatingBar_Indicator = 2131886933;
    
    public static int Widget_AppCompat_RatingBar_Small = 2131886934;
    
    public static int Widget_AppCompat_SearchView = 2131886935;
    
    public static int Widget_AppCompat_SearchView_ActionBar = 2131886936;
    
    public static int Widget_AppCompat_SeekBar = 2131886937;
    
    public static int Widget_AppCompat_SeekBar_Discrete = 2131886938;
    
    public static int Widget_AppCompat_Spinner = 2131886939;
    
    public static int Widget_AppCompat_Spinner_DropDown = 2131886940;
    
    public static int Widget_AppCompat_Spinner_DropDown_ActionBar = 2131886941;
    
    public static int Widget_AppCompat_Spinner_Underlined = 2131886942;
    
    public static int Widget_AppCompat_TextView = 2131886943;
    
    public static int Widget_AppCompat_TextView_SpinnerItem = 2131886944;
    
    public static int Widget_AppCompat_Toolbar = 2131886945;
    
    public static int Widget_AppCompat_Toolbar_Button_Navigation = 2131886946;
  }
  
  public static final class styleable {
    public static int[] ActionBar = new int[] { 
        2130968656, 2130968663, 2130968664, 2130968872, 2130968873, 2130968874, 2130968875, 2130968876, 2130968877, 2130968957, 
        2130968990, 2130968992, 2130969032, 2130969176, 2130969183, 2130969189, 2130969190, 2130969194, 2130969213, 2130969238, 
        2130969371, 2130969547, 2130969603, 2130969622, 2130969623, 2130969767, 2130969771, 2130969914, 2130969928 };
    
    public static int[] ActionBarLayout = new int[] { 16842931 };
    
    public static int ActionBarLayout_android_layout_gravity = 0;
    
    public static int ActionBar_background = 0;
    
    public static int ActionBar_backgroundSplit = 1;
    
    public static int ActionBar_backgroundStacked = 2;
    
    public static int ActionBar_contentInsetEnd = 3;
    
    public static int ActionBar_contentInsetEndWithActions = 4;
    
    public static int ActionBar_contentInsetLeft = 5;
    
    public static int ActionBar_contentInsetRight = 6;
    
    public static int ActionBar_contentInsetStart = 7;
    
    public static int ActionBar_contentInsetStartWithNavigation = 8;
    
    public static int ActionBar_customNavigationLayout = 9;
    
    public static int ActionBar_displayOptions = 10;
    
    public static int ActionBar_divider = 11;
    
    public static int ActionBar_elevation = 12;
    
    public static int ActionBar_height = 13;
    
    public static int ActionBar_hideOnContentScroll = 14;
    
    public static int ActionBar_homeAsUpIndicator = 15;
    
    public static int ActionBar_homeLayout = 16;
    
    public static int ActionBar_icon = 17;
    
    public static int ActionBar_indeterminateProgressStyle = 18;
    
    public static int ActionBar_itemPadding = 19;
    
    public static int ActionBar_logo = 20;
    
    public static int ActionBar_navigationMode = 21;
    
    public static int ActionBar_popupTheme = 22;
    
    public static int ActionBar_progressBarPadding = 23;
    
    public static int ActionBar_progressBarStyle = 24;
    
    public static int ActionBar_subtitle = 25;
    
    public static int ActionBar_subtitleTextStyle = 26;
    
    public static int ActionBar_title = 27;
    
    public static int ActionBar_titleTextStyle = 28;
    
    public static int[] ActionMenuItemView = new int[] { 16843071 };
    
    public static int ActionMenuItemView_android_minWidth = 0;
    
    public static int[] ActionMenuView = new int[0];
    
    public static int[] ActionMode = new int[] { 2130968656, 2130968663, 2130968808, 2130969176, 2130969771, 2130969928 };
    
    public static int ActionMode_background = 0;
    
    public static int ActionMode_backgroundSplit = 1;
    
    public static int ActionMode_closeItemLayout = 2;
    
    public static int ActionMode_height = 3;
    
    public static int ActionMode_subtitleTextStyle = 4;
    
    public static int ActionMode_titleTextStyle = 5;
    
    public static int[] ActivityChooserView = new int[] { 2130969060, 2130969219 };
    
    public static int ActivityChooserView_expandActivityOverflowButtonDrawable = 0;
    
    public static int ActivityChooserView_initialActivityCount = 1;
    
    public static int[] AlertDialog = new int[] { 16842994, 2130968720, 2130968723, 2130969360, 2130969361, 2130969540, 2130969692, 2130969698 };
    
    public static int AlertDialog_android_layout = 0;
    
    public static int AlertDialog_buttonIconDimen = 1;
    
    public static int AlertDialog_buttonPanelSideLayout = 2;
    
    public static int AlertDialog_listItemLayout = 3;
    
    public static int AlertDialog_listLayout = 4;
    
    public static int AlertDialog_multiChoiceItemLayout = 5;
    
    public static int AlertDialog_showTitle = 6;
    
    public static int AlertDialog_singleChoiceItemLayout = 7;
    
    public static int[] AppCompatEmojiHelper = new int[0];
    
    public static int[] AppCompatImageView = new int[] { 16843033, 2130969724, 2130969912, 2130969913 };
    
    public static int AppCompatImageView_android_src = 0;
    
    public static int AppCompatImageView_srcCompat = 1;
    
    public static int AppCompatImageView_tint = 2;
    
    public static int AppCompatImageView_tintMode = 3;
    
    public static int[] AppCompatSeekBar = new int[] { 16843074, 2130969908, 2130969909, 2130969910 };
    
    public static int AppCompatSeekBar_android_thumb = 0;
    
    public static int AppCompatSeekBar_tickMark = 1;
    
    public static int AppCompatSeekBar_tickMarkTint = 2;
    
    public static int AppCompatSeekBar_tickMarkTintMode = 3;
    
    public static int[] AppCompatTextHelper = new int[] { 16842804, 16843117, 16843118, 16843119, 16843120, 16843666, 16843667 };
    
    public static int AppCompatTextHelper_android_drawableBottom = 2;
    
    public static int AppCompatTextHelper_android_drawableEnd = 6;
    
    public static int AppCompatTextHelper_android_drawableLeft = 3;
    
    public static int AppCompatTextHelper_android_drawableRight = 4;
    
    public static int AppCompatTextHelper_android_drawableStart = 5;
    
    public static int AppCompatTextHelper_android_drawableTop = 1;
    
    public static int AppCompatTextHelper_android_textAppearance = 0;
    
    public static int[] AppCompatTextView = new int[] { 
        16842804, 2130968650, 2130968651, 2130968652, 2130968653, 2130968654, 2130969004, 2130969005, 2130969006, 2130969007, 
        2130969009, 2130969010, 2130969011, 2130969012, 2130969036, 2130969105, 2130969148, 2130969157, 2130969273, 2130969353, 
        2130969824, 2130969881 };
    
    public static int AppCompatTextView_android_textAppearance = 0;
    
    public static int AppCompatTextView_autoSizeMaxTextSize = 1;
    
    public static int AppCompatTextView_autoSizeMinTextSize = 2;
    
    public static int AppCompatTextView_autoSizePresetSizes = 3;
    
    public static int AppCompatTextView_autoSizeStepGranularity = 4;
    
    public static int AppCompatTextView_autoSizeTextType = 5;
    
    public static int AppCompatTextView_drawableBottomCompat = 6;
    
    public static int AppCompatTextView_drawableEndCompat = 7;
    
    public static int AppCompatTextView_drawableLeftCompat = 8;
    
    public static int AppCompatTextView_drawableRightCompat = 9;
    
    public static int AppCompatTextView_drawableStartCompat = 10;
    
    public static int AppCompatTextView_drawableTint = 11;
    
    public static int AppCompatTextView_drawableTintMode = 12;
    
    public static int AppCompatTextView_drawableTopCompat = 13;
    
    public static int AppCompatTextView_emojiCompatEnabled = 14;
    
    public static int AppCompatTextView_firstBaselineToTopHeight = 15;
    
    public static int AppCompatTextView_fontFamily = 16;
    
    public static int AppCompatTextView_fontVariationSettings = 17;
    
    public static int AppCompatTextView_lastBaselineToBottomHeight = 18;
    
    public static int AppCompatTextView_lineHeight = 19;
    
    public static int AppCompatTextView_textAllCaps = 20;
    
    public static int AppCompatTextView_textLocale = 21;
    
    public static int[] AppCompatTheme = new int[] { 
        16842839, 16842926, 2130968579, 2130968580, 2130968582, 2130968583, 2130968584, 2130968585, 2130968586, 2130968587, 
        2130968588, 2130968590, 2130968591, 2130968592, 2130968593, 2130968595, 2130968596, 2130968597, 2130968598, 2130968599, 
        2130968600, 2130968601, 2130968602, 2130968603, 2130968604, 2130968605, 2130968606, 2130968607, 2130968608, 2130968609, 
        2130968610, 2130968611, 2130968612, 2130968613, 2130968618, 2130968624, 2130968625, 2130968626, 2130968627, 2130968649, 
        2130968692, 2130968711, 2130968712, 2130968713, 2130968714, 2130968715, 2130968726, 2130968727, 2130968755, 2130968766, 
        2130968822, 2130968823, 2130968824, 2130968826, 2130968827, 2130968828, 2130968829, 2130968847, 2130968849, 2130968859, 
        2130968887, 2130968977, 2130968983, 2130968986, 2130968994, 2130968999, 2130969016, 2130969017, 2130969026, 2130969028, 
        2130969031, 2130969189, 2130969207, 2130969356, 2130969357, 2130969358, 2130969359, 2130969362, 2130969363, 2130969364, 
        2130969365, 2130969366, 2130969367, 2130969368, 2130969369, 2130969370, 2130969577, 2130969578, 2130969579, 2130969602, 
        2130969604, 2130969630, 2130969632, 2130969633, 2130969634, 2130969658, 2130969663, 2130969665, 2130969666, 2130969712, 
        2130969713, 2130969787, 2130969847, 2130969849, 2130969850, 2130969851, 2130969853, 2130969854, 2130969855, 2130969856, 
        2130969868, 2130969869, 2130969934, 2130969935, 2130969937, 2130969938, 2130969977, 2130969993, 2130969994, 2130969995, 
        2130969996, 2130969997, 2130969998, 2130969999, 2130970000, 2130970001, 2130970002 };
    
    public static int AppCompatTheme_actionBarDivider = 2;
    
    public static int AppCompatTheme_actionBarItemBackground = 3;
    
    public static int AppCompatTheme_actionBarPopupTheme = 4;
    
    public static int AppCompatTheme_actionBarSize = 5;
    
    public static int AppCompatTheme_actionBarSplitStyle = 6;
    
    public static int AppCompatTheme_actionBarStyle = 7;
    
    public static int AppCompatTheme_actionBarTabBarStyle = 8;
    
    public static int AppCompatTheme_actionBarTabStyle = 9;
    
    public static int AppCompatTheme_actionBarTabTextStyle = 10;
    
    public static int AppCompatTheme_actionBarTheme = 11;
    
    public static int AppCompatTheme_actionBarWidgetTheme = 12;
    
    public static int AppCompatTheme_actionButtonStyle = 13;
    
    public static int AppCompatTheme_actionDropDownStyle = 14;
    
    public static int AppCompatTheme_actionMenuTextAppearance = 15;
    
    public static int AppCompatTheme_actionMenuTextColor = 16;
    
    public static int AppCompatTheme_actionModeBackground = 17;
    
    public static int AppCompatTheme_actionModeCloseButtonStyle = 18;
    
    public static int AppCompatTheme_actionModeCloseContentDescription = 19;
    
    public static int AppCompatTheme_actionModeCloseDrawable = 20;
    
    public static int AppCompatTheme_actionModeCopyDrawable = 21;
    
    public static int AppCompatTheme_actionModeCutDrawable = 22;
    
    public static int AppCompatTheme_actionModeFindDrawable = 23;
    
    public static int AppCompatTheme_actionModePasteDrawable = 24;
    
    public static int AppCompatTheme_actionModePopupWindowStyle = 25;
    
    public static int AppCompatTheme_actionModeSelectAllDrawable = 26;
    
    public static int AppCompatTheme_actionModeShareDrawable = 27;
    
    public static int AppCompatTheme_actionModeSplitBackground = 28;
    
    public static int AppCompatTheme_actionModeStyle = 29;
    
    public static int AppCompatTheme_actionModeTheme = 30;
    
    public static int AppCompatTheme_actionModeWebSearchDrawable = 31;
    
    public static int AppCompatTheme_actionOverflowButtonStyle = 32;
    
    public static int AppCompatTheme_actionOverflowMenuStyle = 33;
    
    public static int AppCompatTheme_activityChooserViewStyle = 34;
    
    public static int AppCompatTheme_alertDialogButtonGroupStyle = 35;
    
    public static int AppCompatTheme_alertDialogCenterButtons = 36;
    
    public static int AppCompatTheme_alertDialogStyle = 37;
    
    public static int AppCompatTheme_alertDialogTheme = 38;
    
    public static int AppCompatTheme_android_windowAnimationStyle = 1;
    
    public static int AppCompatTheme_android_windowIsFloating = 0;
    
    public static int AppCompatTheme_autoCompleteTextViewStyle = 39;
    
    public static int AppCompatTheme_borderlessButtonStyle = 40;
    
    public static int AppCompatTheme_buttonBarButtonStyle = 41;
    
    public static int AppCompatTheme_buttonBarNegativeButtonStyle = 42;
    
    public static int AppCompatTheme_buttonBarNeutralButtonStyle = 43;
    
    public static int AppCompatTheme_buttonBarPositiveButtonStyle = 44;
    
    public static int AppCompatTheme_buttonBarStyle = 45;
    
    public static int AppCompatTheme_buttonStyle = 46;
    
    public static int AppCompatTheme_buttonStyleSmall = 47;
    
    public static int AppCompatTheme_checkboxStyle = 48;
    
    public static int AppCompatTheme_checkedTextViewStyle = 49;
    
    public static int AppCompatTheme_colorAccent = 50;
    
    public static int AppCompatTheme_colorBackgroundFloating = 51;
    
    public static int AppCompatTheme_colorButtonNormal = 52;
    
    public static int AppCompatTheme_colorControlActivated = 53;
    
    public static int AppCompatTheme_colorControlHighlight = 54;
    
    public static int AppCompatTheme_colorControlNormal = 55;
    
    public static int AppCompatTheme_colorError = 56;
    
    public static int AppCompatTheme_colorPrimary = 57;
    
    public static int AppCompatTheme_colorPrimaryDark = 58;
    
    public static int AppCompatTheme_colorSwitchThumbNormal = 59;
    
    public static int AppCompatTheme_controlBackground = 60;
    
    public static int AppCompatTheme_dialogCornerRadius = 61;
    
    public static int AppCompatTheme_dialogPreferredPadding = 62;
    
    public static int AppCompatTheme_dialogTheme = 63;
    
    public static int AppCompatTheme_dividerHorizontal = 64;
    
    public static int AppCompatTheme_dividerVertical = 65;
    
    public static int AppCompatTheme_dropDownListViewStyle = 66;
    
    public static int AppCompatTheme_dropdownListPreferredItemHeight = 67;
    
    public static int AppCompatTheme_editTextBackground = 68;
    
    public static int AppCompatTheme_editTextColor = 69;
    
    public static int AppCompatTheme_editTextStyle = 70;
    
    public static int AppCompatTheme_homeAsUpIndicator = 71;
    
    public static int AppCompatTheme_imageButtonStyle = 72;
    
    public static int AppCompatTheme_listChoiceBackgroundIndicator = 73;
    
    public static int AppCompatTheme_listChoiceIndicatorMultipleAnimated = 74;
    
    public static int AppCompatTheme_listChoiceIndicatorSingleAnimated = 75;
    
    public static int AppCompatTheme_listDividerAlertDialog = 76;
    
    public static int AppCompatTheme_listMenuViewStyle = 77;
    
    public static int AppCompatTheme_listPopupWindowStyle = 78;
    
    public static int AppCompatTheme_listPreferredItemHeight = 79;
    
    public static int AppCompatTheme_listPreferredItemHeightLarge = 80;
    
    public static int AppCompatTheme_listPreferredItemHeightSmall = 81;
    
    public static int AppCompatTheme_listPreferredItemPaddingEnd = 82;
    
    public static int AppCompatTheme_listPreferredItemPaddingLeft = 83;
    
    public static int AppCompatTheme_listPreferredItemPaddingRight = 84;
    
    public static int AppCompatTheme_listPreferredItemPaddingStart = 85;
    
    public static int AppCompatTheme_panelBackground = 86;
    
    public static int AppCompatTheme_panelMenuListTheme = 87;
    
    public static int AppCompatTheme_panelMenuListWidth = 88;
    
    public static int AppCompatTheme_popupMenuStyle = 89;
    
    public static int AppCompatTheme_popupWindowStyle = 90;
    
    public static int AppCompatTheme_radioButtonStyle = 91;
    
    public static int AppCompatTheme_ratingBarStyle = 92;
    
    public static int AppCompatTheme_ratingBarStyleIndicator = 93;
    
    public static int AppCompatTheme_ratingBarStyleSmall = 94;
    
    public static int AppCompatTheme_searchViewStyle = 95;
    
    public static int AppCompatTheme_seekBarStyle = 96;
    
    public static int AppCompatTheme_selectableItemBackground = 97;
    
    public static int AppCompatTheme_selectableItemBackgroundBorderless = 98;
    
    public static int AppCompatTheme_spinnerDropDownItemStyle = 99;
    
    public static int AppCompatTheme_spinnerStyle = 100;
    
    public static int AppCompatTheme_switchStyle = 101;
    
    public static int AppCompatTheme_textAppearanceLargePopupMenu = 102;
    
    public static int AppCompatTheme_textAppearanceListItem = 103;
    
    public static int AppCompatTheme_textAppearanceListItemSecondary = 104;
    
    public static int AppCompatTheme_textAppearanceListItemSmall = 105;
    
    public static int AppCompatTheme_textAppearancePopupMenuHeader = 106;
    
    public static int AppCompatTheme_textAppearanceSearchResultSubtitle = 107;
    
    public static int AppCompatTheme_textAppearanceSearchResultTitle = 108;
    
    public static int AppCompatTheme_textAppearanceSmallPopupMenu = 109;
    
    public static int AppCompatTheme_textColorAlertDialogListItem = 110;
    
    public static int AppCompatTheme_textColorSearchUrl = 111;
    
    public static int AppCompatTheme_toolbarNavigationButtonStyle = 112;
    
    public static int AppCompatTheme_toolbarStyle = 113;
    
    public static int AppCompatTheme_tooltipForegroundColor = 114;
    
    public static int AppCompatTheme_tooltipFrameBackground = 115;
    
    public static int AppCompatTheme_viewInflaterClass = 116;
    
    public static int AppCompatTheme_windowActionBar = 117;
    
    public static int AppCompatTheme_windowActionBarOverlay = 118;
    
    public static int AppCompatTheme_windowActionModeOverlay = 119;
    
    public static int AppCompatTheme_windowFixedHeightMajor = 120;
    
    public static int AppCompatTheme_windowFixedHeightMinor = 121;
    
    public static int AppCompatTheme_windowFixedWidthMajor = 122;
    
    public static int AppCompatTheme_windowFixedWidthMinor = 123;
    
    public static int AppCompatTheme_windowMinWidthMajor = 124;
    
    public static int AppCompatTheme_windowMinWidthMinor = 125;
    
    public static int AppCompatTheme_windowNoTitle = 126;
    
    public static int[] ButtonBarLayout = new int[] { 2130968632 };
    
    public static int ButtonBarLayout_allowStacking = 0;
    
    public static int[] CheckedTextView = new int[] { 16843016, 2130968752, 2130968753, 2130968754 };
    
    public static int CheckedTextView_android_checkMark = 0;
    
    public static int CheckedTextView_checkMarkCompat = 1;
    
    public static int CheckedTextView_checkMarkTint = 2;
    
    public static int CheckedTextView_checkMarkTintMode = 3;
    
    public static int[] CompoundButton = new int[] { 16843015, 2130968716, 2130968728, 2130968729 };
    
    public static int CompoundButton_android_button = 0;
    
    public static int CompoundButton_buttonCompat = 1;
    
    public static int CompoundButton_buttonTint = 2;
    
    public static int CompoundButton_buttonTintMode = 3;
    
    public static int[] DrawerArrowToggle = new int[] { 2130968644, 2130968645, 2130968673, 2130968821, 2130969008, 2130969163, 2130969711, 2130969893 };
    
    public static int DrawerArrowToggle_arrowHeadLength = 0;
    
    public static int DrawerArrowToggle_arrowShaftLength = 1;
    
    public static int DrawerArrowToggle_barLength = 2;
    
    public static int DrawerArrowToggle_color = 3;
    
    public static int DrawerArrowToggle_drawableSize = 4;
    
    public static int DrawerArrowToggle_gapBetweenBars = 5;
    
    public static int DrawerArrowToggle_spinBars = 6;
    
    public static int DrawerArrowToggle_thickness = 7;
    
    public static int[] LinearLayoutCompat = new int[] { 16842927, 16842948, 16843046, 16843047, 16843048, 2130968992, 2130968997, 2130969449, 2130969687 };
    
    public static int[] LinearLayoutCompat_Layout = new int[] { 16842931, 16842996, 16842997, 16843137 };
    
    public static int LinearLayoutCompat_Layout_android_layout_gravity = 0;
    
    public static int LinearLayoutCompat_Layout_android_layout_height = 2;
    
    public static int LinearLayoutCompat_Layout_android_layout_weight = 3;
    
    public static int LinearLayoutCompat_Layout_android_layout_width = 1;
    
    public static int LinearLayoutCompat_android_baselineAligned = 2;
    
    public static int LinearLayoutCompat_android_baselineAlignedChildIndex = 3;
    
    public static int LinearLayoutCompat_android_gravity = 0;
    
    public static int LinearLayoutCompat_android_orientation = 1;
    
    public static int LinearLayoutCompat_android_weightSum = 4;
    
    public static int LinearLayoutCompat_divider = 5;
    
    public static int LinearLayoutCompat_dividerPadding = 6;
    
    public static int LinearLayoutCompat_measureWithLargestChild = 7;
    
    public static int LinearLayoutCompat_showDividers = 8;
    
    public static int[] ListPopupWindow = new int[] { 16843436, 16843437 };
    
    public static int ListPopupWindow_android_dropDownHorizontalOffset = 0;
    
    public static int ListPopupWindow_android_dropDownVerticalOffset = 1;
    
    public static int[] MenuGroup = new int[] { 16842766, 16842960, 16843156, 16843230, 16843231, 16843232 };
    
    public static int MenuGroup_android_checkableBehavior = 5;
    
    public static int MenuGroup_android_enabled = 0;
    
    public static int MenuGroup_android_id = 1;
    
    public static int MenuGroup_android_menuCategory = 3;
    
    public static int MenuGroup_android_orderInCategory = 4;
    
    public static int MenuGroup_android_visible = 2;
    
    public static int[] MenuItem = new int[] { 
        16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 
        16843236, 16843237, 16843375, 2130968594, 2130968614, 2130968616, 2130968634, 2130968871, 2130969202, 2130969203, 
        2130969556, 2130969685, 2130969940 };
    
    public static int MenuItem_actionLayout = 13;
    
    public static int MenuItem_actionProviderClass = 14;
    
    public static int MenuItem_actionViewClass = 15;
    
    public static int MenuItem_alphabeticModifiers = 16;
    
    public static int MenuItem_android_alphabeticShortcut = 9;
    
    public static int MenuItem_android_checkable = 11;
    
    public static int MenuItem_android_checked = 3;
    
    public static int MenuItem_android_enabled = 1;
    
    public static int MenuItem_android_icon = 0;
    
    public static int MenuItem_android_id = 2;
    
    public static int MenuItem_android_menuCategory = 5;
    
    public static int MenuItem_android_numericShortcut = 10;
    
    public static int MenuItem_android_onClick = 12;
    
    public static int MenuItem_android_orderInCategory = 6;
    
    public static int MenuItem_android_title = 7;
    
    public static int MenuItem_android_titleCondensed = 8;
    
    public static int MenuItem_android_visible = 4;
    
    public static int MenuItem_contentDescription = 17;
    
    public static int MenuItem_iconTint = 18;
    
    public static int MenuItem_iconTintMode = 19;
    
    public static int MenuItem_numericModifiers = 20;
    
    public static int MenuItem_showAsAction = 21;
    
    public static int MenuItem_tooltipText = 22;
    
    public static int[] MenuView = new int[] { 16842926, 16843052, 16843053, 16843054, 16843055, 16843056, 16843057, 2130969619, 2130969758 };
    
    public static int MenuView_android_headerBackground = 4;
    
    public static int MenuView_android_horizontalDivider = 2;
    
    public static int MenuView_android_itemBackground = 5;
    
    public static int MenuView_android_itemIconDisabledAlpha = 6;
    
    public static int MenuView_android_itemTextAppearance = 1;
    
    public static int MenuView_android_verticalDivider = 3;
    
    public static int MenuView_android_windowAnimationStyle = 0;
    
    public static int MenuView_preserveIconSpacing = 7;
    
    public static int MenuView_subMenuArrow = 8;
    
    public static int[] PopupWindow = new int[] { 16843126, 16843465, 2130969567 };
    
    public static int[] PopupWindowBackgroundState = new int[] { 2130969732 };
    
    public static int PopupWindowBackgroundState_state_above_anchor = 0;
    
    public static int PopupWindow_android_popupAnimationStyle = 1;
    
    public static int PopupWindow_android_popupBackground = 0;
    
    public static int PopupWindow_overlapAnchor = 2;
    
    public static int[] RecycleListView = new int[] { 2130969569, 2130969575 };
    
    public static int RecycleListView_paddingBottomNoButtons = 0;
    
    public static int RecycleListView_paddingTopNoTitle = 1;
    
    public static int[] SearchView = new int[] { 
        16842970, 16843039, 16843296, 16843364, 2130968801, 2130968862, 2130968970, 2130969165, 2130969204, 2130969275, 
        2130969627, 2130969628, 2130969656, 2130969657, 2130969763, 2130969775, 2130969983 };
    
    public static int SearchView_android_focusable = 0;
    
    public static int SearchView_android_imeOptions = 3;
    
    public static int SearchView_android_inputType = 2;
    
    public static int SearchView_android_maxWidth = 1;
    
    public static int SearchView_closeIcon = 4;
    
    public static int SearchView_commitIcon = 5;
    
    public static int SearchView_defaultQueryHint = 6;
    
    public static int SearchView_goIcon = 7;
    
    public static int SearchView_iconifiedByDefault = 8;
    
    public static int SearchView_layout = 9;
    
    public static int SearchView_queryBackground = 10;
    
    public static int SearchView_queryHint = 11;
    
    public static int SearchView_searchHintIcon = 12;
    
    public static int SearchView_searchIcon = 13;
    
    public static int SearchView_submitBackground = 14;
    
    public static int SearchView_suggestionRowLayout = 15;
    
    public static int SearchView_voiceIcon = 16;
    
    public static int[] Spinner = new int[] { 16842930, 16843126, 16843131, 16843362, 2130969603 };
    
    public static int Spinner_android_dropDownWidth = 3;
    
    public static int Spinner_android_entries = 0;
    
    public static int Spinner_android_popupBackground = 1;
    
    public static int Spinner_android_prompt = 2;
    
    public static int Spinner_popupTheme = 4;
    
    public static int[] SwitchCompat = new int[] { 
        16843044, 16843045, 16843074, 2130969691, 2130969718, 2130969783, 2130969784, 2130969788, 2130969902, 2130969903, 
        2130969904, 2130969946, 2130969956, 2130969957 };
    
    public static int SwitchCompat_android_textOff = 1;
    
    public static int SwitchCompat_android_textOn = 0;
    
    public static int SwitchCompat_android_thumb = 2;
    
    public static int SwitchCompat_showText = 3;
    
    public static int SwitchCompat_splitTrack = 4;
    
    public static int SwitchCompat_switchMinWidth = 5;
    
    public static int SwitchCompat_switchPadding = 6;
    
    public static int SwitchCompat_switchTextAppearance = 7;
    
    public static int SwitchCompat_thumbTextPadding = 8;
    
    public static int SwitchCompat_thumbTint = 9;
    
    public static int SwitchCompat_thumbTintMode = 10;
    
    public static int SwitchCompat_track = 11;
    
    public static int SwitchCompat_trackTint = 12;
    
    public static int SwitchCompat_trackTintMode = 13;
    
    public static int[] TextAppearance = new int[] { 
        16842901, 16842902, 16842903, 16842904, 16842906, 16842907, 16843105, 16843106, 16843107, 16843108, 
        16843692, 16844165, 2130969148, 2130969157, 2130969824, 2130969881 };
    
    public static int TextAppearance_android_fontFamily = 10;
    
    public static int TextAppearance_android_shadowColor = 6;
    
    public static int TextAppearance_android_shadowDx = 7;
    
    public static int TextAppearance_android_shadowDy = 8;
    
    public static int TextAppearance_android_shadowRadius = 9;
    
    public static int TextAppearance_android_textColor = 3;
    
    public static int TextAppearance_android_textColorHint = 4;
    
    public static int TextAppearance_android_textColorLink = 5;
    
    public static int TextAppearance_android_textFontWeight = 11;
    
    public static int TextAppearance_android_textSize = 0;
    
    public static int TextAppearance_android_textStyle = 2;
    
    public static int TextAppearance_android_typeface = 1;
    
    public static int TextAppearance_fontFamily = 12;
    
    public static int TextAppearance_fontVariationSettings = 13;
    
    public static int TextAppearance_textAllCaps = 14;
    
    public static int TextAppearance_textLocale = 15;
    
    public static int[] Toolbar = new int[] { 
        16842927, 16843072, 2130968718, 2130968809, 2130968810, 2130968872, 2130968873, 2130968874, 2130968875, 2130968876, 
        2130968877, 2130969371, 2130969373, 2130969424, 2130969450, 2130969544, 2130969545, 2130969603, 2130969767, 2130969769, 
        2130969770, 2130969914, 2130969918, 2130969919, 2130969920, 2130969921, 2130969922, 2130969923, 2130969925, 2130969926 };
    
    public static int Toolbar_android_gravity = 0;
    
    public static int Toolbar_android_minHeight = 1;
    
    public static int Toolbar_buttonGravity = 2;
    
    public static int Toolbar_collapseContentDescription = 3;
    
    public static int Toolbar_collapseIcon = 4;
    
    public static int Toolbar_contentInsetEnd = 5;
    
    public static int Toolbar_contentInsetEndWithActions = 6;
    
    public static int Toolbar_contentInsetLeft = 7;
    
    public static int Toolbar_contentInsetRight = 8;
    
    public static int Toolbar_contentInsetStart = 9;
    
    public static int Toolbar_contentInsetStartWithNavigation = 10;
    
    public static int Toolbar_logo = 11;
    
    public static int Toolbar_logoDescription = 12;
    
    public static int Toolbar_maxButtonHeight = 13;
    
    public static int Toolbar_menu = 14;
    
    public static int Toolbar_navigationContentDescription = 15;
    
    public static int Toolbar_navigationIcon = 16;
    
    public static int Toolbar_popupTheme = 17;
    
    public static int Toolbar_subtitle = 18;
    
    public static int Toolbar_subtitleTextAppearance = 19;
    
    public static int Toolbar_subtitleTextColor = 20;
    
    public static int Toolbar_title = 21;
    
    public static int Toolbar_titleMargin = 22;
    
    public static int Toolbar_titleMarginBottom = 23;
    
    public static int Toolbar_titleMarginEnd = 24;
    
    public static int Toolbar_titleMarginStart = 25;
    
    public static int Toolbar_titleMarginTop = 26;
    
    public static int Toolbar_titleMargins = 27;
    
    public static int Toolbar_titleTextAppearance = 28;
    
    public static int Toolbar_titleTextColor = 29;
    
    public static int[] View = new int[] { 16842752, 16842970, 2130969571, 2130969574, 2130969892 };
    
    public static int[] ViewBackgroundHelper = new int[] { 16842964, 2130968665, 2130968666 };
    
    public static int ViewBackgroundHelper_android_background = 0;
    
    public static int ViewBackgroundHelper_backgroundTint = 1;
    
    public static int ViewBackgroundHelper_backgroundTintMode = 2;
    
    public static int[] ViewStubCompat = new int[] { 16842960, 16842994, 16842995 };
    
    public static int ViewStubCompat_android_id = 0;
    
    public static int ViewStubCompat_android_inflatedId = 2;
    
    public static int ViewStubCompat_android_layout = 1;
    
    public static int View_android_focusable = 1;
    
    public static int View_android_theme = 0;
    
    public static int View_paddingEnd = 2;
    
    public static int View_paddingStart = 3;
    
    public static int View_theme = 4;
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\appcompat\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */