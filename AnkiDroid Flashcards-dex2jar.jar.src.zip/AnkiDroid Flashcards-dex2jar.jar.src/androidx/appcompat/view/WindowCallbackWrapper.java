package androidx.appcompat.view;

import android.view.ActionMode;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SearchEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import androidx.annotation.DoNotInline;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import java.util.List;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
public class WindowCallbackWrapper implements Window.Callback {
  final Window.Callback mWrapped;
  
  public WindowCallbackWrapper(Window.Callback paramCallback) {
    if (paramCallback != null) {
      this.mWrapped = paramCallback;
      return;
    } 
    throw new IllegalArgumentException("Window callback may not be null");
  }
  
  public boolean dispatchGenericMotionEvent(MotionEvent paramMotionEvent) {
    return this.mWrapped.dispatchGenericMotionEvent(paramMotionEvent);
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    return this.mWrapped.dispatchKeyEvent(paramKeyEvent);
  }
  
  public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent) {
    return this.mWrapped.dispatchKeyShortcutEvent(paramKeyEvent);
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    return this.mWrapped.dispatchPopulateAccessibilityEvent(paramAccessibilityEvent);
  }
  
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    return this.mWrapped.dispatchTouchEvent(paramMotionEvent);
  }
  
  public boolean dispatchTrackballEvent(MotionEvent paramMotionEvent) {
    return this.mWrapped.dispatchTrackballEvent(paramMotionEvent);
  }
  
  public final Window.Callback getWrapped() {
    return this.mWrapped;
  }
  
  public void onActionModeFinished(ActionMode paramActionMode) {
    this.mWrapped.onActionModeFinished(paramActionMode);
  }
  
  public void onActionModeStarted(ActionMode paramActionMode) {
    this.mWrapped.onActionModeStarted(paramActionMode);
  }
  
  public void onAttachedToWindow() {
    this.mWrapped.onAttachedToWindow();
  }
  
  public void onContentChanged() {
    this.mWrapped.onContentChanged();
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    return this.mWrapped.onCreatePanelMenu(paramInt, paramMenu);
  }
  
  public View onCreatePanelView(int paramInt) {
    return this.mWrapped.onCreatePanelView(paramInt);
  }
  
  public void onDetachedFromWindow() {
    this.mWrapped.onDetachedFromWindow();
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return this.mWrapped.onMenuItemSelected(paramInt, paramMenuItem);
  }
  
  public boolean onMenuOpened(int paramInt, Menu paramMenu) {
    return this.mWrapped.onMenuOpened(paramInt, paramMenu);
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    this.mWrapped.onPanelClosed(paramInt, paramMenu);
  }
  
  @RequiresApi(26)
  public void onPointerCaptureChanged(boolean paramBoolean) {
    Api26Impl.onPointerCaptureChanged(this.mWrapped, paramBoolean);
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    return this.mWrapped.onPreparePanel(paramInt, paramView, paramMenu);
  }
  
  @RequiresApi(24)
  public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> paramList, Menu paramMenu, int paramInt) {
    Api24Impl.onProvideKeyboardShortcuts(this.mWrapped, paramList, paramMenu, paramInt);
  }
  
  public boolean onSearchRequested() {
    return this.mWrapped.onSearchRequested();
  }
  
  @RequiresApi(23)
  public boolean onSearchRequested(SearchEvent paramSearchEvent) {
    return Api23Impl.onSearchRequested(this.mWrapped, paramSearchEvent);
  }
  
  public void onWindowAttributesChanged(WindowManager.LayoutParams paramLayoutParams) {
    this.mWrapped.onWindowAttributesChanged(paramLayoutParams);
  }
  
  public void onWindowFocusChanged(boolean paramBoolean) {
    this.mWrapped.onWindowFocusChanged(paramBoolean);
  }
  
  public ActionMode onWindowStartingActionMode(ActionMode.Callback paramCallback) {
    return this.mWrapped.onWindowStartingActionMode(paramCallback);
  }
  
  @RequiresApi(23)
  public ActionMode onWindowStartingActionMode(ActionMode.Callback paramCallback, int paramInt) {
    return Api23Impl.onWindowStartingActionMode(this.mWrapped, paramCallback, paramInt);
  }
  
  @RequiresApi(23)
  static class Api23Impl {
    @DoNotInline
    static boolean onSearchRequested(Window.Callback param1Callback, SearchEvent param1SearchEvent) {
      return a.a(param1Callback, param1SearchEvent);
    }
    
    @DoNotInline
    static ActionMode onWindowStartingActionMode(Window.Callback param1Callback, ActionMode.Callback param1Callback1, int param1Int) {
      return b.a(param1Callback, param1Callback1, param1Int);
    }
  }
  
  @RequiresApi(24)
  static class Api24Impl {
    @DoNotInline
    static void onProvideKeyboardShortcuts(Window.Callback param1Callback, List<KeyboardShortcutGroup> param1List, Menu param1Menu, int param1Int) {
      c.a(param1Callback, param1List, param1Menu, param1Int);
    }
  }
  
  @RequiresApi(26)
  static class Api26Impl {
    @DoNotInline
    static void onPointerCaptureChanged(Window.Callback param1Callback, boolean param1Boolean) {
      d.a(param1Callback, param1Boolean);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\appcompat\view\WindowCallbackWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */