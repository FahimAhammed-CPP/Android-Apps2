package androidx.appcompat.resources;

import android.animation.ObjectAnimator;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

@RestrictTo({RestrictTo.Scope.LIBRARY})
public final class Compatibility {
  @RequiresApi(15)
  public static class Api15Impl {
    @DoNotInline
    public static void getValueForDensity(@NonNull Resources param1Resources, int param1Int1, int param1Int2, @NonNull TypedValue param1TypedValue, boolean param1Boolean) {
      param1Resources.getValueForDensity(param1Int1, param1Int2, param1TypedValue, param1Boolean);
    }
  }
  
  @RequiresApi(18)
  public static class Api18Impl {
    @DoNotInline
    public static void setAutoCancel(@NonNull ObjectAnimator param1ObjectAnimator, boolean param1Boolean) {
      param1ObjectAnimator.setAutoCancel(param1Boolean);
    }
  }
  
  @RequiresApi(21)
  public static class Api21Impl {
    @DoNotInline
    @NonNull
    public static Drawable createFromXmlInner(@NonNull Resources param1Resources, @NonNull XmlPullParser param1XmlPullParser, @NonNull AttributeSet param1AttributeSet, @Nullable Resources.Theme param1Theme) throws IOException, XmlPullParserException {
      return Drawable.createFromXmlInner(param1Resources, param1XmlPullParser, param1AttributeSet, param1Theme);
    }
    
    @DoNotInline
    public static int getChangingConfigurations(@NonNull TypedArray param1TypedArray) {
      return param1TypedArray.getChangingConfigurations();
    }
    
    @DoNotInline
    public static void inflate(@NonNull Drawable param1Drawable, @NonNull Resources param1Resources, @NonNull XmlPullParser param1XmlPullParser, @NonNull AttributeSet param1AttributeSet, @Nullable Resources.Theme param1Theme) throws IOException, XmlPullParserException {
      param1Drawable.inflate(param1Resources, param1XmlPullParser, param1AttributeSet, param1Theme);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\appcompat\resources\Compatibility.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */