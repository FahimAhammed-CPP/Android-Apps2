package androidx.appcompat.app;

import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import androidx.annotation.NonNull;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.concurrent.Executor;

class AppLocalesStorageHelper {
  static final String APPLICATION_LOCALES_RECORD_FILE = "androidx.appcompat.app.AppCompatDelegate.application_locales_record_file";
  
  static final String APP_LOCALES_META_DATA_HOLDER_SERVICE_NAME = "androidx.appcompat.app.AppLocalesMetadataHolderService";
  
  static final boolean DEBUG = false;
  
  static final String LOCALE_RECORD_ATTRIBUTE_TAG = "application_locales";
  
  static final String LOCALE_RECORD_FILE_TAG = "locales";
  
  static final String TAG = "AppLocalesStorageHelper";
  
  static void persistLocales(@NonNull Context paramContext, @NonNull String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: ldc ''
    //   3: invokevirtual equals : (Ljava/lang/Object;)Z
    //   6: ifeq -> 17
    //   9: aload_0
    //   10: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   12: invokevirtual deleteFile : (Ljava/lang/String;)Z
    //   15: pop
    //   16: return
    //   17: aload_0
    //   18: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   20: iconst_0
    //   21: invokevirtual openFileOutput : (Ljava/lang/String;I)Ljava/io/FileOutputStream;
    //   24: astore_0
    //   25: invokestatic newSerializer : ()Lorg/xmlpull/v1/XmlSerializer;
    //   28: astore_2
    //   29: aload_2
    //   30: aload_0
    //   31: aconst_null
    //   32: invokeinterface setOutput : (Ljava/io/OutputStream;Ljava/lang/String;)V
    //   37: aload_2
    //   38: ldc 'UTF-8'
    //   40: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   43: invokeinterface startDocument : (Ljava/lang/String;Ljava/lang/Boolean;)V
    //   48: aload_2
    //   49: aconst_null
    //   50: ldc 'locales'
    //   52: invokeinterface startTag : (Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    //   57: pop
    //   58: aload_2
    //   59: aconst_null
    //   60: ldc 'application_locales'
    //   62: aload_1
    //   63: invokeinterface attribute : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    //   68: pop
    //   69: aload_2
    //   70: aconst_null
    //   71: ldc 'locales'
    //   73: invokeinterface endTag : (Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    //   78: pop
    //   79: aload_2
    //   80: invokeinterface endDocument : ()V
    //   85: aload_0
    //   86: ifnull -> 115
    //   89: aload_0
    //   90: invokevirtual close : ()V
    //   93: return
    //   94: astore_1
    //   95: goto -> 116
    //   98: astore_1
    //   99: ldc 'AppLocalesStorageHelper'
    //   101: ldc 'Storing App Locales : Failed to persist app-locales in storage '
    //   103: aload_1
    //   104: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   107: pop
    //   108: aload_0
    //   109: ifnull -> 115
    //   112: goto -> 89
    //   115: return
    //   116: aload_0
    //   117: ifnull -> 124
    //   120: aload_0
    //   121: invokevirtual close : ()V
    //   124: aload_1
    //   125: athrow
    //   126: ldc 'AppLocalesStorageHelper'
    //   128: ldc 'Storing App Locales : FileNotFoundException: Cannot open file %s for writing '
    //   130: iconst_1
    //   131: anewarray java/lang/Object
    //   134: dup
    //   135: iconst_0
    //   136: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   138: aastore
    //   139: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   142: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   145: pop
    //   146: return
    //   147: astore_0
    //   148: goto -> 126
    //   151: astore_0
    //   152: return
    //   153: astore_0
    //   154: goto -> 124
    // Exception table:
    //   from	to	target	type
    //   17	25	147	java/io/FileNotFoundException
    //   29	85	98	java/lang/Exception
    //   29	85	94	finally
    //   89	93	151	java/io/IOException
    //   99	108	94	finally
    //   120	124	153	java/io/IOException
  }
  
  @NonNull
  static String readLocales(@NonNull Context paramContext) {
    // Byte code:
    //   0: ldc ''
    //   2: astore #4
    //   4: aload_0
    //   5: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   7: invokevirtual openFileInput : (Ljava/lang/String;)Ljava/io/FileInputStream;
    //   10: astore #6
    //   12: invokestatic newPullParser : ()Lorg/xmlpull/v1/XmlPullParser;
    //   15: astore #5
    //   17: aload #5
    //   19: aload #6
    //   21: ldc 'UTF-8'
    //   23: invokeinterface setInput : (Ljava/io/InputStream;Ljava/lang/String;)V
    //   28: aload #5
    //   30: invokeinterface getDepth : ()I
    //   35: istore_1
    //   36: aload #5
    //   38: invokeinterface next : ()I
    //   43: istore_2
    //   44: aload #4
    //   46: astore_3
    //   47: iload_2
    //   48: iconst_1
    //   49: if_icmpeq -> 100
    //   52: iload_2
    //   53: iconst_3
    //   54: if_icmpne -> 202
    //   57: aload #4
    //   59: astore_3
    //   60: aload #5
    //   62: invokeinterface getDepth : ()I
    //   67: iload_1
    //   68: if_icmple -> 100
    //   71: goto -> 202
    //   74: aload #5
    //   76: invokeinterface getName : ()Ljava/lang/String;
    //   81: ldc 'locales'
    //   83: invokevirtual equals : (Ljava/lang/Object;)Z
    //   86: ifeq -> 36
    //   89: aload #5
    //   91: aconst_null
    //   92: ldc 'application_locales'
    //   94: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   99: astore_3
    //   100: aload_3
    //   101: astore #5
    //   103: aload #6
    //   105: ifnull -> 152
    //   108: aload #6
    //   110: invokevirtual close : ()V
    //   113: aload_3
    //   114: astore #5
    //   116: goto -> 152
    //   119: aload_3
    //   120: astore #5
    //   122: goto -> 152
    //   125: astore_0
    //   126: goto -> 173
    //   129: ldc 'AppLocalesStorageHelper'
    //   131: ldc 'Reading app Locales : Unable to parse through file :androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   133: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   136: pop
    //   137: aload #4
    //   139: astore #5
    //   141: aload #6
    //   143: ifnull -> 152
    //   146: aload #4
    //   148: astore_3
    //   149: goto -> 108
    //   152: aload #5
    //   154: invokevirtual isEmpty : ()Z
    //   157: ifne -> 163
    //   160: aload #5
    //   162: areturn
    //   163: aload_0
    //   164: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   166: invokevirtual deleteFile : (Ljava/lang/String;)Z
    //   169: pop
    //   170: aload #5
    //   172: areturn
    //   173: aload #6
    //   175: ifnull -> 183
    //   178: aload #6
    //   180: invokevirtual close : ()V
    //   183: aload_0
    //   184: athrow
    //   185: astore_0
    //   186: ldc ''
    //   188: areturn
    //   189: astore_3
    //   190: goto -> 129
    //   193: astore #4
    //   195: goto -> 119
    //   198: astore_3
    //   199: goto -> 183
    //   202: iload_2
    //   203: iconst_3
    //   204: if_icmpeq -> 36
    //   207: iload_2
    //   208: iconst_4
    //   209: if_icmpne -> 74
    //   212: goto -> 36
    // Exception table:
    //   from	to	target	type
    //   4	12	185	java/io/FileNotFoundException
    //   12	36	189	org/xmlpull/v1/XmlPullParserException
    //   12	36	189	java/io/IOException
    //   12	36	125	finally
    //   36	44	189	org/xmlpull/v1/XmlPullParserException
    //   36	44	189	java/io/IOException
    //   36	44	125	finally
    //   60	71	189	org/xmlpull/v1/XmlPullParserException
    //   60	71	189	java/io/IOException
    //   60	71	125	finally
    //   74	100	189	org/xmlpull/v1/XmlPullParserException
    //   74	100	189	java/io/IOException
    //   74	100	125	finally
    //   108	113	193	java/io/IOException
    //   129	137	125	finally
    //   178	183	198	java/io/IOException
  }
  
  static void syncLocalesToFramework(Context paramContext) {
    if (Build.VERSION.SDK_INT >= 33) {
      ComponentName componentName = new ComponentName(paramContext, "androidx.appcompat.app.AppLocalesMetadataHolderService");
      if (paramContext.getPackageManager().getComponentEnabledSetting(componentName) != 1) {
        if (AppCompatDelegate.getApplicationLocales().isEmpty()) {
          String str = readLocales(paramContext);
          Object object = paramContext.getSystemService("locale");
          if (object != null)
            AppCompatDelegate.Api33Impl.localeManagerSetApplicationLocales(object, AppCompatDelegate.Api24Impl.localeListForLanguageTags(str)); 
        } 
        paramContext.getPackageManager().setComponentEnabledSetting(componentName, 1, 1);
      } 
    } 
  }
  
  static class SerialExecutor implements Executor {
    Runnable mActive;
    
    final Executor mExecutor;
    
    private final Object mLock = new Object();
    
    final Queue<Runnable> mTasks = new ArrayDeque<Runnable>();
    
    SerialExecutor(Executor param1Executor) {
      this.mExecutor = param1Executor;
    }
    
    public void execute(Runnable param1Runnable) {
      synchronized (this.mLock) {
        this.mTasks.add(new p(this, param1Runnable));
        if (this.mActive == null)
          scheduleNext(); 
        return;
      } 
    }
    
    protected void scheduleNext() {
      synchronized (this.mLock) {
        Runnable runnable = this.mTasks.poll();
        this.mActive = runnable;
        if (runnable != null)
          this.mExecutor.execute(runnable); 
        return;
      } 
    }
  }
  
  static class ThreadPerTaskExecutor implements Executor {
    public void execute(Runnable param1Runnable) {
      (new Thread(param1Runnable)).start();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\appcompat\app\AppLocalesStorageHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */