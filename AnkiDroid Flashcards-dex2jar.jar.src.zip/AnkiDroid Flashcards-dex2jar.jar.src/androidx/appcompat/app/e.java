package androidx.appcompat.app;

import android.app.LocaleManager;
import android.os.LocaleList;



/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\appcompat\app\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */