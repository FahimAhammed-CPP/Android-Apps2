package androidx.appcompat.widget;

import android.view.inspector.InspectionCompanion;
import android.view.inspector.PropertyMapper;
import android.view.inspector.PropertyReader;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.appcompat.R;

@RequiresApi(29)
@RestrictTo({RestrictTo.Scope.LIBRARY})
public final class AppCompatEditText$InspectionCompanion implements InspectionCompanion<AppCompatEditText> {
  private int mBackgroundTintId;
  
  private int mBackgroundTintModeId;
  
  private int mDrawableTintId;
  
  private int mDrawableTintModeId;
  
  private boolean mPropertiesMapped = false;
  
  public void mapProperties(@NonNull PropertyMapper paramPropertyMapper) {
    this.mBackgroundTintId = b.a(paramPropertyMapper, "backgroundTint", R.attr.backgroundTint);
    this.mBackgroundTintModeId = b.a(paramPropertyMapper, "backgroundTintMode", R.attr.backgroundTintMode);
    this.mDrawableTintId = b.a(paramPropertyMapper, "drawableTint", R.attr.drawableTint);
    this.mDrawableTintModeId = b.a(paramPropertyMapper, "drawableTintMode", R.attr.drawableTintMode);
    this.mPropertiesMapped = true;
  }
  
  public void readProperties(@NonNull AppCompatEditText paramAppCompatEditText, @NonNull PropertyReader paramPropertyReader) {
    if (this.mPropertiesMapped) {
      a.a(paramPropertyReader, this.mBackgroundTintId, paramAppCompatEditText.getBackgroundTintList());
      a.a(paramPropertyReader, this.mBackgroundTintModeId, paramAppCompatEditText.getBackgroundTintMode());
      a.a(paramPropertyReader, this.mDrawableTintId, paramAppCompatEditText.getCompoundDrawableTintList());
      a.a(paramPropertyReader, this.mDrawableTintModeId, paramAppCompatEditText.getCompoundDrawableTintMode());
      return;
    } 
    d.a();
    throw c.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\appcompat\widget\AppCompatEditText$InspectionCompanion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */