package androidx.appcompat.widget;

import android.view.inspector.InspectionCompanion;
import android.view.inspector.PropertyMapper;
import android.view.inspector.PropertyReader;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.appcompat.R;

@RequiresApi(29)
@RestrictTo({RestrictTo.Scope.LIBRARY})
public final class AppCompatCheckBox$InspectionCompanion implements InspectionCompanion<AppCompatCheckBox> {
  private int mBackgroundTintId;
  
  private int mBackgroundTintModeId;
  
  private int mButtonTintId;
  
  private int mButtonTintModeId;
  
  private int mDrawableTintId;
  
  private int mDrawableTintModeId;
  
  private boolean mPropertiesMapped = false;
  
  public void mapProperties(@NonNull PropertyMapper paramPropertyMapper) {
    this.mBackgroundTintId = b.a(paramPropertyMapper, "backgroundTint", R.attr.backgroundTint);
    this.mBackgroundTintModeId = b.a(paramPropertyMapper, "backgroundTintMode", R.attr.backgroundTintMode);
    this.mButtonTintId = b.a(paramPropertyMapper, "buttonTint", R.attr.buttonTint);
    this.mButtonTintModeId = b.a(paramPropertyMapper, "buttonTintMode", R.attr.buttonTintMode);
    this.mDrawableTintId = b.a(paramPropertyMapper, "drawableTint", R.attr.drawableTint);
    this.mDrawableTintModeId = b.a(paramPropertyMapper, "drawableTintMode", R.attr.drawableTintMode);
    this.mPropertiesMapped = true;
  }
  
  public void readProperties(@NonNull AppCompatCheckBox paramAppCompatCheckBox, @NonNull PropertyReader paramPropertyReader) {
    if (this.mPropertiesMapped) {
      a.a(paramPropertyReader, this.mBackgroundTintId, paramAppCompatCheckBox.getBackgroundTintList());
      a.a(paramPropertyReader, this.mBackgroundTintModeId, paramAppCompatCheckBox.getBackgroundTintMode());
      a.a(paramPropertyReader, this.mButtonTintId, paramAppCompatCheckBox.getButtonTintList());
      a.a(paramPropertyReader, this.mButtonTintModeId, paramAppCompatCheckBox.getButtonTintMode());
      a.a(paramPropertyReader, this.mDrawableTintId, paramAppCompatCheckBox.getCompoundDrawableTintList());
      a.a(paramPropertyReader, this.mDrawableTintModeId, paramAppCompatCheckBox.getCompoundDrawableTintMode());
      return;
    } 
    d.a();
    throw c.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\appcompat\widget\AppCompatCheckBox$InspectionCompanion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */