package androidx.appcompat.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.appcompat.R;
import androidx.appcompat.view.menu.MenuPresenter;
import androidx.core.graphics.Insets;
import androidx.core.view.NestedScrollingParent;
import androidx.core.view.NestedScrollingParent2;
import androidx.core.view.NestedScrollingParent3;
import androidx.core.view.NestedScrollingParentHelper;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

@SuppressLint({"UnknownNullness"})
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
public class ActionBarOverlayLayout extends ViewGroup implements DecorContentParent, NestedScrollingParent, NestedScrollingParent2, NestedScrollingParent3 {
  private static final int ACTION_BAR_ANIMATE_DELAY = 600;
  
  static final int[] ATTRS = new int[] { R.attr.actionBarSize, 16842841 };
  
  private static final String TAG = "ActionBarOverlayLayout";
  
  private int mActionBarHeight;
  
  ActionBarContainer mActionBarTop;
  
  private ActionBarVisibilityCallback mActionBarVisibilityCallback;
  
  private final Runnable mAddActionBarHideOffset;
  
  boolean mAnimatingForFling;
  
  private final Rect mBaseContentInsets = new Rect();
  
  @NonNull
  private WindowInsetsCompat mBaseInnerInsets;
  
  private final Rect mBaseInnerInsetsRect = new Rect();
  
  private ContentFrameLayout mContent;
  
  private final Rect mContentInsets = new Rect();
  
  ViewPropertyAnimator mCurrentActionBarTopAnimator;
  
  private DecorToolbar mDecorToolbar;
  
  private OverScroller mFlingEstimator;
  
  private boolean mHasNonEmbeddedTabs;
  
  private boolean mHideOnContentScroll;
  
  private int mHideOnContentScrollReference;
  
  private boolean mIgnoreWindowContentOverlay;
  
  @NonNull
  private WindowInsetsCompat mInnerInsets;
  
  private final Rect mInnerInsetsRect = new Rect();
  
  private final Rect mLastBaseContentInsets = new Rect();
  
  @NonNull
  private WindowInsetsCompat mLastBaseInnerInsets;
  
  private final Rect mLastBaseInnerInsetsRect = new Rect();
  
  @NonNull
  private WindowInsetsCompat mLastInnerInsets;
  
  private final Rect mLastInnerInsetsRect = new Rect();
  
  private int mLastSystemUiVisibility;
  
  private boolean mOverlayMode;
  
  private final NestedScrollingParentHelper mParentHelper;
  
  private final Runnable mRemoveActionBarHideOffset;
  
  final AnimatorListenerAdapter mTopAnimatorListener;
  
  private Drawable mWindowContentOverlay;
  
  private int mWindowVisibility = 0;
  
  public ActionBarOverlayLayout(@NonNull Context paramContext) {
    this(paramContext, null);
  }
  
  public ActionBarOverlayLayout(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    WindowInsetsCompat windowInsetsCompat = WindowInsetsCompat.CONSUMED;
    this.mBaseInnerInsets = windowInsetsCompat;
    this.mLastBaseInnerInsets = windowInsetsCompat;
    this.mInnerInsets = windowInsetsCompat;
    this.mLastInnerInsets = windowInsetsCompat;
    this.mTopAnimatorListener = new AnimatorListenerAdapter() {
        public void onAnimationCancel(Animator param1Animator) {
          ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
          actionBarOverlayLayout.mCurrentActionBarTopAnimator = null;
          actionBarOverlayLayout.mAnimatingForFling = false;
        }
        
        public void onAnimationEnd(Animator param1Animator) {
          ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
          actionBarOverlayLayout.mCurrentActionBarTopAnimator = null;
          actionBarOverlayLayout.mAnimatingForFling = false;
        }
      };
    this.mRemoveActionBarHideOffset = new Runnable() {
        public void run() {
          ActionBarOverlayLayout.this.haltActionBarHideOffsetAnimations();
          ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
          actionBarOverlayLayout.mCurrentActionBarTopAnimator = actionBarOverlayLayout.mActionBarTop.animate().translationY(0.0F).setListener((Animator.AnimatorListener)ActionBarOverlayLayout.this.mTopAnimatorListener);
        }
      };
    this.mAddActionBarHideOffset = new Runnable() {
        public void run() {
          ActionBarOverlayLayout.this.haltActionBarHideOffsetAnimations();
          ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
          actionBarOverlayLayout.mCurrentActionBarTopAnimator = actionBarOverlayLayout.mActionBarTop.animate().translationY(-ActionBarOverlayLayout.this.mActionBarTop.getHeight()).setListener((Animator.AnimatorListener)ActionBarOverlayLayout.this.mTopAnimatorListener);
        }
      };
    init(paramContext);
    this.mParentHelper = new NestedScrollingParentHelper(this);
  }
  
  private void addActionBarHideOffset() {
    haltActionBarHideOffsetAnimations();
    this.mAddActionBarHideOffset.run();
  }
  
  private boolean applyInsets(@NonNull View paramView, @NonNull Rect paramRect, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   4: checkcast androidx/appcompat/widget/ActionBarOverlayLayout$LayoutParams
    //   7: astore_1
    //   8: iload_3
    //   9: ifeq -> 43
    //   12: aload_1
    //   13: getfield leftMargin : I
    //   16: istore #7
    //   18: aload_2
    //   19: getfield left : I
    //   22: istore #8
    //   24: iload #7
    //   26: iload #8
    //   28: if_icmpeq -> 43
    //   31: aload_1
    //   32: iload #8
    //   34: putfield leftMargin : I
    //   37: iconst_1
    //   38: istore #9
    //   40: goto -> 46
    //   43: iconst_0
    //   44: istore #9
    //   46: iload #9
    //   48: istore_3
    //   49: iload #4
    //   51: ifeq -> 84
    //   54: aload_1
    //   55: getfield topMargin : I
    //   58: istore #7
    //   60: aload_2
    //   61: getfield top : I
    //   64: istore #8
    //   66: iload #9
    //   68: istore_3
    //   69: iload #7
    //   71: iload #8
    //   73: if_icmpeq -> 84
    //   76: aload_1
    //   77: iload #8
    //   79: putfield topMargin : I
    //   82: iconst_1
    //   83: istore_3
    //   84: iload_3
    //   85: istore #4
    //   87: iload #6
    //   89: ifeq -> 123
    //   92: aload_1
    //   93: getfield rightMargin : I
    //   96: istore #7
    //   98: aload_2
    //   99: getfield right : I
    //   102: istore #8
    //   104: iload_3
    //   105: istore #4
    //   107: iload #7
    //   109: iload #8
    //   111: if_icmpeq -> 123
    //   114: aload_1
    //   115: iload #8
    //   117: putfield rightMargin : I
    //   120: iconst_1
    //   121: istore #4
    //   123: iload #5
    //   125: ifeq -> 155
    //   128: aload_1
    //   129: getfield bottomMargin : I
    //   132: istore #7
    //   134: aload_2
    //   135: getfield bottom : I
    //   138: istore #8
    //   140: iload #7
    //   142: iload #8
    //   144: if_icmpeq -> 155
    //   147: aload_1
    //   148: iload #8
    //   150: putfield bottomMargin : I
    //   153: iconst_1
    //   154: ireturn
    //   155: iload #4
    //   157: ireturn
  }
  
  private DecorToolbar getDecorToolbar(View paramView) {
    if (paramView instanceof DecorToolbar)
      return (DecorToolbar)paramView; 
    if (paramView instanceof Toolbar)
      return ((Toolbar)paramView).getWrapper(); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can't make a decor toolbar out of ");
    stringBuilder.append(paramView.getClass().getSimpleName());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void init(Context paramContext) {
    TypedArray typedArray = getContext().getTheme().obtainStyledAttributes(ATTRS);
    boolean bool2 = false;
    this.mActionBarHeight = typedArray.getDimensionPixelSize(0, 0);
    Drawable drawable = typedArray.getDrawable(1);
    this.mWindowContentOverlay = drawable;
    if (drawable == null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    setWillNotDraw(bool1);
    typedArray.recycle();
    boolean bool1 = bool2;
    if ((paramContext.getApplicationInfo()).targetSdkVersion < 19)
      bool1 = true; 
    this.mIgnoreWindowContentOverlay = bool1;
    this.mFlingEstimator = new OverScroller(paramContext);
  }
  
  private void postAddActionBarHideOffset() {
    haltActionBarHideOffsetAnimations();
    postDelayed(this.mAddActionBarHideOffset, 600L);
  }
  
  private void postRemoveActionBarHideOffset() {
    haltActionBarHideOffsetAnimations();
    postDelayed(this.mRemoveActionBarHideOffset, 600L);
  }
  
  private void removeActionBarHideOffset() {
    haltActionBarHideOffsetAnimations();
    this.mRemoveActionBarHideOffset.run();
  }
  
  private boolean shouldHideActionBarOnFling(float paramFloat) {
    this.mFlingEstimator.fling(0, 0, 0, (int)paramFloat, 0, 0, -2147483648, 2147483647);
    return (this.mFlingEstimator.getFinalY() > this.mActionBarTop.getHeight());
  }
  
  public boolean canShowOverflowMenu() {
    pullChildren();
    return this.mDecorToolbar.canShowOverflowMenu();
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  public void dismissPopups() {
    pullChildren();
    this.mDecorToolbar.dismissPopupMenus();
  }
  
  public void draw(@NonNull Canvas paramCanvas) {
    super.draw(paramCanvas);
    if (this.mWindowContentOverlay != null && !this.mIgnoreWindowContentOverlay) {
      byte b;
      if (this.mActionBarTop.getVisibility() == 0) {
        b = (int)(this.mActionBarTop.getBottom() + this.mActionBarTop.getTranslationY() + 0.5F);
      } else {
        b = 0;
      } 
      this.mWindowContentOverlay.setBounds(0, b, getWidth(), this.mWindowContentOverlay.getIntrinsicHeight() + b);
      this.mWindowContentOverlay.draw(paramCanvas);
    } 
  }
  
  protected boolean fitSystemWindows(Rect paramRect) {
    return super.fitSystemWindows(paramRect);
  }
  
  protected LayoutParams generateDefaultLayoutParams() {
    return new LayoutParams(-1, -1);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new LayoutParams(paramLayoutParams);
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  public int getActionBarHideOffset() {
    ActionBarContainer actionBarContainer = this.mActionBarTop;
    return (actionBarContainer != null) ? -((int)actionBarContainer.getTranslationY()) : 0;
  }
  
  public int getNestedScrollAxes() {
    return this.mParentHelper.getNestedScrollAxes();
  }
  
  public CharSequence getTitle() {
    pullChildren();
    return this.mDecorToolbar.getTitle();
  }
  
  void haltActionBarHideOffsetAnimations() {
    removeCallbacks(this.mRemoveActionBarHideOffset);
    removeCallbacks(this.mAddActionBarHideOffset);
    ViewPropertyAnimator viewPropertyAnimator = this.mCurrentActionBarTopAnimator;
    if (viewPropertyAnimator != null)
      viewPropertyAnimator.cancel(); 
  }
  
  public boolean hasIcon() {
    pullChildren();
    return this.mDecorToolbar.hasIcon();
  }
  
  public boolean hasLogo() {
    pullChildren();
    return this.mDecorToolbar.hasLogo();
  }
  
  public boolean hideOverflowMenu() {
    pullChildren();
    return this.mDecorToolbar.hideOverflowMenu();
  }
  
  public void initFeature(int paramInt) {
    pullChildren();
    if (paramInt != 2) {
      if (paramInt != 5) {
        if (paramInt != 109)
          return; 
        setOverlayMode(true);
        return;
      } 
      this.mDecorToolbar.initIndeterminateProgress();
      return;
    } 
    this.mDecorToolbar.initProgress();
  }
  
  public boolean isHideOnContentScrollEnabled() {
    return this.mHideOnContentScroll;
  }
  
  public boolean isInOverlayMode() {
    return this.mOverlayMode;
  }
  
  public boolean isOverflowMenuShowPending() {
    pullChildren();
    return this.mDecorToolbar.isOverflowMenuShowPending();
  }
  
  public boolean isOverflowMenuShowing() {
    pullChildren();
    return this.mDecorToolbar.isOverflowMenuShowing();
  }
  
  @RequiresApi(21)
  public WindowInsets onApplyWindowInsets(@NonNull WindowInsets paramWindowInsets) {
    pullChildren();
    WindowInsetsCompat windowInsetsCompat1 = WindowInsetsCompat.toWindowInsetsCompat(paramWindowInsets, (View)this);
    Rect rect = new Rect(windowInsetsCompat1.getSystemWindowInsetLeft(), windowInsetsCompat1.getSystemWindowInsetTop(), windowInsetsCompat1.getSystemWindowInsetRight(), windowInsetsCompat1.getSystemWindowInsetBottom());
    boolean bool1 = applyInsets((View)this.mActionBarTop, rect, true, true, false, true);
    ViewCompat.computeSystemWindowInsets((View)this, windowInsetsCompat1, this.mBaseContentInsets);
    rect = this.mBaseContentInsets;
    WindowInsetsCompat windowInsetsCompat2 = windowInsetsCompat1.inset(rect.left, rect.top, rect.right, rect.bottom);
    this.mBaseInnerInsets = windowInsetsCompat2;
    boolean bool2 = this.mLastBaseInnerInsets.equals(windowInsetsCompat2);
    boolean bool = true;
    if (!bool2) {
      this.mLastBaseInnerInsets = this.mBaseInnerInsets;
      bool1 = true;
    } 
    if (!this.mLastBaseContentInsets.equals(this.mBaseContentInsets)) {
      this.mLastBaseContentInsets.set(this.mBaseContentInsets);
      bool1 = bool;
    } 
    if (bool1)
      requestLayout(); 
    return windowInsetsCompat1.consumeDisplayCutout().consumeSystemWindowInsets().consumeStableInsets().toWindowInsets();
  }
  
  protected void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    init(getContext());
    ViewCompat.requestApplyInsets((View)this);
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    haltActionBarHideOffsetAnimations();
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt2 = getChildCount();
    paramInt3 = getPaddingLeft();
    paramInt4 = getPaddingTop();
    for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
      View view = getChildAt(paramInt1);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        int i = view.getMeasuredWidth();
        int j = view.getMeasuredHeight();
        int k = layoutParams.leftMargin + paramInt3;
        int m = layoutParams.topMargin + paramInt4;
        view.layout(k, m, i + k, j + m);
      } 
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    pullChildren();
    measureChildWithMargins((View)this.mActionBarTop, paramInt1, 0, paramInt2, 0);
    LayoutParams layoutParams2 = (LayoutParams)this.mActionBarTop.getLayoutParams();
    int i1 = Math.max(0, this.mActionBarTop.getMeasuredWidth() + layoutParams2.leftMargin + layoutParams2.rightMargin);
    int n = Math.max(0, this.mActionBarTop.getMeasuredHeight() + layoutParams2.topMargin + layoutParams2.bottomMargin);
    int m = View.combineMeasuredStates(0, this.mActionBarTop.getMeasuredState());
    if ((ViewCompat.getWindowSystemUiVisibility((View)this) & 0x100) != 0) {
      j = 1;
    } else {
      j = 0;
    } 
    if (j) {
      int i2 = this.mActionBarHeight;
      i = i2;
      if (this.mHasNonEmbeddedTabs) {
        i = i2;
        if (this.mActionBarTop.getTabContainer() != null)
          i = i2 + this.mActionBarHeight; 
      } 
    } else if (this.mActionBarTop.getVisibility() != 8) {
      i = this.mActionBarTop.getMeasuredHeight();
    } else {
      i = 0;
    } 
    this.mContentInsets.set(this.mBaseContentInsets);
    WindowInsetsCompat windowInsetsCompat = this.mBaseInnerInsets;
    this.mInnerInsets = windowInsetsCompat;
    if (!this.mOverlayMode && !j) {
      Rect rect = this.mContentInsets;
      rect.top += i;
      rect.bottom += 0;
      this.mInnerInsets = windowInsetsCompat.inset(0, i, 0, 0);
    } else {
      Insets insets = Insets.of(windowInsetsCompat.getSystemWindowInsetLeft(), this.mInnerInsets.getSystemWindowInsetTop() + i, this.mInnerInsets.getSystemWindowInsetRight(), this.mInnerInsets.getSystemWindowInsetBottom() + 0);
      this.mInnerInsets = (new WindowInsetsCompat.Builder(this.mInnerInsets)).setSystemWindowInsets(insets).build();
    } 
    applyInsets((View)this.mContent, this.mContentInsets, true, true, true, true);
    if (!this.mLastInnerInsets.equals(this.mInnerInsets)) {
      windowInsetsCompat = this.mInnerInsets;
      this.mLastInnerInsets = windowInsetsCompat;
      ViewCompat.dispatchApplyWindowInsets((View)this.mContent, windowInsetsCompat);
    } 
    measureChildWithMargins((View)this.mContent, paramInt1, 0, paramInt2, 0);
    LayoutParams layoutParams1 = (LayoutParams)this.mContent.getLayoutParams();
    int i = Math.max(i1, this.mContent.getMeasuredWidth() + layoutParams1.leftMargin + layoutParams1.rightMargin);
    int j = Math.max(n, this.mContent.getMeasuredHeight() + layoutParams1.topMargin + layoutParams1.bottomMargin);
    int k = View.combineMeasuredStates(m, this.mContent.getMeasuredState());
    m = getPaddingLeft();
    n = getPaddingRight();
    j = Math.max(j + getPaddingTop() + getPaddingBottom(), getSuggestedMinimumHeight());
    setMeasuredDimension(View.resolveSizeAndState(Math.max(i + m + n, getSuggestedMinimumWidth()), paramInt1, k), View.resolveSizeAndState(j, paramInt2, k << 16));
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    if (!this.mHideOnContentScroll || !paramBoolean)
      return false; 
    if (shouldHideActionBarOnFling(paramFloat2)) {
      addActionBarHideOffset();
    } else {
      removeActionBarHideOffset();
    } 
    this.mAnimatingForFling = true;
    return true;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return false;
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {}
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    if (paramInt3 == 0)
      onNestedPreScroll(paramView, paramInt1, paramInt2, paramArrayOfint); 
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt1 = this.mHideOnContentScrollReference + paramInt2;
    this.mHideOnContentScrollReference = paramInt1;
    setActionBarHideOffset(paramInt1);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    if (paramInt5 == 0)
      onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    this.mParentHelper.onNestedScrollAccepted(paramView1, paramView2, paramInt);
    this.mHideOnContentScrollReference = getActionBarHideOffset();
    haltActionBarHideOffsetAnimations();
    ActionBarVisibilityCallback actionBarVisibilityCallback = this.mActionBarVisibilityCallback;
    if (actionBarVisibilityCallback != null)
      actionBarVisibilityCallback.onContentScrollStarted(); 
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    if (paramInt2 == 0)
      onNestedScrollAccepted(paramView1, paramView2, paramInt1); 
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return ((paramInt & 0x2) == 0 || this.mActionBarTop.getVisibility() != 0) ? false : this.mHideOnContentScroll;
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    return (paramInt2 == 0 && onStartNestedScroll(paramView1, paramView2, paramInt1));
  }
  
  public void onStopNestedScroll(View paramView) {
    if (this.mHideOnContentScroll && !this.mAnimatingForFling)
      if (this.mHideOnContentScrollReference <= this.mActionBarTop.getHeight()) {
        postRemoveActionBarHideOffset();
      } else {
        postAddActionBarHideOffset();
      }  
    ActionBarVisibilityCallback actionBarVisibilityCallback = this.mActionBarVisibilityCallback;
    if (actionBarVisibilityCallback != null)
      actionBarVisibilityCallback.onContentScrollStopped(); 
  }
  
  public void onStopNestedScroll(View paramView, int paramInt) {
    if (paramInt == 0)
      onStopNestedScroll(paramView); 
  }
  
  @Deprecated
  public void onWindowSystemUiVisibilityChanged(int paramInt) {
    boolean bool1;
    super.onWindowSystemUiVisibilityChanged(paramInt);
    pullChildren();
    int i = this.mLastSystemUiVisibility;
    this.mLastSystemUiVisibility = paramInt;
    boolean bool2 = false;
    if ((paramInt & 0x4) == 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if ((paramInt & 0x100) != 0)
      bool2 = true; 
    ActionBarVisibilityCallback actionBarVisibilityCallback = this.mActionBarVisibilityCallback;
    if (actionBarVisibilityCallback != null) {
      actionBarVisibilityCallback.enableContentAnimations(bool2 ^ true);
      if (bool1 || !bool2) {
        this.mActionBarVisibilityCallback.showForSystem();
      } else {
        this.mActionBarVisibilityCallback.hideForSystem();
      } 
    } 
    if (((i ^ paramInt) & 0x100) != 0 && this.mActionBarVisibilityCallback != null)
      ViewCompat.requestApplyInsets((View)this); 
  }
  
  protected void onWindowVisibilityChanged(int paramInt) {
    super.onWindowVisibilityChanged(paramInt);
    this.mWindowVisibility = paramInt;
    ActionBarVisibilityCallback actionBarVisibilityCallback = this.mActionBarVisibilityCallback;
    if (actionBarVisibilityCallback != null)
      actionBarVisibilityCallback.onWindowVisibilityChanged(paramInt); 
  }
  
  void pullChildren() {
    if (this.mContent == null) {
      this.mContent = (ContentFrameLayout)findViewById(R.id.action_bar_activity_content);
      this.mActionBarTop = (ActionBarContainer)findViewById(R.id.action_bar_container);
      this.mDecorToolbar = getDecorToolbar(findViewById(R.id.action_bar));
    } 
  }
  
  public void restoreToolbarHierarchyState(SparseArray<Parcelable> paramSparseArray) {
    pullChildren();
    this.mDecorToolbar.restoreHierarchyState(paramSparseArray);
  }
  
  public void saveToolbarHierarchyState(SparseArray<Parcelable> paramSparseArray) {
    pullChildren();
    this.mDecorToolbar.saveHierarchyState(paramSparseArray);
  }
  
  public void setActionBarHideOffset(int paramInt) {
    haltActionBarHideOffsetAnimations();
    paramInt = Math.max(0, Math.min(paramInt, this.mActionBarTop.getHeight()));
    this.mActionBarTop.setTranslationY(-paramInt);
  }
  
  public void setActionBarVisibilityCallback(ActionBarVisibilityCallback paramActionBarVisibilityCallback) {
    this.mActionBarVisibilityCallback = paramActionBarVisibilityCallback;
    if (getWindowToken() != null) {
      this.mActionBarVisibilityCallback.onWindowVisibilityChanged(this.mWindowVisibility);
      int i = this.mLastSystemUiVisibility;
      if (i != 0) {
        onWindowSystemUiVisibilityChanged(i);
        ViewCompat.requestApplyInsets((View)this);
      } 
    } 
  }
  
  public void setHasNonEmbeddedTabs(boolean paramBoolean) {
    this.mHasNonEmbeddedTabs = paramBoolean;
  }
  
  public void setHideOnContentScrollEnabled(boolean paramBoolean) {
    if (paramBoolean != this.mHideOnContentScroll) {
      this.mHideOnContentScroll = paramBoolean;
      if (!paramBoolean) {
        haltActionBarHideOffsetAnimations();
        setActionBarHideOffset(0);
      } 
    } 
  }
  
  public void setIcon(int paramInt) {
    pullChildren();
    this.mDecorToolbar.setIcon(paramInt);
  }
  
  public void setIcon(Drawable paramDrawable) {
    pullChildren();
    this.mDecorToolbar.setIcon(paramDrawable);
  }
  
  public void setLogo(int paramInt) {
    pullChildren();
    this.mDecorToolbar.setLogo(paramInt);
  }
  
  public void setMenu(Menu paramMenu, MenuPresenter.Callback paramCallback) {
    pullChildren();
    this.mDecorToolbar.setMenu(paramMenu, paramCallback);
  }
  
  public void setMenuPrepared() {
    pullChildren();
    this.mDecorToolbar.setMenuPrepared();
  }
  
  public void setOverlayMode(boolean paramBoolean) {
    this.mOverlayMode = paramBoolean;
    if (paramBoolean && (getContext().getApplicationInfo()).targetSdkVersion < 19) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    this.mIgnoreWindowContentOverlay = paramBoolean;
  }
  
  public void setShowingForActionMode(boolean paramBoolean) {}
  
  public void setUiOptions(int paramInt) {}
  
  public void setWindowCallback(Window.Callback paramCallback) {
    pullChildren();
    this.mDecorToolbar.setWindowCallback(paramCallback);
  }
  
  public void setWindowTitle(CharSequence paramCharSequence) {
    pullChildren();
    this.mDecorToolbar.setWindowTitle(paramCharSequence);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public boolean showOverflowMenu() {
    pullChildren();
    return this.mDecorToolbar.showOverflowMenu();
  }
  
  public static interface ActionBarVisibilityCallback {
    void enableContentAnimations(boolean param1Boolean);
    
    void hideForSystem();
    
    void onContentScrollStarted();
    
    void onContentScrollStopped();
    
    void onWindowVisibilityChanged(int param1Int);
    
    void showForSystem();
  }
  
  public static class LayoutParams extends ViewGroup.MarginLayoutParams {
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\appcompat\widget\ActionBarOverlayLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */