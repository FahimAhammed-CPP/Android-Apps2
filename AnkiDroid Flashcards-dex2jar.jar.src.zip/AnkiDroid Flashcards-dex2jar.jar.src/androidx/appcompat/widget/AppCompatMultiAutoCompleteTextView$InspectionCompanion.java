package androidx.appcompat.widget;

import android.view.inspector.InspectionCompanion;
import android.view.inspector.PropertyMapper;
import android.view.inspector.PropertyReader;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.appcompat.R;

@RequiresApi(29)
@RestrictTo({RestrictTo.Scope.LIBRARY})
public final class AppCompatMultiAutoCompleteTextView$InspectionCompanion implements InspectionCompanion<AppCompatMultiAutoCompleteTextView> {
  private int mBackgroundTintId;
  
  private int mBackgroundTintModeId;
  
  private int mDrawableTintId;
  
  private int mDrawableTintModeId;
  
  private boolean mPropertiesMapped = false;
  
  public void mapProperties(@NonNull PropertyMapper paramPropertyMapper) {
    this.mBackgroundTintId = b.a(paramPropertyMapper, "backgroundTint", R.attr.backgroundTint);
    this.mBackgroundTintModeId = b.a(paramPropertyMapper, "backgroundTintMode", R.attr.backgroundTintMode);
    this.mDrawableTintId = b.a(paramPropertyMapper, "drawableTint", R.attr.drawableTint);
    this.mDrawableTintModeId = b.a(paramPropertyMapper, "drawableTintMode", R.attr.drawableTintMode);
    this.mPropertiesMapped = true;
  }
  
  public void readProperties(@NonNull AppCompatMultiAutoCompleteTextView paramAppCompatMultiAutoCompleteTextView, @NonNull PropertyReader paramPropertyReader) {
    if (this.mPropertiesMapped) {
      a.a(paramPropertyReader, this.mBackgroundTintId, paramAppCompatMultiAutoCompleteTextView.getBackgroundTintList());
      a.a(paramPropertyReader, this.mBackgroundTintModeId, paramAppCompatMultiAutoCompleteTextView.getBackgroundTintMode());
      a.a(paramPropertyReader, this.mDrawableTintId, paramAppCompatMultiAutoCompleteTextView.getCompoundDrawableTintList());
      a.a(paramPropertyReader, this.mDrawableTintModeId, paramAppCompatMultiAutoCompleteTextView.getCompoundDrawableTintMode());
      return;
    } 
    d.a();
    throw c.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\appcompat\widget\AppCompatMultiAutoCompleteTextView$InspectionCompanion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */