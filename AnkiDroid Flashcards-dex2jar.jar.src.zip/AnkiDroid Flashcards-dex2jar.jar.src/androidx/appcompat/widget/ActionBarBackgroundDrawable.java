package androidx.appcompat.widget;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.drawable.Drawable;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

class ActionBarBackgroundDrawable extends Drawable {
  final ActionBarContainer mContainer;
  
  public ActionBarBackgroundDrawable(ActionBarContainer paramActionBarContainer) {
    this.mContainer = paramActionBarContainer;
  }
  
  public void draw(@NonNull Canvas paramCanvas) {
    Drawable drawable;
    ActionBarContainer actionBarContainer = this.mContainer;
    if (actionBarContainer.mIsSplit) {
      drawable = actionBarContainer.mSplitBackground;
      if (drawable != null) {
        drawable.draw(paramCanvas);
        return;
      } 
    } else {
      drawable = ((ActionBarContainer)drawable).mBackground;
      if (drawable != null)
        drawable.draw(paramCanvas); 
      ActionBarContainer actionBarContainer1 = this.mContainer;
      Drawable drawable1 = actionBarContainer1.mStackedBackground;
      if (drawable1 != null && actionBarContainer1.mIsStacked)
        drawable1.draw(paramCanvas); 
    } 
  }
  
  public int getOpacity() {
    return 0;
  }
  
  @RequiresApi(21)
  public void getOutline(@NonNull Outline paramOutline) {
    ActionBarContainer actionBarContainer = this.mContainer;
    if (actionBarContainer.mIsSplit) {
      if (actionBarContainer.mSplitBackground != null) {
        Api21Impl.getOutline(actionBarContainer.mBackground, paramOutline);
        return;
      } 
    } else {
      Drawable drawable = actionBarContainer.mBackground;
      if (drawable != null)
        Api21Impl.getOutline(drawable, paramOutline); 
    } 
  }
  
  public void setAlpha(int paramInt) {}
  
  public void setColorFilter(ColorFilter paramColorFilter) {}
  
  @RequiresApi(21)
  private static class Api21Impl {
    public static void getOutline(Drawable param1Drawable, Outline param1Outline) {
      param1Drawable.getOutline(param1Outline);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\appcompat\widget\ActionBarBackgroundDrawable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */