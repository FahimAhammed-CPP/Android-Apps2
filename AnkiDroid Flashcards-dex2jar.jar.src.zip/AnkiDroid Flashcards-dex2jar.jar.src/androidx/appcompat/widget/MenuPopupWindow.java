package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.transition.Transition;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.appcompat.view.menu.ListMenuItemView;
import androidx.appcompat.view.menu.MenuAdapter;
import androidx.appcompat.view.menu.MenuBuilder;
import java.lang.reflect.Method;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
public class MenuPopupWindow extends ListPopupWindow implements MenuItemHoverListener {
  private static final String TAG = "MenuPopupWindow";
  
  private static Method sSetTouchModalMethod;
  
  private MenuItemHoverListener mHoverListener;
  
  static {
    try {
      if (Build.VERSION.SDK_INT <= 28) {
        sSetTouchModalMethod = PopupWindow.class.getDeclaredMethod("setTouchModal", new Class[] { boolean.class });
        return;
      } 
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
    } 
  }
  
  public MenuPopupWindow(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
  }
  
  @NonNull
  DropDownListView createDropDownListView(Context paramContext, boolean paramBoolean) {
    MenuDropDownListView menuDropDownListView = new MenuDropDownListView(paramContext, paramBoolean);
    menuDropDownListView.setHoverListener(this);
    return menuDropDownListView;
  }
  
  public void onItemHoverEnter(@NonNull MenuBuilder paramMenuBuilder, @NonNull MenuItem paramMenuItem) {
    MenuItemHoverListener menuItemHoverListener = this.mHoverListener;
    if (menuItemHoverListener != null)
      menuItemHoverListener.onItemHoverEnter(paramMenuBuilder, paramMenuItem); 
  }
  
  public void onItemHoverExit(@NonNull MenuBuilder paramMenuBuilder, @NonNull MenuItem paramMenuItem) {
    MenuItemHoverListener menuItemHoverListener = this.mHoverListener;
    if (menuItemHoverListener != null)
      menuItemHoverListener.onItemHoverExit(paramMenuBuilder, paramMenuItem); 
  }
  
  public void setEnterTransition(Object paramObject) {
    if (Build.VERSION.SDK_INT >= 23)
      Api23Impl.setEnterTransition(this.mPopup, (Transition)paramObject); 
  }
  
  public void setExitTransition(Object paramObject) {
    if (Build.VERSION.SDK_INT >= 23)
      Api23Impl.setExitTransition(this.mPopup, (Transition)paramObject); 
  }
  
  public void setHoverListener(MenuItemHoverListener paramMenuItemHoverListener) {
    this.mHoverListener = paramMenuItemHoverListener;
  }
  
  public void setTouchModal(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = sSetTouchModalMethod;
      if (method != null)
        try {
          method.invoke(this.mPopup, new Object[] { Boolean.valueOf(paramBoolean) });
          return;
        } catch (Exception exception) {
          Log.i("MenuPopupWindow", "Could not invoke setTouchModal() on PopupWindow. Oh well.");
          return;
        }  
    } else {
      Api29Impl.setTouchModal(this.mPopup, paramBoolean);
    } 
  }
  
  @RequiresApi(23)
  static class Api23Impl {
    @DoNotInline
    static void setEnterTransition(PopupWindow param1PopupWindow, Transition param1Transition) {
      v1.a(param1PopupWindow, param1Transition);
    }
    
    @DoNotInline
    static void setExitTransition(PopupWindow param1PopupWindow, Transition param1Transition) {
      u1.a(param1PopupWindow, param1Transition);
    }
  }
  
  @RequiresApi(29)
  static class Api29Impl {
    @DoNotInline
    static void setTouchModal(PopupWindow param1PopupWindow, boolean param1Boolean) {
      w1.a(param1PopupWindow, param1Boolean);
    }
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public static class MenuDropDownListView extends DropDownListView {
    final int mAdvanceKey;
    
    private MenuItemHoverListener mHoverListener;
    
    private MenuItem mHoveredMenuItem;
    
    final int mRetreatKey;
    
    public MenuDropDownListView(Context param1Context, boolean param1Boolean) {
      super(param1Context, param1Boolean);
      if (1 == Api17Impl.getLayoutDirection(param1Context.getResources().getConfiguration())) {
        this.mAdvanceKey = 21;
        this.mRetreatKey = 22;
        return;
      } 
      this.mAdvanceKey = 22;
      this.mRetreatKey = 21;
    }
    
    public void clearSelection() {
      setSelection(-1);
    }
    
    public boolean onHoverEvent(MotionEvent param1MotionEvent) {
      // Byte code:
      //   0: aload_0
      //   1: getfield mHoverListener : Landroidx/appcompat/widget/MenuItemHoverListener;
      //   4: ifnull -> 178
      //   7: aload_0
      //   8: invokevirtual getAdapter : ()Landroid/widget/ListAdapter;
      //   11: astore #4
      //   13: aload #4
      //   15: instanceof android/widget/HeaderViewListAdapter
      //   18: ifeq -> 47
      //   21: aload #4
      //   23: checkcast android/widget/HeaderViewListAdapter
      //   26: astore #4
      //   28: aload #4
      //   30: invokevirtual getHeadersCount : ()I
      //   33: istore_2
      //   34: aload #4
      //   36: invokevirtual getWrappedAdapter : ()Landroid/widget/ListAdapter;
      //   39: checkcast androidx/appcompat/view/menu/MenuAdapter
      //   42: astore #4
      //   44: goto -> 56
      //   47: aload #4
      //   49: checkcast androidx/appcompat/view/menu/MenuAdapter
      //   52: astore #4
      //   54: iconst_0
      //   55: istore_2
      //   56: aload_1
      //   57: invokevirtual getAction : ()I
      //   60: bipush #10
      //   62: if_icmpeq -> 113
      //   65: aload_0
      //   66: aload_1
      //   67: invokevirtual getX : ()F
      //   70: f2i
      //   71: aload_1
      //   72: invokevirtual getY : ()F
      //   75: f2i
      //   76: invokevirtual pointToPosition : (II)I
      //   79: istore_3
      //   80: iload_3
      //   81: iconst_m1
      //   82: if_icmpeq -> 113
      //   85: iload_3
      //   86: iload_2
      //   87: isub
      //   88: istore_2
      //   89: iload_2
      //   90: iflt -> 113
      //   93: iload_2
      //   94: aload #4
      //   96: invokevirtual getCount : ()I
      //   99: if_icmpge -> 113
      //   102: aload #4
      //   104: iload_2
      //   105: invokevirtual getItem : (I)Landroidx/appcompat/view/menu/MenuItemImpl;
      //   108: astore #5
      //   110: goto -> 116
      //   113: aconst_null
      //   114: astore #5
      //   116: aload_0
      //   117: getfield mHoveredMenuItem : Landroid/view/MenuItem;
      //   120: astore #6
      //   122: aload #6
      //   124: aload #5
      //   126: if_acmpeq -> 178
      //   129: aload #4
      //   131: invokevirtual getAdapterMenu : ()Landroidx/appcompat/view/menu/MenuBuilder;
      //   134: astore #4
      //   136: aload #6
      //   138: ifnull -> 154
      //   141: aload_0
      //   142: getfield mHoverListener : Landroidx/appcompat/widget/MenuItemHoverListener;
      //   145: aload #4
      //   147: aload #6
      //   149: invokeinterface onItemHoverExit : (Landroidx/appcompat/view/menu/MenuBuilder;Landroid/view/MenuItem;)V
      //   154: aload_0
      //   155: aload #5
      //   157: putfield mHoveredMenuItem : Landroid/view/MenuItem;
      //   160: aload #5
      //   162: ifnull -> 178
      //   165: aload_0
      //   166: getfield mHoverListener : Landroidx/appcompat/widget/MenuItemHoverListener;
      //   169: aload #4
      //   171: aload #5
      //   173: invokeinterface onItemHoverEnter : (Landroidx/appcompat/view/menu/MenuBuilder;Landroid/view/MenuItem;)V
      //   178: aload_0
      //   179: aload_1
      //   180: invokespecial onHoverEvent : (Landroid/view/MotionEvent;)Z
      //   183: ireturn
    }
    
    public boolean onKeyDown(int param1Int, KeyEvent param1KeyEvent) {
      MenuAdapter menuAdapter;
      ListMenuItemView listMenuItemView = (ListMenuItemView)getSelectedView();
      if (listMenuItemView != null && param1Int == this.mAdvanceKey) {
        if (listMenuItemView.isEnabled() && listMenuItemView.getItemData().hasSubMenu())
          performItemClick((View)listMenuItemView, getSelectedItemPosition(), getSelectedItemId()); 
        return true;
      } 
      if (listMenuItemView != null && param1Int == this.mRetreatKey) {
        setSelection(-1);
        ListAdapter listAdapter = getAdapter();
        if (listAdapter instanceof HeaderViewListAdapter) {
          menuAdapter = (MenuAdapter)((HeaderViewListAdapter)listAdapter).getWrappedAdapter();
        } else {
          menuAdapter = menuAdapter;
        } 
        menuAdapter.getAdapterMenu().close(false);
        return true;
      } 
      return super.onKeyDown(param1Int, (KeyEvent)menuAdapter);
    }
    
    public void setHoverListener(MenuItemHoverListener param1MenuItemHoverListener) {
      this.mHoverListener = param1MenuItemHoverListener;
    }
    
    @RequiresApi(17)
    static class Api17Impl {
      @DoNotInline
      static int getLayoutDirection(Configuration param2Configuration) {
        return param2Configuration.getLayoutDirection();
      }
    }
  }
  
  @RequiresApi(17)
  static class Api17Impl {
    @DoNotInline
    static int getLayoutDirection(Configuration param1Configuration) {
      return param1Configuration.getLayoutDirection();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\appcompat\widget\MenuPopupWindow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */