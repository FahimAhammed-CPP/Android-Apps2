package androidx.appcompat.widget;

import android.os.Build;
import android.view.View;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

public class TooltipCompat {
  public static void setTooltipText(@NonNull View paramView, @Nullable CharSequence paramCharSequence) {
    if (Build.VERSION.SDK_INT >= 26) {
      Api26Impl.setTooltipText(paramView, paramCharSequence);
      return;
    } 
    TooltipCompatHandler.setTooltipText(paramView, paramCharSequence);
  }
  
  @RequiresApi(26)
  static class Api26Impl {
    @DoNotInline
    static void setTooltipText(View param1View, CharSequence param1CharSequence) {
      e2.a(param1View, param1CharSequence);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\appcompat\widget\TooltipCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */