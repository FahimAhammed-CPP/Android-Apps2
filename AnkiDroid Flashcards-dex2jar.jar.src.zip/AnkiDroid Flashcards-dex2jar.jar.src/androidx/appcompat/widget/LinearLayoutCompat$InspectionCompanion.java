package androidx.appcompat.widget;

import android.view.inspector.InspectionCompanion;
import android.view.inspector.PropertyMapper;
import android.view.inspector.PropertyReader;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.appcompat.R;
import java.util.HashSet;
import java.util.Set;
import java.util.function.IntFunction;

@RequiresApi(29)
@RestrictTo({RestrictTo.Scope.LIBRARY})
public final class LinearLayoutCompat$InspectionCompanion implements InspectionCompanion<LinearLayoutCompat> {
  private int mBaselineAlignedChildIndexId;
  
  private int mBaselineAlignedId;
  
  private int mDividerId;
  
  private int mDividerPaddingId;
  
  private int mGravityId;
  
  private int mMeasureWithLargestChildId;
  
  private int mOrientationId;
  
  private boolean mPropertiesMapped = false;
  
  private int mShowDividersId;
  
  private int mWeightSumId;
  
  public void mapProperties(@NonNull PropertyMapper paramPropertyMapper) {
    this.mBaselineAlignedId = j1.a(paramPropertyMapper, "baselineAligned", 16843046);
    this.mBaselineAlignedChildIndexId = g.a(paramPropertyMapper, "baselineAlignedChildIndex", 16843047);
    this.mGravityId = k1.a(paramPropertyMapper, "gravity", 16842927);
    this.mOrientationId = h.a(paramPropertyMapper, "orientation", 16842948, new IntFunction<String>() {
          public String apply(int param1Int) {
            return (param1Int != 0) ? ((param1Int != 1) ? String.valueOf(param1Int) : "vertical") : "horizontal";
          }
        });
    this.mWeightSumId = l1.a(paramPropertyMapper, "weightSum", 16843048);
    this.mDividerId = b.a(paramPropertyMapper, "divider", R.attr.divider);
    this.mDividerPaddingId = g.a(paramPropertyMapper, "dividerPadding", R.attr.dividerPadding);
    this.mMeasureWithLargestChildId = j1.a(paramPropertyMapper, "measureWithLargestChild", R.attr.measureWithLargestChild);
    this.mShowDividersId = m1.a(paramPropertyMapper, "showDividers", R.attr.showDividers, new IntFunction<Set<String>>() {
          public Set<String> apply(int param1Int) {
            HashSet<String> hashSet = new HashSet();
            if (param1Int == 0)
              hashSet.add("none"); 
            if (param1Int == 1)
              hashSet.add("beginning"); 
            if (param1Int == 2)
              hashSet.add("middle"); 
            if (param1Int == 4)
              hashSet.add("end"); 
            return hashSet;
          }
        });
    this.mPropertiesMapped = true;
  }
  
  public void readProperties(@NonNull LinearLayoutCompat paramLinearLayoutCompat, @NonNull PropertyReader paramPropertyReader) {
    if (this.mPropertiesMapped) {
      n1.a(paramPropertyReader, this.mBaselineAlignedId, paramLinearLayoutCompat.isBaselineAligned());
      e.a(paramPropertyReader, this.mBaselineAlignedChildIndexId, paramLinearLayoutCompat.getBaselineAlignedChildIndex());
      o1.a(paramPropertyReader, this.mGravityId, paramLinearLayoutCompat.getGravity());
      f.a(paramPropertyReader, this.mOrientationId, paramLinearLayoutCompat.getOrientation());
      p1.a(paramPropertyReader, this.mWeightSumId, paramLinearLayoutCompat.getWeightSum());
      a.a(paramPropertyReader, this.mDividerId, paramLinearLayoutCompat.getDividerDrawable());
      e.a(paramPropertyReader, this.mDividerPaddingId, paramLinearLayoutCompat.getDividerPadding());
      n1.a(paramPropertyReader, this.mMeasureWithLargestChildId, paramLinearLayoutCompat.isMeasureWithLargestChildEnabled());
      q1.a(paramPropertyReader, this.mShowDividersId, paramLinearLayoutCompat.getShowDividers());
      return;
    } 
    d.a();
    throw c.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\appcompat\widget\LinearLayoutCompat$InspectionCompanion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */