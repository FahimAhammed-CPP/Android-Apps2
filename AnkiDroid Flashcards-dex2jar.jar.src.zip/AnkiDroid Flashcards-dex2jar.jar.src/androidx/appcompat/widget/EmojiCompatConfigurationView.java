package androidx.appcompat.widget;

public interface EmojiCompatConfigurationView {
  boolean isEmojiCompatEnabled();
  
  void setEmojiCompatEnabled(boolean paramBoolean);
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\appcompat\widget\EmojiCompatConfigurationView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */