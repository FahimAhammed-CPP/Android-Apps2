package androidx.appcompat.widget;

import android.text.StaticLayout;



/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\appcompat\widget\s0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */