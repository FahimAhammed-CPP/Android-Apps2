package androidx.appcompat.widget;

import android.view.inspector.InspectionCompanion;
import android.view.inspector.PropertyMapper;
import android.view.inspector.PropertyReader;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.appcompat.R;

@RequiresApi(29)
@RestrictTo({RestrictTo.Scope.LIBRARY})
public final class Toolbar$InspectionCompanion implements InspectionCompanion<Toolbar> {
  private int mCollapseContentDescriptionId;
  
  private int mCollapseIconId;
  
  private int mContentInsetEndId;
  
  private int mContentInsetEndWithActionsId;
  
  private int mContentInsetLeftId;
  
  private int mContentInsetRightId;
  
  private int mContentInsetStartId;
  
  private int mContentInsetStartWithNavigationId;
  
  private int mLogoDescriptionId;
  
  private int mLogoId;
  
  private int mMenuId;
  
  private int mNavigationContentDescriptionId;
  
  private int mNavigationIconId;
  
  private int mPopupThemeId;
  
  private boolean mPropertiesMapped = false;
  
  private int mSubtitleId;
  
  private int mTitleId;
  
  private int mTitleMarginBottomId;
  
  private int mTitleMarginEndId;
  
  private int mTitleMarginStartId;
  
  private int mTitleMarginTopId;
  
  public void mapProperties(@NonNull PropertyMapper paramPropertyMapper) {
    this.mCollapseContentDescriptionId = b.a(paramPropertyMapper, "collapseContentDescription", R.attr.collapseContentDescription);
    this.mCollapseIconId = b.a(paramPropertyMapper, "collapseIcon", R.attr.collapseIcon);
    this.mContentInsetEndId = g.a(paramPropertyMapper, "contentInsetEnd", R.attr.contentInsetEnd);
    this.mContentInsetEndWithActionsId = g.a(paramPropertyMapper, "contentInsetEndWithActions", R.attr.contentInsetEndWithActions);
    this.mContentInsetLeftId = g.a(paramPropertyMapper, "contentInsetLeft", R.attr.contentInsetLeft);
    this.mContentInsetRightId = g.a(paramPropertyMapper, "contentInsetRight", R.attr.contentInsetRight);
    this.mContentInsetStartId = g.a(paramPropertyMapper, "contentInsetStart", R.attr.contentInsetStart);
    this.mContentInsetStartWithNavigationId = g.a(paramPropertyMapper, "contentInsetStartWithNavigation", R.attr.contentInsetStartWithNavigation);
    this.mLogoId = b.a(paramPropertyMapper, "logo", R.attr.logo);
    this.mLogoDescriptionId = b.a(paramPropertyMapper, "logoDescription", R.attr.logoDescription);
    this.mMenuId = b.a(paramPropertyMapper, "menu", R.attr.menu);
    this.mNavigationContentDescriptionId = b.a(paramPropertyMapper, "navigationContentDescription", R.attr.navigationContentDescription);
    this.mNavigationIconId = b.a(paramPropertyMapper, "navigationIcon", R.attr.navigationIcon);
    this.mPopupThemeId = c2.a(paramPropertyMapper, "popupTheme", R.attr.popupTheme);
    this.mSubtitleId = b.a(paramPropertyMapper, "subtitle", R.attr.subtitle);
    this.mTitleId = b.a(paramPropertyMapper, "title", R.attr.title);
    this.mTitleMarginBottomId = g.a(paramPropertyMapper, "titleMarginBottom", R.attr.titleMarginBottom);
    this.mTitleMarginEndId = g.a(paramPropertyMapper, "titleMarginEnd", R.attr.titleMarginEnd);
    this.mTitleMarginStartId = g.a(paramPropertyMapper, "titleMarginStart", R.attr.titleMarginStart);
    this.mTitleMarginTopId = g.a(paramPropertyMapper, "titleMarginTop", R.attr.titleMarginTop);
    this.mPropertiesMapped = true;
  }
  
  public void readProperties(@NonNull Toolbar paramToolbar, @NonNull PropertyReader paramPropertyReader) {
    if (this.mPropertiesMapped) {
      a.a(paramPropertyReader, this.mCollapseContentDescriptionId, paramToolbar.getCollapseContentDescription());
      a.a(paramPropertyReader, this.mCollapseIconId, paramToolbar.getCollapseIcon());
      e.a(paramPropertyReader, this.mContentInsetEndId, paramToolbar.getContentInsetEnd());
      e.a(paramPropertyReader, this.mContentInsetEndWithActionsId, paramToolbar.getContentInsetEndWithActions());
      e.a(paramPropertyReader, this.mContentInsetLeftId, paramToolbar.getContentInsetLeft());
      e.a(paramPropertyReader, this.mContentInsetRightId, paramToolbar.getContentInsetRight());
      e.a(paramPropertyReader, this.mContentInsetStartId, paramToolbar.getContentInsetStart());
      e.a(paramPropertyReader, this.mContentInsetStartWithNavigationId, paramToolbar.getContentInsetStartWithNavigation());
      a.a(paramPropertyReader, this.mLogoId, paramToolbar.getLogo());
      a.a(paramPropertyReader, this.mLogoDescriptionId, paramToolbar.getLogoDescription());
      a.a(paramPropertyReader, this.mMenuId, paramToolbar.getMenu());
      a.a(paramPropertyReader, this.mNavigationContentDescriptionId, paramToolbar.getNavigationContentDescription());
      a.a(paramPropertyReader, this.mNavigationIconId, paramToolbar.getNavigationIcon());
      d2.a(paramPropertyReader, this.mPopupThemeId, paramToolbar.getPopupTheme());
      a.a(paramPropertyReader, this.mSubtitleId, paramToolbar.getSubtitle());
      a.a(paramPropertyReader, this.mTitleId, paramToolbar.getTitle());
      e.a(paramPropertyReader, this.mTitleMarginBottomId, paramToolbar.getTitleMarginBottom());
      e.a(paramPropertyReader, this.mTitleMarginEndId, paramToolbar.getTitleMarginEnd());
      e.a(paramPropertyReader, this.mTitleMarginStartId, paramToolbar.getTitleMarginStart());
      e.a(paramPropertyReader, this.mTitleMarginTopId, paramToolbar.getTitleMarginTop());
      return;
    } 
    d.a();
    throw c.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\appcompat\widget\Toolbar$InspectionCompanion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */