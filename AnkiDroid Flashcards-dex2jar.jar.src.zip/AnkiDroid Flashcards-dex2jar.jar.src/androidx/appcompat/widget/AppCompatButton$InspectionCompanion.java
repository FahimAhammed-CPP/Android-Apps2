package androidx.appcompat.widget;

import android.view.inspector.InspectionCompanion;
import android.view.inspector.PropertyMapper;
import android.view.inspector.PropertyReader;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.appcompat.R;
import java.util.function.IntFunction;

@RequiresApi(29)
@RestrictTo({RestrictTo.Scope.LIBRARY})
public final class AppCompatButton$InspectionCompanion implements InspectionCompanion<AppCompatButton> {
  private int mAutoSizeMaxTextSizeId;
  
  private int mAutoSizeMinTextSizeId;
  
  private int mAutoSizeStepGranularityId;
  
  private int mAutoSizeTextTypeId;
  
  private int mBackgroundTintId;
  
  private int mBackgroundTintModeId;
  
  private int mDrawableTintId;
  
  private int mDrawableTintModeId;
  
  private boolean mPropertiesMapped = false;
  
  public void mapProperties(@NonNull PropertyMapper paramPropertyMapper) {
    this.mAutoSizeMaxTextSizeId = g.a(paramPropertyMapper, "autoSizeMaxTextSize", R.attr.autoSizeMaxTextSize);
    this.mAutoSizeMinTextSizeId = g.a(paramPropertyMapper, "autoSizeMinTextSize", R.attr.autoSizeMinTextSize);
    this.mAutoSizeStepGranularityId = g.a(paramPropertyMapper, "autoSizeStepGranularity", R.attr.autoSizeStepGranularity);
    this.mAutoSizeTextTypeId = h.a(paramPropertyMapper, "autoSizeTextType", R.attr.autoSizeTextType, new IntFunction<String>() {
          public String apply(int param1Int) {
            return (param1Int != 0) ? ((param1Int != 1) ? String.valueOf(param1Int) : "uniform") : "none";
          }
        });
    this.mBackgroundTintId = b.a(paramPropertyMapper, "backgroundTint", R.attr.backgroundTint);
    this.mBackgroundTintModeId = b.a(paramPropertyMapper, "backgroundTintMode", R.attr.backgroundTintMode);
    this.mDrawableTintId = b.a(paramPropertyMapper, "drawableTint", R.attr.drawableTint);
    this.mDrawableTintModeId = b.a(paramPropertyMapper, "drawableTintMode", R.attr.drawableTintMode);
    this.mPropertiesMapped = true;
  }
  
  public void readProperties(@NonNull AppCompatButton paramAppCompatButton, @NonNull PropertyReader paramPropertyReader) {
    if (this.mPropertiesMapped) {
      e.a(paramPropertyReader, this.mAutoSizeMaxTextSizeId, paramAppCompatButton.getAutoSizeMaxTextSize());
      e.a(paramPropertyReader, this.mAutoSizeMinTextSizeId, paramAppCompatButton.getAutoSizeMinTextSize());
      e.a(paramPropertyReader, this.mAutoSizeStepGranularityId, paramAppCompatButton.getAutoSizeStepGranularity());
      f.a(paramPropertyReader, this.mAutoSizeTextTypeId, paramAppCompatButton.getAutoSizeTextType());
      a.a(paramPropertyReader, this.mBackgroundTintId, paramAppCompatButton.getBackgroundTintList());
      a.a(paramPropertyReader, this.mBackgroundTintModeId, paramAppCompatButton.getBackgroundTintMode());
      a.a(paramPropertyReader, this.mDrawableTintId, paramAppCompatButton.getCompoundDrawableTintList());
      a.a(paramPropertyReader, this.mDrawableTintModeId, paramAppCompatButton.getCompoundDrawableTintMode());
      return;
    } 
    d.a();
    throw c.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\appcompat\widget\AppCompatButton$InspectionCompanion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */