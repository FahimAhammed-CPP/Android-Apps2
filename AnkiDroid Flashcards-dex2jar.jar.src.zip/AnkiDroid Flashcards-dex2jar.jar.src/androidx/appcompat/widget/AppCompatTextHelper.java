package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.LocaleList;
import android.util.AttributeSet;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.appcompat.R;
import androidx.appcompat.app.c;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.inputmethod.EditorInfoCompat;
import java.lang.ref.WeakReference;
import java.util.Locale;

class AppCompatTextHelper {
  private static final int MONOSPACE = 3;
  
  private static final int SANS = 1;
  
  private static final int SERIF = 2;
  
  private static final int TEXT_FONT_WEIGHT_UNSPECIFIED = -1;
  
  private boolean mAsyncFontPending;
  
  @NonNull
  private final AppCompatTextViewAutoSizeHelper mAutoSizeTextHelper;
  
  private TintInfo mDrawableBottomTint;
  
  private TintInfo mDrawableEndTint;
  
  private TintInfo mDrawableLeftTint;
  
  private TintInfo mDrawableRightTint;
  
  private TintInfo mDrawableStartTint;
  
  private TintInfo mDrawableTint;
  
  private TintInfo mDrawableTopTint;
  
  private Typeface mFontTypeface;
  
  private int mFontWeight = -1;
  
  private int mStyle = 0;
  
  @NonNull
  private final TextView mView;
  
  AppCompatTextHelper(@NonNull TextView paramTextView) {
    this.mView = paramTextView;
    this.mAutoSizeTextHelper = new AppCompatTextViewAutoSizeHelper(paramTextView);
  }
  
  private void applyCompoundDrawableTint(Drawable paramDrawable, TintInfo paramTintInfo) {
    if (paramDrawable != null && paramTintInfo != null)
      AppCompatDrawableManager.tintDrawable(paramDrawable, paramTintInfo, this.mView.getDrawableState()); 
  }
  
  private static TintInfo createTintInfo(Context paramContext, AppCompatDrawableManager paramAppCompatDrawableManager, int paramInt) {
    ColorStateList colorStateList = paramAppCompatDrawableManager.getTintList(paramContext, paramInt);
    if (colorStateList != null) {
      TintInfo tintInfo = new TintInfo();
      tintInfo.mHasTintList = true;
      tintInfo.mTintList = colorStateList;
      return tintInfo;
    } 
    return null;
  }
  
  private void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4, Drawable paramDrawable5, Drawable paramDrawable6) {
    TextView textView;
    Drawable[] arrayOfDrawable;
    if (paramDrawable5 != null || paramDrawable6 != null) {
      arrayOfDrawable = Api17Impl.getCompoundDrawablesRelative(this.mView);
      textView = this.mView;
      if (paramDrawable5 == null)
        paramDrawable5 = arrayOfDrawable[0]; 
      if (paramDrawable2 == null)
        paramDrawable2 = arrayOfDrawable[1]; 
      if (paramDrawable6 == null)
        paramDrawable6 = arrayOfDrawable[2]; 
      if (paramDrawable4 == null)
        paramDrawable4 = arrayOfDrawable[3]; 
      Api17Impl.setCompoundDrawablesRelativeWithIntrinsicBounds(textView, paramDrawable5, paramDrawable2, paramDrawable6, paramDrawable4);
      return;
    } 
    if (textView != null || paramDrawable2 != null || arrayOfDrawable != null || paramDrawable4 != null) {
      Drawable drawable1;
      Drawable drawable2;
      Drawable[] arrayOfDrawable1 = Api17Impl.getCompoundDrawablesRelative(this.mView);
      paramDrawable5 = arrayOfDrawable1[0];
      if (paramDrawable5 != null || arrayOfDrawable1[2] != null) {
        textView = this.mView;
        if (paramDrawable2 == null)
          paramDrawable2 = arrayOfDrawable1[1]; 
        drawable2 = arrayOfDrawable1[2];
        if (paramDrawable4 == null)
          paramDrawable4 = arrayOfDrawable1[3]; 
        Api17Impl.setCompoundDrawablesRelativeWithIntrinsicBounds(textView, paramDrawable5, paramDrawable2, drawable2, paramDrawable4);
        return;
      } 
      arrayOfDrawable1 = this.mView.getCompoundDrawables();
      TextView textView1 = this.mView;
      if (textView == null)
        drawable1 = arrayOfDrawable1[0]; 
      if (paramDrawable2 == null)
        paramDrawable2 = arrayOfDrawable1[1]; 
      if (drawable2 == null)
        drawable2 = arrayOfDrawable1[2]; 
      if (paramDrawable4 == null)
        paramDrawable4 = arrayOfDrawable1[3]; 
      textView1.setCompoundDrawablesWithIntrinsicBounds(drawable1, paramDrawable2, drawable2, paramDrawable4);
      return;
    } 
  }
  
  private void setCompoundTints() {
    TintInfo tintInfo = this.mDrawableTint;
    this.mDrawableLeftTint = tintInfo;
    this.mDrawableTopTint = tintInfo;
    this.mDrawableRightTint = tintInfo;
    this.mDrawableBottomTint = tintInfo;
    this.mDrawableStartTint = tintInfo;
    this.mDrawableEndTint = tintInfo;
  }
  
  private void setTextSizeInternal(int paramInt, float paramFloat) {
    this.mAutoSizeTextHelper.setTextSizeInternal(paramInt, paramFloat);
  }
  
  private void updateTypefaceAndStyle(Context paramContext, TintTypedArray paramTintTypedArray) {
    this.mStyle = paramTintTypedArray.getInt(R.styleable.TextAppearance_android_textStyle, this.mStyle);
    int i = Build.VERSION.SDK_INT;
    boolean bool = false;
    if (i >= 28) {
      int j = paramTintTypedArray.getInt(R.styleable.TextAppearance_android_textFontWeight, -1);
      this.mFontWeight = j;
      if (j != -1)
        this.mStyle = this.mStyle & 0x2 | 0x0; 
    } 
    if (paramTintTypedArray.hasValue(R.styleable.TextAppearance_android_fontFamily) || paramTintTypedArray.hasValue(R.styleable.TextAppearance_fontFamily)) {
      int j;
      this.mFontTypeface = null;
      if (paramTintTypedArray.hasValue(R.styleable.TextAppearance_fontFamily)) {
        j = R.styleable.TextAppearance_fontFamily;
      } else {
        j = R.styleable.TextAppearance_android_fontFamily;
      } 
      final int fontWeight = this.mFontWeight;
      final int style = this.mStyle;
      if (!paramContext.isRestricted()) {
        ResourcesCompat.FontCallback fontCallback = new ResourcesCompat.FontCallback() {
            public void onFontRetrievalFailed(int param1Int) {}
            
            public void onFontRetrieved(@NonNull Typeface param1Typeface) {
              Typeface typeface = param1Typeface;
              if (Build.VERSION.SDK_INT >= 28) {
                int i = fontWeight;
                typeface = param1Typeface;
                if (i != -1) {
                  boolean bool;
                  if ((style & 0x2) != 0) {
                    bool = true;
                  } else {
                    bool = false;
                  } 
                  typeface = AppCompatTextHelper.Api28Impl.create(param1Typeface, i, bool);
                } 
              } 
              AppCompatTextHelper.this.onAsyncTypefaceReceived(textViewWeak, typeface);
            }
          };
        try {
          boolean bool1;
          Typeface typeface = paramTintTypedArray.getFont(j, this.mStyle, fontCallback);
          if (typeface != null)
            if (i >= 28 && this.mFontWeight != -1) {
              typeface = Typeface.create(typeface, 0);
              i = this.mFontWeight;
              if ((this.mStyle & 0x2) != 0) {
                bool1 = true;
              } else {
                bool1 = false;
              } 
              this.mFontTypeface = Api28Impl.create(typeface, i, bool1);
            } else {
              this.mFontTypeface = typeface;
            }  
          if (this.mFontTypeface == null) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          this.mAsyncFontPending = bool1;
        } catch (UnsupportedOperationException|android.content.res.Resources.NotFoundException unsupportedOperationException) {}
      } 
      if (this.mFontTypeface == null) {
        String str = paramTintTypedArray.getString(j);
        if (str != null) {
          Typeface typeface;
          if (Build.VERSION.SDK_INT >= 28 && this.mFontWeight != -1) {
            typeface = Typeface.create(str, 0);
            j = this.mFontWeight;
            boolean bool1 = bool;
            if ((this.mStyle & 0x2) != 0)
              bool1 = true; 
            this.mFontTypeface = Api28Impl.create(typeface, j, bool1);
            return;
          } 
          this.mFontTypeface = Typeface.create((String)typeface, this.mStyle);
        } 
      } 
      return;
    } 
    if (paramTintTypedArray.hasValue(R.styleable.TextAppearance_android_typeface)) {
      this.mAsyncFontPending = false;
      int j = paramTintTypedArray.getInt(R.styleable.TextAppearance_android_typeface, 1);
      if (j != 1) {
        if (j != 2) {
          if (j != 3)
            return; 
          this.mFontTypeface = Typeface.MONOSPACE;
          return;
        } 
        this.mFontTypeface = Typeface.SERIF;
        return;
      } 
      this.mFontTypeface = Typeface.SANS_SERIF;
    } 
  }
  
  void applyCompoundDrawablesTints() {
    if (this.mDrawableLeftTint != null || this.mDrawableTopTint != null || this.mDrawableRightTint != null || this.mDrawableBottomTint != null) {
      Drawable[] arrayOfDrawable = this.mView.getCompoundDrawables();
      applyCompoundDrawableTint(arrayOfDrawable[0], this.mDrawableLeftTint);
      applyCompoundDrawableTint(arrayOfDrawable[1], this.mDrawableTopTint);
      applyCompoundDrawableTint(arrayOfDrawable[2], this.mDrawableRightTint);
      applyCompoundDrawableTint(arrayOfDrawable[3], this.mDrawableBottomTint);
    } 
    if (this.mDrawableStartTint != null || this.mDrawableEndTint != null) {
      Drawable[] arrayOfDrawable = Api17Impl.getCompoundDrawablesRelative(this.mView);
      applyCompoundDrawableTint(arrayOfDrawable[0], this.mDrawableStartTint);
      applyCompoundDrawableTint(arrayOfDrawable[2], this.mDrawableEndTint);
    } 
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  void autoSizeText() {
    this.mAutoSizeTextHelper.autoSizeText();
  }
  
  int getAutoSizeMaxTextSize() {
    return this.mAutoSizeTextHelper.getAutoSizeMaxTextSize();
  }
  
  int getAutoSizeMinTextSize() {
    return this.mAutoSizeTextHelper.getAutoSizeMinTextSize();
  }
  
  int getAutoSizeStepGranularity() {
    return this.mAutoSizeTextHelper.getAutoSizeStepGranularity();
  }
  
  int[] getAutoSizeTextAvailableSizes() {
    return this.mAutoSizeTextHelper.getAutoSizeTextAvailableSizes();
  }
  
  int getAutoSizeTextType() {
    return this.mAutoSizeTextHelper.getAutoSizeTextType();
  }
  
  @Nullable
  ColorStateList getCompoundDrawableTintList() {
    TintInfo tintInfo = this.mDrawableTint;
    return (tintInfo != null) ? tintInfo.mTintList : null;
  }
  
  @Nullable
  PorterDuff.Mode getCompoundDrawableTintMode() {
    TintInfo tintInfo = this.mDrawableTint;
    return (tintInfo != null) ? tintInfo.mTintMode : null;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  boolean isAutoSizeEnabled() {
    return this.mAutoSizeTextHelper.isAutoSizeEnabled();
  }
  
  @SuppressLint({"NewApi"})
  void loadFromAttributes(@Nullable AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mView : Landroid/widget/TextView;
    //   4: invokevirtual getContext : ()Landroid/content/Context;
    //   7: astore #16
    //   9: invokestatic get : ()Landroidx/appcompat/widget/AppCompatDrawableManager;
    //   12: astore #15
    //   14: aload #16
    //   16: aload_1
    //   17: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper : [I
    //   20: iload_2
    //   21: iconst_0
    //   22: invokestatic obtainStyledAttributes : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/TintTypedArray;
    //   25: astore #7
    //   27: aload_0
    //   28: getfield mView : Landroid/widget/TextView;
    //   31: astore #8
    //   33: aload #8
    //   35: aload #8
    //   37: invokevirtual getContext : ()Landroid/content/Context;
    //   40: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper : [I
    //   43: aload_1
    //   44: aload #7
    //   46: invokevirtual getWrappedTypeArray : ()Landroid/content/res/TypedArray;
    //   49: iload_2
    //   50: iconst_0
    //   51: invokestatic saveAttributeDataForStyleable : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   54: aload #7
    //   56: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper_android_textAppearance : I
    //   59: iconst_m1
    //   60: invokevirtual getResourceId : (II)I
    //   63: istore_3
    //   64: aload #7
    //   66: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper_android_drawableLeft : I
    //   69: invokevirtual hasValue : (I)Z
    //   72: ifeq -> 95
    //   75: aload_0
    //   76: aload #16
    //   78: aload #15
    //   80: aload #7
    //   82: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper_android_drawableLeft : I
    //   85: iconst_0
    //   86: invokevirtual getResourceId : (II)I
    //   89: invokestatic createTintInfo : (Landroid/content/Context;Landroidx/appcompat/widget/AppCompatDrawableManager;I)Landroidx/appcompat/widget/TintInfo;
    //   92: putfield mDrawableLeftTint : Landroidx/appcompat/widget/TintInfo;
    //   95: aload #7
    //   97: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper_android_drawableTop : I
    //   100: invokevirtual hasValue : (I)Z
    //   103: ifeq -> 126
    //   106: aload_0
    //   107: aload #16
    //   109: aload #15
    //   111: aload #7
    //   113: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper_android_drawableTop : I
    //   116: iconst_0
    //   117: invokevirtual getResourceId : (II)I
    //   120: invokestatic createTintInfo : (Landroid/content/Context;Landroidx/appcompat/widget/AppCompatDrawableManager;I)Landroidx/appcompat/widget/TintInfo;
    //   123: putfield mDrawableTopTint : Landroidx/appcompat/widget/TintInfo;
    //   126: aload #7
    //   128: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper_android_drawableRight : I
    //   131: invokevirtual hasValue : (I)Z
    //   134: ifeq -> 157
    //   137: aload_0
    //   138: aload #16
    //   140: aload #15
    //   142: aload #7
    //   144: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper_android_drawableRight : I
    //   147: iconst_0
    //   148: invokevirtual getResourceId : (II)I
    //   151: invokestatic createTintInfo : (Landroid/content/Context;Landroidx/appcompat/widget/AppCompatDrawableManager;I)Landroidx/appcompat/widget/TintInfo;
    //   154: putfield mDrawableRightTint : Landroidx/appcompat/widget/TintInfo;
    //   157: aload #7
    //   159: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper_android_drawableBottom : I
    //   162: invokevirtual hasValue : (I)Z
    //   165: ifeq -> 188
    //   168: aload_0
    //   169: aload #16
    //   171: aload #15
    //   173: aload #7
    //   175: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper_android_drawableBottom : I
    //   178: iconst_0
    //   179: invokevirtual getResourceId : (II)I
    //   182: invokestatic createTintInfo : (Landroid/content/Context;Landroidx/appcompat/widget/AppCompatDrawableManager;I)Landroidx/appcompat/widget/TintInfo;
    //   185: putfield mDrawableBottomTint : Landroidx/appcompat/widget/TintInfo;
    //   188: getstatic android/os/Build$VERSION.SDK_INT : I
    //   191: istore #4
    //   193: aload #7
    //   195: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper_android_drawableStart : I
    //   198: invokevirtual hasValue : (I)Z
    //   201: ifeq -> 224
    //   204: aload_0
    //   205: aload #16
    //   207: aload #15
    //   209: aload #7
    //   211: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper_android_drawableStart : I
    //   214: iconst_0
    //   215: invokevirtual getResourceId : (II)I
    //   218: invokestatic createTintInfo : (Landroid/content/Context;Landroidx/appcompat/widget/AppCompatDrawableManager;I)Landroidx/appcompat/widget/TintInfo;
    //   221: putfield mDrawableStartTint : Landroidx/appcompat/widget/TintInfo;
    //   224: aload #7
    //   226: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper_android_drawableEnd : I
    //   229: invokevirtual hasValue : (I)Z
    //   232: ifeq -> 255
    //   235: aload_0
    //   236: aload #16
    //   238: aload #15
    //   240: aload #7
    //   242: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper_android_drawableEnd : I
    //   245: iconst_0
    //   246: invokevirtual getResourceId : (II)I
    //   249: invokestatic createTintInfo : (Landroid/content/Context;Landroidx/appcompat/widget/AppCompatDrawableManager;I)Landroidx/appcompat/widget/TintInfo;
    //   252: putfield mDrawableEndTint : Landroidx/appcompat/widget/TintInfo;
    //   255: aload #7
    //   257: invokevirtual recycle : ()V
    //   260: aload_0
    //   261: getfield mView : Landroid/widget/TextView;
    //   264: invokevirtual getTransformationMethod : ()Landroid/text/method/TransformationMethod;
    //   267: instanceof android/text/method/PasswordTransformationMethod
    //   270: istore #6
    //   272: iload_3
    //   273: iconst_m1
    //   274: if_icmpeq -> 524
    //   277: aload #16
    //   279: iload_3
    //   280: getstatic androidx/appcompat/R$styleable.TextAppearance : [I
    //   283: invokestatic obtainStyledAttributes : (Landroid/content/Context;I[I)Landroidx/appcompat/widget/TintTypedArray;
    //   286: astore #13
    //   288: iload #6
    //   290: ifne -> 320
    //   293: aload #13
    //   295: getstatic androidx/appcompat/R$styleable.TextAppearance_textAllCaps : I
    //   298: invokevirtual hasValue : (I)Z
    //   301: ifeq -> 320
    //   304: aload #13
    //   306: getstatic androidx/appcompat/R$styleable.TextAppearance_textAllCaps : I
    //   309: iconst_0
    //   310: invokevirtual getBoolean : (IZ)Z
    //   313: istore #5
    //   315: iconst_1
    //   316: istore_3
    //   317: goto -> 325
    //   320: iconst_0
    //   321: istore #5
    //   323: iconst_0
    //   324: istore_3
    //   325: aload_0
    //   326: aload #16
    //   328: aload #13
    //   330: invokespecial updateTypefaceAndStyle : (Landroid/content/Context;Landroidx/appcompat/widget/TintTypedArray;)V
    //   333: iload #4
    //   335: bipush #23
    //   337: if_icmpge -> 434
    //   340: aload #13
    //   342: getstatic androidx/appcompat/R$styleable.TextAppearance_android_textColor : I
    //   345: invokevirtual hasValue : (I)Z
    //   348: ifeq -> 364
    //   351: aload #13
    //   353: getstatic androidx/appcompat/R$styleable.TextAppearance_android_textColor : I
    //   356: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   359: astore #7
    //   361: goto -> 367
    //   364: aconst_null
    //   365: astore #7
    //   367: aload #13
    //   369: getstatic androidx/appcompat/R$styleable.TextAppearance_android_textColorHint : I
    //   372: invokevirtual hasValue : (I)Z
    //   375: ifeq -> 391
    //   378: aload #13
    //   380: getstatic androidx/appcompat/R$styleable.TextAppearance_android_textColorHint : I
    //   383: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   386: astore #8
    //   388: goto -> 394
    //   391: aconst_null
    //   392: astore #8
    //   394: aload #7
    //   396: astore #10
    //   398: aload #8
    //   400: astore #9
    //   402: aload #13
    //   404: getstatic androidx/appcompat/R$styleable.TextAppearance_android_textColorLink : I
    //   407: invokevirtual hasValue : (I)Z
    //   410: ifeq -> 440
    //   413: aload #13
    //   415: getstatic androidx/appcompat/R$styleable.TextAppearance_android_textColorLink : I
    //   418: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   421: astore #11
    //   423: aload #7
    //   425: astore #10
    //   427: aload #8
    //   429: astore #7
    //   431: goto -> 447
    //   434: aconst_null
    //   435: astore #10
    //   437: aconst_null
    //   438: astore #9
    //   440: aconst_null
    //   441: astore #11
    //   443: aload #9
    //   445: astore #7
    //   447: aload #13
    //   449: getstatic androidx/appcompat/R$styleable.TextAppearance_textLocale : I
    //   452: invokevirtual hasValue : (I)Z
    //   455: ifeq -> 471
    //   458: aload #13
    //   460: getstatic androidx/appcompat/R$styleable.TextAppearance_textLocale : I
    //   463: invokevirtual getString : (I)Ljava/lang/String;
    //   466: astore #12
    //   468: goto -> 474
    //   471: aconst_null
    //   472: astore #12
    //   474: iload #4
    //   476: bipush #26
    //   478: if_icmplt -> 505
    //   481: aload #13
    //   483: getstatic androidx/appcompat/R$styleable.TextAppearance_fontVariationSettings : I
    //   486: invokevirtual hasValue : (I)Z
    //   489: ifeq -> 505
    //   492: aload #13
    //   494: getstatic androidx/appcompat/R$styleable.TextAppearance_fontVariationSettings : I
    //   497: invokevirtual getString : (I)Ljava/lang/String;
    //   500: astore #9
    //   502: goto -> 508
    //   505: aconst_null
    //   506: astore #9
    //   508: aload #13
    //   510: invokevirtual recycle : ()V
    //   513: aload #10
    //   515: astore #8
    //   517: aload #12
    //   519: astore #10
    //   521: goto -> 544
    //   524: aconst_null
    //   525: astore #9
    //   527: aconst_null
    //   528: astore #8
    //   530: aconst_null
    //   531: astore #10
    //   533: iconst_0
    //   534: istore #5
    //   536: aconst_null
    //   537: astore #7
    //   539: aconst_null
    //   540: astore #11
    //   542: iconst_0
    //   543: istore_3
    //   544: aload #16
    //   546: aload_1
    //   547: getstatic androidx/appcompat/R$styleable.TextAppearance : [I
    //   550: iload_2
    //   551: iconst_0
    //   552: invokestatic obtainStyledAttributes : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/TintTypedArray;
    //   555: astore #17
    //   557: iload #6
    //   559: ifne -> 589
    //   562: aload #17
    //   564: getstatic androidx/appcompat/R$styleable.TextAppearance_textAllCaps : I
    //   567: invokevirtual hasValue : (I)Z
    //   570: ifeq -> 589
    //   573: aload #17
    //   575: getstatic androidx/appcompat/R$styleable.TextAppearance_textAllCaps : I
    //   578: iconst_0
    //   579: invokevirtual getBoolean : (IZ)Z
    //   582: istore #5
    //   584: iconst_1
    //   585: istore_3
    //   586: goto -> 589
    //   589: aload #8
    //   591: astore #12
    //   593: aload #7
    //   595: astore #13
    //   597: aload #11
    //   599: astore #14
    //   601: iload #4
    //   603: bipush #23
    //   605: if_icmpge -> 691
    //   608: aload #17
    //   610: getstatic androidx/appcompat/R$styleable.TextAppearance_android_textColor : I
    //   613: invokevirtual hasValue : (I)Z
    //   616: ifeq -> 629
    //   619: aload #17
    //   621: getstatic androidx/appcompat/R$styleable.TextAppearance_android_textColor : I
    //   624: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   627: astore #8
    //   629: aload #17
    //   631: getstatic androidx/appcompat/R$styleable.TextAppearance_android_textColorHint : I
    //   634: invokevirtual hasValue : (I)Z
    //   637: ifeq -> 650
    //   640: aload #17
    //   642: getstatic androidx/appcompat/R$styleable.TextAppearance_android_textColorHint : I
    //   645: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   648: astore #7
    //   650: aload #8
    //   652: astore #12
    //   654: aload #7
    //   656: astore #13
    //   658: aload #11
    //   660: astore #14
    //   662: aload #17
    //   664: getstatic androidx/appcompat/R$styleable.TextAppearance_android_textColorLink : I
    //   667: invokevirtual hasValue : (I)Z
    //   670: ifeq -> 691
    //   673: aload #17
    //   675: getstatic androidx/appcompat/R$styleable.TextAppearance_android_textColorLink : I
    //   678: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   681: astore #14
    //   683: aload #7
    //   685: astore #13
    //   687: aload #8
    //   689: astore #12
    //   691: aload #17
    //   693: getstatic androidx/appcompat/R$styleable.TextAppearance_textLocale : I
    //   696: invokevirtual hasValue : (I)Z
    //   699: ifeq -> 712
    //   702: aload #17
    //   704: getstatic androidx/appcompat/R$styleable.TextAppearance_textLocale : I
    //   707: invokevirtual getString : (I)Ljava/lang/String;
    //   710: astore #10
    //   712: aload #9
    //   714: astore #7
    //   716: iload #4
    //   718: bipush #26
    //   720: if_icmplt -> 748
    //   723: aload #9
    //   725: astore #7
    //   727: aload #17
    //   729: getstatic androidx/appcompat/R$styleable.TextAppearance_fontVariationSettings : I
    //   732: invokevirtual hasValue : (I)Z
    //   735: ifeq -> 748
    //   738: aload #17
    //   740: getstatic androidx/appcompat/R$styleable.TextAppearance_fontVariationSettings : I
    //   743: invokevirtual getString : (I)Ljava/lang/String;
    //   746: astore #7
    //   748: iload #4
    //   750: bipush #28
    //   752: if_icmplt -> 790
    //   755: aload #17
    //   757: getstatic androidx/appcompat/R$styleable.TextAppearance_android_textSize : I
    //   760: invokevirtual hasValue : (I)Z
    //   763: ifeq -> 790
    //   766: aload #17
    //   768: getstatic androidx/appcompat/R$styleable.TextAppearance_android_textSize : I
    //   771: iconst_m1
    //   772: invokevirtual getDimensionPixelSize : (II)I
    //   775: ifne -> 790
    //   778: aload_0
    //   779: getfield mView : Landroid/widget/TextView;
    //   782: iconst_0
    //   783: fconst_0
    //   784: invokevirtual setTextSize : (IF)V
    //   787: goto -> 790
    //   790: aload_0
    //   791: aload #16
    //   793: aload #17
    //   795: invokespecial updateTypefaceAndStyle : (Landroid/content/Context;Landroidx/appcompat/widget/TintTypedArray;)V
    //   798: aload #17
    //   800: invokevirtual recycle : ()V
    //   803: aload #12
    //   805: ifnull -> 817
    //   808: aload_0
    //   809: getfield mView : Landroid/widget/TextView;
    //   812: aload #12
    //   814: invokevirtual setTextColor : (Landroid/content/res/ColorStateList;)V
    //   817: aload #13
    //   819: ifnull -> 831
    //   822: aload_0
    //   823: getfield mView : Landroid/widget/TextView;
    //   826: aload #13
    //   828: invokevirtual setHintTextColor : (Landroid/content/res/ColorStateList;)V
    //   831: aload #14
    //   833: ifnull -> 845
    //   836: aload_0
    //   837: getfield mView : Landroid/widget/TextView;
    //   840: aload #14
    //   842: invokevirtual setLinkTextColor : (Landroid/content/res/ColorStateList;)V
    //   845: iload #6
    //   847: ifne -> 860
    //   850: iload_3
    //   851: ifeq -> 860
    //   854: aload_0
    //   855: iload #5
    //   857: invokevirtual setAllCaps : (Z)V
    //   860: aload_0
    //   861: getfield mFontTypeface : Landroid/graphics/Typeface;
    //   864: astore #8
    //   866: aload #8
    //   868: ifnull -> 904
    //   871: aload_0
    //   872: getfield mFontWeight : I
    //   875: iconst_m1
    //   876: if_icmpne -> 895
    //   879: aload_0
    //   880: getfield mView : Landroid/widget/TextView;
    //   883: aload #8
    //   885: aload_0
    //   886: getfield mStyle : I
    //   889: invokevirtual setTypeface : (Landroid/graphics/Typeface;I)V
    //   892: goto -> 904
    //   895: aload_0
    //   896: getfield mView : Landroid/widget/TextView;
    //   899: aload #8
    //   901: invokevirtual setTypeface : (Landroid/graphics/Typeface;)V
    //   904: aload #7
    //   906: ifnull -> 919
    //   909: aload_0
    //   910: getfield mView : Landroid/widget/TextView;
    //   913: aload #7
    //   915: invokestatic setFontVariationSettings : (Landroid/widget/TextView;Ljava/lang/String;)Z
    //   918: pop
    //   919: aload #10
    //   921: ifnull -> 970
    //   924: iload #4
    //   926: bipush #24
    //   928: if_icmplt -> 946
    //   931: aload_0
    //   932: getfield mView : Landroid/widget/TextView;
    //   935: aload #10
    //   937: invokestatic forLanguageTags : (Ljava/lang/String;)Landroid/os/LocaleList;
    //   940: invokestatic setTextLocales : (Landroid/widget/TextView;Landroid/os/LocaleList;)V
    //   943: goto -> 970
    //   946: aload #10
    //   948: ldc_w ','
    //   951: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   954: iconst_0
    //   955: aaload
    //   956: astore #7
    //   958: aload_0
    //   959: getfield mView : Landroid/widget/TextView;
    //   962: aload #7
    //   964: invokestatic forLanguageTag : (Ljava/lang/String;)Ljava/util/Locale;
    //   967: invokestatic setTextLocale : (Landroid/widget/TextView;Ljava/util/Locale;)V
    //   970: aload_0
    //   971: getfield mAutoSizeTextHelper : Landroidx/appcompat/widget/AppCompatTextViewAutoSizeHelper;
    //   974: aload_1
    //   975: iload_2
    //   976: invokevirtual loadFromAttributes : (Landroid/util/AttributeSet;I)V
    //   979: getstatic androidx/appcompat/widget/ViewUtils.SDK_LEVEL_SUPPORTS_AUTOSIZE : Z
    //   982: ifeq -> 1067
    //   985: aload_0
    //   986: getfield mAutoSizeTextHelper : Landroidx/appcompat/widget/AppCompatTextViewAutoSizeHelper;
    //   989: invokevirtual getAutoSizeTextType : ()I
    //   992: ifeq -> 1067
    //   995: aload_0
    //   996: getfield mAutoSizeTextHelper : Landroidx/appcompat/widget/AppCompatTextViewAutoSizeHelper;
    //   999: invokevirtual getAutoSizeTextAvailableSizes : ()[I
    //   1002: astore #7
    //   1004: aload #7
    //   1006: arraylength
    //   1007: ifle -> 1067
    //   1010: aload_0
    //   1011: getfield mView : Landroid/widget/TextView;
    //   1014: invokestatic getAutoSizeStepGranularity : (Landroid/widget/TextView;)I
    //   1017: i2f
    //   1018: ldc_w -1.0
    //   1021: fcmpl
    //   1022: ifeq -> 1057
    //   1025: aload_0
    //   1026: getfield mView : Landroid/widget/TextView;
    //   1029: aload_0
    //   1030: getfield mAutoSizeTextHelper : Landroidx/appcompat/widget/AppCompatTextViewAutoSizeHelper;
    //   1033: invokevirtual getAutoSizeMinTextSize : ()I
    //   1036: aload_0
    //   1037: getfield mAutoSizeTextHelper : Landroidx/appcompat/widget/AppCompatTextViewAutoSizeHelper;
    //   1040: invokevirtual getAutoSizeMaxTextSize : ()I
    //   1043: aload_0
    //   1044: getfield mAutoSizeTextHelper : Landroidx/appcompat/widget/AppCompatTextViewAutoSizeHelper;
    //   1047: invokevirtual getAutoSizeStepGranularity : ()I
    //   1050: iconst_0
    //   1051: invokestatic setAutoSizeTextTypeUniformWithConfiguration : (Landroid/widget/TextView;IIII)V
    //   1054: goto -> 1067
    //   1057: aload_0
    //   1058: getfield mView : Landroid/widget/TextView;
    //   1061: aload #7
    //   1063: iconst_0
    //   1064: invokestatic setAutoSizeTextTypeUniformWithPresetSizes : (Landroid/widget/TextView;[II)V
    //   1067: aload #16
    //   1069: aload_1
    //   1070: getstatic androidx/appcompat/R$styleable.AppCompatTextView : [I
    //   1073: invokestatic obtainStyledAttributes : (Landroid/content/Context;Landroid/util/AttributeSet;[I)Landroidx/appcompat/widget/TintTypedArray;
    //   1076: astore #12
    //   1078: aload #12
    //   1080: getstatic androidx/appcompat/R$styleable.AppCompatTextView_drawableLeftCompat : I
    //   1083: iconst_m1
    //   1084: invokevirtual getResourceId : (II)I
    //   1087: istore_2
    //   1088: iload_2
    //   1089: iconst_m1
    //   1090: if_icmpeq -> 1105
    //   1093: aload #15
    //   1095: aload #16
    //   1097: iload_2
    //   1098: invokevirtual getDrawable : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1101: astore_1
    //   1102: goto -> 1107
    //   1105: aconst_null
    //   1106: astore_1
    //   1107: aload #12
    //   1109: getstatic androidx/appcompat/R$styleable.AppCompatTextView_drawableTopCompat : I
    //   1112: iconst_m1
    //   1113: invokevirtual getResourceId : (II)I
    //   1116: istore_2
    //   1117: iload_2
    //   1118: iconst_m1
    //   1119: if_icmpeq -> 1135
    //   1122: aload #15
    //   1124: aload #16
    //   1126: iload_2
    //   1127: invokevirtual getDrawable : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1130: astore #7
    //   1132: goto -> 1138
    //   1135: aconst_null
    //   1136: astore #7
    //   1138: aload #12
    //   1140: getstatic androidx/appcompat/R$styleable.AppCompatTextView_drawableRightCompat : I
    //   1143: iconst_m1
    //   1144: invokevirtual getResourceId : (II)I
    //   1147: istore_2
    //   1148: iload_2
    //   1149: iconst_m1
    //   1150: if_icmpeq -> 1166
    //   1153: aload #15
    //   1155: aload #16
    //   1157: iload_2
    //   1158: invokevirtual getDrawable : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1161: astore #8
    //   1163: goto -> 1169
    //   1166: aconst_null
    //   1167: astore #8
    //   1169: aload #12
    //   1171: getstatic androidx/appcompat/R$styleable.AppCompatTextView_drawableBottomCompat : I
    //   1174: iconst_m1
    //   1175: invokevirtual getResourceId : (II)I
    //   1178: istore_2
    //   1179: iload_2
    //   1180: iconst_m1
    //   1181: if_icmpeq -> 1197
    //   1184: aload #15
    //   1186: aload #16
    //   1188: iload_2
    //   1189: invokevirtual getDrawable : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1192: astore #9
    //   1194: goto -> 1200
    //   1197: aconst_null
    //   1198: astore #9
    //   1200: aload #12
    //   1202: getstatic androidx/appcompat/R$styleable.AppCompatTextView_drawableStartCompat : I
    //   1205: iconst_m1
    //   1206: invokevirtual getResourceId : (II)I
    //   1209: istore_2
    //   1210: iload_2
    //   1211: iconst_m1
    //   1212: if_icmpeq -> 1228
    //   1215: aload #15
    //   1217: aload #16
    //   1219: iload_2
    //   1220: invokevirtual getDrawable : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1223: astore #10
    //   1225: goto -> 1231
    //   1228: aconst_null
    //   1229: astore #10
    //   1231: aload #12
    //   1233: getstatic androidx/appcompat/R$styleable.AppCompatTextView_drawableEndCompat : I
    //   1236: iconst_m1
    //   1237: invokevirtual getResourceId : (II)I
    //   1240: istore_2
    //   1241: iload_2
    //   1242: iconst_m1
    //   1243: if_icmpeq -> 1259
    //   1246: aload #15
    //   1248: aload #16
    //   1250: iload_2
    //   1251: invokevirtual getDrawable : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1254: astore #11
    //   1256: goto -> 1262
    //   1259: aconst_null
    //   1260: astore #11
    //   1262: aload_0
    //   1263: aload_1
    //   1264: aload #7
    //   1266: aload #8
    //   1268: aload #9
    //   1270: aload #10
    //   1272: aload #11
    //   1274: invokespecial setCompoundDrawables : (Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   1277: aload #12
    //   1279: getstatic androidx/appcompat/R$styleable.AppCompatTextView_drawableTint : I
    //   1282: invokevirtual hasValue : (I)Z
    //   1285: ifeq -> 1305
    //   1288: aload #12
    //   1290: getstatic androidx/appcompat/R$styleable.AppCompatTextView_drawableTint : I
    //   1293: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   1296: astore_1
    //   1297: aload_0
    //   1298: getfield mView : Landroid/widget/TextView;
    //   1301: aload_1
    //   1302: invokestatic setCompoundDrawableTintList : (Landroid/widget/TextView;Landroid/content/res/ColorStateList;)V
    //   1305: aload #12
    //   1307: getstatic androidx/appcompat/R$styleable.AppCompatTextView_drawableTintMode : I
    //   1310: invokevirtual hasValue : (I)Z
    //   1313: ifeq -> 1341
    //   1316: aload #12
    //   1318: getstatic androidx/appcompat/R$styleable.AppCompatTextView_drawableTintMode : I
    //   1321: iconst_m1
    //   1322: invokevirtual getInt : (II)I
    //   1325: aconst_null
    //   1326: invokestatic parseTintMode : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;
    //   1329: astore_1
    //   1330: aload_0
    //   1331: getfield mView : Landroid/widget/TextView;
    //   1334: aload_1
    //   1335: invokestatic setCompoundDrawableTintMode : (Landroid/widget/TextView;Landroid/graphics/PorterDuff$Mode;)V
    //   1338: goto -> 1341
    //   1341: aload #12
    //   1343: getstatic androidx/appcompat/R$styleable.AppCompatTextView_firstBaselineToTopHeight : I
    //   1346: iconst_m1
    //   1347: invokevirtual getDimensionPixelSize : (II)I
    //   1350: istore_2
    //   1351: aload #12
    //   1353: getstatic androidx/appcompat/R$styleable.AppCompatTextView_lastBaselineToBottomHeight : I
    //   1356: iconst_m1
    //   1357: invokevirtual getDimensionPixelSize : (II)I
    //   1360: istore_3
    //   1361: aload #12
    //   1363: getstatic androidx/appcompat/R$styleable.AppCompatTextView_lineHeight : I
    //   1366: iconst_m1
    //   1367: invokevirtual getDimensionPixelSize : (II)I
    //   1370: istore #4
    //   1372: aload #12
    //   1374: invokevirtual recycle : ()V
    //   1377: iload_2
    //   1378: iconst_m1
    //   1379: if_icmpeq -> 1390
    //   1382: aload_0
    //   1383: getfield mView : Landroid/widget/TextView;
    //   1386: iload_2
    //   1387: invokestatic setFirstBaselineToTopHeight : (Landroid/widget/TextView;I)V
    //   1390: iload_3
    //   1391: iconst_m1
    //   1392: if_icmpeq -> 1403
    //   1395: aload_0
    //   1396: getfield mView : Landroid/widget/TextView;
    //   1399: iload_3
    //   1400: invokestatic setLastBaselineToBottomHeight : (Landroid/widget/TextView;I)V
    //   1403: iload #4
    //   1405: iconst_m1
    //   1406: if_icmpeq -> 1418
    //   1409: aload_0
    //   1410: getfield mView : Landroid/widget/TextView;
    //   1413: iload #4
    //   1415: invokestatic setLineHeight : (Landroid/widget/TextView;I)V
    //   1418: return
  }
  
  void onAsyncTypefaceReceived(WeakReference<TextView> paramWeakReference, final Typeface typeface) {
    if (this.mAsyncFontPending) {
      this.mFontTypeface = typeface;
      final TextView textView = paramWeakReference.get();
      if (textView != null) {
        if (ViewCompat.isAttachedToWindow((View)textView)) {
          textView.post(new Runnable() {
                public void run() {
                  textView.setTypeface(typeface, style);
                }
              });
          return;
        } 
        textView.setTypeface(typeface, this.mStyle);
      } 
    } 
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!ViewUtils.SDK_LEVEL_SUPPORTS_AUTOSIZE)
      autoSizeText(); 
  }
  
  void onSetCompoundDrawables() {
    applyCompoundDrawablesTints();
  }
  
  void onSetTextAppearance(Context paramContext, int paramInt) {
    TintTypedArray tintTypedArray = TintTypedArray.obtainStyledAttributes(paramContext, paramInt, R.styleable.TextAppearance);
    if (tintTypedArray.hasValue(R.styleable.TextAppearance_textAllCaps))
      setAllCaps(tintTypedArray.getBoolean(R.styleable.TextAppearance_textAllCaps, false)); 
    paramInt = Build.VERSION.SDK_INT;
    if (paramInt < 23) {
      if (tintTypedArray.hasValue(R.styleable.TextAppearance_android_textColor)) {
        ColorStateList colorStateList = tintTypedArray.getColorStateList(R.styleable.TextAppearance_android_textColor);
        if (colorStateList != null)
          this.mView.setTextColor(colorStateList); 
      } 
      if (tintTypedArray.hasValue(R.styleable.TextAppearance_android_textColorLink)) {
        ColorStateList colorStateList = tintTypedArray.getColorStateList(R.styleable.TextAppearance_android_textColorLink);
        if (colorStateList != null)
          this.mView.setLinkTextColor(colorStateList); 
      } 
      if (tintTypedArray.hasValue(R.styleable.TextAppearance_android_textColorHint)) {
        ColorStateList colorStateList = tintTypedArray.getColorStateList(R.styleable.TextAppearance_android_textColorHint);
        if (colorStateList != null)
          this.mView.setHintTextColor(colorStateList); 
      } 
    } 
    if (tintTypedArray.hasValue(R.styleable.TextAppearance_android_textSize) && tintTypedArray.getDimensionPixelSize(R.styleable.TextAppearance_android_textSize, -1) == 0)
      this.mView.setTextSize(0, 0.0F); 
    updateTypefaceAndStyle(paramContext, tintTypedArray);
    if (paramInt >= 26 && tintTypedArray.hasValue(R.styleable.TextAppearance_fontVariationSettings)) {
      String str = tintTypedArray.getString(R.styleable.TextAppearance_fontVariationSettings);
      if (str != null)
        Api26Impl.setFontVariationSettings(this.mView, str); 
    } 
    tintTypedArray.recycle();
    Typeface typeface = this.mFontTypeface;
    if (typeface != null)
      this.mView.setTypeface(typeface, this.mStyle); 
  }
  
  void populateSurroundingTextIfNeeded(@NonNull TextView paramTextView, @Nullable InputConnection paramInputConnection, @NonNull EditorInfo paramEditorInfo) {
    if (Build.VERSION.SDK_INT < 30 && paramInputConnection != null)
      EditorInfoCompat.setInitialSurroundingText(paramEditorInfo, paramTextView.getText()); 
  }
  
  void setAllCaps(boolean paramBoolean) {
    this.mView.setAllCaps(paramBoolean);
  }
  
  void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws IllegalArgumentException {
    this.mAutoSizeTextHelper.setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  void setAutoSizeTextTypeUniformWithPresetSizes(@NonNull int[] paramArrayOfint, int paramInt) throws IllegalArgumentException {
    this.mAutoSizeTextHelper.setAutoSizeTextTypeUniformWithPresetSizes(paramArrayOfint, paramInt);
  }
  
  void setAutoSizeTextTypeWithDefaults(int paramInt) {
    this.mAutoSizeTextHelper.setAutoSizeTextTypeWithDefaults(paramInt);
  }
  
  void setCompoundDrawableTintList(@Nullable ColorStateList paramColorStateList) {
    boolean bool;
    if (this.mDrawableTint == null)
      this.mDrawableTint = new TintInfo(); 
    TintInfo tintInfo = this.mDrawableTint;
    tintInfo.mTintList = paramColorStateList;
    if (paramColorStateList != null) {
      bool = true;
    } else {
      bool = false;
    } 
    tintInfo.mHasTintList = bool;
    setCompoundTints();
  }
  
  void setCompoundDrawableTintMode(@Nullable PorterDuff.Mode paramMode) {
    boolean bool;
    if (this.mDrawableTint == null)
      this.mDrawableTint = new TintInfo(); 
    TintInfo tintInfo = this.mDrawableTint;
    tintInfo.mTintMode = paramMode;
    if (paramMode != null) {
      bool = true;
    } else {
      bool = false;
    } 
    tintInfo.mHasTintMode = bool;
    setCompoundTints();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  void setTextSize(int paramInt, float paramFloat) {
    if (!ViewUtils.SDK_LEVEL_SUPPORTS_AUTOSIZE && !isAutoSizeEnabled())
      setTextSizeInternal(paramInt, paramFloat); 
  }
  
  @RequiresApi(17)
  static class Api17Impl {
    @DoNotInline
    static Drawable[] getCompoundDrawablesRelative(TextView param1TextView) {
      return param1TextView.getCompoundDrawablesRelative();
    }
    
    @DoNotInline
    static void setCompoundDrawablesRelativeWithIntrinsicBounds(TextView param1TextView, Drawable param1Drawable1, Drawable param1Drawable2, Drawable param1Drawable3, Drawable param1Drawable4) {
      param1TextView.setCompoundDrawablesRelativeWithIntrinsicBounds(param1Drawable1, param1Drawable2, param1Drawable3, param1Drawable4);
    }
    
    @DoNotInline
    static void setTextLocale(TextView param1TextView, Locale param1Locale) {
      param1TextView.setTextLocale(param1Locale);
    }
  }
  
  @RequiresApi(21)
  static class Api21Impl {
    @DoNotInline
    static Locale forLanguageTag(String param1String) {
      return Locale.forLanguageTag(param1String);
    }
  }
  
  @RequiresApi(24)
  static class Api24Impl {
    @DoNotInline
    static LocaleList forLanguageTags(String param1String) {
      return c.a(param1String);
    }
    
    @DoNotInline
    static void setTextLocales(TextView param1TextView, LocaleList param1LocaleList) {
      j0.a(param1TextView, param1LocaleList);
    }
  }
  
  @RequiresApi(26)
  static class Api26Impl {
    @DoNotInline
    static int getAutoSizeStepGranularity(TextView param1TextView) {
      return m0.a(param1TextView);
    }
    
    @DoNotInline
    static void setAutoSizeTextTypeUniformWithConfiguration(TextView param1TextView, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      l0.a(param1TextView, param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    @DoNotInline
    static void setAutoSizeTextTypeUniformWithPresetSizes(TextView param1TextView, int[] param1ArrayOfint, int param1Int) {
      n0.a(param1TextView, param1ArrayOfint, param1Int);
    }
    
    @DoNotInline
    static boolean setFontVariationSettings(TextView param1TextView, String param1String) {
      return k0.a(param1TextView, param1String);
    }
  }
  
  @RequiresApi(28)
  static class Api28Impl {
    @DoNotInline
    static Typeface create(Typeface param1Typeface, int param1Int, boolean param1Boolean) {
      return o0.a(param1Typeface, param1Int, param1Boolean);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\appcompat\widget\AppCompatTextHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */