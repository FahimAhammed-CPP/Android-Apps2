package androidx.appcompat.widget;

import android.view.inspector.InspectionCompanion;
import android.view.inspector.PropertyMapper;
import android.view.inspector.PropertyReader;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.appcompat.R;

@RequiresApi(29)
@RestrictTo({RestrictTo.Scope.LIBRARY})
public final class SwitchCompat$InspectionCompanion implements InspectionCompanion<SwitchCompat> {
  private boolean mPropertiesMapped = false;
  
  private int mShowTextId;
  
  private int mSplitTrackId;
  
  private int mSwitchMinWidthId;
  
  private int mSwitchPaddingId;
  
  private int mTextOffId;
  
  private int mTextOnId;
  
  private int mThumbId;
  
  private int mThumbTextPaddingId;
  
  private int mThumbTintId;
  
  private int mThumbTintModeId;
  
  private int mTrackId;
  
  private int mTrackTintId;
  
  private int mTrackTintModeId;
  
  public void mapProperties(@NonNull PropertyMapper paramPropertyMapper) {
    this.mTextOffId = b.a(paramPropertyMapper, "textOff", 16843045);
    this.mTextOnId = b.a(paramPropertyMapper, "textOn", 16843044);
    this.mThumbId = b.a(paramPropertyMapper, "thumb", 16843074);
    this.mShowTextId = j1.a(paramPropertyMapper, "showText", R.attr.showText);
    this.mSplitTrackId = j1.a(paramPropertyMapper, "splitTrack", R.attr.splitTrack);
    this.mSwitchMinWidthId = g.a(paramPropertyMapper, "switchMinWidth", R.attr.switchMinWidth);
    this.mSwitchPaddingId = g.a(paramPropertyMapper, "switchPadding", R.attr.switchPadding);
    this.mThumbTextPaddingId = g.a(paramPropertyMapper, "thumbTextPadding", R.attr.thumbTextPadding);
    this.mThumbTintId = b.a(paramPropertyMapper, "thumbTint", R.attr.thumbTint);
    this.mThumbTintModeId = b.a(paramPropertyMapper, "thumbTintMode", R.attr.thumbTintMode);
    this.mTrackId = b.a(paramPropertyMapper, "track", R.attr.track);
    this.mTrackTintId = b.a(paramPropertyMapper, "trackTint", R.attr.trackTint);
    this.mTrackTintModeId = b.a(paramPropertyMapper, "trackTintMode", R.attr.trackTintMode);
    this.mPropertiesMapped = true;
  }
  
  public void readProperties(@NonNull SwitchCompat paramSwitchCompat, @NonNull PropertyReader paramPropertyReader) {
    if (this.mPropertiesMapped) {
      a.a(paramPropertyReader, this.mTextOffId, paramSwitchCompat.getTextOff());
      a.a(paramPropertyReader, this.mTextOnId, paramSwitchCompat.getTextOn());
      a.a(paramPropertyReader, this.mThumbId, paramSwitchCompat.getThumbDrawable());
      n1.a(paramPropertyReader, this.mShowTextId, paramSwitchCompat.getShowText());
      n1.a(paramPropertyReader, this.mSplitTrackId, paramSwitchCompat.getSplitTrack());
      e.a(paramPropertyReader, this.mSwitchMinWidthId, paramSwitchCompat.getSwitchMinWidth());
      e.a(paramPropertyReader, this.mSwitchPaddingId, paramSwitchCompat.getSwitchPadding());
      e.a(paramPropertyReader, this.mThumbTextPaddingId, paramSwitchCompat.getThumbTextPadding());
      a.a(paramPropertyReader, this.mThumbTintId, paramSwitchCompat.getThumbTintList());
      a.a(paramPropertyReader, this.mThumbTintModeId, paramSwitchCompat.getThumbTintMode());
      a.a(paramPropertyReader, this.mTrackId, paramSwitchCompat.getTrackDrawable());
      a.a(paramPropertyReader, this.mTrackTintId, paramSwitchCompat.getTrackTintList());
      a.a(paramPropertyReader, this.mTrackTintModeId, paramSwitchCompat.getTrackTintMode());
      return;
    } 
    d.a();
    throw c.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\appcompat\widget\SwitchCompat$InspectionCompanion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */