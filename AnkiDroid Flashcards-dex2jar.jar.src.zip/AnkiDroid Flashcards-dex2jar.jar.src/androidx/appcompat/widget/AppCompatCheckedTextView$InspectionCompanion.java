package androidx.appcompat.widget;

import android.view.inspector.InspectionCompanion;
import android.view.inspector.PropertyMapper;
import android.view.inspector.PropertyReader;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.appcompat.R;

@RequiresApi(29)
@RestrictTo({RestrictTo.Scope.LIBRARY})
public final class AppCompatCheckedTextView$InspectionCompanion implements InspectionCompanion<AppCompatCheckedTextView> {
  private int mBackgroundTintId;
  
  private int mBackgroundTintModeId;
  
  private int mCheckMarkTintId;
  
  private int mCheckMarkTintModeId;
  
  private int mDrawableTintId;
  
  private int mDrawableTintModeId;
  
  private boolean mPropertiesMapped = false;
  
  public void mapProperties(@NonNull PropertyMapper paramPropertyMapper) {
    this.mBackgroundTintId = b.a(paramPropertyMapper, "backgroundTint", R.attr.backgroundTint);
    this.mBackgroundTintModeId = b.a(paramPropertyMapper, "backgroundTintMode", R.attr.backgroundTintMode);
    this.mCheckMarkTintId = b.a(paramPropertyMapper, "checkMarkTint", R.attr.checkMarkTint);
    this.mCheckMarkTintModeId = b.a(paramPropertyMapper, "checkMarkTintMode", R.attr.checkMarkTintMode);
    this.mDrawableTintId = b.a(paramPropertyMapper, "drawableTint", R.attr.drawableTint);
    this.mDrawableTintModeId = b.a(paramPropertyMapper, "drawableTintMode", R.attr.drawableTintMode);
    this.mPropertiesMapped = true;
  }
  
  public void readProperties(@NonNull AppCompatCheckedTextView paramAppCompatCheckedTextView, @NonNull PropertyReader paramPropertyReader) {
    if (this.mPropertiesMapped) {
      a.a(paramPropertyReader, this.mBackgroundTintId, paramAppCompatCheckedTextView.getBackgroundTintList());
      a.a(paramPropertyReader, this.mBackgroundTintModeId, paramAppCompatCheckedTextView.getBackgroundTintMode());
      a.a(paramPropertyReader, this.mCheckMarkTintId, paramAppCompatCheckedTextView.getCheckMarkTintList());
      a.a(paramPropertyReader, this.mCheckMarkTintModeId, paramAppCompatCheckedTextView.getCheckMarkTintMode());
      a.a(paramPropertyReader, this.mDrawableTintId, paramAppCompatCheckedTextView.getCompoundDrawableTintList());
      a.a(paramPropertyReader, this.mDrawableTintModeId, paramAppCompatCheckedTextView.getCompoundDrawableTintMode());
      return;
    } 
    d.a();
    throw c.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\appcompat\widget\AppCompatCheckedTextView$InspectionCompanion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */