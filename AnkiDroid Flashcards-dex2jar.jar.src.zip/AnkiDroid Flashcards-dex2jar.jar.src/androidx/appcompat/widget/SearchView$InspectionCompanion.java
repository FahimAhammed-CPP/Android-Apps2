package androidx.appcompat.widget;

import android.view.inspector.InspectionCompanion;
import android.view.inspector.PropertyMapper;
import android.view.inspector.PropertyReader;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.appcompat.R;

@RequiresApi(29)
@RestrictTo({RestrictTo.Scope.LIBRARY})
public final class SearchView$InspectionCompanion implements InspectionCompanion<SearchView> {
  private int mIconifiedByDefaultId;
  
  private int mImeOptionsId;
  
  private int mMaxWidthId;
  
  private boolean mPropertiesMapped = false;
  
  private int mQueryHintId;
  
  public void mapProperties(@NonNull PropertyMapper paramPropertyMapper) {
    this.mImeOptionsId = g.a(paramPropertyMapper, "imeOptions", 16843364);
    this.mMaxWidthId = g.a(paramPropertyMapper, "maxWidth", 16843039);
    this.mIconifiedByDefaultId = j1.a(paramPropertyMapper, "iconifiedByDefault", R.attr.iconifiedByDefault);
    this.mQueryHintId = b.a(paramPropertyMapper, "queryHint", R.attr.queryHint);
    this.mPropertiesMapped = true;
  }
  
  public void readProperties(@NonNull SearchView paramSearchView, @NonNull PropertyReader paramPropertyReader) {
    if (this.mPropertiesMapped) {
      e.a(paramPropertyReader, this.mImeOptionsId, paramSearchView.getImeOptions());
      e.a(paramPropertyReader, this.mMaxWidthId, paramSearchView.getMaxWidth());
      n1.a(paramPropertyReader, this.mIconifiedByDefaultId, paramSearchView.isIconfiedByDefault());
      a.a(paramPropertyReader, this.mQueryHintId, paramSearchView.getQueryHint());
      return;
    } 
    d.a();
    throw c.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\appcompat\widget\SearchView$InspectionCompanion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */