package androidx.activity;

import androidx.annotation.GuardedBy;
import androidx.annotation.RestrictTo;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;

@Metadata(d1 = {"\000<\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\000\n\002\030\002\n\002\020\002\n\002\b\002\n\002\020\013\n\002\b\003\n\002\020!\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\b\030\0002\0020\001B\033\022\006\020\002\032\0020\003\022\f\020\004\032\b\022\004\022\0020\0060\005¢\006\002\020\007J\024\020\024\032\0020\0062\f\020\025\032\b\022\004\022\0020\0060\005J\006\020\026\032\0020\006J\b\020\027\032\0020\006H\007J\b\020\030\032\0020\006H\002J\024\020\031\032\0020\0062\f\020\025\032\b\022\004\022\0020\0060\005J\006\020\032\032\0020\006R\016\020\002\032\0020\003X\004¢\006\002\n\000R\021\020\b\032\0020\t8F¢\006\006\032\004\b\b\020\nR\016\020\013\032\0020\001X\004¢\006\002\n\000R\034\020\f\032\016\022\n\022\b\022\004\022\0020\0060\0050\r8\002X\004¢\006\002\n\000R\024\020\004\032\b\022\004\022\0020\0060\005X\004¢\006\002\n\000R\022\020\016\032\0020\t8\002@\002X\016¢\006\002\n\000R\016\020\017\032\0020\020X\004¢\006\002\n\000R\022\020\021\032\0020\t8\002@\002X\016¢\006\002\n\000R\022\020\022\032\0020\0238\002@\002X\016¢\006\002\n\000¨\006\033"}, d2 = {"Landroidx/activity/FullyDrawnReporter;", "", "executor", "Ljava/util/concurrent/Executor;", "reportFullyDrawn", "Lkotlin/Function0;", "", "(Ljava/util/concurrent/Executor;Lkotlin/jvm/functions/Function0;)V", "isFullyDrawnReported", "", "()Z", "lock", "onReportCallbacks", "", "reportPosted", "reportRunnable", "Ljava/lang/Runnable;", "reportedFullyDrawn", "reporterCount", "", "addOnReportDrawnListener", "callback", "addReporter", "fullyDrawnReported", "postWhenReportersAreDone", "removeOnReportDrawnListener", "removeReporter", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nFullyDrawnReporter.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FullyDrawnReporter.kt\nandroidx/activity/FullyDrawnReporter\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,190:1\n1#2:191\n1855#3,2:192\n*S KotlinDebug\n*F\n+ 1 FullyDrawnReporter.kt\nandroidx/activity/FullyDrawnReporter\n*L\n154#1:192,2\n*E\n"})
public final class FullyDrawnReporter {
  @NotNull
  private final Executor executor;
  
  @NotNull
  private final Object lock;
  
  @GuardedBy("lock")
  @NotNull
  private final List<Function0<Unit>> onReportCallbacks;
  
  @NotNull
  private final Function0<Unit> reportFullyDrawn;
  
  @GuardedBy("lock")
  private boolean reportPosted;
  
  @NotNull
  private final Runnable reportRunnable;
  
  @GuardedBy("lock")
  private boolean reportedFullyDrawn;
  
  @GuardedBy("lock")
  private int reporterCount;
  
  public FullyDrawnReporter(@NotNull Executor paramExecutor, @NotNull Function0<Unit> paramFunction0) {
    this.executor = paramExecutor;
    this.reportFullyDrawn = paramFunction0;
    this.lock = new Object();
    this.onReportCallbacks = new ArrayList<Function0<Unit>>();
    this.reportRunnable = new m(this);
  }
  
  private final void postWhenReportersAreDone() {
    if (!this.reportPosted && this.reporterCount == 0) {
      this.reportPosted = true;
      this.executor.execute(this.reportRunnable);
    } 
  }
  
  private static final void reportRunnable$lambda$2(FullyDrawnReporter paramFullyDrawnReporter) {
    Intrinsics.checkNotNullParameter(paramFullyDrawnReporter, "this$0");
    synchronized (paramFullyDrawnReporter.lock) {
      paramFullyDrawnReporter.reportPosted = false;
      if (paramFullyDrawnReporter.reporterCount == 0 && !paramFullyDrawnReporter.reportedFullyDrawn) {
        paramFullyDrawnReporter.reportFullyDrawn.invoke();
        paramFullyDrawnReporter.fullyDrawnReported();
      } 
      Unit unit = Unit.INSTANCE;
      return;
    } 
  }
  
  public final void addOnReportDrawnListener(@NotNull Function0<Unit> paramFunction0) {
    Intrinsics.checkNotNullParameter(paramFunction0, "callback");
    synchronized (this.lock) {
      boolean bool;
      if (this.reportedFullyDrawn) {
        bool = true;
      } else {
        this.onReportCallbacks.add(paramFunction0);
        bool = false;
      } 
      if (bool)
        paramFunction0.invoke(); 
      return;
    } 
  }
  
  public final void addReporter() {
    synchronized (this.lock) {
      if (!this.reportedFullyDrawn)
        this.reporterCount++; 
      Unit unit = Unit.INSTANCE;
      return;
    } 
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public final void fullyDrawnReported() {
    synchronized (this.lock) {
      this.reportedFullyDrawn = true;
      Iterator<Function0<Unit>> iterator = this.onReportCallbacks.iterator();
      while (iterator.hasNext())
        ((Function0)iterator.next()).invoke(); 
      this.onReportCallbacks.clear();
      Unit unit = Unit.INSTANCE;
      return;
    } 
  }
  
  public final boolean isFullyDrawnReported() {
    synchronized (this.lock) {
      return this.reportedFullyDrawn;
    } 
  }
  
  public final void removeOnReportDrawnListener(@NotNull Function0<Unit> paramFunction0) {
    Intrinsics.checkNotNullParameter(paramFunction0, "callback");
    synchronized (this.lock) {
      this.onReportCallbacks.remove(paramFunction0);
      Unit unit = Unit.INSTANCE;
      return;
    } 
  }
  
  public final void removeReporter() {
    synchronized (this.lock) {
      if (!this.reportedFullyDrawn) {
        int i = this.reporterCount;
        if (i > 0) {
          this.reporterCount = i - 1;
          postWhenReportersAreDone();
        } 
      } 
      Unit unit = Unit.INSTANCE;
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\activity\FullyDrawnReporter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */