package androidx.activity.result;

import androidx.core.app.ActivityOptionsCompat;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.JvmName;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(d1 = {"\000\030\n\000\n\002\020\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\032\036\020\000\032\0020\001*\n\022\006\022\004\030\0010\0030\0022\n\b\002\020\004\032\004\030\0010\005\032#\020\000\032\0020\001*\b\022\004\022\0020\0010\0022\n\b\002\020\004\032\004\030\0010\005H\007¢\006\002\b\006¨\006\007"}, d2 = {"launch", "", "Landroidx/activity/result/ActivityResultLauncher;", "Ljava/lang/Void;", "options", "Landroidx/core/app/ActivityOptionsCompat;", "launchUnit", "activity-ktx_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class ActivityResultLauncherKt {
  public static final void launch(@NotNull ActivityResultLauncher<Void> paramActivityResultLauncher, @Nullable ActivityOptionsCompat paramActivityOptionsCompat) {
    Intrinsics.checkNotNullParameter(paramActivityResultLauncher, "<this>");
    paramActivityResultLauncher.launch(null, paramActivityOptionsCompat);
  }
  
  @JvmName(name = "launchUnit")
  public static final void launchUnit(@NotNull ActivityResultLauncher<Unit> paramActivityResultLauncher, @Nullable ActivityOptionsCompat paramActivityOptionsCompat) {
    Intrinsics.checkNotNullParameter(paramActivityResultLauncher, "<this>");
    paramActivityResultLauncher.launch(Unit.INSTANCE, paramActivityOptionsCompat);
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\activity\result\ActivityResultLauncherKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */