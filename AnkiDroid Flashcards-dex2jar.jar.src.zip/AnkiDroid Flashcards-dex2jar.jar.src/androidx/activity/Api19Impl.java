package androidx.activity;

import android.view.View;
import androidx.annotation.RequiresApi;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(d1 = {"\000\030\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\000\bÁ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\016\020\003\032\0020\0042\006\020\005\032\0020\006¨\006\007"}, d2 = {"Landroidx/activity/Api19Impl;", "", "()V", "isAttachedToWindow", "", "view", "Landroid/view/View;", "activity-ktx_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
@RequiresApi(19)
public final class Api19Impl {
  @NotNull
  public static final Api19Impl INSTANCE = new Api19Impl();
  
  public final boolean isAttachedToWindow(@NotNull View paramView) {
    Intrinsics.checkNotNullParameter(paramView, "view");
    return paramView.isAttachedToWindow();
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\activity\Api19Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */