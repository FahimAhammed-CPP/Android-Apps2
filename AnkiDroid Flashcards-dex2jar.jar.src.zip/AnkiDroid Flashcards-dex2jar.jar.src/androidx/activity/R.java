package androidx.activity;

public final class R {
  public static final class id {
    public static int report_drawn = 2131297112;
    
    public static int view_tree_on_back_pressed_dispatcher_owner = 2131297326;
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\activity\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */