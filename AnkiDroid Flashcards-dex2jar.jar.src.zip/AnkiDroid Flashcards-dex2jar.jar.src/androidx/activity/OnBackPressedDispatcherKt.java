package androidx.activity;

import androidx.lifecycle.LifecycleOwner;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(d1 = {"\000&\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\000\n\002\030\002\n\002\020\002\n\002\030\002\n\000\0329\020\000\032\0020\001*\0020\0022\n\b\002\020\003\032\004\030\0010\0042\b\b\002\020\005\032\0020\0062\027\020\007\032\023\022\004\022\0020\001\022\004\022\0020\t0\b¢\006\002\b\n¨\006\013"}, d2 = {"addCallback", "Landroidx/activity/OnBackPressedCallback;", "Landroidx/activity/OnBackPressedDispatcher;", "owner", "Landroidx/lifecycle/LifecycleOwner;", "enabled", "", "onBackPressed", "Lkotlin/Function1;", "", "Lkotlin/ExtensionFunctionType;", "activity_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class OnBackPressedDispatcherKt {
  @NotNull
  public static final OnBackPressedCallback addCallback(@NotNull OnBackPressedDispatcher paramOnBackPressedDispatcher, @Nullable LifecycleOwner paramLifecycleOwner, boolean paramBoolean, @NotNull Function1<? super OnBackPressedCallback, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramOnBackPressedDispatcher, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "onBackPressed");
    OnBackPressedDispatcherKt$addCallback$callback$1 onBackPressedDispatcherKt$addCallback$callback$1 = new OnBackPressedDispatcherKt$addCallback$callback$1(paramBoolean, paramFunction1);
    if (paramLifecycleOwner != null) {
      paramOnBackPressedDispatcher.addCallback(paramLifecycleOwner, onBackPressedDispatcherKt$addCallback$callback$1);
      return onBackPressedDispatcherKt$addCallback$callback$1;
    } 
    paramOnBackPressedDispatcher.addCallback(onBackPressedDispatcherKt$addCallback$callback$1);
    return onBackPressedDispatcherKt$addCallback$callback$1;
  }
  
  @Metadata(d1 = {"\000\021\n\000\n\002\030\002\n\000\n\002\020\002\n\000*\001\000\b\n\030\0002\0020\001J\b\020\002\032\0020\003H\026¨\006\004"}, d2 = {"androidx/activity/OnBackPressedDispatcherKt$addCallback$callback$1", "Landroidx/activity/OnBackPressedCallback;", "handleOnBackPressed", "", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class OnBackPressedDispatcherKt$addCallback$callback$1 extends OnBackPressedCallback {
    OnBackPressedDispatcherKt$addCallback$callback$1(boolean param1Boolean, Function1<? super OnBackPressedCallback, Unit> param1Function1) {
      super(param1Boolean);
    }
    
    public void handleOnBackPressed() {
      this.$onBackPressed.invoke(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\activity\OnBackPressedDispatcherKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */