package androidx.activity.contextaware;

import android.content.Context;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(d1 = {"\000\026\n\002\030\002\n\002\020\000\n\000\n\002\020\002\n\000\n\002\030\002\n\000\bæ\001\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H&ø\001\000\002\006\n\004\b!0\001¨\006\006À\006\001"}, d2 = {"Landroidx/activity/contextaware/OnContextAvailableListener;", "", "onContextAvailable", "", "context", "Landroid/content/Context;", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public interface OnContextAvailableListener {
  void onContextAvailable(@NotNull Context paramContext);
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\activity\contextaware\OnContextAvailableListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */