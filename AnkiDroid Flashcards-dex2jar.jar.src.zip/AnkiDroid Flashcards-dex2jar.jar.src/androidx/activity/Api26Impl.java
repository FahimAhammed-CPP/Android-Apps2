package androidx.activity;

import android.app.Activity;
import android.graphics.Rect;
import androidx.annotation.RequiresApi;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(d1 = {"\000\036\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\bÁ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\026\020\003\032\0020\0042\006\020\005\032\0020\0062\006\020\007\032\0020\b¨\006\t"}, d2 = {"Landroidx/activity/Api26Impl;", "", "()V", "setPipParamsSourceRectHint", "", "activity", "Landroid/app/Activity;", "hint", "Landroid/graphics/Rect;", "activity-ktx_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
@RequiresApi(26)
public final class Api26Impl {
  @NotNull
  public static final Api26Impl INSTANCE = new Api26Impl();
  
  public final void setPipParamsSourceRectHint(@NotNull Activity paramActivity, @NotNull Rect paramRect) {
    Intrinsics.checkNotNullParameter(paramActivity, "activity");
    Intrinsics.checkNotNullParameter(paramRect, "hint");
    e.a();
    c.a(paramActivity, b.a(a.a(d.a(), paramRect)));
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\activity\Api26Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */