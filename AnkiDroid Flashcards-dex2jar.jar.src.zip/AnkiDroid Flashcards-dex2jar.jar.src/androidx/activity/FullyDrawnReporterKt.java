package androidx.activity;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(d1 = {"\000\034\n\000\n\002\020\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\020\000\n\002\b\002\0323\020\000\032\0020\001*\0020\0022\034\020\003\032\030\b\001\022\n\022\b\022\004\022\0020\0010\005\022\006\022\004\030\0010\0060\004HHø\001\000¢\006\002\020\007\002\004\n\002\b\031¨\006\b"}, d2 = {"reportWhenComplete", "", "Landroidx/activity/FullyDrawnReporter;", "reporter", "Lkotlin/Function1;", "Lkotlin/coroutines/Continuation;", "", "(Landroidx/activity/FullyDrawnReporter;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "activity_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class FullyDrawnReporterKt {
  @Nullable
  public static final Object reportWhenComplete(@NotNull FullyDrawnReporter paramFullyDrawnReporter, @NotNull Function1<? super Continuation<? super Unit>, ? extends Object> paramFunction1, @NotNull Continuation<? super Unit> paramContinuation) {
    // Byte code:
    //   0: aload_2
    //   1: instanceof androidx/activity/FullyDrawnReporterKt$reportWhenComplete$1
    //   4: ifeq -> 38
    //   7: aload_2
    //   8: checkcast androidx/activity/FullyDrawnReporterKt$reportWhenComplete$1
    //   11: astore #4
    //   13: aload #4
    //   15: getfield label : I
    //   18: istore_3
    //   19: iload_3
    //   20: ldc -2147483648
    //   22: iand
    //   23: ifeq -> 38
    //   26: aload #4
    //   28: iload_3
    //   29: ldc -2147483648
    //   31: iadd
    //   32: putfield label : I
    //   35: goto -> 48
    //   38: new androidx/activity/FullyDrawnReporterKt$reportWhenComplete$1
    //   41: dup
    //   42: aload_2
    //   43: invokespecial <init> : (Lkotlin/coroutines/Continuation;)V
    //   46: astore #4
    //   48: aload #4
    //   50: getfield result : Ljava/lang/Object;
    //   53: astore #6
    //   55: invokestatic getCOROUTINE_SUSPENDED : ()Ljava/lang/Object;
    //   58: astore #5
    //   60: aload #4
    //   62: getfield label : I
    //   65: istore_3
    //   66: iload_3
    //   67: ifeq -> 104
    //   70: iload_3
    //   71: iconst_1
    //   72: if_icmpne -> 94
    //   75: aload #4
    //   77: getfield L$0 : Ljava/lang/Object;
    //   80: checkcast androidx/activity/FullyDrawnReporter
    //   83: astore_0
    //   84: aload_0
    //   85: astore_2
    //   86: aload #6
    //   88: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   91: goto -> 160
    //   94: new java/lang/IllegalStateException
    //   97: dup
    //   98: ldc 'call to 'resume' before 'invoke' with coroutine'
    //   100: invokespecial <init> : (Ljava/lang/String;)V
    //   103: athrow
    //   104: aload #6
    //   106: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   109: aload_0
    //   110: invokevirtual addReporter : ()V
    //   113: aload_0
    //   114: invokevirtual isFullyDrawnReported : ()Z
    //   117: ifeq -> 124
    //   120: getstatic kotlin/Unit.INSTANCE : Lkotlin/Unit;
    //   123: areturn
    //   124: aload_0
    //   125: astore_2
    //   126: aload #4
    //   128: aload_0
    //   129: putfield L$0 : Ljava/lang/Object;
    //   132: aload_0
    //   133: astore_2
    //   134: aload #4
    //   136: iconst_1
    //   137: putfield label : I
    //   140: aload_0
    //   141: astore_2
    //   142: aload_1
    //   143: aload #4
    //   145: invokeinterface invoke : (Ljava/lang/Object;)Ljava/lang/Object;
    //   150: astore_1
    //   151: aload_1
    //   152: aload #5
    //   154: if_acmpne -> 160
    //   157: aload #5
    //   159: areturn
    //   160: iconst_1
    //   161: invokestatic finallyStart : (I)V
    //   164: aload_0
    //   165: invokevirtual removeReporter : ()V
    //   168: iconst_1
    //   169: invokestatic finallyEnd : (I)V
    //   172: getstatic kotlin/Unit.INSTANCE : Lkotlin/Unit;
    //   175: areturn
    //   176: astore_0
    //   177: iconst_1
    //   178: invokestatic finallyStart : (I)V
    //   181: aload_2
    //   182: invokevirtual removeReporter : ()V
    //   185: iconst_1
    //   186: invokestatic finallyEnd : (I)V
    //   189: aload_0
    //   190: athrow
    // Exception table:
    //   from	to	target	type
    //   86	91	176	finally
    //   126	132	176	finally
    //   134	140	176	finally
    //   142	151	176	finally
  }
  
  private static final Object reportWhenComplete$$forInline(FullyDrawnReporter paramFullyDrawnReporter, Function1<? super Continuation<? super Unit>, ? extends Object> paramFunction1, Continuation<? super Unit> paramContinuation) {
    paramFullyDrawnReporter.addReporter();
    if (paramFullyDrawnReporter.isFullyDrawnReported())
      return Unit.INSTANCE; 
    try {
      paramFunction1.invoke(paramContinuation);
      return Unit.INSTANCE;
    } finally {
      InlineMarker.finallyStart(1);
      paramFullyDrawnReporter.removeReporter();
      InlineMarker.finallyEnd(1);
    } 
  }
  
  @Metadata(k = 3, mv = {1, 8, 0}, xi = 176)
  @DebugMetadata(c = "androidx.activity.FullyDrawnReporterKt", f = "FullyDrawnReporter.kt", i = {0}, l = {185}, m = "reportWhenComplete", n = {"$this$reportWhenComplete"}, s = {"L$0"})
  @SourceDebugExtension({"SMAP\nFullyDrawnReporter.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FullyDrawnReporter.kt\nandroidx/activity/FullyDrawnReporterKt$reportWhenComplete$1\n*L\n1#1,190:1\n*E\n"})
  static final class FullyDrawnReporterKt$reportWhenComplete$1 extends ContinuationImpl {
    Object L$0;
    
    int label;
    
    FullyDrawnReporterKt$reportWhenComplete$1(Continuation<? super FullyDrawnReporterKt$reportWhenComplete$1> param1Continuation) {
      super(param1Continuation);
    }
    
    @Nullable
    public final Object invokeSuspend(@NotNull Object param1Object) {
      this.result = param1Object;
      this.label |= Integer.MIN_VALUE;
      return FullyDrawnReporterKt.reportWhenComplete(null, null, (Continuation<? super Unit>)this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\activity\FullyDrawnReporterKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */