package androidx.arch.core.executor;

import java.util.concurrent.Executor;



/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\arch\core\executor\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */