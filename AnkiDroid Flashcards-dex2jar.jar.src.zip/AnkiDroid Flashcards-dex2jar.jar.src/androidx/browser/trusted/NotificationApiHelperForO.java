package androidx.browser.trusted;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;

@RequiresApi(26)
@RestrictTo({RestrictTo.Scope.LIBRARY})
class NotificationApiHelperForO {
  @Nullable
  static Notification copyNotificationOntoChannel(Context paramContext, NotificationManager paramNotificationManager, Notification paramNotification, String paramString1, String paramString2) {
    i.a();
    c.a(paramNotificationManager, h.a(paramString1, paramString2, 3));
    if (e.a(d.a(paramNotificationManager, paramString1)) == 0)
      return null; 
    Notification.Builder builder = f.a(paramContext, paramNotification);
    g.a(builder, paramString1);
    return builder.build();
  }
  
  static boolean isChannelEnabled(NotificationManager paramNotificationManager, String paramString) {
    NotificationChannel notificationChannel = d.a(paramNotificationManager, paramString);
    return (notificationChannel == null || e.a(notificationChannel) != 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\browser\trusted\NotificationApiHelperForO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */