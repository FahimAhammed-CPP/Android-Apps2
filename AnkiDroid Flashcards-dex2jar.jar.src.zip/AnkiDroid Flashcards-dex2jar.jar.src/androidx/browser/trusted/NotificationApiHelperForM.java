package androidx.browser.trusted;

import android.app.NotificationManager;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;

@RequiresApi(23)
@RestrictTo({RestrictTo.Scope.LIBRARY})
public class NotificationApiHelperForM {
  @NonNull
  static Parcelable[] getActiveNotifications(NotificationManager paramNotificationManager) {
    return (Parcelable[])b.a(paramNotificationManager);
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\browser\trusted\NotificationApiHelperForM.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */