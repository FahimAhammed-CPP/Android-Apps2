package androidx.browser.trusted;

import android.net.Uri;



/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\browser\trusted\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */