package androidx.browser.browseractions;

import android.app.PendingIntent;
import android.net.Uri;
import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

@Deprecated
public class BrowserActionItem {
  @Nullable
  private final PendingIntent mAction;
  
  @DrawableRes
  private int mIconId;
  
  @Nullable
  private Uri mIconUri;
  
  @Nullable
  private Runnable mRunnableAction;
  
  private final String mTitle;
  
  public BrowserActionItem(@NonNull String paramString, @NonNull PendingIntent paramPendingIntent) {
    this(paramString, paramPendingIntent, 0);
  }
  
  public BrowserActionItem(@NonNull String paramString, @NonNull PendingIntent paramPendingIntent, @DrawableRes int paramInt) {
    this.mTitle = paramString;
    this.mAction = paramPendingIntent;
    this.mIconId = paramInt;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public BrowserActionItem(@NonNull String paramString, @NonNull PendingIntent paramPendingIntent, @NonNull Uri paramUri) {
    this.mTitle = paramString;
    this.mAction = paramPendingIntent;
    this.mIconUri = paramUri;
  }
  
  BrowserActionItem(@NonNull String paramString, @NonNull Runnable paramRunnable) {
    this.mTitle = paramString;
    this.mAction = null;
    this.mRunnableAction = paramRunnable;
  }
  
  @NonNull
  public PendingIntent getAction() {
    PendingIntent pendingIntent = this.mAction;
    if (pendingIntent != null)
      return pendingIntent; 
    throw new IllegalStateException("Can't call getAction on BrowserActionItem with null action.");
  }
  
  public int getIconId() {
    return this.mIconId;
  }
  
  @Nullable
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public Uri getIconUri() {
    return this.mIconUri;
  }
  
  @Nullable
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  Runnable getRunnableAction() {
    return this.mRunnableAction;
  }
  
  @NonNull
  public String getTitle() {
    return this.mTitle;
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\browser\browseractions\BrowserActionItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */