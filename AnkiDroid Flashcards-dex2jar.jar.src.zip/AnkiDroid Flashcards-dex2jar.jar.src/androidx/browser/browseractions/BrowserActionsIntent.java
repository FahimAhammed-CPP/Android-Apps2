package androidx.browser.browseractions;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;
import androidx.core.content.ContextCompat;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Deprecated
public class BrowserActionsIntent {
  public static final String ACTION_BROWSER_ACTIONS_OPEN = "androidx.browser.browseractions.browser_action_open";
  
  public static final String EXTRA_APP_ID = "androidx.browser.browseractions.APP_ID";
  
  public static final String EXTRA_MENU_ITEMS = "androidx.browser.browseractions.extra.MENU_ITEMS";
  
  public static final String EXTRA_SELECTED_ACTION_PENDING_INTENT = "androidx.browser.browseractions.extra.SELECTED_ACTION_PENDING_INTENT";
  
  public static final String EXTRA_TYPE = "androidx.browser.browseractions.extra.TYPE";
  
  public static final int ITEM_COPY = 3;
  
  public static final int ITEM_DOWNLOAD = 2;
  
  public static final int ITEM_INVALID_ITEM = -1;
  
  public static final int ITEM_OPEN_IN_INCOGNITO = 1;
  
  public static final int ITEM_OPEN_IN_NEW_TAB = 0;
  
  public static final int ITEM_SHARE = 4;
  
  public static final String KEY_ACTION = "androidx.browser.browseractions.ACTION";
  
  public static final String KEY_ICON_ID = "androidx.browser.browseractions.ICON_ID";
  
  private static final String KEY_ICON_URI = "androidx.browser.browseractions.ICON_URI";
  
  public static final String KEY_TITLE = "androidx.browser.browseractions.TITLE";
  
  @SuppressLint({"MinMaxConstant"})
  public static final int MAX_CUSTOM_ITEMS = 5;
  
  private static final String TAG = "BrowserActions";
  
  private static final String TEST_URL = "https://www.example.com";
  
  public static final int URL_TYPE_AUDIO = 3;
  
  public static final int URL_TYPE_FILE = 4;
  
  public static final int URL_TYPE_IMAGE = 1;
  
  public static final int URL_TYPE_NONE = 0;
  
  public static final int URL_TYPE_PLUGIN = 5;
  
  public static final int URL_TYPE_VIDEO = 2;
  
  @Nullable
  private static BrowserActionsFallDialogListener sDialogListenter;
  
  @NonNull
  private final Intent mIntent;
  
  BrowserActionsIntent(@NonNull Intent paramIntent) {
    this.mIntent = paramIntent;
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static List<ResolveInfo> getBrowserActionsIntentHandlers(@NonNull Context paramContext) {
    Intent intent = new Intent("androidx.browser.browseractions.browser_action_open", Uri.parse("https://www.example.com"));
    return paramContext.getPackageManager().queryIntentActivities(intent, 131072);
  }
  
  @Deprecated
  @Nullable
  public static String getCreatorPackageName(@NonNull Intent paramIntent) {
    return getUntrustedCreatorPackageName(paramIntent);
  }
  
  @Nullable
  public static String getUntrustedCreatorPackageName(@NonNull Intent paramIntent) {
    PendingIntent pendingIntent = (PendingIntent)paramIntent.getParcelableExtra("androidx.browser.browseractions.APP_ID");
    return (pendingIntent != null) ? pendingIntent.getTargetPackage() : null;
  }
  
  public static void launchIntent(@NonNull Context paramContext, @NonNull Intent paramIntent) {
    launchIntent(paramContext, paramIntent, getBrowserActionsIntentHandlers(paramContext));
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  @VisibleForTesting
  static void launchIntent(Context paramContext, Intent paramIntent, List<ResolveInfo> paramList) {
    if (paramList == null || paramList.size() == 0) {
      openFallbackBrowserActionsMenu(paramContext, paramIntent);
      return;
    } 
    int j = paramList.size();
    int i = 0;
    if (j == 1) {
      paramIntent.setPackage(((ResolveInfo)paramList.get(0)).activityInfo.packageName);
    } else {
      Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("https://www.example.com"));
      ResolveInfo resolveInfo = paramContext.getPackageManager().resolveActivity(intent, 65536);
      if (resolveInfo != null) {
        String str = resolveInfo.activityInfo.packageName;
        while (i < paramList.size()) {
          if (str.equals(((ResolveInfo)paramList.get(i)).activityInfo.packageName)) {
            paramIntent.setPackage(str);
            break;
          } 
          i++;
        } 
      } 
    } 
    ContextCompat.startActivity(paramContext, paramIntent, null);
  }
  
  public static void openBrowserAction(@NonNull Context paramContext, @NonNull Uri paramUri) {
    launchIntent(paramContext, (new Builder(paramContext, paramUri)).build().getIntent());
  }
  
  public static void openBrowserAction(@NonNull Context paramContext, @NonNull Uri paramUri, int paramInt, @NonNull ArrayList<BrowserActionItem> paramArrayList, @NonNull PendingIntent paramPendingIntent) {
    launchIntent(paramContext, (new Builder(paramContext, paramUri)).setUrlType(paramInt).setCustomItems(paramArrayList).setOnItemSelectedAction(paramPendingIntent).build().getIntent());
  }
  
  private static void openFallbackBrowserActionsMenu(Context paramContext, Intent paramIntent) {
    Uri uri = paramIntent.getData();
    ArrayList<Bundle> arrayList = paramIntent.getParcelableArrayListExtra("androidx.browser.browseractions.extra.MENU_ITEMS");
    if (arrayList != null) {
      List<BrowserActionItem> list = parseBrowserActionItems(arrayList);
    } else {
      arrayList = null;
    } 
    openFallbackBrowserActionsMenu(paramContext, uri, (List)arrayList);
  }
  
  private static void openFallbackBrowserActionsMenu(Context paramContext, Uri paramUri, List<BrowserActionItem> paramList) {
    (new BrowserActionsFallbackMenuUi(paramContext, paramUri, paramList)).displayMenu();
    BrowserActionsFallDialogListener browserActionsFallDialogListener = sDialogListenter;
    if (browserActionsFallDialogListener != null)
      browserActionsFallDialogListener.onDialogShown(); 
  }
  
  @NonNull
  public static List<BrowserActionItem> parseBrowserActionItems(@NonNull ArrayList<Bundle> paramArrayList) {
    ArrayList<BrowserActionItem> arrayList = new ArrayList();
    int i = 0;
    while (i < paramArrayList.size()) {
      Bundle bundle = paramArrayList.get(i);
      String str = bundle.getString("androidx.browser.browseractions.TITLE");
      PendingIntent pendingIntent = (PendingIntent)bundle.getParcelable("androidx.browser.browseractions.ACTION");
      int j = bundle.getInt("androidx.browser.browseractions.ICON_ID");
      Uri uri = (Uri)bundle.getParcelable("androidx.browser.browseractions.ICON_URI");
      if (!TextUtils.isEmpty(str) && pendingIntent != null) {
        BrowserActionItem browserActionItem;
        if (j != 0) {
          browserActionItem = new BrowserActionItem(str, pendingIntent, j);
        } else {
          browserActionItem = new BrowserActionItem((String)browserActionItem, pendingIntent, uri);
        } 
        arrayList.add(browserActionItem);
        i++;
        continue;
      } 
      throw new IllegalArgumentException("Custom item should contain a non-empty title and non-null intent.");
    } 
    return arrayList;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  @VisibleForTesting
  static void setDialogShownListenter(BrowserActionsFallDialogListener paramBrowserActionsFallDialogListener) {
    sDialogListenter = paramBrowserActionsFallDialogListener;
  }
  
  @NonNull
  public Intent getIntent() {
    return this.mIntent;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  @VisibleForTesting
  static interface BrowserActionsFallDialogListener {
    void onDialogShown();
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public static @interface BrowserActionsItemId {}
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public static @interface BrowserActionsUrlType {}
  
  public static final class Builder {
    private Context mContext;
    
    private List<Uri> mImageUris = new ArrayList<Uri>();
    
    private final Intent mIntent = new Intent("androidx.browser.browseractions.browser_action_open");
    
    private ArrayList<Bundle> mMenuItems = new ArrayList<Bundle>();
    
    @Nullable
    private PendingIntent mOnItemSelectedPendingIntent = null;
    
    private int mType = 0;
    
    private Uri mUri;
    
    public Builder(@NonNull Context param1Context, @NonNull Uri param1Uri) {
      this.mContext = param1Context;
      this.mUri = param1Uri;
    }
    
    @NonNull
    private Bundle getBundleFromItem(@NonNull BrowserActionItem param1BrowserActionItem) {
      Bundle bundle = new Bundle();
      bundle.putString("androidx.browser.browseractions.TITLE", param1BrowserActionItem.getTitle());
      bundle.putParcelable("androidx.browser.browseractions.ACTION", (Parcelable)param1BrowserActionItem.getAction());
      if (param1BrowserActionItem.getIconId() != 0)
        bundle.putInt("androidx.browser.browseractions.ICON_ID", param1BrowserActionItem.getIconId()); 
      if (param1BrowserActionItem.getIconUri() != null)
        bundle.putParcelable("androidx.browser.browseractions.ICON_URI", (Parcelable)param1BrowserActionItem.getIconUri()); 
      return bundle;
    }
    
    @NonNull
    public BrowserActionsIntent build() {
      this.mIntent.setData(this.mUri);
      this.mIntent.putExtra("androidx.browser.browseractions.extra.TYPE", this.mType);
      this.mIntent.putParcelableArrayListExtra("androidx.browser.browseractions.extra.MENU_ITEMS", this.mMenuItems);
      PendingIntent pendingIntent = PendingIntent.getActivity(this.mContext, 0, new Intent(), 67108864);
      this.mIntent.putExtra("androidx.browser.browseractions.APP_ID", (Parcelable)pendingIntent);
      pendingIntent = this.mOnItemSelectedPendingIntent;
      if (pendingIntent != null)
        this.mIntent.putExtra("androidx.browser.browseractions.extra.SELECTED_ACTION_PENDING_INTENT", (Parcelable)pendingIntent); 
      BrowserServiceFileProvider.grantReadPermission(this.mIntent, this.mImageUris, this.mContext);
      return new BrowserActionsIntent(this.mIntent);
    }
    
    @NonNull
    public Builder setCustomItems(@NonNull ArrayList<BrowserActionItem> param1ArrayList) {
      if (param1ArrayList.size() <= 5) {
        int i = 0;
        while (i < param1ArrayList.size()) {
          if (!TextUtils.isEmpty(((BrowserActionItem)param1ArrayList.get(i)).getTitle()) && ((BrowserActionItem)param1ArrayList.get(i)).getAction() != null) {
            this.mMenuItems.add(getBundleFromItem(param1ArrayList.get(i)));
            if (((BrowserActionItem)param1ArrayList.get(i)).getIconUri() != null)
              this.mImageUris.add(((BrowserActionItem)param1ArrayList.get(i)).getIconUri()); 
            i++;
            continue;
          } 
          throw new IllegalArgumentException("Custom item should contain a non-empty title and non-null intent.");
        } 
        return this;
      } 
      throw new IllegalStateException("Exceeded maximum toolbar item count of 5");
    }
    
    @NonNull
    public Builder setCustomItems(@NonNull BrowserActionItem... param1VarArgs) {
      return setCustomItems(new ArrayList<BrowserActionItem>(Arrays.asList(param1VarArgs)));
    }
    
    @NonNull
    public Builder setOnItemSelectedAction(@NonNull PendingIntent param1PendingIntent) {
      this.mOnItemSelectedPendingIntent = param1PendingIntent;
      return this;
    }
    
    @NonNull
    public Builder setUrlType(int param1Int) {
      this.mType = param1Int;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\browser\browseractions\BrowserActionsIntent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */