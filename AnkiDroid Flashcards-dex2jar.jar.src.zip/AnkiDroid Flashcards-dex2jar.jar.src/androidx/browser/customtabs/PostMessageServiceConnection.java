package androidx.browser.customtabs;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.customtabs.ICustomTabsCallback;
import android.support.customtabs.IPostMessageService;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

public abstract class PostMessageServiceConnection implements PostMessageBackend, ServiceConnection {
  private static final String TAG = "PostMessageServConn";
  
  private final Object mLock = new Object();
  
  private boolean mMessageChannelCreated;
  
  @Nullable
  private String mPackageName;
  
  @Nullable
  private IPostMessageService mService;
  
  private final ICustomTabsCallback mSessionBinder;
  
  public PostMessageServiceConnection(@NonNull CustomTabsSessionToken paramCustomTabsSessionToken) {
    IBinder iBinder = paramCustomTabsSessionToken.getCallbackBinder();
    if (iBinder != null) {
      this.mSessionBinder = ICustomTabsCallback.Stub.asInterface(iBinder);
      return;
    } 
    throw new IllegalArgumentException("Provided session must have binder.");
  }
  
  private boolean isBoundToService() {
    return (this.mService != null);
  }
  
  private boolean notifyMessageChannelReadyInternal(@Nullable Bundle paramBundle) {
    if (this.mService == null)
      return false; 
    synchronized (this.mLock) {
      this.mService.onMessageChannelReady(this.mSessionBinder, paramBundle);
      return true;
    } 
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public boolean bindSessionToPostMessageService(@NonNull Context paramContext) {
    String str = this.mPackageName;
    if (str != null)
      return bindSessionToPostMessageService(paramContext, str); 
    throw new IllegalStateException("setPackageName must be called before bindSessionToPostMessageService.");
  }
  
  public boolean bindSessionToPostMessageService(@NonNull Context paramContext, @NonNull String paramString) {
    Intent intent = new Intent();
    intent.setClassName(paramString, PostMessageService.class.getName());
    boolean bool = paramContext.bindService(intent, this, 1);
    if (!bool)
      Log.w("PostMessageServConn", "Could not bind to PostMessageService in client."); 
    return bool;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public void cleanup(@NonNull Context paramContext) {
    if (isBoundToService())
      unbindFromContext(paramContext); 
  }
  
  public final boolean notifyMessageChannelReady(@Nullable Bundle paramBundle) {
    this.mMessageChannelCreated = true;
    return notifyMessageChannelReadyInternal(paramBundle);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public void onDisconnectChannel(@NonNull Context paramContext) {
    unbindFromContext(paramContext);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public final boolean onNotifyMessageChannelReady(@Nullable Bundle paramBundle) {
    return notifyMessageChannelReady(paramBundle);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public final boolean onPostMessage(@NonNull String paramString, @Nullable Bundle paramBundle) {
    return postMessage(paramString, paramBundle);
  }
  
  public void onPostMessageServiceConnected() {
    if (this.mMessageChannelCreated)
      notifyMessageChannelReadyInternal(null); 
  }
  
  public void onPostMessageServiceDisconnected() {}
  
  public final void onServiceConnected(@NonNull ComponentName paramComponentName, @NonNull IBinder paramIBinder) {
    this.mService = IPostMessageService.Stub.asInterface(paramIBinder);
    onPostMessageServiceConnected();
  }
  
  public final void onServiceDisconnected(@NonNull ComponentName paramComponentName) {
    this.mService = null;
    onPostMessageServiceDisconnected();
  }
  
  public final boolean postMessage(@NonNull String paramString, @Nullable Bundle paramBundle) {
    if (this.mService == null)
      return false; 
    synchronized (this.mLock) {
      this.mService.onPostMessage(this.mSessionBinder, paramString, paramBundle);
      return true;
    } 
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public void setPackageName(@NonNull String paramString) {
    this.mPackageName = paramString;
  }
  
  public void unbindFromContext(@NonNull Context paramContext) {
    if (isBoundToService()) {
      paramContext.unbindService(this);
      this.mService = null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\browser\customtabs\PostMessageServiceConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */