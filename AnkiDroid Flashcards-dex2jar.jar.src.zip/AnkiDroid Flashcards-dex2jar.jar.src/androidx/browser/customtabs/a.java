package androidx.browser.customtabs;

import android.os.LocaleList;



/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\browser\customtabs\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */