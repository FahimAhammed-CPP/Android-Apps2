package androidx.browser.customtabs;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import androidx.annotation.WorkerThread;
import androidx.core.app.BundleCompat;
import androidx.core.content.FileProvider;
import java.io.File;

public class TrustedWebUtils {
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static final String ACTION_MANAGE_TRUSTED_WEB_ACTIVITY_DATA = "android.support.customtabs.action.ACTION_MANAGE_TRUSTED_WEB_ACTIVITY_DATA";
  
  public static final String EXTRA_LAUNCH_AS_TRUSTED_WEB_ACTIVITY = "android.support.customtabs.extra.LAUNCH_AS_TRUSTED_WEB_ACTIVITY";
  
  public static boolean areSplashScreensSupported(@NonNull Context paramContext, @NonNull String paramString1, @NonNull String paramString2) {
    Intent intent = (new Intent()).setAction("android.support.customtabs.action.CustomTabsService").setPackage(paramString1);
    ResolveInfo resolveInfo = paramContext.getPackageManager().resolveService(intent, 64);
    if (resolveInfo != null) {
      IntentFilter intentFilter = resolveInfo.filter;
      if (intentFilter != null)
        return intentFilter.hasCategory(paramString2); 
    } 
    return false;
  }
  
  @Deprecated
  public static void launchAsTrustedWebActivity(@NonNull Context paramContext, @NonNull CustomTabsIntent paramCustomTabsIntent, @NonNull Uri paramUri) {
    if (BundleCompat.getBinder(paramCustomTabsIntent.intent.getExtras(), "android.support.customtabs.extra.SESSION") != null) {
      paramCustomTabsIntent.intent.putExtra("android.support.customtabs.extra.LAUNCH_AS_TRUSTED_WEB_ACTIVITY", true);
      paramCustomTabsIntent.launchUrl(paramContext, paramUri);
      return;
    } 
    throw new IllegalArgumentException("Given CustomTabsIntent should be associated with a valid CustomTabsSession");
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static void launchBrowserSiteSettings(@NonNull Context paramContext, @NonNull CustomTabsSession paramCustomTabsSession, @NonNull Uri paramUri) {
    Intent intent = new Intent("android.support.customtabs.action.ACTION_MANAGE_TRUSTED_WEB_ACTIVITY_DATA");
    intent.setPackage(paramCustomTabsSession.getComponentName().getPackageName());
    intent.setData(paramUri);
    Bundle bundle = new Bundle();
    BundleCompat.putBinder(bundle, "android.support.customtabs.extra.SESSION", paramCustomTabsSession.getBinder());
    intent.putExtras(bundle);
    PendingIntent pendingIntent = paramCustomTabsSession.getId();
    if (pendingIntent != null)
      intent.putExtra("android.support.customtabs.extra.SESSION_ID", (Parcelable)pendingIntent); 
    paramContext.startActivity(intent);
  }
  
  @WorkerThread
  public static boolean transferSplashImage(@NonNull Context paramContext, @NonNull File paramFile, @NonNull String paramString1, @NonNull String paramString2, @NonNull CustomTabsSession paramCustomTabsSession) {
    Uri uri = FileProvider.getUriForFile(paramContext, paramString1, paramFile);
    paramContext.grantUriPermission(paramString2, uri, 1);
    return paramCustomTabsSession.receiveFile(uri, 1, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\browser\customtabs\TrustedWebUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */