package androidx.browser.customtabs;

import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.Dimension;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

public class CustomTabsCallback {
  public static final int NAVIGATION_ABORTED = 4;
  
  public static final int NAVIGATION_FAILED = 3;
  
  public static final int NAVIGATION_FINISHED = 2;
  
  public static final int NAVIGATION_STARTED = 1;
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static final String ONLINE_EXTRAS_KEY = "online";
  
  public static final int TAB_HIDDEN = 6;
  
  public static final int TAB_SHOWN = 5;
  
  public void extraCallback(@NonNull String paramString, @Nullable Bundle paramBundle) {}
  
  @Nullable
  public Bundle extraCallbackWithResult(@NonNull String paramString, @Nullable Bundle paramBundle) {
    return null;
  }
  
  public void onActivityResized(@Dimension(unit = 1) int paramInt1, @Dimension(unit = 1) int paramInt2, @NonNull Bundle paramBundle) {}
  
  public void onMessageChannelReady(@Nullable Bundle paramBundle) {}
  
  public void onNavigationEvent(int paramInt, @Nullable Bundle paramBundle) {}
  
  public void onPostMessage(@NonNull String paramString, @Nullable Bundle paramBundle) {}
  
  public void onRelationshipValidationResult(int paramInt, @NonNull Uri paramUri, boolean paramBoolean, @Nullable Bundle paramBundle) {}
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\browser\customtabs\CustomTabsCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */