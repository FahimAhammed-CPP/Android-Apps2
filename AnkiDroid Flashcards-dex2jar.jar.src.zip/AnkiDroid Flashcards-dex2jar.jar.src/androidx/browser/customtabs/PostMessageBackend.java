package androidx.browser.customtabs;

import android.content.Context;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

@RestrictTo({RestrictTo.Scope.LIBRARY})
public interface PostMessageBackend {
  void onDisconnectChannel(@NonNull Context paramContext);
  
  boolean onNotifyMessageChannelReady(@Nullable Bundle paramBundle);
  
  boolean onPostMessage(@NonNull String paramString, @Nullable Bundle paramBundle);
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\browser\customtabs\PostMessageBackend.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */