package androidx.browser;

public final class R {
  public static final class color {
    public static int browser_actions_bg_grey = 2131099707;
    
    public static int browser_actions_divider_color = 2131099708;
    
    public static int browser_actions_text_color = 2131099709;
    
    public static int browser_actions_title_color = 2131099710;
  }
  
  public static final class dimen {
    public static int browser_actions_context_menu_max_width = 2131165291;
    
    public static int browser_actions_context_menu_min_padding = 2131165292;
  }
  
  public static final class id {
    public static int browser_actions_header_text = 2131296517;
    
    public static int browser_actions_menu_item_icon = 2131296518;
    
    public static int browser_actions_menu_item_text = 2131296519;
    
    public static int browser_actions_menu_items = 2131296520;
    
    public static int browser_actions_menu_view = 2131296521;
  }
  
  public static final class layout {
    public static int browser_actions_context_menu_page = 2131492904;
    
    public static int browser_actions_context_menu_row = 2131492905;
  }
  
  public static final class string {
    public static int copy_toast_msg = 2131820845;
    
    public static int fallback_menu_item_copy_link = 2131821193;
    
    public static int fallback_menu_item_open_in_browser = 2131821194;
    
    public static int fallback_menu_item_share_link = 2131821195;
  }
  
  public static final class xml {
    public static int image_share_filepaths = 2132017155;
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\androidx\browser\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */