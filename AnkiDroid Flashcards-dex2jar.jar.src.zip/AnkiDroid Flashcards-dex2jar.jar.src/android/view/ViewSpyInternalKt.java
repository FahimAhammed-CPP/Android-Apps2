package android.view;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv = {1, 0, 3}, d1 = {"\000\016\n\000\n\002\020\b\n\000\n\002\030\002\n\000\032\020\020\000\032\0020\0012\006\020\002\032\0020\003H\000¨\006\004"}, d2 = {"windowAttachCount", "", "view", "Landroid/view/View;", "curtains_release"}, k = 2, mv = {1, 4, 1})
public final class ViewSpyInternalKt {
  public static final int windowAttachCount(@NotNull View paramView) {
    Intrinsics.checkNotNullParameter(paramView, "view");
    return JavaViewSpy.windowAttachCount(paramView);
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\android\view\ViewSpyInternalKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */