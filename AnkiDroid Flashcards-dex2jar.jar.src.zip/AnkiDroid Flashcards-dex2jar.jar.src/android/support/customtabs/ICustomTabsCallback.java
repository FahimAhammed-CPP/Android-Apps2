package android.support.customtabs;

import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;

public interface ICustomTabsCallback extends IInterface {
  public static final String DESCRIPTOR = "android.support.customtabs.ICustomTabsCallback";
  
  void extraCallback(String paramString, Bundle paramBundle) throws RemoteException;
  
  Bundle extraCallbackWithResult(String paramString, Bundle paramBundle) throws RemoteException;
  
  void onActivityResized(int paramInt1, int paramInt2, Bundle paramBundle) throws RemoteException;
  
  void onMessageChannelReady(Bundle paramBundle) throws RemoteException;
  
  void onNavigationEvent(int paramInt, Bundle paramBundle) throws RemoteException;
  
  void onPostMessage(String paramString, Bundle paramBundle) throws RemoteException;
  
  void onRelationshipValidationResult(int paramInt, Uri paramUri, boolean paramBoolean, Bundle paramBundle) throws RemoteException;
  
  public static class Default implements ICustomTabsCallback {
    public IBinder asBinder() {
      return null;
    }
    
    public void extraCallback(String param1String, Bundle param1Bundle) throws RemoteException {}
    
    public Bundle extraCallbackWithResult(String param1String, Bundle param1Bundle) throws RemoteException {
      return null;
    }
    
    public void onActivityResized(int param1Int1, int param1Int2, Bundle param1Bundle) throws RemoteException {}
    
    public void onMessageChannelReady(Bundle param1Bundle) throws RemoteException {}
    
    public void onNavigationEvent(int param1Int, Bundle param1Bundle) throws RemoteException {}
    
    public void onPostMessage(String param1String, Bundle param1Bundle) throws RemoteException {}
    
    public void onRelationshipValidationResult(int param1Int, Uri param1Uri, boolean param1Boolean, Bundle param1Bundle) throws RemoteException {}
  }
  
  public static abstract class Stub extends Binder implements ICustomTabsCallback {
    static final int TRANSACTION_extraCallback = 3;
    
    static final int TRANSACTION_extraCallbackWithResult = 7;
    
    static final int TRANSACTION_onActivityResized = 8;
    
    static final int TRANSACTION_onMessageChannelReady = 4;
    
    static final int TRANSACTION_onNavigationEvent = 2;
    
    static final int TRANSACTION_onPostMessage = 5;
    
    static final int TRANSACTION_onRelationshipValidationResult = 6;
    
    public Stub() {
      attachInterface(this, "android.support.customtabs.ICustomTabsCallback");
    }
    
    public static ICustomTabsCallback asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("android.support.customtabs.ICustomTabsCallback");
      return (iInterface != null && iInterface instanceof ICustomTabsCallback) ? (ICustomTabsCallback)iInterface : new Proxy(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      Uri uri;
      if (param1Int1 >= 1 && param1Int1 <= 16777215)
        param1Parcel1.enforceInterface("android.support.customtabs.ICustomTabsCallback"); 
      if (param1Int1 != 1598968902) {
        Bundle bundle;
        boolean bool;
        switch (param1Int1) {
          default:
            return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
          case 8:
            onActivityResized(param1Parcel1.readInt(), param1Parcel1.readInt(), (Bundle)ICustomTabsCallback._Parcel.readTypedObject(param1Parcel1, Bundle.CREATOR));
            return true;
          case 7:
            bundle = extraCallbackWithResult(param1Parcel1.readString(), (Bundle)ICustomTabsCallback._Parcel.readTypedObject(param1Parcel1, Bundle.CREATOR));
            param1Parcel2.writeNoException();
            ICustomTabsCallback._Parcel.writeTypedObject(param1Parcel2, (T)bundle, 1);
            return true;
          case 6:
            param1Int1 = bundle.readInt();
            uri = (Uri)ICustomTabsCallback._Parcel.readTypedObject((Parcel)bundle, Uri.CREATOR);
            if (bundle.readInt() != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            onRelationshipValidationResult(param1Int1, uri, bool, (Bundle)ICustomTabsCallback._Parcel.readTypedObject((Parcel)bundle, Bundle.CREATOR));
            return true;
          case 5:
            onPostMessage(bundle.readString(), (Bundle)ICustomTabsCallback._Parcel.readTypedObject((Parcel)bundle, Bundle.CREATOR));
            uri.writeNoException();
            return true;
          case 4:
            onMessageChannelReady((Bundle)ICustomTabsCallback._Parcel.readTypedObject((Parcel)bundle, Bundle.CREATOR));
            uri.writeNoException();
            return true;
          case 3:
            extraCallback(bundle.readString(), (Bundle)ICustomTabsCallback._Parcel.readTypedObject((Parcel)bundle, Bundle.CREATOR));
            return true;
          case 2:
            break;
        } 
        onNavigationEvent(bundle.readInt(), (Bundle)ICustomTabsCallback._Parcel.readTypedObject((Parcel)bundle, Bundle.CREATOR));
        return true;
      } 
      uri.writeString("android.support.customtabs.ICustomTabsCallback");
      return true;
    }
    
    private static class Proxy implements ICustomTabsCallback {
      private IBinder mRemote;
      
      Proxy(IBinder param2IBinder) {
        this.mRemote = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.mRemote;
      }
      
      public void extraCallback(String param2String, Bundle param2Bundle) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
          parcel.writeString(param2String);
          ICustomTabsCallback._Parcel.writeTypedObject(parcel, (T)param2Bundle, 0);
          this.mRemote.transact(3, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public Bundle extraCallbackWithResult(String param2String, Bundle param2Bundle) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
          parcel1.writeString(param2String);
          ICustomTabsCallback._Parcel.writeTypedObject(parcel1, (T)param2Bundle, 0);
          this.mRemote.transact(7, parcel1, parcel2, 0);
          parcel2.readException();
          return (Bundle)ICustomTabsCallback._Parcel.readTypedObject(parcel2, Bundle.CREATOR);
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public String getInterfaceDescriptor() {
        return "android.support.customtabs.ICustomTabsCallback";
      }
      
      public void onActivityResized(int param2Int1, int param2Int2, Bundle param2Bundle) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
          parcel.writeInt(param2Int1);
          parcel.writeInt(param2Int2);
          ICustomTabsCallback._Parcel.writeTypedObject(parcel, (T)param2Bundle, 0);
          this.mRemote.transact(8, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public void onMessageChannelReady(Bundle param2Bundle) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
          ICustomTabsCallback._Parcel.writeTypedObject(parcel1, (T)param2Bundle, 0);
          this.mRemote.transact(4, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void onNavigationEvent(int param2Int, Bundle param2Bundle) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
          parcel.writeInt(param2Int);
          ICustomTabsCallback._Parcel.writeTypedObject(parcel, (T)param2Bundle, 0);
          this.mRemote.transact(2, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public void onPostMessage(String param2String, Bundle param2Bundle) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
          parcel1.writeString(param2String);
          ICustomTabsCallback._Parcel.writeTypedObject(parcel1, (T)param2Bundle, 0);
          this.mRemote.transact(5, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void onRelationshipValidationResult(int param2Int, Uri param2Uri, boolean param2Boolean, Bundle param2Bundle) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
          parcel.writeInt(param2Int);
          ICustomTabsCallback._Parcel.writeTypedObject(parcel, (T)param2Uri, 0);
          if (param2Boolean) {
            param2Int = 1;
          } else {
            param2Int = 0;
          } 
          parcel.writeInt(param2Int);
          ICustomTabsCallback._Parcel.writeTypedObject(parcel, (T)param2Bundle, 0);
          this.mRemote.transact(6, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
    }
  }
  
  private static class Proxy implements ICustomTabsCallback {
    private IBinder mRemote;
    
    Proxy(IBinder param1IBinder) {
      this.mRemote = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.mRemote;
    }
    
    public void extraCallback(String param1String, Bundle param1Bundle) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
        parcel.writeString(param1String);
        ICustomTabsCallback._Parcel.writeTypedObject(parcel, (T)param1Bundle, 0);
        this.mRemote.transact(3, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public Bundle extraCallbackWithResult(String param1String, Bundle param1Bundle) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
        parcel1.writeString(param1String);
        ICustomTabsCallback._Parcel.writeTypedObject(parcel1, (T)param1Bundle, 0);
        this.mRemote.transact(7, parcel1, parcel2, 0);
        parcel2.readException();
        return (Bundle)ICustomTabsCallback._Parcel.readTypedObject(parcel2, Bundle.CREATOR);
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public String getInterfaceDescriptor() {
      return "android.support.customtabs.ICustomTabsCallback";
    }
    
    public void onActivityResized(int param1Int1, int param1Int2, Bundle param1Bundle) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
        parcel.writeInt(param1Int1);
        parcel.writeInt(param1Int2);
        ICustomTabsCallback._Parcel.writeTypedObject(parcel, (T)param1Bundle, 0);
        this.mRemote.transact(8, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public void onMessageChannelReady(Bundle param1Bundle) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
        ICustomTabsCallback._Parcel.writeTypedObject(parcel1, (T)param1Bundle, 0);
        this.mRemote.transact(4, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void onNavigationEvent(int param1Int, Bundle param1Bundle) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
        parcel.writeInt(param1Int);
        ICustomTabsCallback._Parcel.writeTypedObject(parcel, (T)param1Bundle, 0);
        this.mRemote.transact(2, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public void onPostMessage(String param1String, Bundle param1Bundle) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
        parcel1.writeString(param1String);
        ICustomTabsCallback._Parcel.writeTypedObject(parcel1, (T)param1Bundle, 0);
        this.mRemote.transact(5, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void onRelationshipValidationResult(int param1Int, Uri param1Uri, boolean param1Boolean, Bundle param1Bundle) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
        parcel.writeInt(param1Int);
        ICustomTabsCallback._Parcel.writeTypedObject(parcel, (T)param1Uri, 0);
        if (param1Boolean) {
          param1Int = 1;
        } else {
          param1Int = 0;
        } 
        parcel.writeInt(param1Int);
        ICustomTabsCallback._Parcel.writeTypedObject(parcel, (T)param1Bundle, 0);
        this.mRemote.transact(6, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
  }
  
  public static class _Parcel {
    private static <T> T readTypedObject(Parcel param1Parcel, Parcelable.Creator<T> param1Creator) {
      return (T)((param1Parcel.readInt() != 0) ? param1Creator.createFromParcel(param1Parcel) : null);
    }
    
    private static <T extends Parcelable> void writeTypedObject(Parcel param1Parcel, T param1T, int param1Int) {
      if (param1T != null) {
        param1Parcel.writeInt(1);
        param1T.writeToParcel(param1Parcel, param1Int);
        return;
      } 
      param1Parcel.writeInt(0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\android\support\customtabs\ICustomTabsCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */