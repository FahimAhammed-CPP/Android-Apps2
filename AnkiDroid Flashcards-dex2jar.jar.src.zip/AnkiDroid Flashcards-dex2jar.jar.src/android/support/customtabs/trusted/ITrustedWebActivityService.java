package android.support.customtabs.trusted;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;

public interface ITrustedWebActivityService extends IInterface {
  public static final String DESCRIPTOR = "android.support.customtabs.trusted.ITrustedWebActivityService";
  
  Bundle areNotificationsEnabled(Bundle paramBundle) throws RemoteException;
  
  void cancelNotification(Bundle paramBundle) throws RemoteException;
  
  Bundle extraCommand(String paramString, Bundle paramBundle, IBinder paramIBinder) throws RemoteException;
  
  Bundle getActiveNotifications() throws RemoteException;
  
  Bundle getSmallIconBitmap() throws RemoteException;
  
  int getSmallIconId() throws RemoteException;
  
  Bundle notifyNotificationWithChannel(Bundle paramBundle) throws RemoteException;
  
  public static class Default implements ITrustedWebActivityService {
    public Bundle areNotificationsEnabled(Bundle param1Bundle) throws RemoteException {
      return null;
    }
    
    public IBinder asBinder() {
      return null;
    }
    
    public void cancelNotification(Bundle param1Bundle) throws RemoteException {}
    
    public Bundle extraCommand(String param1String, Bundle param1Bundle, IBinder param1IBinder) throws RemoteException {
      return null;
    }
    
    public Bundle getActiveNotifications() throws RemoteException {
      return null;
    }
    
    public Bundle getSmallIconBitmap() throws RemoteException {
      return null;
    }
    
    public int getSmallIconId() throws RemoteException {
      return 0;
    }
    
    public Bundle notifyNotificationWithChannel(Bundle param1Bundle) throws RemoteException {
      return null;
    }
  }
  
  public static abstract class Stub extends Binder implements ITrustedWebActivityService {
    static final int TRANSACTION_areNotificationsEnabled = 6;
    
    static final int TRANSACTION_cancelNotification = 3;
    
    static final int TRANSACTION_extraCommand = 9;
    
    static final int TRANSACTION_getActiveNotifications = 5;
    
    static final int TRANSACTION_getSmallIconBitmap = 7;
    
    static final int TRANSACTION_getSmallIconId = 4;
    
    static final int TRANSACTION_notifyNotificationWithChannel = 2;
    
    public Stub() {
      attachInterface(this, "android.support.customtabs.trusted.ITrustedWebActivityService");
    }
    
    public static ITrustedWebActivityService asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("android.support.customtabs.trusted.ITrustedWebActivityService");
      return (iInterface != null && iInterface instanceof ITrustedWebActivityService) ? (ITrustedWebActivityService)iInterface : new Proxy(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      if (param1Int1 >= 1 && param1Int1 <= 16777215)
        param1Parcel1.enforceInterface("android.support.customtabs.trusted.ITrustedWebActivityService"); 
      if (param1Int1 != 1598968902) {
        switch (param1Int1) {
          default:
            return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
          case 9:
            bundle = extraCommand(param1Parcel1.readString(), (Bundle)ITrustedWebActivityService._Parcel.readTypedObject(param1Parcel1, Bundle.CREATOR), param1Parcel1.readStrongBinder());
            param1Parcel2.writeNoException();
            ITrustedWebActivityService._Parcel.writeTypedObject(param1Parcel2, (T)bundle, 1);
            return true;
          case 7:
            bundle = getSmallIconBitmap();
            param1Parcel2.writeNoException();
            ITrustedWebActivityService._Parcel.writeTypedObject(param1Parcel2, (T)bundle, 1);
            return true;
          case 6:
            bundle = areNotificationsEnabled((Bundle)ITrustedWebActivityService._Parcel.readTypedObject((Parcel)bundle, Bundle.CREATOR));
            param1Parcel2.writeNoException();
            ITrustedWebActivityService._Parcel.writeTypedObject(param1Parcel2, (T)bundle, 1);
            return true;
          case 5:
            bundle = getActiveNotifications();
            param1Parcel2.writeNoException();
            ITrustedWebActivityService._Parcel.writeTypedObject(param1Parcel2, (T)bundle, 1);
            return true;
          case 4:
            param1Int1 = getSmallIconId();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(param1Int1);
            return true;
          case 3:
            cancelNotification((Bundle)ITrustedWebActivityService._Parcel.readTypedObject((Parcel)bundle, Bundle.CREATOR));
            param1Parcel2.writeNoException();
            return true;
          case 2:
            break;
        } 
        Bundle bundle = notifyNotificationWithChannel((Bundle)ITrustedWebActivityService._Parcel.readTypedObject((Parcel)bundle, Bundle.CREATOR));
        param1Parcel2.writeNoException();
        ITrustedWebActivityService._Parcel.writeTypedObject(param1Parcel2, (T)bundle, 1);
        return true;
      } 
      param1Parcel2.writeString("android.support.customtabs.trusted.ITrustedWebActivityService");
      return true;
    }
    
    private static class Proxy implements ITrustedWebActivityService {
      private IBinder mRemote;
      
      Proxy(IBinder param2IBinder) {
        this.mRemote = param2IBinder;
      }
      
      public Bundle areNotificationsEnabled(Bundle param2Bundle) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.support.customtabs.trusted.ITrustedWebActivityService");
          ITrustedWebActivityService._Parcel.writeTypedObject(parcel1, (T)param2Bundle, 0);
          this.mRemote.transact(6, parcel1, parcel2, 0);
          parcel2.readException();
          param2Bundle = (Bundle)ITrustedWebActivityService._Parcel.readTypedObject(parcel2, Bundle.CREATOR);
          return param2Bundle;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public IBinder asBinder() {
        return this.mRemote;
      }
      
      public void cancelNotification(Bundle param2Bundle) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.support.customtabs.trusted.ITrustedWebActivityService");
          ITrustedWebActivityService._Parcel.writeTypedObject(parcel1, (T)param2Bundle, 0);
          this.mRemote.transact(3, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public Bundle extraCommand(String param2String, Bundle param2Bundle, IBinder param2IBinder) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.support.customtabs.trusted.ITrustedWebActivityService");
          parcel1.writeString(param2String);
          ITrustedWebActivityService._Parcel.writeTypedObject(parcel1, (T)param2Bundle, 0);
          parcel1.writeStrongBinder(param2IBinder);
          this.mRemote.transact(9, parcel1, parcel2, 0);
          parcel2.readException();
          return (Bundle)ITrustedWebActivityService._Parcel.readTypedObject(parcel2, Bundle.CREATOR);
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public Bundle getActiveNotifications() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.support.customtabs.trusted.ITrustedWebActivityService");
          this.mRemote.transact(5, parcel1, parcel2, 0);
          parcel2.readException();
          return (Bundle)ITrustedWebActivityService._Parcel.readTypedObject(parcel2, Bundle.CREATOR);
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public String getInterfaceDescriptor() {
        return "android.support.customtabs.trusted.ITrustedWebActivityService";
      }
      
      public Bundle getSmallIconBitmap() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.support.customtabs.trusted.ITrustedWebActivityService");
          this.mRemote.transact(7, parcel1, parcel2, 0);
          parcel2.readException();
          return (Bundle)ITrustedWebActivityService._Parcel.readTypedObject(parcel2, Bundle.CREATOR);
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public int getSmallIconId() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.support.customtabs.trusted.ITrustedWebActivityService");
          this.mRemote.transact(4, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readInt();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public Bundle notifyNotificationWithChannel(Bundle param2Bundle) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.support.customtabs.trusted.ITrustedWebActivityService");
          ITrustedWebActivityService._Parcel.writeTypedObject(parcel1, (T)param2Bundle, 0);
          this.mRemote.transact(2, parcel1, parcel2, 0);
          parcel2.readException();
          param2Bundle = (Bundle)ITrustedWebActivityService._Parcel.readTypedObject(parcel2, Bundle.CREATOR);
          return param2Bundle;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class Proxy implements ITrustedWebActivityService {
    private IBinder mRemote;
    
    Proxy(IBinder param1IBinder) {
      this.mRemote = param1IBinder;
    }
    
    public Bundle areNotificationsEnabled(Bundle param1Bundle) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.support.customtabs.trusted.ITrustedWebActivityService");
        ITrustedWebActivityService._Parcel.writeTypedObject(parcel1, (T)param1Bundle, 0);
        this.mRemote.transact(6, parcel1, parcel2, 0);
        parcel2.readException();
        param1Bundle = (Bundle)ITrustedWebActivityService._Parcel.readTypedObject(parcel2, Bundle.CREATOR);
        return param1Bundle;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public IBinder asBinder() {
      return this.mRemote;
    }
    
    public void cancelNotification(Bundle param1Bundle) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.support.customtabs.trusted.ITrustedWebActivityService");
        ITrustedWebActivityService._Parcel.writeTypedObject(parcel1, (T)param1Bundle, 0);
        this.mRemote.transact(3, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public Bundle extraCommand(String param1String, Bundle param1Bundle, IBinder param1IBinder) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.support.customtabs.trusted.ITrustedWebActivityService");
        parcel1.writeString(param1String);
        ITrustedWebActivityService._Parcel.writeTypedObject(parcel1, (T)param1Bundle, 0);
        parcel1.writeStrongBinder(param1IBinder);
        this.mRemote.transact(9, parcel1, parcel2, 0);
        parcel2.readException();
        return (Bundle)ITrustedWebActivityService._Parcel.readTypedObject(parcel2, Bundle.CREATOR);
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public Bundle getActiveNotifications() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.support.customtabs.trusted.ITrustedWebActivityService");
        this.mRemote.transact(5, parcel1, parcel2, 0);
        parcel2.readException();
        return (Bundle)ITrustedWebActivityService._Parcel.readTypedObject(parcel2, Bundle.CREATOR);
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public String getInterfaceDescriptor() {
      return "android.support.customtabs.trusted.ITrustedWebActivityService";
    }
    
    public Bundle getSmallIconBitmap() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.support.customtabs.trusted.ITrustedWebActivityService");
        this.mRemote.transact(7, parcel1, parcel2, 0);
        parcel2.readException();
        return (Bundle)ITrustedWebActivityService._Parcel.readTypedObject(parcel2, Bundle.CREATOR);
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public int getSmallIconId() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.support.customtabs.trusted.ITrustedWebActivityService");
        this.mRemote.transact(4, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readInt();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public Bundle notifyNotificationWithChannel(Bundle param1Bundle) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.support.customtabs.trusted.ITrustedWebActivityService");
        ITrustedWebActivityService._Parcel.writeTypedObject(parcel1, (T)param1Bundle, 0);
        this.mRemote.transact(2, parcel1, parcel2, 0);
        parcel2.readException();
        param1Bundle = (Bundle)ITrustedWebActivityService._Parcel.readTypedObject(parcel2, Bundle.CREATOR);
        return param1Bundle;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
  
  public static class _Parcel {
    private static <T> T readTypedObject(Parcel param1Parcel, Parcelable.Creator<T> param1Creator) {
      return (T)((param1Parcel.readInt() != 0) ? param1Creator.createFromParcel(param1Parcel) : null);
    }
    
    private static <T extends Parcelable> void writeTypedObject(Parcel param1Parcel, T param1T, int param1Int) {
      if (param1T != null) {
        param1Parcel.writeInt(1);
        param1T.writeToParcel(param1Parcel, param1Int);
        return;
      } 
      param1Parcel.writeInt(0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\AnkiDroid Flashcards-dex2jar.jar!\android\support\customtabs\trusted\ITrustedWebActivityService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */