package a2;

import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.l;
import org.json.JSONArray;
import org.json.JSONObject;

public final class b {
  public static final a e = new a(null);
  
  private final String a;
  
  private final String b;
  
  private final List<c> c;
  
  private final String d;
  
  public b(JSONObject paramJSONObject) {
    String str = paramJSONObject.getString("name");
    l.d(str, "component.getString(PARAMETER_NAME_KEY)");
    this.a = str;
    str = paramJSONObject.optString("value");
    l.d(str, "component.optString(PARAMETER_VALUE_KEY)");
    this.b = str;
    str = paramJSONObject.optString("path_type", "absolute");
    l.d(str, "component.optString(Constants.EVENT_MAPPING_PATH_TYPE_KEY, Constants.PATH_TYPE_ABSOLUTE)");
    this.d = str;
    ArrayList<c> arrayList = new ArrayList();
    JSONArray jSONArray = paramJSONObject.optJSONArray("path");
    if (jSONArray != null) {
      int i = 0;
      int j = jSONArray.length();
      if (j > 0)
        while (true) {
          int k = i + 1;
          JSONObject jSONObject = jSONArray.getJSONObject(i);
          l.d(jSONObject, "jsonPathArray.getJSONObject(i)");
          arrayList.add(new c(jSONObject));
          if (k >= j)
            break; 
          i = k;
        }  
    } 
    this.c = arrayList;
  }
  
  public final String a() {
    return this.a;
  }
  
  public final List<c> b() {
    return this.c;
  }
  
  public final String c() {
    return this.d;
  }
  
  public final String d() {
    return this.b;
  }
  
  public static final class a {
    private a() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a2\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */