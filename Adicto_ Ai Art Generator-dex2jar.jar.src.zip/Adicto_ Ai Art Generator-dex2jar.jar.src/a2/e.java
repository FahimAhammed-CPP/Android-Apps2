package a2;

import android.util.Log;
import java.lang.reflect.Method;
import kotlin.jvm.internal.l;

public final class e {
  public static final e a = new e();
  
  private static final String b = e.class.getCanonicalName();
  
  private static Class<?> c;
  
  public static final void a() {
    d("UnityFacebookSDKPlugin", "CaptureViewHierarchy", "");
  }
  
  private final Class<?> b() {
    Class<?> clazz = Class.forName("com.unity3d.player.UnityPlayer");
    l.d(clazz, "forName(UNITY_PLAYER_CLASS)");
    return clazz;
  }
  
  public static final void c(String paramString) {
    d("UnityFacebookSDKPlugin", "OnReceiveMapping", paramString);
  }
  
  public static final void d(String paramString1, String paramString2, String paramString3) {
    try {
      if (c == null)
        c = a.b(); 
      Class<?> clazz = c;
      if (clazz != null) {
        Method method = clazz.getMethod("UnitySendMessage", new Class[] { String.class, String.class, String.class });
        Class<?> clazz1 = c;
        if (clazz1 != null) {
          method.invoke(clazz1, new Object[] { paramString1, paramString2, paramString3 });
          return;
        } 
        l.t("unityPlayer");
        throw null;
      } 
      l.t("unityPlayer");
      throw null;
    } catch (Exception exception) {
      Log.e(b, "Failed to send message to Unity", exception);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a2\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */