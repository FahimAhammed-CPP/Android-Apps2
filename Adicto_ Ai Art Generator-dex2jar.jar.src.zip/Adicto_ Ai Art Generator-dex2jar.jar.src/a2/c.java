package a2;

import java.util.Arrays;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.l;
import org.json.JSONObject;

public final class c {
  public static final a i = new a(null);
  
  private final String a;
  
  private final int b;
  
  private final int c;
  
  private final String d;
  
  private final String e;
  
  private final String f;
  
  private final String g;
  
  private final int h;
  
  public c(JSONObject paramJSONObject) {
    String str = paramJSONObject.getString("class_name");
    l.d(str, "component.getString(PATH_CLASS_NAME_KEY)");
    this.a = str;
    this.b = paramJSONObject.optInt("index", -1);
    this.c = paramJSONObject.optInt("id");
    str = paramJSONObject.optString("text");
    l.d(str, "component.optString(PATH_TEXT_KEY)");
    this.d = str;
    str = paramJSONObject.optString("tag");
    l.d(str, "component.optString(PATH_TAG_KEY)");
    this.e = str;
    str = paramJSONObject.optString("description");
    l.d(str, "component.optString(PATH_DESCRIPTION_KEY)");
    this.f = str;
    str = paramJSONObject.optString("hint");
    l.d(str, "component.optString(PATH_HINT_KEY)");
    this.g = str;
    this.h = paramJSONObject.optInt("match_bitmask");
  }
  
  public final String a() {
    return this.a;
  }
  
  public final String b() {
    return this.f;
  }
  
  public final String c() {
    return this.g;
  }
  
  public final int d() {
    return this.c;
  }
  
  public final int e() {
    return this.b;
  }
  
  public final int f() {
    return this.h;
  }
  
  public final String g() {
    return this.e;
  }
  
  public final String h() {
    return this.d;
  }
  
  public static final class a {
    private a() {}
  }
  
  public enum b {
    c(1),
    d(2),
    e(4),
    f(8),
    g(16);
    
    private final int b;
    
    b(int param1Int1) {
      this.b = param1Int1;
    }
    
    public final int b() {
      return this.b;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a2\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */