package a2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.l;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class a {
  public static final b j = new b(null);
  
  private final String a;
  
  private final c b;
  
  private final a c;
  
  private final String d;
  
  private final List<c> e;
  
  private final List<b> f;
  
  private final String g;
  
  private final String h;
  
  private final String i;
  
  public a(String paramString1, c paramc, a parama, String paramString2, List<c> paramList, List<b> paramList1, String paramString3, String paramString4, String paramString5) {
    this.a = paramString1;
    this.b = paramc;
    this.c = parama;
    this.d = paramString2;
    this.e = paramList;
    this.f = paramList1;
    this.g = paramString3;
    this.h = paramString4;
    this.i = paramString5;
  }
  
  public final String a() {
    return this.i;
  }
  
  public final String b() {
    return this.a;
  }
  
  public final List<b> c() {
    List<b> list = Collections.unmodifiableList(this.f);
    l.d(list, "unmodifiableList(parameters)");
    return list;
  }
  
  public final List<c> d() {
    List<c> list = Collections.unmodifiableList(this.e);
    l.d(list, "unmodifiableList(path)");
    return list;
  }
  
  public enum a {
    b, c, d;
  }
  
  public static final class b {
    private b() {}
    
    public final a a(JSONObject param1JSONObject) throws JSONException, IllegalArgumentException {
      l.e(param1JSONObject, "mapping");
      String str2 = param1JSONObject.getString("event_name");
      String str3 = param1JSONObject.getString("method");
      l.d(str3, "mapping.getString(\"method\")");
      Locale locale = Locale.ENGLISH;
      l.d(locale, "ENGLISH");
      str3 = str3.toUpperCase(locale);
      l.d(str3, "(this as java.lang.String).toUpperCase(locale)");
      a.c c = a.c.valueOf(str3);
      String str5 = param1JSONObject.getString("event_type");
      l.d(str5, "mapping.getString(\"event_type\")");
      l.d(locale, "ENGLISH");
      String str4 = str5.toUpperCase(locale);
      l.d(str4, "(this as java.lang.String).toUpperCase(locale)");
      a.a a = a.a.valueOf(str4);
      str5 = param1JSONObject.getString("app_version");
      JSONArray jSONArray1 = param1JSONObject.getJSONArray("path");
      ArrayList<c> arrayList = new ArrayList();
      int j = jSONArray1.length();
      int i = 0;
      if (j > 0)
        for (int k = 0;; k = m) {
          int m = k + 1;
          JSONObject jSONObject = jSONArray1.getJSONObject(k);
          l.d(jSONObject, "jsonPath");
          arrayList.add(new c(jSONObject));
          if (m >= j)
            break; 
        }  
      String str6 = param1JSONObject.optString("path_type", "absolute");
      JSONArray jSONArray2 = param1JSONObject.optJSONArray("parameters");
      ArrayList<b> arrayList1 = new ArrayList();
      if (jSONArray2 != null) {
        int k = jSONArray2.length();
        if (k > 0)
          for (int m = i;; m = i) {
            i = m + 1;
            JSONObject jSONObject = jSONArray2.getJSONObject(m);
            l.d(jSONObject, "jsonParameter");
            arrayList1.add(new b(jSONObject));
            if (i >= k)
              break; 
          }  
      } 
      String str7 = param1JSONObject.optString("component_id");
      String str1 = param1JSONObject.optString("activity_name");
      l.d(str2, "eventName");
      l.d(str5, "appVersion");
      l.d(str7, "componentId");
      l.d(str6, "pathType");
      l.d(str1, "activityName");
      return new a(str2, c, a, str5, arrayList, arrayList1, str7, str6, str1);
    }
    
    public final List<a> b(JSONArray param1JSONArray) {
      ArrayList<a> arrayList = new ArrayList();
      if (param1JSONArray != null) {
        int i = 0;
        try {
          int j = param1JSONArray.length();
          if (j > 0)
            while (true) {
              int k = i + 1;
              JSONObject jSONObject = param1JSONArray.getJSONObject(i);
              l.d(jSONObject, "array.getJSONObject(i)");
              arrayList.add(a(jSONObject));
              if (k >= j)
                return arrayList; 
              i = k;
            }  
          return arrayList;
        } catch (JSONException|IllegalArgumentException jSONException) {
          return arrayList;
        } 
      } 
      return arrayList;
    }
  }
  
  public enum c {
    b, c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a2\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */