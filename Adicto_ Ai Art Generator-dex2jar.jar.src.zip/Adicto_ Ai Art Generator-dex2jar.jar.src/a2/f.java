package a2;

import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.EditText;
import android.widget.TextView;
import com.facebook.internal.m0;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.internal.l;
import o2.a;
import org.json.JSONObject;

public final class f {
  public static final f a = new f();
  
  private static final String b = f.class.getCanonicalName();
  
  private static WeakReference<View> c = new WeakReference<View>(null);
  
  private static Method d;
  
  public static final View a(View paramView) {
    if (a.d(f.class))
      return null; 
    while (paramView != null) {
      try {
        if (a.q(paramView))
          return paramView; 
        ViewParent viewParent = paramView.getParent();
      } finally {
        paramView = null;
      } 
    } 
    return null;
  }
  
  public static final List<View> b(View paramView) {
    if (a.d(f.class))
      return null; 
    try {
      return arrayList;
    } finally {
      paramView = null;
      a.b((Throwable)paramView, f.class);
    } 
  }
  
  public static final int c(View paramView) {
    if (a.d(f.class))
      return 0; 
    try {
      l.e(paramView, "view");
      if (paramView instanceof android.widget.ImageView) {
        j = 2;
      } else {
        j = 0;
      } 
      int i = j;
      if (paramView.isClickable())
        i = j | 0x20; 
      int j = i;
      return k;
    } finally {
      paramView = null;
      a.b((Throwable)paramView, f.class);
    } 
  }
  
  public static final JSONObject d(View paramView) {
    if (a.d(f.class))
      return null; 
    try {
      l.e(paramView, "view");
      if (l.a(paramView.getClass().getName(), "com.facebook.react.ReactRootView"))
        c = new WeakReference<View>(paramView); 
    } finally {
      paramView = null;
      a.b((Throwable)paramView, f.class);
    } 
  }
  
  private final JSONObject e(View paramView) {
    if (a.d(this))
      return null; 
    try {
    
    } finally {
      paramView = null;
      a.b((Throwable)paramView, this);
    } 
  }
  
  private final Class<?> f(String paramString) {
    if (a.d(this))
      return null; 
    try {
      return Class.forName(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      return null;
    } finally {
      paramString = null;
      a.b((Throwable)paramString, this);
    } 
  }
  
  public static final View.OnClickListener g(View paramView) {
    if (a.d(f.class))
      return null; 
    try {
      Field field = Class.forName("android.view.View").getDeclaredField("mListenerInfo");
      if (field != null)
        field.setAccessible(true); 
      Object object = field.get(paramView);
      if (object == null)
        return null; 
      return null;
    } catch (NoSuchFieldException|ClassNotFoundException|IllegalAccessException noSuchFieldException) {
      return null;
    } finally {
      paramView = null;
      a.b((Throwable)paramView, f.class);
    } 
  }
  
  public static final View.OnTouchListener h(View paramView) {
    if (a.d(f.class))
      return null; 
    try {
      Field field = Class.forName("android.view.View").getDeclaredField("mListenerInfo");
      if (field != null)
        field.setAccessible(true); 
      Object object = field.get(paramView);
      if (object == null)
        return null; 
      field = Class.forName("android.view.View$ListenerInfo").getDeclaredField("mOnTouchListener");
      if (field != null) {
        field.setAccessible(true);
        object = field.get(object);
        if (object != null)
          return (View.OnTouchListener)object; 
        throw new NullPointerException("null cannot be cast to non-null type android.view.View.OnTouchListener");
      } 
      return null;
    } catch (NoSuchFieldException noSuchFieldException) {
      m0 m0 = m0.a;
      m0.i0(b, noSuchFieldException);
      return null;
    } catch (ClassNotFoundException classNotFoundException) {
      m0 m0 = m0.a;
      m0.i0(b, classNotFoundException);
      return null;
    } catch (IllegalAccessException illegalAccessException) {
      m0 m0 = m0.a;
      m0.i0(b, illegalAccessException);
      return null;
    } finally {}
    a.b((Throwable)paramView, f.class);
    return null;
  }
  
  public static final String i(View paramView) {
    if (a.d(f.class))
      return null; 
    try {
      CharSequence charSequence;
      if (paramView instanceof EditText) {
        charSequence = ((EditText)paramView).getHint();
      } else if (charSequence instanceof TextView) {
        charSequence = ((TextView)charSequence).getHint();
      } else {
        charSequence = null;
      } 
      return (String)((charSequence == null) ? "" : charSequence);
    } finally {
      paramView = null;
      a.b((Throwable)paramView, f.class);
    } 
  }
  
  public static final ViewGroup j(View paramView) {
    boolean bool = a.d(f.class);
    View view = null;
    if (bool)
      return null; 
    if (paramView == null)
      return null; 
    try {
      ViewParent viewParent = paramView.getParent();
      return viewGroup;
    } finally {
      paramView = null;
      a.b((Throwable)paramView, f.class);
    } 
  }
  
  public static final String k(View paramView) {
    // Byte code:
    //   0: ldc a2/f
    //   2: invokestatic d : (Ljava/lang/Object;)Z
    //   5: ifeq -> 10
    //   8: aconst_null
    //   9: areturn
    //   10: aload_0
    //   11: instanceof android/widget/TextView
    //   14: ifeq -> 50
    //   17: aload_0
    //   18: checkcast android/widget/TextView
    //   21: invokevirtual getText : ()Ljava/lang/CharSequence;
    //   24: astore #6
    //   26: aload_0
    //   27: instanceof android/widget/Switch
    //   30: ifeq -> 370
    //   33: aload_0
    //   34: checkcast android/widget/Switch
    //   37: invokevirtual isChecked : ()Z
    //   40: ifeq -> 404
    //   43: ldc_w '1'
    //   46: astore_0
    //   47: goto -> 408
    //   50: aload_0
    //   51: instanceof android/widget/Spinner
    //   54: ifeq -> 88
    //   57: aload_0
    //   58: checkcast android/widget/Spinner
    //   61: invokevirtual getCount : ()I
    //   64: ifle -> 367
    //   67: aload_0
    //   68: checkcast android/widget/Spinner
    //   71: invokevirtual getSelectedItem : ()Ljava/lang/Object;
    //   74: astore_0
    //   75: aload_0
    //   76: ifnull -> 367
    //   79: aload_0
    //   80: invokevirtual toString : ()Ljava/lang/String;
    //   83: astore #6
    //   85: goto -> 370
    //   88: aload_0
    //   89: instanceof android/widget/DatePicker
    //   92: istore #5
    //   94: iconst_0
    //   95: istore_1
    //   96: iload #5
    //   98: ifeq -> 177
    //   101: aload_0
    //   102: checkcast android/widget/DatePicker
    //   105: invokevirtual getYear : ()I
    //   108: istore_1
    //   109: aload_0
    //   110: checkcast android/widget/DatePicker
    //   113: invokevirtual getMonth : ()I
    //   116: istore_2
    //   117: aload_0
    //   118: checkcast android/widget/DatePicker
    //   121: invokevirtual getDayOfMonth : ()I
    //   124: istore_3
    //   125: getstatic kotlin/jvm/internal/z.a : Lkotlin/jvm/internal/z;
    //   128: astore_0
    //   129: ldc_w '%04d-%02d-%02d'
    //   132: iconst_3
    //   133: anewarray java/lang/Object
    //   136: dup
    //   137: iconst_0
    //   138: iload_1
    //   139: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   142: aastore
    //   143: dup
    //   144: iconst_1
    //   145: iload_2
    //   146: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   149: aastore
    //   150: dup
    //   151: iconst_2
    //   152: iload_3
    //   153: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   156: aastore
    //   157: iconst_3
    //   158: invokestatic copyOf : ([Ljava/lang/Object;I)[Ljava/lang/Object;
    //   161: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   164: astore #6
    //   166: aload #6
    //   168: ldc_w 'java.lang.String.format(format, *args)'
    //   171: invokestatic d : (Ljava/lang/Object;Ljava/lang/String;)V
    //   174: goto -> 370
    //   177: aload_0
    //   178: instanceof android/widget/TimePicker
    //   181: ifeq -> 272
    //   184: aload_0
    //   185: checkcast android/widget/TimePicker
    //   188: invokevirtual getCurrentHour : ()Ljava/lang/Integer;
    //   191: astore #6
    //   193: aload #6
    //   195: ldc_w 'view.currentHour'
    //   198: invokestatic d : (Ljava/lang/Object;Ljava/lang/String;)V
    //   201: aload #6
    //   203: invokevirtual intValue : ()I
    //   206: istore_1
    //   207: aload_0
    //   208: checkcast android/widget/TimePicker
    //   211: invokevirtual getCurrentMinute : ()Ljava/lang/Integer;
    //   214: astore_0
    //   215: aload_0
    //   216: ldc_w 'view.currentMinute'
    //   219: invokestatic d : (Ljava/lang/Object;Ljava/lang/String;)V
    //   222: aload_0
    //   223: invokevirtual intValue : ()I
    //   226: istore_2
    //   227: getstatic kotlin/jvm/internal/z.a : Lkotlin/jvm/internal/z;
    //   230: astore_0
    //   231: ldc_w '%02d:%02d'
    //   234: iconst_2
    //   235: anewarray java/lang/Object
    //   238: dup
    //   239: iconst_0
    //   240: iload_1
    //   241: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   244: aastore
    //   245: dup
    //   246: iconst_1
    //   247: iload_2
    //   248: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   251: aastore
    //   252: iconst_2
    //   253: invokestatic copyOf : ([Ljava/lang/Object;I)[Ljava/lang/Object;
    //   256: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   259: astore #6
    //   261: aload #6
    //   263: ldc_w 'java.lang.String.format(format, *args)'
    //   266: invokestatic d : (Ljava/lang/Object;Ljava/lang/String;)V
    //   269: goto -> 370
    //   272: aload_0
    //   273: instanceof android/widget/RadioGroup
    //   276: ifeq -> 345
    //   279: aload_0
    //   280: checkcast android/widget/RadioGroup
    //   283: invokevirtual getCheckedRadioButtonId : ()I
    //   286: istore_3
    //   287: aload_0
    //   288: checkcast android/widget/RadioGroup
    //   291: invokevirtual getChildCount : ()I
    //   294: istore #4
    //   296: iload #4
    //   298: ifle -> 367
    //   301: iload_1
    //   302: iconst_1
    //   303: iadd
    //   304: istore_2
    //   305: aload_0
    //   306: checkcast android/widget/RadioGroup
    //   309: iload_1
    //   310: invokevirtual getChildAt : (I)Landroid/view/View;
    //   313: astore #6
    //   315: aload #6
    //   317: invokevirtual getId : ()I
    //   320: iload_3
    //   321: if_icmpne -> 414
    //   324: aload #6
    //   326: instanceof android/widget/RadioButton
    //   329: ifeq -> 414
    //   332: aload #6
    //   334: checkcast android/widget/RadioButton
    //   337: invokevirtual getText : ()Ljava/lang/CharSequence;
    //   340: astore #6
    //   342: goto -> 370
    //   345: aload_0
    //   346: instanceof android/widget/RatingBar
    //   349: ifeq -> 367
    //   352: aload_0
    //   353: checkcast android/widget/RatingBar
    //   356: invokevirtual getRating : ()F
    //   359: invokestatic valueOf : (F)Ljava/lang/String;
    //   362: astore #6
    //   364: goto -> 370
    //   367: aconst_null
    //   368: astore #6
    //   370: aload #6
    //   372: ifnonnull -> 379
    //   375: ldc_w ''
    //   378: areturn
    //   379: aload #6
    //   381: invokevirtual toString : ()Ljava/lang/String;
    //   384: astore_0
    //   385: aload_0
    //   386: ifnonnull -> 393
    //   389: ldc_w ''
    //   392: areturn
    //   393: aload_0
    //   394: areturn
    //   395: astore_0
    //   396: aload_0
    //   397: ldc a2/f
    //   399: invokestatic b : (Ljava/lang/Throwable;Ljava/lang/Object;)V
    //   402: aconst_null
    //   403: areturn
    //   404: ldc_w '0'
    //   407: astore_0
    //   408: aload_0
    //   409: astore #6
    //   411: goto -> 370
    //   414: iload_2
    //   415: iload #4
    //   417: if_icmplt -> 423
    //   420: goto -> 367
    //   423: iload_2
    //   424: istore_1
    //   425: goto -> 301
    // Exception table:
    //   from	to	target	type
    //   10	26	395	finally
    //   26	43	395	finally
    //   50	75	395	finally
    //   79	85	395	finally
    //   88	94	395	finally
    //   101	174	395	finally
    //   177	269	395	finally
    //   272	296	395	finally
    //   305	342	395	finally
    //   345	364	395	finally
    //   379	385	395	finally
  }
  
  private final View l(float[] paramArrayOffloat, View paramView) {
    if (a.d(this))
      return null; 
    try {
      n();
      return null;
    } finally {
      paramArrayOffloat = null;
      a.b((Throwable)paramArrayOffloat, this);
    } 
  }
  
  private final float[] m(View paramView) {
    if (a.d(this))
      return null; 
    try {
      int[] arrayOfInt = new int[2];
      paramView.getLocationOnScreen(arrayOfInt);
      return new float[] { f1, f2 };
    } finally {
      paramView = null;
      a.b((Throwable)paramView, this);
    } 
  }
  
  private final void n() {
    if (a.d(this))
      return; 
    try {
      Method method = d;
    } finally {
      Exception exception = null;
      a.b(exception, this);
    } 
  }
  
  private static final boolean o(View paramView) {
    boolean bool = a.d(f.class);
    boolean bool1 = false;
    if (bool)
      return false; 
    try {
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof android.widget.AdapterView)
        return true; 
      f f1 = a;
      Class<?> clazz2 = f1.f("android.support.v4.view.NestedScrollingChild");
      if (clazz2 != null && clazz2.isInstance(viewParent))
        return true; 
      Class<?> clazz1 = f1.f("androidx.core.view.NestedScrollingChild");
      return bool;
    } finally {
      paramView = null;
      a.b((Throwable)paramView, f.class);
    } 
  }
  
  private final boolean q(View paramView) {
    if (a.d(this))
      return false; 
    try {
      return l.a(paramView.getClass().getName(), "com.facebook.react.ReactRootView");
    } finally {
      paramView = null;
      a.b((Throwable)paramView, this);
    } 
  }
  
  public static final void r(View paramView, View.OnClickListener paramOnClickListener) {
    // Byte code:
    //   0: ldc a2/f
    //   2: invokestatic d : (Ljava/lang/Object;)Z
    //   5: ifeq -> 9
    //   8: return
    //   9: aload_0
    //   10: ldc 'view'
    //   12: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   15: aconst_null
    //   16: astore #4
    //   18: ldc 'android.view.View'
    //   20: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   23: ldc 'mListenerInfo'
    //   25: invokevirtual getDeclaredField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   28: astore_2
    //   29: ldc 'android.view.View$ListenerInfo'
    //   31: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   34: ldc 'mOnClickListener'
    //   36: invokevirtual getDeclaredField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   39: astore_3
    //   40: goto -> 50
    //   43: goto -> 48
    //   46: aconst_null
    //   47: astore_2
    //   48: aconst_null
    //   49: astore_3
    //   50: aload_2
    //   51: ifnull -> 102
    //   54: aload_3
    //   55: ifnonnull -> 61
    //   58: goto -> 102
    //   61: aload_2
    //   62: iconst_1
    //   63: invokevirtual setAccessible : (Z)V
    //   66: aload_3
    //   67: iconst_1
    //   68: invokevirtual setAccessible : (Z)V
    //   71: aload_2
    //   72: iconst_1
    //   73: invokevirtual setAccessible : (Z)V
    //   76: aload_2
    //   77: aload_0
    //   78: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   81: astore_2
    //   82: goto -> 85
    //   85: aload_2
    //   86: ifnonnull -> 95
    //   89: aload_0
    //   90: aload_1
    //   91: invokevirtual setOnClickListener : (Landroid/view/View$OnClickListener;)V
    //   94: return
    //   95: aload_3
    //   96: aload_2
    //   97: aload_1
    //   98: invokevirtual set : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   101: return
    //   102: aload_0
    //   103: aload_1
    //   104: invokevirtual setOnClickListener : (Landroid/view/View$OnClickListener;)V
    //   107: return
    //   108: astore_0
    //   109: aload_0
    //   110: ldc a2/f
    //   112: invokestatic b : (Ljava/lang/Throwable;Ljava/lang/Object;)V
    //   115: return
    //   116: astore_2
    //   117: goto -> 46
    //   120: astore_0
    //   121: return
    //   122: astore_3
    //   123: goto -> 43
    //   126: astore_2
    //   127: aload #4
    //   129: astore_2
    //   130: goto -> 85
    // Exception table:
    //   from	to	target	type
    //   9	15	108	finally
    //   18	29	116	java/lang/ClassNotFoundException
    //   18	29	116	java/lang/NoSuchFieldException
    //   18	29	120	java/lang/Exception
    //   18	29	108	finally
    //   29	40	122	java/lang/ClassNotFoundException
    //   29	40	122	java/lang/NoSuchFieldException
    //   29	40	120	java/lang/Exception
    //   29	40	108	finally
    //   61	71	120	java/lang/Exception
    //   61	71	108	finally
    //   71	82	126	java/lang/IllegalAccessException
    //   71	82	120	java/lang/Exception
    //   71	82	108	finally
    //   89	94	120	java/lang/Exception
    //   89	94	108	finally
    //   95	101	120	java/lang/Exception
    //   95	101	108	finally
    //   102	107	120	java/lang/Exception
    //   102	107	108	finally
  }
  
  public static final void s(View paramView, JSONObject paramJSONObject) {
    if (a.d(f.class))
      return; 
    try {
      l.e(paramView, "view");
    } finally {
      paramView = null;
      a.b((Throwable)paramView, f.class);
    } 
  }
  
  public final boolean p(View paramView1, View paramView2) {
    boolean bool = a.d(this);
    boolean bool1 = false;
    if (bool)
      return false; 
    try {
      l.e(paramView1, "view");
      return bool;
    } finally {
      paramView1 = null;
      a.b((Throwable)paramView1, this);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a2\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */