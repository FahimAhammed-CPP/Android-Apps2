package a2;

import android.util.Patterns;
import android.view.View;
import android.widget.TextView;
import o2.a;

public final class d {
  public static final d a = new d();
  
  private final boolean a(TextView paramTextView) {
    // Byte code:
    //   0: aload_0
    //   1: invokestatic d : (Ljava/lang/Object;)Z
    //   4: istore #8
    //   6: iconst_0
    //   7: istore #9
    //   9: iload #8
    //   11: ifeq -> 16
    //   14: iconst_0
    //   15: ireturn
    //   16: aload_1
    //   17: invokestatic k : (Landroid/view/View;)Ljava/lang/String;
    //   20: astore_1
    //   21: new de/f
    //   24: dup
    //   25: ldc '\s'
    //   27: invokespecial <init> : (Ljava/lang/String;)V
    //   30: aload_1
    //   31: ldc ''
    //   33: invokevirtual b : (Ljava/lang/CharSequence;Ljava/lang/String;)Ljava/lang/String;
    //   36: astore_1
    //   37: aload_1
    //   38: invokevirtual length : ()I
    //   41: istore_3
    //   42: iload #9
    //   44: istore #8
    //   46: iload_3
    //   47: bipush #12
    //   49: if_icmplt -> 136
    //   52: iload_3
    //   53: bipush #19
    //   55: if_icmple -> 147
    //   58: iconst_0
    //   59: ireturn
    //   60: iload_3
    //   61: iconst_1
    //   62: isub
    //   63: istore #6
    //   65: aload_1
    //   66: iload_3
    //   67: invokevirtual charAt : (I)C
    //   70: istore_2
    //   71: iload_2
    //   72: invokestatic isDigit : (C)Z
    //   75: ifne -> 80
    //   78: iconst_0
    //   79: ireturn
    //   80: iload_2
    //   81: invokestatic d : (C)I
    //   84: istore #7
    //   86: iload #7
    //   88: istore_3
    //   89: iload #4
    //   91: ifeq -> 164
    //   94: iload #7
    //   96: iconst_2
    //   97: imul
    //   98: istore #7
    //   100: iload #7
    //   102: istore_3
    //   103: iload #7
    //   105: bipush #9
    //   107: if_icmple -> 164
    //   110: iload #7
    //   112: bipush #10
    //   114: irem
    //   115: iconst_1
    //   116: iadd
    //   117: istore_3
    //   118: goto -> 164
    //   121: iload #9
    //   123: istore #8
    //   125: iload #5
    //   127: bipush #10
    //   129: irem
    //   130: ifne -> 136
    //   133: iconst_1
    //   134: istore #8
    //   136: iload #8
    //   138: ireturn
    //   139: astore_1
    //   140: aload_1
    //   141: aload_0
    //   142: invokestatic b : (Ljava/lang/Throwable;Ljava/lang/Object;)V
    //   145: iconst_0
    //   146: ireturn
    //   147: iload_3
    //   148: iconst_1
    //   149: isub
    //   150: istore_3
    //   151: iload_3
    //   152: iflt -> 190
    //   155: iconst_0
    //   156: istore #4
    //   158: iconst_0
    //   159: istore #5
    //   161: goto -> 60
    //   164: iload #5
    //   166: iload_3
    //   167: iadd
    //   168: istore #5
    //   170: iload #4
    //   172: iconst_1
    //   173: ixor
    //   174: istore #4
    //   176: iload #6
    //   178: ifge -> 184
    //   181: goto -> 121
    //   184: iload #6
    //   186: istore_3
    //   187: goto -> 60
    //   190: iconst_0
    //   191: istore #5
    //   193: goto -> 121
    // Exception table:
    //   from	to	target	type
    //   16	42	139	finally
    //   65	78	139	finally
    //   80	86	139	finally
  }
  
  private final boolean b(TextView paramTextView) {
    boolean bool;
    boolean bool1 = a.d(this);
    null = false;
    if (bool1)
      return false; 
    try {
      int i = paramTextView.getInputType();
      bool = true;
      if (i == 32)
        return true; 
    } finally {
      paramTextView = null;
      a.b((Throwable)paramTextView, this);
    } 
    return bool ? false : Patterns.EMAIL_ADDRESS.matcher((CharSequence)paramTextView).matches();
  }
  
  private final boolean c(TextView paramTextView) {
    if (a.d(this))
      return false; 
    try {
      return (paramTextView.getInputType() == 128) ? true : (paramTextView.getTransformationMethod() instanceof android.text.method.PasswordTransformationMethod);
    } finally {
      paramTextView = null;
      a.b((Throwable)paramTextView, this);
    } 
  }
  
  private final boolean d(TextView paramTextView) {
    boolean bool1 = a.d(this);
    boolean bool = false;
    if (bool1)
      return false; 
    try {
      return bool;
    } finally {
      paramTextView = null;
      a.b((Throwable)paramTextView, this);
    } 
  }
  
  private final boolean e(TextView paramTextView) {
    boolean bool1 = a.d(this);
    boolean bool = false;
    if (bool1)
      return false; 
    try {
      return bool;
    } finally {
      paramTextView = null;
      a.b((Throwable)paramTextView, this);
    } 
  }
  
  private final boolean f(TextView paramTextView) {
    boolean bool1 = a.d(this);
    boolean bool = false;
    if (bool1)
      return false; 
    try {
      return bool;
    } finally {
      paramTextView = null;
      a.b((Throwable)paramTextView, this);
    } 
  }
  
  public static final boolean g(View paramView) {
    boolean bool = a.d(d.class);
    boolean bool1 = false;
    if (bool)
      return false; 
    bool = bool1;
    try {
      return true;
    } finally {
      paramView = null;
      a.b((Throwable)paramView, d.class);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a2\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */