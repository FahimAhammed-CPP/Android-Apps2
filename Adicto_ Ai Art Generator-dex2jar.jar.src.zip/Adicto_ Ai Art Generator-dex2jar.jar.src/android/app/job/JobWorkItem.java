package android.app.job;

import android.content.Intent;
import android.os.Parcelable;



/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\android\app\job\JobWorkItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */