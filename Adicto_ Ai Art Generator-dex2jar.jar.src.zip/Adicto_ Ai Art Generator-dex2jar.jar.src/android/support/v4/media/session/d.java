package android.support.v4.media.session;

import androidx.annotation.NonNull;
import androidx.media.AudioAttributesCompat;

public final class d {
  private final int a;
  
  private final AudioAttributesCompat b;
  
  private final int c;
  
  private final int d;
  
  private final int e;
  
  d(int paramInt1, @NonNull AudioAttributesCompat paramAudioAttributesCompat, int paramInt2, int paramInt3, int paramInt4) {
    this.a = paramInt1;
    this.b = paramAudioAttributesCompat;
    this.c = paramInt2;
    this.d = paramInt3;
    this.e = paramInt4;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\android\support\v4\media\session\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */