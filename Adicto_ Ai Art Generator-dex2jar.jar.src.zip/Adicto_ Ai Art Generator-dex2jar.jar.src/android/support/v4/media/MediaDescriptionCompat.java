package android.support.v4.media;

import android.graphics.Bitmap;
import android.media.MediaDescription;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.session.MediaSessionCompat;
import androidx.annotation.Nullable;

public final class MediaDescriptionCompat implements Parcelable {
  public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new a();
  
  private final String b;
  
  private final CharSequence c;
  
  private final CharSequence d;
  
  private final CharSequence e;
  
  private final Bitmap f;
  
  private final Uri g;
  
  private final Bundle h;
  
  private final Uri i;
  
  private MediaDescription j;
  
  MediaDescriptionCompat(String paramString, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, Bitmap paramBitmap, Uri paramUri1, Bundle paramBundle, Uri paramUri2) {
    this.b = paramString;
    this.c = paramCharSequence1;
    this.d = paramCharSequence2;
    this.e = paramCharSequence3;
    this.f = paramBitmap;
    this.g = paramUri1;
    this.h = paramBundle;
    this.i = paramUri2;
  }
  
  public static MediaDescriptionCompat a(Object paramObject) {
    MediaDescriptionCompat mediaDescriptionCompat;
    Bundle bundle1 = null;
    Bundle bundle2 = null;
    if (paramObject != null) {
      int i = Build.VERSION.SDK_INT;
      b b = new b();
      MediaDescription mediaDescription = (MediaDescription)paramObject;
      b.f(mediaDescription.getMediaId());
      b.i(mediaDescription.getTitle());
      b.h(mediaDescription.getSubtitle());
      b.b(mediaDescription.getDescription());
      b.d(mediaDescription.getIconBitmap());
      b.e(mediaDescription.getIconUri());
      bundle1 = mediaDescription.getExtras();
      if (bundle1 != null) {
        MediaSessionCompat.a(bundle1);
        paramObject = bundle1.getParcelable("android.support.v4.media.description.MEDIA_URI");
      } else {
        paramObject = null;
      } 
      if (paramObject != null)
        if (bundle1.containsKey("android.support.v4.media.description.NULL_BUNDLE_FLAG") && bundle1.size() == 2) {
          bundle1 = bundle2;
        } else {
          bundle1.remove("android.support.v4.media.description.MEDIA_URI");
          bundle1.remove("android.support.v4.media.description.NULL_BUNDLE_FLAG");
        }  
      b.c(bundle1);
      if (paramObject != null) {
        b.g((Uri)paramObject);
      } else if (i >= 23) {
        b.g(b.a(mediaDescription));
      } 
      mediaDescriptionCompat = b.a();
      mediaDescriptionCompat.j = mediaDescription;
    } 
    return mediaDescriptionCompat;
  }
  
  public Object c() {
    MediaDescription mediaDescription2 = this.j;
    MediaDescription mediaDescription1 = mediaDescription2;
    if (mediaDescription2 == null) {
      int i = Build.VERSION.SDK_INT;
      MediaDescription.Builder builder = new MediaDescription.Builder();
      builder.setMediaId(this.b);
      builder.setTitle(this.c);
      builder.setSubtitle(this.d);
      builder.setDescription(this.e);
      builder.setIconBitmap(this.f);
      builder.setIconUri(this.g);
      Bundle bundle2 = this.h;
      Bundle bundle1 = bundle2;
      if (i < 23) {
        bundle1 = bundle2;
        if (this.i != null) {
          bundle1 = bundle2;
          if (bundle2 == null) {
            bundle1 = new Bundle();
            bundle1.putBoolean("android.support.v4.media.description.NULL_BUNDLE_FLAG", true);
          } 
          bundle1.putParcelable("android.support.v4.media.description.MEDIA_URI", (Parcelable)this.i);
        } 
      } 
      builder.setExtras(bundle1);
      if (i >= 23)
        a.a(builder, this.i); 
      mediaDescription1 = builder.build();
      this.j = mediaDescription1;
    } 
    return mediaDescription1;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.c);
    stringBuilder.append(", ");
    stringBuilder.append(this.d);
    stringBuilder.append(", ");
    stringBuilder.append(this.e);
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    ((MediaDescription)c()).writeToParcel(paramParcel, paramInt);
  }
  
  static final class a implements Parcelable.Creator<MediaDescriptionCompat> {
    public MediaDescriptionCompat a(Parcel param1Parcel) {
      return MediaDescriptionCompat.a(MediaDescription.CREATOR.createFromParcel(param1Parcel));
    }
    
    public MediaDescriptionCompat[] b(int param1Int) {
      return new MediaDescriptionCompat[param1Int];
    }
  }
  
  public static final class b {
    private String a;
    
    private CharSequence b;
    
    private CharSequence c;
    
    private CharSequence d;
    
    private Bitmap e;
    
    private Uri f;
    
    private Bundle g;
    
    private Uri h;
    
    public MediaDescriptionCompat a() {
      return new MediaDescriptionCompat(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h);
    }
    
    public b b(@Nullable CharSequence param1CharSequence) {
      this.d = param1CharSequence;
      return this;
    }
    
    public b c(@Nullable Bundle param1Bundle) {
      this.g = param1Bundle;
      return this;
    }
    
    public b d(@Nullable Bitmap param1Bitmap) {
      this.e = param1Bitmap;
      return this;
    }
    
    public b e(@Nullable Uri param1Uri) {
      this.f = param1Uri;
      return this;
    }
    
    public b f(@Nullable String param1String) {
      this.a = param1String;
      return this;
    }
    
    public b g(@Nullable Uri param1Uri) {
      this.h = param1Uri;
      return this;
    }
    
    public b h(@Nullable CharSequence param1CharSequence) {
      this.c = param1CharSequence;
      return this;
    }
    
    public b i(@Nullable CharSequence param1CharSequence) {
      this.b = param1CharSequence;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\android\support\v4\media\MediaDescriptionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */