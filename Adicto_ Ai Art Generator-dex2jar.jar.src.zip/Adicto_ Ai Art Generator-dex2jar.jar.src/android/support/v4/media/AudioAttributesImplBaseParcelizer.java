package android.support.v4.media;

import androidx.media.AudioAttributesImplBase;
import androidx.media.AudioAttributesImplBaseParcelizer;
import androidx.versionedparcelable.a;

public final class AudioAttributesImplBaseParcelizer extends AudioAttributesImplBaseParcelizer {
  public static AudioAttributesImplBase read(a parama) {
    return AudioAttributesImplBaseParcelizer.read(parama);
  }
  
  public static void write(AudioAttributesImplBase paramAudioAttributesImplBase, a parama) {
    AudioAttributesImplBaseParcelizer.write(paramAudioAttributesImplBase, parama);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\android\support\v4\media\AudioAttributesImplBaseParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */