package android.support.v4.media;

import androidx.media.AudioAttributesCompat;
import androidx.media.AudioAttributesCompatParcelizer;
import androidx.versionedparcelable.a;

public final class AudioAttributesCompatParcelizer extends AudioAttributesCompatParcelizer {
  public static AudioAttributesCompat read(a parama) {
    return AudioAttributesCompatParcelizer.read(parama);
  }
  
  public static void write(AudioAttributesCompat paramAudioAttributesCompat, a parama) {
    AudioAttributesCompatParcelizer.write(paramAudioAttributesCompat, parama);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\android\support\v4\media\AudioAttributesCompatParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */