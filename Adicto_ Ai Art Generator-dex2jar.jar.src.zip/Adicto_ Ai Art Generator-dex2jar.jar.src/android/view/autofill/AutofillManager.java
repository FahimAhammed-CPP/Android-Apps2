package android.view.autofill;

import android.annotation.NonNull;
import android.graphics.Rect;
import android.view.View;



/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\android\view\autofill\AutofillManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */