package a4;

import android.os.SystemClock;

public class e implements a {
  public long a() {
    return SystemClock.elapsedRealtime();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a4\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */