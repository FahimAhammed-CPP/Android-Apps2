package a4;

import s3.b;
import s3.d;

public final class c implements b<a> {
  public static c a() {
    return a.a();
  }
  
  public static a b() {
    return (a)d.c(b.a(), "Cannot return null from a non-@Nullable @Provides method");
  }
  
  public a c() {
    return b();
  }
  
  private static final class a {
    private static final c a = new c();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a4\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */