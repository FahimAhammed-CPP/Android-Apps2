package a4;

public class f implements a {
  public long a() {
    return System.currentTimeMillis();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a4\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */