package a4;

import s3.b;

public final class d implements b<a> {
  public static d a() {
    return a.a();
  }
  
  public static a c() {
    return (a)s3.d.c(b.b(), "Cannot return null from a non-@Nullable @Provides method");
  }
  
  public a b() {
    return c();
  }
  
  private static final class a {
    private static final d a = new d();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a4\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */