package a1;

import android.net.Uri;
import android.os.Handler;
import android.webkit.WebMessage;
import android.webkit.WebMessagePort;
import android.webkit.WebResourceError;
import android.webkit.WebSettings;
import android.webkit.WebView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import z0.d;
import z0.e;

@RequiresApi(23)
public class g {
  public static void a(@NonNull WebMessagePort paramWebMessagePort) {
    paramWebMessagePort.close();
  }
  
  @NonNull
  public static WebMessage b(@NonNull d paramd) {
    return new WebMessage(paramd.a(), c0.b(paramd.b()));
  }
  
  @NonNull
  public static WebMessagePort[] c(@NonNull WebView paramWebView) {
    return c.a(paramWebView);
  }
  
  @NonNull
  public static d d(@NonNull WebMessage paramWebMessage) {
    return new d(paramWebMessage.getData(), c0.e(paramWebMessage.getPorts()));
  }
  
  @NonNull
  public static CharSequence e(@NonNull WebResourceError paramWebResourceError) {
    return paramWebResourceError.getDescription();
  }
  
  public static int f(@NonNull WebResourceError paramWebResourceError) {
    return paramWebResourceError.getErrorCode();
  }
  
  public static boolean g(@NonNull WebSettings paramWebSettings) {
    return b.a(paramWebSettings);
  }
  
  public static void h(@NonNull WebMessagePort paramWebMessagePort, @NonNull WebMessage paramWebMessage) {
    paramWebMessagePort.postMessage(paramWebMessage);
  }
  
  public static void i(@NonNull WebView paramWebView, long paramLong, @NonNull z0.g.a parama) {
    d.a(paramWebView, paramLong, new c(parama));
  }
  
  public static void j(@NonNull WebView paramWebView, @NonNull WebMessage paramWebMessage, @NonNull Uri paramUri) {
    e.a(paramWebView, paramWebMessage, paramUri);
  }
  
  public static void k(@NonNull WebSettings paramWebSettings, boolean paramBoolean) {
    f.a(paramWebSettings, paramBoolean);
  }
  
  public static void l(@NonNull WebMessagePort paramWebMessagePort, @NonNull e.a parama) {
    paramWebMessagePort.setWebMessageCallback(new a(parama));
  }
  
  public static void m(@NonNull WebMessagePort paramWebMessagePort, @NonNull e.a parama, @Nullable Handler paramHandler) {
    paramWebMessagePort.setWebMessageCallback(new b(parama), paramHandler);
  }
  
  class a extends WebMessagePort.WebMessageCallback {
    a(g this$0) {}
    
    public void onMessage(WebMessagePort param1WebMessagePort, WebMessage param1WebMessage) {
      new c0(param1WebMessagePort);
      c0.c(param1WebMessage);
      throw null;
    }
  }
  
  class b extends WebMessagePort.WebMessageCallback {
    b(g this$0) {}
    
    public void onMessage(WebMessagePort param1WebMessagePort, WebMessage param1WebMessage) {
      new c0(param1WebMessagePort);
      c0.c(param1WebMessage);
      throw null;
    }
  }
  
  class c extends WebView.VisualStateCallback {
    c(g this$0) {}
    
    public void onComplete(long param1Long) {
      this.a.onComplete(param1Long);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a1\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */