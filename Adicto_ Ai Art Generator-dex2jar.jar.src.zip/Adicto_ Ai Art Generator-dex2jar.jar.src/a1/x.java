package a1;

import androidx.annotation.NonNull;
import java.lang.reflect.InvocationHandler;
import java.util.concurrent.Callable;
import org.chromium.support_lib_boundary.JsReplyProxyBoundaryInterface;
import z0.a;

public class x extends a {
  private JsReplyProxyBoundaryInterface a;
  
  public x(@NonNull JsReplyProxyBoundaryInterface paramJsReplyProxyBoundaryInterface) {
    this.a = paramJsReplyProxyBoundaryInterface;
  }
  
  @NonNull
  public static x a(@NonNull InvocationHandler paramInvocationHandler) {
    JsReplyProxyBoundaryInterface jsReplyProxyBoundaryInterface = (JsReplyProxyBoundaryInterface)ye.a.a(JsReplyProxyBoundaryInterface.class, paramInvocationHandler);
    return (x)jsReplyProxyBoundaryInterface.getOrCreatePeer(new a(jsReplyProxyBoundaryInterface));
  }
  
  class a implements Callable<Object> {
    a(x this$0) {}
    
    public Object call() {
      return new x(this.a);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a1\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */