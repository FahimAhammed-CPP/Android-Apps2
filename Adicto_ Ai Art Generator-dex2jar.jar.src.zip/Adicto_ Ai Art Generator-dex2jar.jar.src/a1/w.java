package a1;

import android.webkit.WebView;
import androidx.annotation.NonNull;
import org.chromium.support_lib_boundary.WebViewProviderBoundaryInterface;
import org.chromium.support_lib_boundary.WebkitToCompatConverterBoundaryInterface;

public class w implements h0 {
  private static final String[] a = new String[0];
  
  @NonNull
  public String[] a() {
    return a;
  }
  
  @NonNull
  public WebViewProviderBoundaryInterface createWebView(@NonNull WebView paramWebView) {
    throw new UnsupportedOperationException("This should never happen, if this method was called it means we're trying to reach into WebView APK code on an incompatible device. This most likely means the current method is being called too early, or is being called on start-up rather than lazily");
  }
  
  @NonNull
  public WebkitToCompatConverterBoundaryInterface getWebkitToCompatConverter() {
    throw new UnsupportedOperationException("This should never happen, if this method was called it means we're trying to reach into WebView APK code on an incompatible device. This most likely means the current method is being called too early, or is being called on start-up rather than lazily");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a1\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */