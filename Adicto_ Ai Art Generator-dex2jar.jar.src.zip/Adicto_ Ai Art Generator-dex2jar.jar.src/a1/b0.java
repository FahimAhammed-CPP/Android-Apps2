package a1;

import android.net.Uri;
import android.webkit.WebView;
import androidx.annotation.NonNull;
import java.lang.reflect.InvocationHandler;
import org.chromium.support_lib_boundary.WebMessageBoundaryInterface;
import org.chromium.support_lib_boundary.WebMessageListenerBoundaryInterface;
import ye.a;
import z0.d;
import z0.g;

public class b0 implements WebMessageListenerBoundaryInterface {
  private g.b b;
  
  public b0(@NonNull g.b paramb) {
    this.b = paramb;
  }
  
  @NonNull
  public String[] getSupportedFeatures() {
    return new String[] { "WEB_MESSAGE_LISTENER" };
  }
  
  public void onPostMessage(@NonNull WebView paramWebView, @NonNull InvocationHandler paramInvocationHandler1, @NonNull Uri paramUri, boolean paramBoolean, @NonNull InvocationHandler paramInvocationHandler2) {
    d d = a0.b((WebMessageBoundaryInterface)a.a(WebMessageBoundaryInterface.class, paramInvocationHandler1));
    if (d != null) {
      x x = x.a(paramInvocationHandler2);
      this.b.a(paramWebView, d, paramUri, paramBoolean, x);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a1\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */