package a1;

import android.webkit.SafeBrowsingResponse;
import android.webkit.WebMessagePort;
import android.webkit.WebResourceError;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import java.lang.reflect.InvocationHandler;
import org.chromium.support_lib_boundary.WebkitToCompatConverterBoundaryInterface;

public class j0 {
  private final WebkitToCompatConverterBoundaryInterface a;
  
  public j0(@NonNull WebkitToCompatConverterBoundaryInterface paramWebkitToCompatConverterBoundaryInterface) {
    this.a = paramWebkitToCompatConverterBoundaryInterface;
  }
  
  @NonNull
  @RequiresApi(27)
  public SafeBrowsingResponse a(@NonNull InvocationHandler paramInvocationHandler) {
    return (SafeBrowsingResponse)this.a.convertSafeBrowsingResponse(paramInvocationHandler);
  }
  
  @NonNull
  public InvocationHandler b(@NonNull SafeBrowsingResponse paramSafeBrowsingResponse) {
    return this.a.convertSafeBrowsingResponse(paramSafeBrowsingResponse);
  }
  
  @NonNull
  @RequiresApi(23)
  public WebMessagePort c(@NonNull InvocationHandler paramInvocationHandler) {
    return (WebMessagePort)this.a.convertWebMessagePort(paramInvocationHandler);
  }
  
  @NonNull
  @RequiresApi(23)
  public WebResourceError d(@NonNull InvocationHandler paramInvocationHandler) {
    return (WebResourceError)this.a.convertWebResourceError(paramInvocationHandler);
  }
  
  @NonNull
  public InvocationHandler e(@NonNull WebResourceError paramWebResourceError) {
    return this.a.convertWebResourceError(paramWebResourceError);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a1\j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */