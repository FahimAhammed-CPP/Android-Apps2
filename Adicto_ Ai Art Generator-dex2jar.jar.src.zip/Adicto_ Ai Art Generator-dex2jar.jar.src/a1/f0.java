package a1;

import android.os.Build;
import android.webkit.WebView;
import androidx.annotation.NonNull;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.chromium.support_lib_boundary.WebViewProviderFactoryBoundaryInterface;

public class f0 {
  @NonNull
  static h0 a() {
    try {
      InvocationHandler invocationHandler = b();
      return new i0((WebViewProviderFactoryBoundaryInterface)ye.a.a(WebViewProviderFactoryBoundaryInterface.class, invocationHandler));
    } catch (IllegalAccessException illegalAccessException) {
      throw new RuntimeException(illegalAccessException);
    } catch (InvocationTargetException invocationTargetException) {
      throw new RuntimeException(invocationTargetException);
    } catch (ClassNotFoundException classNotFoundException) {
      return new w();
    } catch (NoSuchMethodException noSuchMethodException) {
      throw new RuntimeException(noSuchMethodException);
    } 
  }
  
  private static InvocationHandler b() throws IllegalAccessException, InvocationTargetException, ClassNotFoundException, NoSuchMethodException {
    return (InvocationHandler)Class.forName("org.chromium.support_lib_glue.SupportLibReflectionUtil", false, e()).getDeclaredMethod("createWebViewProviderFactory", new Class[0]).invoke(null, new Object[0]);
  }
  
  @NonNull
  public static j0 c() {
    return a.a;
  }
  
  @NonNull
  public static h0 d() {
    return b.a;
  }
  
  @NonNull
  public static ClassLoader e() {
    return (Build.VERSION.SDK_INT >= 28) ? u.b() : f().getClass().getClassLoader();
  }
  
  private static Object f() {
    try {
      Method method = WebView.class.getDeclaredMethod("getFactory", new Class[0]);
      method.setAccessible(true);
      return method.invoke(null, new Object[0]);
    } catch (NoSuchMethodException noSuchMethodException) {
      throw new RuntimeException(noSuchMethodException);
    } catch (InvocationTargetException invocationTargetException) {
      throw new RuntimeException(invocationTargetException);
    } catch (IllegalAccessException illegalAccessException) {
      throw new RuntimeException(illegalAccessException);
    } 
  }
  
  private static class a {
    static final j0 a = new j0(f0.d().getWebkitToCompatConverter());
  }
  
  private static class b {
    static final h0 a = f0.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a1\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */