package a1;

import androidx.annotation.NonNull;
import java.util.HashSet;
import java.util.Set;

public abstract class z {
  private static final Set<z> c = new HashSet<z>();
  
  private final String a;
  
  private final String b;
  
  z(@NonNull String paramString1, @NonNull String paramString2) {
    this.a = paramString1;
    this.b = paramString2;
    c.add(this);
  }
  
  public static class a extends z {
    a(@NonNull String param1String1, @NonNull String param1String2) {
      super(param1String1, param1String2);
    }
  }
  
  public static class b extends z {
    b(@NonNull String param1String1, @NonNull String param1String2) {
      super(param1String1, param1String2);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a1\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */