package a1;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.lang.reflect.InvocationHandler;
import org.chromium.support_lib_boundary.WebMessageBoundaryInterface;
import org.chromium.support_lib_boundary.WebMessagePayloadBoundaryInterface;
import ye.a;
import z0.d;
import z0.e;

public class a0 implements WebMessageBoundaryInterface {
  private static final String[] b = new String[] { "WEB_MESSAGE_GET_MESSAGE_PAYLOAD" };
  
  @NonNull
  private static e[] a(InvocationHandler[] paramArrayOfInvocationHandler) {
    e[] arrayOfE = new e[paramArrayOfInvocationHandler.length];
    for (int i = 0; i < paramArrayOfInvocationHandler.length; i++)
      arrayOfE[i] = new c0(paramArrayOfInvocationHandler[i]); 
    return arrayOfE;
  }
  
  @Nullable
  public static d b(@NonNull WebMessageBoundaryInterface paramWebMessageBoundaryInterface) {
    WebMessagePayloadBoundaryInterface webMessagePayloadBoundaryInterface;
    e[] arrayOfE = a(paramWebMessageBoundaryInterface.getPorts());
    if (e0.C.c()) {
      webMessagePayloadBoundaryInterface = (WebMessagePayloadBoundaryInterface)a.a(WebMessagePayloadBoundaryInterface.class, paramWebMessageBoundaryInterface.getMessagePayload());
      int i = webMessagePayloadBoundaryInterface.getType();
      return (i != 0) ? ((i != 1) ? null : new d(webMessagePayloadBoundaryInterface.getAsArrayBuffer(), arrayOfE)) : new d(webMessagePayloadBoundaryInterface.getAsString(), arrayOfE);
    } 
    return new d(webMessagePayloadBoundaryInterface.getData(), arrayOfE);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a1\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */