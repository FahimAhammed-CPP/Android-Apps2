package a1;

import android.webkit.WebMessage;
import android.webkit.WebMessagePort;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import org.chromium.support_lib_boundary.WebMessagePortBoundaryInterface;
import ye.a;
import z0.d;
import z0.e;

public class c0 extends e {
  private WebMessagePort a;
  
  private WebMessagePortBoundaryInterface b;
  
  public c0(@NonNull WebMessagePort paramWebMessagePort) {
    this.a = paramWebMessagePort;
  }
  
  public c0(@NonNull InvocationHandler paramInvocationHandler) {
    this.b = (WebMessagePortBoundaryInterface)a.a(WebMessagePortBoundaryInterface.class, paramInvocationHandler);
  }
  
  @Nullable
  @RequiresApi(23)
  public static WebMessagePort[] b(@Nullable e[] paramArrayOfe) {
    if (paramArrayOfe == null)
      return null; 
    int j = paramArrayOfe.length;
    WebMessagePort[] arrayOfWebMessagePort = new WebMessagePort[j];
    for (int i = 0; i < j; i++)
      arrayOfWebMessagePort[i] = paramArrayOfe[i].a(); 
    return arrayOfWebMessagePort;
  }
  
  @NonNull
  @RequiresApi(23)
  public static d c(@NonNull WebMessage paramWebMessage) {
    return g.d(paramWebMessage);
  }
  
  @RequiresApi(23)
  private WebMessagePort d() {
    if (this.a == null)
      this.a = f0.c().c(Proxy.getInvocationHandler(this.b)); 
    return this.a;
  }
  
  @Nullable
  public static e[] e(@Nullable WebMessagePort[] paramArrayOfWebMessagePort) {
    if (paramArrayOfWebMessagePort == null)
      return null; 
    e[] arrayOfE = new e[paramArrayOfWebMessagePort.length];
    for (int i = 0; i < paramArrayOfWebMessagePort.length; i++)
      arrayOfE[i] = new c0(paramArrayOfWebMessagePort[i]); 
    return arrayOfE;
  }
  
  @NonNull
  @RequiresApi(23)
  public WebMessagePort a() {
    return d();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a1\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */