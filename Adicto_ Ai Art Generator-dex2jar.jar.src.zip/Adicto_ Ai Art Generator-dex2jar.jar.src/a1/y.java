package a1;

import android.webkit.SafeBrowsingResponse;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import org.chromium.support_lib_boundary.SafeBrowsingResponseBoundaryInterface;
import ye.a;
import z0.b;

public class y extends b {
  private SafeBrowsingResponse a;
  
  private SafeBrowsingResponseBoundaryInterface b;
  
  public y(@NonNull SafeBrowsingResponse paramSafeBrowsingResponse) {
    this.a = paramSafeBrowsingResponse;
  }
  
  public y(@NonNull InvocationHandler paramInvocationHandler) {
    this.b = (SafeBrowsingResponseBoundaryInterface)a.a(SafeBrowsingResponseBoundaryInterface.class, paramInvocationHandler);
  }
  
  private SafeBrowsingResponseBoundaryInterface b() {
    if (this.b == null)
      this.b = (SafeBrowsingResponseBoundaryInterface)a.a(SafeBrowsingResponseBoundaryInterface.class, f0.c().b(this.a)); 
    return this.b;
  }
  
  @RequiresApi(27)
  private SafeBrowsingResponse c() {
    if (this.a == null)
      this.a = f0.c().a(Proxy.getInvocationHandler(this.b)); 
    return this.a;
  }
  
  public void a(boolean paramBoolean) {
    a.f f = e0.z;
    if (f.b()) {
      q.e(c(), paramBoolean);
      return;
    } 
    if (f.c()) {
      b().showInterstitial(paramBoolean);
      return;
    } 
    throw e0.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a1\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */