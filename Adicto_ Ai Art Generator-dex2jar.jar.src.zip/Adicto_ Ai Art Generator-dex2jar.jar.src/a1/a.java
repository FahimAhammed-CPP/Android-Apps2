package a1;

import android.os.Build;
import androidx.annotation.NonNull;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public abstract class a implements v {
  private static final Set<a> c = new HashSet<a>();
  
  private final String a;
  
  private final String b;
  
  a(@NonNull String paramString1, @NonNull String paramString2) {
    this.a = paramString1;
    this.b = paramString2;
    c.add(this);
  }
  
  @NonNull
  public static Set<a> d() {
    return Collections.unmodifiableSet(c);
  }
  
  @NonNull
  public String a() {
    return this.a;
  }
  
  public abstract boolean b();
  
  public boolean c() {
    return ye.a.b(a.a, this.b);
  }
  
  public boolean isSupported() {
    return (b() || c());
  }
  
  private static class a {
    static final Set<String> a = new HashSet<String>(Arrays.asList(f0.d().a()));
  }
  
  public static class b extends a {
    b(@NonNull String param1String1, @NonNull String param1String2) {
      super(param1String1, param1String2);
    }
    
    public final boolean b() {
      return (Build.VERSION.SDK_INT >= 23);
    }
  }
  
  public static class c extends a {
    c(@NonNull String param1String1, @NonNull String param1String2) {
      super(param1String1, param1String2);
    }
    
    public final boolean b() {
      return (Build.VERSION.SDK_INT >= 24);
    }
  }
  
  public static class d extends a {
    d(@NonNull String param1String1, @NonNull String param1String2) {
      super(param1String1, param1String2);
    }
    
    public final boolean b() {
      return false;
    }
  }
  
  public static class e extends a {
    e(@NonNull String param1String1, @NonNull String param1String2) {
      super(param1String1, param1String2);
    }
    
    public final boolean b() {
      return (Build.VERSION.SDK_INT >= 26);
    }
  }
  
  public static class f extends a {
    f(@NonNull String param1String1, @NonNull String param1String2) {
      super(param1String1, param1String2);
    }
    
    public final boolean b() {
      return (Build.VERSION.SDK_INT >= 27);
    }
  }
  
  public static class g extends a {
    g(@NonNull String param1String1, @NonNull String param1String2) {
      super(param1String1, param1String2);
    }
    
    public final boolean b() {
      return (Build.VERSION.SDK_INT >= 28);
    }
  }
  
  public static class h extends a {
    h(@NonNull String param1String1, @NonNull String param1String2) {
      super(param1String1, param1String2);
    }
    
    public final boolean b() {
      return (Build.VERSION.SDK_INT >= 29);
    }
  }
  
  public static class i extends a {
    i(@NonNull String param1String1, @NonNull String param1String2) {
      super(param1String1, param1String2);
    }
    
    public final boolean b() {
      return (Build.VERSION.SDK_INT >= 33);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a1\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */