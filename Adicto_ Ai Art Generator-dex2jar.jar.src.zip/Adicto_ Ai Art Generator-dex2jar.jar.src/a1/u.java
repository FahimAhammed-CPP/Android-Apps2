package a1;

import android.os.Looper;
import android.webkit.TracingConfig;
import android.webkit.TracingController;
import android.webkit.WebView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import java.io.OutputStream;
import java.util.concurrent.Executor;
import z0.c;

@RequiresApi(28)
public class u {
  @NonNull
  public static TracingController a() {
    return TracingController.getInstance();
  }
  
  @NonNull
  public static ClassLoader b() {
    return s.a();
  }
  
  @NonNull
  public static Looper c(@NonNull WebView paramWebView) {
    return r.a(paramWebView);
  }
  
  public static boolean d(@NonNull TracingController paramTracingController) {
    return paramTracingController.isTracing();
  }
  
  public static void e(@NonNull String paramString) {
    t.a(paramString);
  }
  
  public static void f(@NonNull TracingController paramTracingController, @NonNull c paramc) {
    new TracingConfig.Builder();
    throw null;
  }
  
  public static boolean g(@NonNull TracingController paramTracingController, @Nullable OutputStream paramOutputStream, @NonNull Executor paramExecutor) {
    return paramTracingController.stop(paramOutputStream, paramExecutor);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */