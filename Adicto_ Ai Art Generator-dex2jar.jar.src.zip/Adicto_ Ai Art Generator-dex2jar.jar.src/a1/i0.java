package a1;

import android.webkit.WebView;
import androidx.annotation.NonNull;
import org.chromium.support_lib_boundary.WebViewProviderBoundaryInterface;
import org.chromium.support_lib_boundary.WebViewProviderFactoryBoundaryInterface;
import org.chromium.support_lib_boundary.WebkitToCompatConverterBoundaryInterface;
import ye.a;

public class i0 implements h0 {
  final WebViewProviderFactoryBoundaryInterface a;
  
  public i0(@NonNull WebViewProviderFactoryBoundaryInterface paramWebViewProviderFactoryBoundaryInterface) {
    this.a = paramWebViewProviderFactoryBoundaryInterface;
  }
  
  @NonNull
  public String[] a() {
    return this.a.getSupportedFeatures();
  }
  
  @NonNull
  public WebViewProviderBoundaryInterface createWebView(@NonNull WebView paramWebView) {
    return (WebViewProviderBoundaryInterface)a.a(WebViewProviderBoundaryInterface.class, this.a.createWebView(paramWebView));
  }
  
  @NonNull
  public WebkitToCompatConverterBoundaryInterface getWebkitToCompatConverter() {
    return (WebkitToCompatConverterBoundaryInterface)a.a(WebkitToCompatConverterBoundaryInterface.class, this.a.getWebkitToCompatConverter());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a1\i0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */