package a1;

import android.content.pm.PackageInfo;
import android.os.Build;
import androidx.annotation.NonNull;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import z0.g;

public class e0 {
  public static final a.b A;
  
  public static final a.b B;
  
  public static final a.d C;
  
  public static final a.b D;
  
  public static final a.b E;
  
  public static final a.b F;
  
  public static final a.b G;
  
  public static final a.e H;
  
  public static final a.e I;
  
  public static final a.h J;
  
  public static final a.h K;
  
  public static final a.g L;
  
  public static final z.b M;
  
  public static final z.a N;
  
  public static final a.h O;
  
  public static final a.i P;
  
  public static final a.d Q;
  
  public static final a.d R;
  
  public static final a.d S;
  
  public static final a.h T;
  
  public static final a.d U;
  
  public static final a.d V;
  
  public static final a.d W;
  
  public static final a.d X;
  
  public static final a.d Y;
  
  public static final a.d Z;
  
  public static final a.b a = new a.b("VISUAL_STATE_CALLBACK", "VISUAL_STATE_CALLBACK");
  
  public static final a.d a0;
  
  public static final a.b b = new a.b("OFF_SCREEN_PRERASTER", "OFF_SCREEN_PRERASTER");
  
  public static final a.d b0;
  
  public static final a.e c = new a.e("SAFE_BROWSING_ENABLE", "SAFE_BROWSING_ENABLE");
  
  public static final a.c d = new a.c("DISABLED_ACTION_MODE_MENU_ITEMS", "DISABLED_ACTION_MODE_MENU_ITEMS");
  
  public static final a.f e = new a.f("START_SAFE_BROWSING", "START_SAFE_BROWSING");
  
  @Deprecated
  public static final a.f f = new a.f("SAFE_BROWSING_WHITELIST", "SAFE_BROWSING_WHITELIST");
  
  @Deprecated
  public static final a.f g = new a.f("SAFE_BROWSING_WHITELIST", "SAFE_BROWSING_ALLOWLIST");
  
  public static final a.f h = new a.f("SAFE_BROWSING_ALLOWLIST", "SAFE_BROWSING_WHITELIST");
  
  public static final a.f i = new a.f("SAFE_BROWSING_ALLOWLIST", "SAFE_BROWSING_ALLOWLIST");
  
  public static final a.f j = new a.f("SAFE_BROWSING_PRIVACY_POLICY_URL", "SAFE_BROWSING_PRIVACY_POLICY_URL");
  
  public static final a.c k = new a.c("SERVICE_WORKER_BASIC_USAGE", "SERVICE_WORKER_BASIC_USAGE");
  
  public static final a.c l = new a.c("SERVICE_WORKER_CACHE_MODE", "SERVICE_WORKER_CACHE_MODE");
  
  public static final a.c m = new a.c("SERVICE_WORKER_CONTENT_ACCESS", "SERVICE_WORKER_CONTENT_ACCESS");
  
  public static final a.c n = new a.c("SERVICE_WORKER_FILE_ACCESS", "SERVICE_WORKER_FILE_ACCESS");
  
  public static final a.c o = new a.c("SERVICE_WORKER_BLOCK_NETWORK_LOADS", "SERVICE_WORKER_BLOCK_NETWORK_LOADS");
  
  public static final a.c p = new a.c("SERVICE_WORKER_SHOULD_INTERCEPT_REQUEST", "SERVICE_WORKER_SHOULD_INTERCEPT_REQUEST");
  
  public static final a.b q = new a.b("RECEIVE_WEB_RESOURCE_ERROR", "RECEIVE_WEB_RESOURCE_ERROR");
  
  public static final a.b r = new a.b("RECEIVE_HTTP_ERROR", "RECEIVE_HTTP_ERROR");
  
  public static final a.c s = new a.c("SHOULD_OVERRIDE_WITH_REDIRECTS", "SHOULD_OVERRIDE_WITH_REDIRECTS");
  
  public static final a.f t = new a.f("SAFE_BROWSING_HIT", "SAFE_BROWSING_HIT");
  
  public static final a.c u = new a.c("WEB_RESOURCE_REQUEST_IS_REDIRECT", "WEB_RESOURCE_REQUEST_IS_REDIRECT");
  
  public static final a.b v = new a.b("WEB_RESOURCE_ERROR_GET_DESCRIPTION", "WEB_RESOURCE_ERROR_GET_DESCRIPTION");
  
  public static final a.b w = new a.b("WEB_RESOURCE_ERROR_GET_CODE", "WEB_RESOURCE_ERROR_GET_CODE");
  
  public static final a.f x = new a.f("SAFE_BROWSING_RESPONSE_BACK_TO_SAFETY", "SAFE_BROWSING_RESPONSE_BACK_TO_SAFETY");
  
  public static final a.f y = new a.f("SAFE_BROWSING_RESPONSE_PROCEED", "SAFE_BROWSING_RESPONSE_PROCEED");
  
  public static final a.f z = new a.f("SAFE_BROWSING_RESPONSE_SHOW_INTERSTITIAL", "SAFE_BROWSING_RESPONSE_SHOW_INTERSTITIAL");
  
  static {
    A = new a.b("WEB_MESSAGE_PORT_POST_MESSAGE", "WEB_MESSAGE_PORT_POST_MESSAGE");
    B = new a.b("WEB_MESSAGE_PORT_CLOSE", "WEB_MESSAGE_PORT_CLOSE");
    C = new a.d("WEB_MESSAGE_GET_MESSAGE_PAYLOAD", "WEB_MESSAGE_GET_MESSAGE_PAYLOAD");
    D = new a.b("WEB_MESSAGE_PORT_SET_MESSAGE_CALLBACK", "WEB_MESSAGE_PORT_SET_MESSAGE_CALLBACK");
    E = new a.b("CREATE_WEB_MESSAGE_CHANNEL", "CREATE_WEB_MESSAGE_CHANNEL");
    F = new a.b("POST_WEB_MESSAGE", "POST_WEB_MESSAGE");
    G = new a.b("WEB_MESSAGE_CALLBACK_ON_MESSAGE", "WEB_MESSAGE_CALLBACK_ON_MESSAGE");
    H = new a.e("GET_WEB_VIEW_CLIENT", "GET_WEB_VIEW_CLIENT");
    I = new a.e("GET_WEB_CHROME_CLIENT", "GET_WEB_CHROME_CLIENT");
    J = new a.h("GET_WEB_VIEW_RENDERER", "GET_WEB_VIEW_RENDERER");
    K = new a.h("WEB_VIEW_RENDERER_TERMINATE", "WEB_VIEW_RENDERER_TERMINATE");
    L = new a.g("TRACING_CONTROLLER_BASIC_USAGE", "TRACING_CONTROLLER_BASIC_USAGE");
    M = new z.b("STARTUP_FEATURE_SET_DATA_DIRECTORY_SUFFIX", "STARTUP_FEATURE_SET_DATA_DIRECTORY_SUFFIX");
    N = new z.a("STARTUP_FEATURE_SET_DIRECTORY_BASE_PATHS", "STARTUP_FEATURE_SET_DIRECTORY_BASE_PATH");
    O = new a.h("WEB_VIEW_RENDERER_CLIENT_BASIC_USAGE", "WEB_VIEW_RENDERER_CLIENT_BASIC_USAGE");
    P = new a("ALGORITHMIC_DARKENING", "ALGORITHMIC_DARKENING");
    Q = new a.d("PROXY_OVERRIDE", "PROXY_OVERRIDE:3");
    R = new a.d("SUPPRESS_ERROR_PAGE", "SUPPRESS_ERROR_PAGE");
    S = new a.d("MULTI_PROCESS", "MULTI_PROCESS_QUERY");
    T = new a.h("FORCE_DARK", "FORCE_DARK");
    U = new a.d("FORCE_DARK_STRATEGY", "FORCE_DARK_BEHAVIOR");
    V = new a.d("WEB_MESSAGE_LISTENER", "WEB_MESSAGE_LISTENER");
    W = new a.d("DOCUMENT_START_SCRIPT", "DOCUMENT_START_SCRIPT:1");
    X = new a.d("PROXY_OVERRIDE_REVERSE_BYPASS", "PROXY_OVERRIDE_REVERSE_BYPASS");
    Y = new a.d("GET_VARIATIONS_HEADER", "GET_VARIATIONS_HEADER");
    Z = new a.d("ENTERPRISE_AUTHENTICATION_APP_LINK_POLICY", "ENTERPRISE_AUTHENTICATION_APP_LINK_POLICY");
    a0 = new a.d("GET_COOKIE_INFO", "GET_COOKIE_INFO");
    b0 = new a.d("REQUESTED_WITH_HEADER_ALLOW_LIST", "REQUESTED_WITH_HEADER_ALLOW_LIST");
  }
  
  @NonNull
  public static UnsupportedOperationException a() {
    return new UnsupportedOperationException("This method is not supported by the current version of the framework and the current WebView APK");
  }
  
  public static boolean b(@NonNull String paramString) {
    return c(paramString, a.d());
  }
  
  public static <T extends v> boolean c(@NonNull String paramString, @NonNull Collection<T> paramCollection) {
    Iterator<v> iterator;
    HashSet<v> hashSet = new HashSet();
    for (v v : paramCollection) {
      if (v.a().equals(paramString))
        hashSet.add(v); 
    } 
    if (!hashSet.isEmpty()) {
      iterator = hashSet.iterator();
      while (iterator.hasNext()) {
        if (((v)iterator.next()).isSupported())
          return true; 
      } 
      return false;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Unknown feature ");
    stringBuilder.append((String)iterator);
    throw new RuntimeException(stringBuilder.toString());
  }
  
  class a extends a.i {
    private final Pattern d = Pattern.compile("\\A\\d+");
    
    a(e0 this$0, String param1String1) {
      super((String)this$0, param1String1);
    }
    
    public boolean c() {
      boolean bool = super.c();
      if (bool) {
        if (Build.VERSION.SDK_INT >= 29)
          return bool; 
        PackageInfo packageInfo = g.c();
        boolean bool1 = false;
        if (packageInfo == null)
          return false; 
        Matcher matcher = this.d.matcher(packageInfo.versionName);
        bool = bool1;
        if (matcher.find()) {
          bool = bool1;
          if (Integer.parseInt(packageInfo.versionName.substring(matcher.start(), matcher.end())) >= 105)
            bool = true; 
        } 
        return bool;
      } 
      return bool;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a1\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */