package a1;

import android.content.Context;
import android.net.Uri;
import android.webkit.SafeBrowsingResponse;
import android.webkit.ValueCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import java.util.List;

@RequiresApi(27)
public class q {
  public static void a(@NonNull SafeBrowsingResponse paramSafeBrowsingResponse, boolean paramBoolean) {
    paramSafeBrowsingResponse.backToSafety(paramBoolean);
  }
  
  @NonNull
  public static Uri b() {
    return p.a();
  }
  
  public static void c(@NonNull SafeBrowsingResponse paramSafeBrowsingResponse, boolean paramBoolean) {
    paramSafeBrowsingResponse.proceed(paramBoolean);
  }
  
  public static void d(@NonNull List<String> paramList, @Nullable ValueCallback<Boolean> paramValueCallback) {
    n.a(paramList, paramValueCallback);
  }
  
  public static void e(@NonNull SafeBrowsingResponse paramSafeBrowsingResponse, boolean paramBoolean) {
    paramSafeBrowsingResponse.showInterstitial(paramBoolean);
  }
  
  public static void f(@NonNull Context paramContext, @Nullable ValueCallback<Boolean> paramValueCallback) {
    o.a(paramContext, paramValueCallback);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a1\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */