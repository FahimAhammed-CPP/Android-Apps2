package a1;

import android.content.pm.PackageInfo;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

@RequiresApi(26)
public class m {
  @NonNull
  public static PackageInfo a() {
    return i.a();
  }
  
  public static boolean b(@NonNull WebSettings paramWebSettings) {
    return h.a(paramWebSettings);
  }
  
  @Nullable
  public static WebChromeClient c(@NonNull WebView paramWebView) {
    return j.a(paramWebView);
  }
  
  @Nullable
  public static WebViewClient d(@NonNull WebView paramWebView) {
    return k.a(paramWebView);
  }
  
  public static void e(@NonNull WebSettings paramWebSettings, boolean paramBoolean) {
    l.a(paramWebSettings, paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a1\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */