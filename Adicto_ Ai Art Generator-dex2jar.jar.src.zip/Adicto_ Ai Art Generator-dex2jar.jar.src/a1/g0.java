package a1;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import org.chromium.support_lib_boundary.WebViewProviderBoundaryInterface;
import ye.a;
import z0.g;

public class g0 {
  WebViewProviderBoundaryInterface a;
  
  public g0(@NonNull WebViewProviderBoundaryInterface paramWebViewProviderBoundaryInterface) {
    this.a = paramWebViewProviderBoundaryInterface;
  }
  
  @RequiresApi(19)
  public void a(@NonNull String paramString, @NonNull String[] paramArrayOfString, @NonNull g.b paramb) {
    this.a.addWebMessageListener(paramString, paramArrayOfString, a.c(new b0(paramb)));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a1\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */