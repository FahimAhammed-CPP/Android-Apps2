package a1;

import android.webkit.WebView;
import android.webkit.WebViewClient;



/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a1\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */