package a1;

import android.webkit.WebResourceError;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import org.chromium.support_lib_boundary.WebResourceErrorBoundaryInterface;
import ye.a;
import z0.f;

public class d0 extends f {
  private WebResourceError a;
  
  private WebResourceErrorBoundaryInterface b;
  
  public d0(@NonNull WebResourceError paramWebResourceError) {
    this.a = paramWebResourceError;
  }
  
  public d0(@NonNull InvocationHandler paramInvocationHandler) {
    this.b = (WebResourceErrorBoundaryInterface)a.a(WebResourceErrorBoundaryInterface.class, paramInvocationHandler);
  }
  
  private WebResourceErrorBoundaryInterface c() {
    if (this.b == null)
      this.b = (WebResourceErrorBoundaryInterface)a.a(WebResourceErrorBoundaryInterface.class, f0.c().e(this.a)); 
    return this.b;
  }
  
  @RequiresApi(23)
  private WebResourceError d() {
    if (this.a == null)
      this.a = f0.c().d(Proxy.getInvocationHandler(this.b)); 
    return this.a;
  }
  
  @NonNull
  public CharSequence a() {
    a.b b = e0.v;
    if (b.b())
      return g.e(d()); 
    if (b.c())
      return c().getDescription(); 
    throw e0.a();
  }
  
  public int b() {
    a.b b = e0.w;
    if (b.b())
      return g.f(d()); 
    if (b.c())
      return c().getErrorCode(); 
    throw e0.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a1\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */