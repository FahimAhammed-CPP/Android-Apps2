package a;

import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;

public interface a extends IInterface {
  void B(int paramInt1, int paramInt2, Bundle paramBundle) throws RemoteException;
  
  void D(int paramInt, Bundle paramBundle) throws RemoteException;
  
  void E(String paramString, Bundle paramBundle) throws RemoteException;
  
  void F(Bundle paramBundle) throws RemoteException;
  
  void I(int paramInt, Uri paramUri, boolean paramBoolean, Bundle paramBundle) throws RemoteException;
  
  Bundle g(String paramString, Bundle paramBundle) throws RemoteException;
  
  void k(String paramString, Bundle paramBundle) throws RemoteException;
  
  public static abstract class a extends Binder implements a {
    public a() {
      attachInterface(this, "android.support.customtabs.ICustomTabsCallback");
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      Uri uri;
      if (param1Int1 >= 1 && param1Int1 <= 16777215)
        param1Parcel1.enforceInterface("android.support.customtabs.ICustomTabsCallback"); 
      if (param1Int1 != 1598968902) {
        Bundle bundle;
        boolean bool;
        switch (param1Int1) {
          default:
            return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
          case 8:
            B(param1Parcel1.readInt(), param1Parcel1.readInt(), (Bundle)a.b.a(param1Parcel1, Bundle.CREATOR));
            return true;
          case 7:
            bundle = g(param1Parcel1.readString(), (Bundle)a.b.a(param1Parcel1, Bundle.CREATOR));
            param1Parcel2.writeNoException();
            a.b.b(param1Parcel2, (Parcelable)bundle, 1);
            return true;
          case 6:
            param1Int1 = bundle.readInt();
            uri = (Uri)a.b.a((Parcel)bundle, Uri.CREATOR);
            if (bundle.readInt() != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            I(param1Int1, uri, bool, (Bundle)a.b.a((Parcel)bundle, Bundle.CREATOR));
            return true;
          case 5:
            E(bundle.readString(), (Bundle)a.b.a((Parcel)bundle, Bundle.CREATOR));
            uri.writeNoException();
            return true;
          case 4:
            F((Bundle)a.b.a((Parcel)bundle, Bundle.CREATOR));
            uri.writeNoException();
            return true;
          case 3:
            k(bundle.readString(), (Bundle)a.b.a((Parcel)bundle, Bundle.CREATOR));
            return true;
          case 2:
            break;
        } 
        D(bundle.readInt(), (Bundle)a.b.a((Parcel)bundle, Bundle.CREATOR));
        return true;
      } 
      uri.writeString("android.support.customtabs.ICustomTabsCallback");
      return true;
    }
  }
  
  public static class b {
    private static <T> T c(Parcel param1Parcel, Parcelable.Creator<T> param1Creator) {
      return (T)((param1Parcel.readInt() != 0) ? param1Creator.createFromParcel(param1Parcel) : null);
    }
    
    private static <T extends Parcelable> void d(Parcel param1Parcel, T param1T, int param1Int) {
      if (param1T != null) {
        param1Parcel.writeInt(1);
        param1T.writeToParcel(param1Parcel, param1Int);
        return;
      } 
      param1Parcel.writeInt(0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */