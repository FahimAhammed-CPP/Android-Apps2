package a9;

import android.content.Context;
import android.net.Uri;
import android.util.Log;
import ec.k;
import h8.a;
import java.io.File;
import java.io.IOException;
import java.util.Map;

public class b {
  public static a a(Map<String, Object> paramMap, Context paramContext, k.d paramd) {
    String str = (String)paramMap.get("type");
    if (str.equals("file"))
      try {
        return a.c(paramContext, Uri.fromFile(new File((String)paramMap.get("path"))));
      } catch (IOException iOException) {
        Log.e("ImageError", "Getting Image failed");
        iOException.printStackTrace();
        paramd.b("InputImageConverterError", iOException.toString(), null);
        return null;
      }  
    if (str.equals("bytes")) {
      Map map = (Map)iOException.get("metadata");
      return a.a((byte[])iOException.get("bytes"), (int)((Double)map.get("width")).doubleValue(), (int)((Double)map.get("height")).doubleValue(), ((Integer)map.get("rotation")).intValue(), 17);
    } 
    paramd.b("InputImageConverterError", "Invalid Input Image", null);
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a9\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */