package a9;

import androidx.annotation.NonNull;
import ec.j;
import ec.k;
import vb.a;

public class a implements a, k.c {
  private k b;
  
  public void onAttachedToEngine(@NonNull a.b paramb) {
    k k1 = new k(paramb.b(), "google_mlkit_commons");
    this.b = k1;
    k1.e(this);
  }
  
  public void onDetachedFromEngine(@NonNull a.b paramb) {
    this.b.e(null);
  }
  
  public void onMethodCall(@NonNull j paramj, @NonNull k.d paramd) {
    paramd.c();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a9\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */