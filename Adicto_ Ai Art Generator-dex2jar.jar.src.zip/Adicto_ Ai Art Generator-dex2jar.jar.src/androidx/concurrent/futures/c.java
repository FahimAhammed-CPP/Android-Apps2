package androidx.concurrent.futures;

import androidx.annotation.Nullable;

public final class c<V> extends a<V> {
  public static <V> c<V> v() {
    return new c<V>();
  }
  
  public boolean r(@Nullable V paramV) {
    return super.r(paramV);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\concurrent\futures\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */