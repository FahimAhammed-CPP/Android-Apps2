package androidx.collection;

import androidx.annotation.Nullable;

public class d<E> implements Cloneable {
  private static final Object f = new Object();
  
  private boolean b = false;
  
  private long[] c;
  
  private Object[] d;
  
  private int e;
  
  public d() {
    this(10);
  }
  
  public d(int paramInt) {
    if (paramInt == 0) {
      this.c = c.b;
      this.d = c.c;
      return;
    } 
    paramInt = c.f(paramInt);
    this.c = new long[paramInt];
    this.d = new Object[paramInt];
  }
  
  private void e() {
    int k = this.e;
    long[] arrayOfLong = this.c;
    Object[] arrayOfObject = this.d;
    int i = 0;
    int j;
    for (j = 0; i < k; j = m) {
      Object object = arrayOfObject[i];
      int m = j;
      if (object != f) {
        if (i != j) {
          arrayOfLong[j] = arrayOfLong[i];
          arrayOfObject[j] = object;
          arrayOfObject[i] = null;
        } 
        m = j + 1;
      } 
      i++;
    } 
    this.b = false;
    this.e = j;
  }
  
  public void a(long paramLong, E paramE) {
    int i = this.e;
    if (i != 0 && paramLong <= this.c[i - 1]) {
      i(paramLong, paramE);
      return;
    } 
    if (this.b && i >= this.c.length)
      e(); 
    i = this.e;
    if (i >= this.c.length) {
      int j = c.f(i + 1);
      long[] arrayOfLong1 = new long[j];
      Object[] arrayOfObject1 = new Object[j];
      long[] arrayOfLong2 = this.c;
      System.arraycopy(arrayOfLong2, 0, arrayOfLong1, 0, arrayOfLong2.length);
      Object[] arrayOfObject2 = this.d;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      this.c = arrayOfLong1;
      this.d = arrayOfObject1;
    } 
    this.c[i] = paramLong;
    this.d[i] = paramE;
    this.e = i + 1;
  }
  
  public void b() {
    int j = this.e;
    Object[] arrayOfObject = this.d;
    for (int i = 0; i < j; i++)
      arrayOfObject[i] = null; 
    this.e = 0;
    this.b = false;
  }
  
  public d<E> c() {
    try {
      d<E> d1 = (d)super.clone();
      d1.c = (long[])this.c.clone();
      d1.d = (Object[])this.d.clone();
      return d1;
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      throw new AssertionError(cloneNotSupportedException);
    } 
  }
  
  @Nullable
  public E f(long paramLong) {
    return g(paramLong, null);
  }
  
  public E g(long paramLong, E paramE) {
    int i = c.b(this.c, this.e, paramLong);
    if (i >= 0) {
      Object object = this.d[i];
      return (E)((object == f) ? (Object)paramE : object);
    } 
    return paramE;
  }
  
  public long h(int paramInt) {
    if (this.b)
      e(); 
    return this.c[paramInt];
  }
  
  public void i(long paramLong, E paramE) {
    int i = c.b(this.c, this.e, paramLong);
    if (i >= 0) {
      this.d[i] = paramE;
      return;
    } 
    int j = i;
    int k = this.e;
    if (j < k) {
      Object[] arrayOfObject = this.d;
      if (arrayOfObject[j] == f) {
        this.c[j] = paramLong;
        arrayOfObject[j] = paramE;
        return;
      } 
    } 
    i = j;
    if (this.b) {
      i = j;
      if (k >= this.c.length) {
        e();
        i = c.b(this.c, this.e, paramLong);
      } 
    } 
    j = this.e;
    if (j >= this.c.length) {
      j = c.f(j + 1);
      long[] arrayOfLong1 = new long[j];
      Object[] arrayOfObject1 = new Object[j];
      long[] arrayOfLong2 = this.c;
      System.arraycopy(arrayOfLong2, 0, arrayOfLong1, 0, arrayOfLong2.length);
      Object[] arrayOfObject2 = this.d;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      this.c = arrayOfLong1;
      this.d = arrayOfObject1;
    } 
    j = this.e;
    if (j - i != 0) {
      long[] arrayOfLong = this.c;
      k = i + 1;
      System.arraycopy(arrayOfLong, i, arrayOfLong, k, j - i);
      Object[] arrayOfObject = this.d;
      System.arraycopy(arrayOfObject, i, arrayOfObject, k, this.e - i);
    } 
    this.c[i] = paramLong;
    this.d[i] = paramE;
    this.e++;
  }
  
  public void j(long paramLong) {
    int i = c.b(this.c, this.e, paramLong);
    if (i >= 0) {
      Object[] arrayOfObject = this.d;
      Object object1 = arrayOfObject[i];
      Object object2 = f;
      if (object1 != object2) {
        arrayOfObject[i] = object2;
        this.b = true;
      } 
    } 
  }
  
  public int k() {
    if (this.b)
      e(); 
    return this.e;
  }
  
  public E l(int paramInt) {
    if (this.b)
      e(); 
    return (E)this.d[paramInt];
  }
  
  public String toString() {
    if (k() <= 0)
      return "{}"; 
    StringBuilder stringBuilder = new StringBuilder(this.e * 28);
    stringBuilder.append('{');
    for (int i = 0; i < this.e; i++) {
      if (i > 0)
        stringBuilder.append(", "); 
      stringBuilder.append(h(i));
      stringBuilder.append('=');
      E e = l(i);
      if (e != this) {
        stringBuilder.append(e);
      } else {
        stringBuilder.append("(this Map)");
      } 
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\collection\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */