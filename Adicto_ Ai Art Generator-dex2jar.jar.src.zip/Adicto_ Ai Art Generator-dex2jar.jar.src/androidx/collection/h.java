package androidx.collection;

import androidx.annotation.Nullable;

public class h<E> implements Cloneable {
  private static final Object f = new Object();
  
  private boolean b = false;
  
  private int[] c;
  
  private Object[] d;
  
  private int e;
  
  public h() {
    this(10);
  }
  
  public h(int paramInt) {
    if (paramInt == 0) {
      this.c = c.a;
      this.d = c.c;
      return;
    } 
    paramInt = c.e(paramInt);
    this.c = new int[paramInt];
    this.d = new Object[paramInt];
  }
  
  private void e() {
    int k = this.e;
    int[] arrayOfInt = this.c;
    Object[] arrayOfObject = this.d;
    int i = 0;
    int j;
    for (j = 0; i < k; j = m) {
      Object object = arrayOfObject[i];
      int m = j;
      if (object != f) {
        if (i != j) {
          arrayOfInt[j] = arrayOfInt[i];
          arrayOfObject[j] = object;
          arrayOfObject[i] = null;
        } 
        m = j + 1;
      } 
      i++;
    } 
    this.b = false;
    this.e = j;
  }
  
  public void a(int paramInt, E paramE) {
    int i = this.e;
    if (i != 0 && paramInt <= this.c[i - 1]) {
      i(paramInt, paramE);
      return;
    } 
    if (this.b && i >= this.c.length)
      e(); 
    i = this.e;
    if (i >= this.c.length) {
      int j = c.e(i + 1);
      int[] arrayOfInt1 = new int[j];
      Object[] arrayOfObject1 = new Object[j];
      int[] arrayOfInt2 = this.c;
      System.arraycopy(arrayOfInt2, 0, arrayOfInt1, 0, arrayOfInt2.length);
      Object[] arrayOfObject2 = this.d;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      this.c = arrayOfInt1;
      this.d = arrayOfObject1;
    } 
    this.c[i] = paramInt;
    this.d[i] = paramE;
    this.e = i + 1;
  }
  
  public void b() {
    int j = this.e;
    Object[] arrayOfObject = this.d;
    for (int i = 0; i < j; i++)
      arrayOfObject[i] = null; 
    this.e = 0;
    this.b = false;
  }
  
  public h<E> c() {
    try {
      h<E> h1 = (h)super.clone();
      h1.c = (int[])this.c.clone();
      h1.d = (Object[])this.d.clone();
      return h1;
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      throw new AssertionError(cloneNotSupportedException);
    } 
  }
  
  @Nullable
  public E f(int paramInt) {
    return g(paramInt, null);
  }
  
  public E g(int paramInt, E paramE) {
    paramInt = c.a(this.c, this.e, paramInt);
    if (paramInt >= 0) {
      Object object = this.d[paramInt];
      return (E)((object == f) ? (Object)paramE : object);
    } 
    return paramE;
  }
  
  public int h(int paramInt) {
    if (this.b)
      e(); 
    return this.c[paramInt];
  }
  
  public void i(int paramInt, E paramE) {
    int i = c.a(this.c, this.e, paramInt);
    if (i >= 0) {
      this.d[i] = paramE;
      return;
    } 
    int j = i;
    int k = this.e;
    if (j < k) {
      Object[] arrayOfObject = this.d;
      if (arrayOfObject[j] == f) {
        this.c[j] = paramInt;
        arrayOfObject[j] = paramE;
        return;
      } 
    } 
    i = j;
    if (this.b) {
      i = j;
      if (k >= this.c.length) {
        e();
        i = c.a(this.c, this.e, paramInt);
      } 
    } 
    j = this.e;
    if (j >= this.c.length) {
      j = c.e(j + 1);
      int[] arrayOfInt1 = new int[j];
      Object[] arrayOfObject1 = new Object[j];
      int[] arrayOfInt2 = this.c;
      System.arraycopy(arrayOfInt2, 0, arrayOfInt1, 0, arrayOfInt2.length);
      Object[] arrayOfObject2 = this.d;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      this.c = arrayOfInt1;
      this.d = arrayOfObject1;
    } 
    j = this.e;
    if (j - i != 0) {
      int[] arrayOfInt = this.c;
      k = i + 1;
      System.arraycopy(arrayOfInt, i, arrayOfInt, k, j - i);
      Object[] arrayOfObject = this.d;
      System.arraycopy(arrayOfObject, i, arrayOfObject, k, this.e - i);
    } 
    this.c[i] = paramInt;
    this.d[i] = paramE;
    this.e++;
  }
  
  public int j() {
    if (this.b)
      e(); 
    return this.e;
  }
  
  public E k(int paramInt) {
    if (this.b)
      e(); 
    return (E)this.d[paramInt];
  }
  
  public String toString() {
    if (j() <= 0)
      return "{}"; 
    StringBuilder stringBuilder = new StringBuilder(this.e * 28);
    stringBuilder.append('{');
    for (int i = 0; i < this.e; i++) {
      if (i > 0)
        stringBuilder.append(", "); 
      stringBuilder.append(h(i));
      stringBuilder.append('=');
      E e = k(i);
      if (e != this) {
        stringBuilder.append(e);
      } else {
        stringBuilder.append("(this Map)");
      } 
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\collection\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */