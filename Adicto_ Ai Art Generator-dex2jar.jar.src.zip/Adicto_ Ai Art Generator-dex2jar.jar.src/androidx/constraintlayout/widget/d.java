package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.Log;
import android.util.SparseArray;
import android.util.Xml;
import java.io.IOException;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class d {
  private final ConstraintLayout a;
  
  e b;
  
  int c = -1;
  
  int d = -1;
  
  private SparseArray<a> e = new SparseArray();
  
  private SparseArray<e> f = new SparseArray();
  
  d(Context paramContext, ConstraintLayout paramConstraintLayout, int paramInt) {
    this.a = paramConstraintLayout;
    a(paramContext, paramInt);
  }
  
  private void a(Context paramContext, int paramInt) {
    XmlResourceParser xmlResourceParser = paramContext.getResources().getXml(paramInt);
    String str = null;
    try {
      paramInt = xmlResourceParser.getEventType();
    } catch (XmlPullParserException xmlPullParserException) {
      xmlPullParserException.printStackTrace();
      return;
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return;
    } 
    while (true) {
      boolean bool = true;
      if (paramInt != 1) {
        String str1;
        if (paramInt != 0) {
          if (paramInt != 2) {
            str1 = str;
          } else {
            str1 = xmlResourceParser.getName();
            switch (str1.hashCode()) {
              case 1901439077:
                if (str1.equals("Variant")) {
                  paramInt = 3;
                  break;
                } 
              case 1657696882:
                if (str1.equals("layoutDescription")) {
                  paramInt = 0;
                  break;
                } 
              case 1382829617:
                if (str1.equals("StateSet")) {
                  paramInt = bool;
                  break;
                } 
              case 80204913:
                if (str1.equals("State")) {
                  paramInt = 2;
                  break;
                } 
              case -1349929691:
                if (str1.equals("ConstraintSet")) {
                  paramInt = 4;
                  break;
                } 
              default:
                paramInt = -1;
                break;
            } 
            if (paramInt != 2) {
              if (paramInt != 3) {
                if (paramInt != 4) {
                  str1 = str;
                } else {
                  b((Context)iOException, (XmlPullParser)xmlResourceParser);
                  str1 = str;
                } 
              } else {
                b b = new b((Context)iOException, (XmlPullParser)xmlResourceParser);
                str1 = str;
                if (str != null) {
                  str.a(b);
                  str1 = str;
                } 
              } 
            } else {
              a a = new a((Context)iOException, (XmlPullParser)xmlResourceParser);
              this.e.put(a.a, a);
            } 
          } 
        } else {
          xmlResourceParser.getName();
          str1 = str;
        } 
        paramInt = xmlResourceParser.next();
        str = str1;
        continue;
      } 
      return;
    } 
  }
  
  private void b(Context paramContext, XmlPullParser paramXmlPullParser) {
    e e1 = new e();
    int j = paramXmlPullParser.getAttributeCount();
    for (int i = 0; i < j; i++) {
      String str2 = paramXmlPullParser.getAttributeName(i);
      String str1 = paramXmlPullParser.getAttributeValue(i);
      if (str2 != null && str1 != null && "id".equals(str2)) {
        if (str1.contains("/")) {
          str2 = str1.substring(str1.indexOf('/') + 1);
          i = paramContext.getResources().getIdentifier(str2, "id", paramContext.getPackageName());
        } else {
          i = -1;
        } 
        j = i;
        if (i == -1)
          if (str1.length() > 1) {
            j = Integer.parseInt(str1.substring(1));
          } else {
            Log.e("ConstraintLayoutStates", "error in parsing id");
            j = i;
          }  
        e1.k(paramContext, paramXmlPullParser);
        this.f.put(j, e1);
        return;
      } 
    } 
  }
  
  public void c(g paramg) {}
  
  public void d(int paramInt, float paramFloat1, float paramFloat2) {
    e e1;
    StringBuilder stringBuilder;
    int i = this.c;
    if (i == paramInt) {
      a a1;
      e e2;
      if (paramInt == -1) {
        a1 = (a)this.e.valueAt(0);
      } else {
        a1 = (a)this.e.get(i);
      } 
      paramInt = this.d;
      if (paramInt != -1 && ((b)a1.b.get(paramInt)).a(paramFloat1, paramFloat2))
        return; 
      paramInt = a1.b(paramFloat1, paramFloat2);
      if (this.d == paramInt)
        return; 
      if (paramInt == -1) {
        e2 = this.b;
      } else {
        e2 = ((b)a1.b.get(paramInt)).f;
      } 
      if (paramInt != -1)
        i = ((b)a1.b.get(paramInt)).e; 
      if (e2 == null)
        return; 
      this.d = paramInt;
      e2.c(this.a);
      return;
    } 
    this.c = paramInt;
    a a = (a)this.e.get(paramInt);
    i = a.b(paramFloat1, paramFloat2);
    if (i == -1) {
      e1 = a.d;
    } else {
      e1 = ((b)a.b.get(i)).f;
    } 
    if (i != -1)
      int j = ((b)a.b.get(i)).e; 
    if (e1 == null) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("NO Constraint set found ! id=");
      stringBuilder.append(paramInt);
      stringBuilder.append(", dim =");
      stringBuilder.append(paramFloat1);
      stringBuilder.append(", ");
      stringBuilder.append(paramFloat2);
      Log.v("ConstraintLayoutStates", stringBuilder.toString());
      return;
    } 
    this.d = i;
    stringBuilder.c(this.a);
  }
  
  static class a {
    int a;
    
    ArrayList<d.b> b = new ArrayList<d.b>();
    
    int c = -1;
    
    e d;
    
    public a(Context param1Context, XmlPullParser param1XmlPullParser) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(Xml.asAttributeSet(param1XmlPullParser), k.U6);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == k.V6) {
          this.a = typedArray.getResourceId(k, this.a);
        } else if (k == k.W6) {
          this.c = typedArray.getResourceId(k, this.c);
          String str = param1Context.getResources().getResourceTypeName(this.c);
          param1Context.getResources().getResourceName(this.c);
          if ("layout".equals(str)) {
            e e1 = new e();
            this.d = e1;
            e1.e(param1Context, this.c);
          } 
        } 
      } 
      typedArray.recycle();
    }
    
    void a(d.b param1b) {
      this.b.add(param1b);
    }
    
    public int b(float param1Float1, float param1Float2) {
      for (int i = 0; i < this.b.size(); i++) {
        if (((d.b)this.b.get(i)).a(param1Float1, param1Float2))
          return i; 
      } 
      return -1;
    }
  }
  
  static class b {
    float a = Float.NaN;
    
    float b = Float.NaN;
    
    float c = Float.NaN;
    
    float d = Float.NaN;
    
    int e = -1;
    
    e f;
    
    public b(Context param1Context, XmlPullParser param1XmlPullParser) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(Xml.asAttributeSet(param1XmlPullParser), k.s7);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == k.t7) {
          this.e = typedArray.getResourceId(k, this.e);
          String str = param1Context.getResources().getResourceTypeName(this.e);
          param1Context.getResources().getResourceName(this.e);
          if ("layout".equals(str)) {
            e e1 = new e();
            this.f = e1;
            e1.e(param1Context, this.e);
          } 
        } else if (k == k.u7) {
          this.d = typedArray.getDimension(k, this.d);
        } else if (k == k.v7) {
          this.b = typedArray.getDimension(k, this.b);
        } else if (k == k.w7) {
          this.c = typedArray.getDimension(k, this.c);
        } else if (k == k.x7) {
          this.a = typedArray.getDimension(k, this.a);
        } else {
          Log.v("ConstraintLayoutStates", "Unknown tag");
        } 
      } 
      typedArray.recycle();
    }
    
    boolean a(float param1Float1, float param1Float2) {
      return (!Float.isNaN(this.a) && param1Float1 < this.a) ? false : ((!Float.isNaN(this.b) && param1Float2 < this.b) ? false : ((!Float.isNaN(this.c) && param1Float1 > this.c) ? false : (!(!Float.isNaN(this.d) && param1Float2 > this.d))));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\constraintlayout\widget\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */