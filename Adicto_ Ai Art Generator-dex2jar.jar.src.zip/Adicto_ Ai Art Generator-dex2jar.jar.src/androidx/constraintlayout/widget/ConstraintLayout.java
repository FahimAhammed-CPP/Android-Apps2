package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import u.d;
import u.e;
import u.f;
import u.g;

public class ConstraintLayout extends ViewGroup {
  private static l y;
  
  SparseArray<View> b = new SparseArray();
  
  private ArrayList<c> c = new ArrayList<c>(4);
  
  protected f d = new f();
  
  private int e = 0;
  
  private int f = 0;
  
  private int g = Integer.MAX_VALUE;
  
  private int h = Integer.MAX_VALUE;
  
  protected boolean i = true;
  
  private int j = 257;
  
  private e k = null;
  
  protected d l = null;
  
  private int m = -1;
  
  private HashMap<String, Integer> n = new HashMap<String, Integer>();
  
  private int o = -1;
  
  private int p = -1;
  
  int q = -1;
  
  int r = -1;
  
  int s = 0;
  
  int t = 0;
  
  private SparseArray<e> u = new SparseArray();
  
  c v = new c(this, this);
  
  private int w = 0;
  
  private int x = 0;
  
  public ConstraintLayout(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    p(paramAttributeSet, 0, 0);
  }
  
  private final e g(int paramInt) {
    if (paramInt == 0)
      return (e)this.d; 
    View view2 = (View)this.b.get(paramInt);
    View view1 = view2;
    if (view2 == null) {
      view2 = findViewById(paramInt);
      view1 = view2;
      if (view2 != null) {
        view1 = view2;
        if (view2 != this) {
          view1 = view2;
          if (view2.getParent() == this) {
            onViewAdded(view2);
            view1 = view2;
          } 
        } 
      } 
    } 
    return (e)((view1 == this) ? this.d : ((view1 == null) ? null : ((b)view1.getLayoutParams()).v0));
  }
  
  private int getPaddingWidth() {
    int i = Math.max(0, getPaddingLeft()) + Math.max(0, getPaddingRight());
    int j = Math.max(0, getPaddingStart()) + Math.max(0, getPaddingEnd());
    if (j > 0)
      i = j; 
    return i;
  }
  
  public static l getSharedValues() {
    if (y == null)
      y = new l(); 
    return y;
  }
  
  private void p(AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this.d.y0(this);
    this.d.R1(this.v);
    this.b.put(getId(), this);
    this.k = null;
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, k.n1, paramInt1, paramInt2);
      paramInt2 = typedArray.getIndexCount();
      paramInt1 = 0;
      while (true) {
        if (paramInt1 < paramInt2) {
          int i = typedArray.getIndex(paramInt1);
          if (i == k.s1) {
            this.e = typedArray.getDimensionPixelOffset(i, this.e);
          } else if (i == k.t1) {
            this.f = typedArray.getDimensionPixelOffset(i, this.f);
          } else if (i == k.q1) {
            this.g = typedArray.getDimensionPixelOffset(i, this.g);
          } else if (i == k.r1) {
            this.h = typedArray.getDimensionPixelOffset(i, this.h);
          } else if (i == k.H2) {
            this.j = typedArray.getInt(i, this.j);
          } else if (i == k.C1) {
            i = typedArray.getResourceId(i, 0);
            if (i != 0)
              try {
                s(i);
              } catch (android.content.res.Resources.NotFoundException notFoundException) {
                this.l = null;
              }  
          } else if (i == k.y1) {
            i = typedArray.getResourceId(i, 0);
            try {
              e e1 = new e();
              this.k = e1;
              e1.j(getContext(), i);
            } catch (android.content.res.Resources.NotFoundException notFoundException) {
              this.k = null;
            } 
            this.m = i;
          } 
          paramInt1++;
          continue;
        } 
        typedArray.recycle();
        this.d.S1(this.j);
        return;
      } 
    } 
    this.d.S1(this.j);
  }
  
  private void r() {
    this.i = true;
    this.o = -1;
    this.p = -1;
    this.q = -1;
    this.r = -1;
    this.s = 0;
    this.t = 0;
  }
  
  private void v() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual isInEditMode : ()Z
    //   4: istore #4
    //   6: aload_0
    //   7: invokevirtual getChildCount : ()I
    //   10: istore_2
    //   11: iconst_0
    //   12: istore_1
    //   13: iload_1
    //   14: iload_2
    //   15: if_icmpge -> 49
    //   18: aload_0
    //   19: aload_0
    //   20: iload_1
    //   21: invokevirtual getChildAt : (I)Landroid/view/View;
    //   24: invokevirtual l : (Landroid/view/View;)Lu/e;
    //   27: astore #5
    //   29: aload #5
    //   31: ifnonnull -> 37
    //   34: goto -> 42
    //   37: aload #5
    //   39: invokevirtual r0 : ()V
    //   42: iload_1
    //   43: iconst_1
    //   44: iadd
    //   45: istore_1
    //   46: goto -> 13
    //   49: iload #4
    //   51: ifeq -> 145
    //   54: iconst_0
    //   55: istore_1
    //   56: iload_1
    //   57: iload_2
    //   58: if_icmpge -> 145
    //   61: aload_0
    //   62: iload_1
    //   63: invokevirtual getChildAt : (I)Landroid/view/View;
    //   66: astore #7
    //   68: aload_0
    //   69: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   72: aload #7
    //   74: invokevirtual getId : ()I
    //   77: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   80: astore #6
    //   82: aload_0
    //   83: iconst_0
    //   84: aload #6
    //   86: aload #7
    //   88: invokevirtual getId : ()I
    //   91: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   94: invokevirtual w : (ILjava/lang/Object;Ljava/lang/Object;)V
    //   97: aload #6
    //   99: bipush #47
    //   101: invokevirtual indexOf : (I)I
    //   104: istore_3
    //   105: aload #6
    //   107: astore #5
    //   109: iload_3
    //   110: iconst_m1
    //   111: if_icmpeq -> 124
    //   114: aload #6
    //   116: iload_3
    //   117: iconst_1
    //   118: iadd
    //   119: invokevirtual substring : (I)Ljava/lang/String;
    //   122: astore #5
    //   124: aload_0
    //   125: aload #7
    //   127: invokevirtual getId : ()I
    //   130: invokespecial g : (I)Lu/e;
    //   133: aload #5
    //   135: invokevirtual z0 : (Ljava/lang/String;)V
    //   138: iload_1
    //   139: iconst_1
    //   140: iadd
    //   141: istore_1
    //   142: goto -> 56
    //   145: aload_0
    //   146: getfield m : I
    //   149: iconst_m1
    //   150: if_icmpeq -> 206
    //   153: iconst_0
    //   154: istore_1
    //   155: iload_1
    //   156: iload_2
    //   157: if_icmpge -> 206
    //   160: aload_0
    //   161: iload_1
    //   162: invokevirtual getChildAt : (I)Landroid/view/View;
    //   165: astore #5
    //   167: aload #5
    //   169: invokevirtual getId : ()I
    //   172: aload_0
    //   173: getfield m : I
    //   176: if_icmpne -> 199
    //   179: aload #5
    //   181: instanceof androidx/constraintlayout/widget/f
    //   184: ifeq -> 199
    //   187: aload_0
    //   188: aload #5
    //   190: checkcast androidx/constraintlayout/widget/f
    //   193: invokevirtual getConstraintSet : ()Landroidx/constraintlayout/widget/e;
    //   196: putfield k : Landroidx/constraintlayout/widget/e;
    //   199: iload_1
    //   200: iconst_1
    //   201: iadd
    //   202: istore_1
    //   203: goto -> 155
    //   206: aload_0
    //   207: getfield k : Landroidx/constraintlayout/widget/e;
    //   210: astore #5
    //   212: aload #5
    //   214: ifnull -> 224
    //   217: aload #5
    //   219: aload_0
    //   220: iconst_1
    //   221: invokevirtual d : (Landroidx/constraintlayout/widget/ConstraintLayout;Z)V
    //   224: aload_0
    //   225: getfield d : Lu/f;
    //   228: invokevirtual r1 : ()V
    //   231: aload_0
    //   232: getfield c : Ljava/util/ArrayList;
    //   235: invokevirtual size : ()I
    //   238: istore_3
    //   239: iload_3
    //   240: ifle -> 272
    //   243: iconst_0
    //   244: istore_1
    //   245: iload_1
    //   246: iload_3
    //   247: if_icmpge -> 272
    //   250: aload_0
    //   251: getfield c : Ljava/util/ArrayList;
    //   254: iload_1
    //   255: invokevirtual get : (I)Ljava/lang/Object;
    //   258: checkcast androidx/constraintlayout/widget/c
    //   261: aload_0
    //   262: invokevirtual r : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   265: iload_1
    //   266: iconst_1
    //   267: iadd
    //   268: istore_1
    //   269: goto -> 245
    //   272: iconst_0
    //   273: istore_1
    //   274: iload_1
    //   275: iload_2
    //   276: if_icmpge -> 310
    //   279: aload_0
    //   280: iload_1
    //   281: invokevirtual getChildAt : (I)Landroid/view/View;
    //   284: astore #5
    //   286: aload #5
    //   288: instanceof androidx/constraintlayout/widget/i
    //   291: ifeq -> 303
    //   294: aload #5
    //   296: checkcast androidx/constraintlayout/widget/i
    //   299: aload_0
    //   300: invokevirtual b : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   303: iload_1
    //   304: iconst_1
    //   305: iadd
    //   306: istore_1
    //   307: goto -> 274
    //   310: aload_0
    //   311: getfield u : Landroid/util/SparseArray;
    //   314: invokevirtual clear : ()V
    //   317: aload_0
    //   318: getfield u : Landroid/util/SparseArray;
    //   321: iconst_0
    //   322: aload_0
    //   323: getfield d : Lu/f;
    //   326: invokevirtual put : (ILjava/lang/Object;)V
    //   329: aload_0
    //   330: getfield u : Landroid/util/SparseArray;
    //   333: aload_0
    //   334: invokevirtual getId : ()I
    //   337: aload_0
    //   338: getfield d : Lu/f;
    //   341: invokevirtual put : (ILjava/lang/Object;)V
    //   344: iconst_0
    //   345: istore_1
    //   346: iload_1
    //   347: iload_2
    //   348: if_icmpge -> 387
    //   351: aload_0
    //   352: iload_1
    //   353: invokevirtual getChildAt : (I)Landroid/view/View;
    //   356: astore #5
    //   358: aload_0
    //   359: aload #5
    //   361: invokevirtual l : (Landroid/view/View;)Lu/e;
    //   364: astore #6
    //   366: aload_0
    //   367: getfield u : Landroid/util/SparseArray;
    //   370: aload #5
    //   372: invokevirtual getId : ()I
    //   375: aload #6
    //   377: invokevirtual put : (ILjava/lang/Object;)V
    //   380: iload_1
    //   381: iconst_1
    //   382: iadd
    //   383: istore_1
    //   384: goto -> 346
    //   387: iconst_0
    //   388: istore_1
    //   389: iload_1
    //   390: iload_2
    //   391: if_icmpge -> 459
    //   394: aload_0
    //   395: iload_1
    //   396: invokevirtual getChildAt : (I)Landroid/view/View;
    //   399: astore #5
    //   401: aload_0
    //   402: aload #5
    //   404: invokevirtual l : (Landroid/view/View;)Lu/e;
    //   407: astore #6
    //   409: aload #6
    //   411: ifnonnull -> 417
    //   414: goto -> 452
    //   417: aload #5
    //   419: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   422: checkcast androidx/constraintlayout/widget/ConstraintLayout$b
    //   425: astore #7
    //   427: aload_0
    //   428: getfield d : Lu/f;
    //   431: aload #6
    //   433: invokevirtual a : (Lu/e;)V
    //   436: aload_0
    //   437: iload #4
    //   439: aload #5
    //   441: aload #6
    //   443: aload #7
    //   445: aload_0
    //   446: getfield u : Landroid/util/SparseArray;
    //   449: invokevirtual c : (ZLandroid/view/View;Lu/e;Landroidx/constraintlayout/widget/ConstraintLayout$b;Landroid/util/SparseArray;)V
    //   452: iload_1
    //   453: iconst_1
    //   454: iadd
    //   455: istore_1
    //   456: goto -> 389
    //   459: return
    //   460: astore #5
    //   462: goto -> 138
    // Exception table:
    //   from	to	target	type
    //   68	105	460	android/content/res/Resources$NotFoundException
    //   114	124	460	android/content/res/Resources$NotFoundException
    //   124	138	460	android/content/res/Resources$NotFoundException
  }
  
  private void y(e parame, b paramb, SparseArray<e> paramSparseArray, int paramInt, d.b paramb1) {
    View view = (View)this.b.get(paramInt);
    e e1 = (e)paramSparseArray.get(paramInt);
    if (e1 != null && view != null && view.getLayoutParams() instanceof b) {
      paramb.g0 = true;
      d.b b1 = d.b.g;
      if (paramb1 == b1) {
        b b2 = (b)view.getLayoutParams();
        b2.g0 = true;
        b2.v0.H0(true);
      } 
      parame.m(b1).a(e1.m(paramb1), paramb.D, paramb.C, true);
      parame.H0(true);
      parame.m(d.b.d).p();
      parame.m(d.b.f).p();
    } 
  }
  
  private boolean z() {
    boolean bool1;
    int j = getChildCount();
    boolean bool2 = false;
    int i = 0;
    while (true) {
      bool1 = bool2;
      if (i < j) {
        if (getChildAt(i).isLayoutRequested()) {
          bool1 = true;
          break;
        } 
        i++;
        continue;
      } 
      break;
    } 
    if (bool1)
      v(); 
    return bool1;
  }
  
  protected void c(boolean paramBoolean, View paramView, e parame, b paramb, SparseArray<e> paramSparseArray) {
    paramb.a();
    paramb.w0 = false;
    parame.g1(paramView.getVisibility());
    if (paramb.j0) {
      parame.Q0(true);
      parame.g1(8);
    } 
    parame.y0(paramView);
    if (paramView instanceof c)
      ((c)paramView).n(parame, this.d.L1()); 
    if (paramb.h0) {
      g g = (g)parame;
      int i = paramb.s0;
      int j = paramb.t0;
      float f1 = paramb.u0;
      if (f1 != -1.0F) {
        g.w1(f1);
        return;
      } 
      if (i != -1) {
        g.u1(i);
        return;
      } 
      if (j != -1) {
        g.v1(j);
        return;
      } 
    } else {
      int i = paramb.l0;
      int j = paramb.m0;
      int k = paramb.n0;
      int m = paramb.o0;
      int n = paramb.p0;
      int i1 = paramb.q0;
      float f1 = paramb.r0;
      int i2 = paramb.p;
      if (i2 != -1) {
        e e1 = (e)paramSparseArray.get(i2);
        if (e1 != null)
          parame.j(e1, paramb.r, paramb.q); 
      } else {
        if (i != -1) {
          e e1 = (e)paramSparseArray.get(i);
          if (e1 != null) {
            d.b b1 = d.b.c;
            parame.c0(b1, e1, b1, paramb.leftMargin, n);
          } 
        } else if (j != -1) {
          e e1 = (e)paramSparseArray.get(j);
          if (e1 != null)
            parame.c0(d.b.c, e1, d.b.e, paramb.leftMargin, n); 
        } 
        if (k != -1) {
          e e1 = (e)paramSparseArray.get(k);
          if (e1 != null)
            parame.c0(d.b.e, e1, d.b.c, paramb.rightMargin, i1); 
        } else if (m != -1) {
          e e1 = (e)paramSparseArray.get(m);
          if (e1 != null) {
            d.b b1 = d.b.e;
            parame.c0(b1, e1, b1, paramb.rightMargin, i1);
          } 
        } 
        i = paramb.i;
        if (i != -1) {
          e e1 = (e)paramSparseArray.get(i);
          if (e1 != null) {
            d.b b1 = d.b.d;
            parame.c0(b1, e1, b1, paramb.topMargin, paramb.x);
          } 
        } else {
          i = paramb.j;
          if (i != -1) {
            e e1 = (e)paramSparseArray.get(i);
            if (e1 != null)
              parame.c0(d.b.d, e1, d.b.f, paramb.topMargin, paramb.x); 
          } 
        } 
        i = paramb.k;
        if (i != -1) {
          e e1 = (e)paramSparseArray.get(i);
          if (e1 != null)
            parame.c0(d.b.f, e1, d.b.d, paramb.bottomMargin, paramb.z); 
        } else {
          i = paramb.l;
          if (i != -1) {
            e e1 = (e)paramSparseArray.get(i);
            if (e1 != null) {
              d.b b1 = d.b.f;
              parame.c0(b1, e1, b1, paramb.bottomMargin, paramb.z);
            } 
          } 
        } 
        i = paramb.m;
        if (i != -1) {
          y(parame, paramb, paramSparseArray, i, d.b.g);
        } else {
          i = paramb.n;
          if (i != -1) {
            y(parame, paramb, paramSparseArray, i, d.b.d);
          } else {
            i = paramb.o;
            if (i != -1)
              y(parame, paramb, paramSparseArray, i, d.b.f); 
          } 
        } 
        if (f1 >= 0.0F)
          parame.J0(f1); 
        f1 = paramb.H;
        if (f1 >= 0.0F)
          parame.a1(f1); 
      } 
      if (paramBoolean) {
        i = paramb.X;
        if (i != -1 || paramb.Y != -1)
          parame.Y0(i, paramb.Y); 
      } 
      if (!paramb.e0) {
        if (paramb.width == -1) {
          if (paramb.a0) {
            parame.M0(e.b.d);
          } else {
            parame.M0(e.b.e);
          } 
          (parame.m(d.b.c)).g = paramb.leftMargin;
          (parame.m(d.b.e)).g = paramb.rightMargin;
        } else {
          parame.M0(e.b.d);
          parame.h1(0);
        } 
      } else {
        parame.M0(e.b.b);
        parame.h1(paramb.width);
        if (paramb.width == -2)
          parame.M0(e.b.c); 
      } 
      if (!paramb.f0) {
        if (paramb.height == -1) {
          if (paramb.b0) {
            parame.d1(e.b.d);
          } else {
            parame.d1(e.b.e);
          } 
          (parame.m(d.b.d)).g = paramb.topMargin;
          (parame.m(d.b.f)).g = paramb.bottomMargin;
        } else {
          parame.d1(e.b.d);
          parame.I0(0);
        } 
      } else {
        parame.d1(e.b.b);
        parame.I0(paramb.height);
        if (paramb.height == -2)
          parame.d1(e.b.c); 
      } 
      parame.A0(paramb.I);
      parame.O0(paramb.L);
      parame.f1(paramb.M);
      parame.K0(paramb.N);
      parame.b1(paramb.O);
      parame.i1(paramb.d0);
      parame.N0(paramb.P, paramb.R, paramb.T, paramb.V);
      parame.e1(paramb.Q, paramb.S, paramb.U, paramb.W);
    } 
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof b;
  }
  
  protected b d() {
    return new b(-2, -2);
  }
  
  protected void dispatchDraw(Canvas paramCanvas) {
    ArrayList<c> arrayList = this.c;
    if (arrayList != null) {
      int i = arrayList.size();
      if (i > 0) {
        int j;
        for (j = 0; j < i; j++)
          ((c)this.c.get(j)).q(this); 
      } 
    } 
    super.dispatchDraw(paramCanvas);
    if (isInEditMode()) {
      float f1 = getWidth();
      float f2 = getHeight();
      int j = getChildCount();
      int i;
      for (i = 0; i < j; i++) {
        View view = getChildAt(i);
        if (view.getVisibility() != 8) {
          Object object = view.getTag();
          if (object != null && object instanceof String) {
            object = ((String)object).split(",");
            if (object.length == 4) {
              int m = Integer.parseInt((String)object[0]);
              int i1 = Integer.parseInt((String)object[1]);
              int n = Integer.parseInt((String)object[2]);
              int k = Integer.parseInt((String)object[3]);
              m = (int)(m / 1080.0F * f1);
              i1 = (int)(i1 / 1920.0F * f2);
              n = (int)(n / 1080.0F * f1);
              k = (int)(k / 1920.0F * f2);
              object = new Paint();
              object.setColor(-65536);
              float f3 = m;
              float f4 = i1;
              float f5 = (m + n);
              paramCanvas.drawLine(f3, f4, f5, f4, (Paint)object);
              float f6 = (i1 + k);
              paramCanvas.drawLine(f5, f4, f5, f6, (Paint)object);
              paramCanvas.drawLine(f5, f6, f3, f6, (Paint)object);
              paramCanvas.drawLine(f3, f6, f3, f4, (Paint)object);
              object.setColor(-16711936);
              paramCanvas.drawLine(f3, f4, f5, f6, (Paint)object);
              paramCanvas.drawLine(f3, f6, f5, f4, (Paint)object);
            } 
          } 
        } 
      } 
    } 
  }
  
  public b e(AttributeSet paramAttributeSet) {
    return new b(getContext(), paramAttributeSet);
  }
  
  public Object f(int paramInt, Object paramObject) {
    if (paramInt == 0 && paramObject instanceof String) {
      paramObject = paramObject;
      HashMap<String, Integer> hashMap = this.n;
      if (hashMap != null && hashMap.containsKey(paramObject))
        return this.n.get(paramObject); 
    } 
    return null;
  }
  
  public void forceLayout() {
    r();
    super.forceLayout();
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new b(paramLayoutParams);
  }
  
  public int getMaxHeight() {
    return this.h;
  }
  
  public int getMaxWidth() {
    return this.g;
  }
  
  public int getMinHeight() {
    return this.f;
  }
  
  public int getMinWidth() {
    return this.e;
  }
  
  public int getOptimizationLevel() {
    return this.d.G1();
  }
  
  public String getSceneString() {
    StringBuilder stringBuilder = new StringBuilder();
    if (((e)this.d).o == null) {
      int i = getId();
      if (i != -1) {
        String str = getContext().getResources().getResourceEntryName(i);
        ((e)this.d).o = str;
      } else {
        ((e)this.d).o = "parent";
      } 
    } 
    if (this.d.r() == null) {
      f f1 = this.d;
      f1.z0(((e)f1).o);
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(" setDebugName ");
      stringBuilder1.append(this.d.r());
      Log.v("ConstraintLayout", stringBuilder1.toString());
    } 
    for (e e1 : this.d.o1()) {
      View view = (View)e1.q();
      if (view != null) {
        if (e1.o == null) {
          int i = view.getId();
          if (i != -1)
            e1.o = getContext().getResources().getResourceEntryName(i); 
        } 
        if (e1.r() == null) {
          e1.z0(e1.o);
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(" setDebugName ");
          stringBuilder1.append(e1.r());
          Log.v("ConstraintLayout", stringBuilder1.toString());
        } 
      } 
    } 
    this.d.M(stringBuilder);
    return stringBuilder.toString();
  }
  
  public View h(int paramInt) {
    return (View)this.b.get(paramInt);
  }
  
  public final e l(View paramView) {
    if (paramView == this)
      return (e)this.d; 
    if (paramView != null) {
      if (paramView.getLayoutParams() instanceof b)
        return ((b)paramView.getLayoutParams()).v0; 
      paramView.setLayoutParams(generateLayoutParams(paramView.getLayoutParams()));
      if (paramView.getLayoutParams() instanceof b)
        return ((b)paramView.getLayoutParams()).v0; 
    } 
    return null;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt3 = getChildCount();
    paramBoolean = isInEditMode();
    paramInt2 = 0;
    for (paramInt1 = 0; paramInt1 < paramInt3; paramInt1++) {
      View view = getChildAt(paramInt1);
      b b = (b)view.getLayoutParams();
      e e1 = b.v0;
      if ((view.getVisibility() != 8 || b.h0 || b.i0 || b.k0 || paramBoolean) && !b.j0) {
        paramInt4 = e1.V();
        int i = e1.W();
        int j = e1.U() + paramInt4;
        int k = e1.v() + i;
        view.layout(paramInt4, i, j, k);
        if (view instanceof i) {
          view = ((i)view).getContent();
          if (view != null) {
            view.setVisibility(0);
            view.layout(paramInt4, i, j, k);
          } 
        } 
      } 
    } 
    paramInt3 = this.c.size();
    if (paramInt3 > 0)
      for (paramInt1 = paramInt2; paramInt1 < paramInt3; paramInt1++)
        ((c)this.c.get(paramInt1)).o(this);  
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.w == paramInt1)
      int i = this.x; 
    if (!this.i) {
      int j = getChildCount();
      for (int i = 0; i < j; i++) {
        if (getChildAt(i).isLayoutRequested()) {
          this.i = true;
          break;
        } 
      } 
    } 
    boolean bool = this.i;
    this.w = paramInt1;
    this.x = paramInt2;
    this.d.U1(q());
    if (this.i) {
      this.i = false;
      if (z())
        this.d.W1(); 
    } 
    u(this.d, this.j, paramInt1, paramInt2);
    t(paramInt1, paramInt2, this.d.U(), this.d.v(), this.d.M1(), this.d.K1());
  }
  
  public void onViewAdded(View paramView) {
    super.onViewAdded(paramView);
    e e1 = l(paramView);
    if (paramView instanceof h && !(e1 instanceof g)) {
      b b = (b)paramView.getLayoutParams();
      g g = new g();
      b.v0 = (e)g;
      b.h0 = true;
      g.x1(b.Z);
    } 
    if (paramView instanceof c) {
      c c1 = (c)paramView;
      c1.s();
      ((b)paramView.getLayoutParams()).i0 = true;
      if (!this.c.contains(c1))
        this.c.add(c1); 
    } 
    this.b.put(paramView.getId(), paramView);
    this.i = true;
  }
  
  public void onViewRemoved(View paramView) {
    super.onViewRemoved(paramView);
    this.b.remove(paramView.getId());
    e e1 = l(paramView);
    this.d.q1(e1);
    this.c.remove(paramView);
    this.i = true;
  }
  
  protected boolean q() {
    int i = (getContext().getApplicationInfo()).flags;
    boolean bool2 = false;
    if ((i & 0x400000) != 0) {
      i = 1;
    } else {
      i = 0;
    } 
    boolean bool1 = bool2;
    if (i != 0) {
      bool1 = bool2;
      if (1 == getLayoutDirection())
        bool1 = true; 
    } 
    return bool1;
  }
  
  public void requestLayout() {
    r();
    super.requestLayout();
  }
  
  protected void s(int paramInt) {
    this.l = new d(getContext(), this, paramInt);
  }
  
  public void setConstraintSet(e parame) {
    this.k = parame;
  }
  
  public void setId(int paramInt) {
    this.b.remove(getId());
    super.setId(paramInt);
    this.b.put(getId(), this);
  }
  
  public void setMaxHeight(int paramInt) {
    if (paramInt == this.h)
      return; 
    this.h = paramInt;
    requestLayout();
  }
  
  public void setMaxWidth(int paramInt) {
    if (paramInt == this.g)
      return; 
    this.g = paramInt;
    requestLayout();
  }
  
  public void setMinHeight(int paramInt) {
    if (paramInt == this.f)
      return; 
    this.f = paramInt;
    requestLayout();
  }
  
  public void setMinWidth(int paramInt) {
    if (paramInt == this.e)
      return; 
    this.e = paramInt;
    requestLayout();
  }
  
  public void setOnConstraintsChanged(g paramg) {
    d d1 = this.l;
    if (d1 != null)
      d1.c(paramg); 
  }
  
  public void setOptimizationLevel(int paramInt) {
    this.j = paramInt;
    this.d.S1(paramInt);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  protected void t(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, boolean paramBoolean2) {
    c c1 = this.v;
    int i = c1.e;
    paramInt1 = View.resolveSizeAndState(paramInt3 + c1.d, paramInt1, 0);
    paramInt3 = View.resolveSizeAndState(paramInt4 + i, paramInt2, 0);
    paramInt2 = Math.min(this.g, paramInt1 & 0xFFFFFF);
    paramInt3 = Math.min(this.h, paramInt3 & 0xFFFFFF);
    paramInt1 = paramInt2;
    if (paramBoolean1)
      paramInt1 = paramInt2 | 0x1000000; 
    paramInt2 = paramInt3;
    if (paramBoolean2)
      paramInt2 = paramInt3 | 0x1000000; 
    setMeasuredDimension(paramInt1, paramInt2);
    this.o = paramInt1;
    this.p = paramInt2;
  }
  
  protected void u(f paramf, int paramInt1, int paramInt2, int paramInt3) {
    int i = View.MeasureSpec.getMode(paramInt2);
    int i1 = View.MeasureSpec.getSize(paramInt2);
    int j = View.MeasureSpec.getMode(paramInt3);
    int m = View.MeasureSpec.getSize(paramInt3);
    int k = Math.max(0, getPaddingTop());
    int i3 = Math.max(0, getPaddingBottom());
    int n = k + i3;
    int i2 = getPaddingWidth();
    this.v.c(paramInt2, paramInt3, k, i3, i2, n);
    paramInt2 = Math.max(0, getPaddingStart());
    paramInt3 = Math.max(0, getPaddingEnd());
    if (paramInt2 > 0 || paramInt3 > 0) {
      if (q())
        paramInt2 = paramInt3; 
    } else {
      paramInt2 = Math.max(0, getPaddingLeft());
    } 
    paramInt3 = i1 - i2;
    m -= n;
    x(paramf, i, paramInt3, j, m);
    paramf.N1(paramInt1, i, paramInt3, j, m, this.o, this.p, paramInt2, k);
  }
  
  public void w(int paramInt, Object paramObject1, Object paramObject2) {
    if (paramInt == 0 && paramObject1 instanceof String && paramObject2 instanceof Integer) {
      if (this.n == null)
        this.n = new HashMap<String, Integer>(); 
      String str = (String)paramObject1;
      paramInt = str.indexOf("/");
      paramObject1 = str;
      if (paramInt != -1)
        paramObject1 = str.substring(paramInt + 1); 
      paramInt = ((Integer)paramObject2).intValue();
      this.n.put(paramObject1, Integer.valueOf(paramInt));
    } 
  }
  
  protected void x(f paramf, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    // Byte code:
    //   0: aload_0
    //   1: getfield v : Landroidx/constraintlayout/widget/ConstraintLayout$c;
    //   4: astore #9
    //   6: aload #9
    //   8: getfield e : I
    //   11: istore #6
    //   13: aload #9
    //   15: getfield d : I
    //   18: istore #7
    //   20: getstatic u/e$b.b : Lu/e$b;
    //   23: astore #9
    //   25: aload_0
    //   26: invokevirtual getChildCount : ()I
    //   29: istore #8
    //   31: iload_2
    //   32: ldc_w -2147483648
    //   35: if_icmpeq -> 107
    //   38: iload_2
    //   39: ifeq -> 77
    //   42: iload_2
    //   43: ldc_w 1073741824
    //   46: if_icmpeq -> 58
    //   49: aload #9
    //   51: astore #10
    //   53: iconst_0
    //   54: istore_3
    //   55: goto -> 134
    //   58: aload_0
    //   59: getfield g : I
    //   62: iload #7
    //   64: isub
    //   65: iload_3
    //   66: invokestatic min : (II)I
    //   69: istore_3
    //   70: aload #9
    //   72: astore #10
    //   74: goto -> 134
    //   77: getstatic u/e$b.c : Lu/e$b;
    //   80: astore #11
    //   82: aload #11
    //   84: astore #10
    //   86: iload #8
    //   88: ifne -> 53
    //   91: iconst_0
    //   92: aload_0
    //   93: getfield e : I
    //   96: invokestatic max : (II)I
    //   99: istore_3
    //   100: aload #11
    //   102: astore #10
    //   104: goto -> 134
    //   107: getstatic u/e$b.c : Lu/e$b;
    //   110: astore #11
    //   112: aload #11
    //   114: astore #10
    //   116: iload #8
    //   118: ifne -> 134
    //   121: iconst_0
    //   122: aload_0
    //   123: getfield e : I
    //   126: invokestatic max : (II)I
    //   129: istore_3
    //   130: aload #11
    //   132: astore #10
    //   134: iload #4
    //   136: ldc_w -2147483648
    //   139: if_icmpeq -> 209
    //   142: iload #4
    //   144: ifeq -> 178
    //   147: iload #4
    //   149: ldc_w 1073741824
    //   152: if_icmpeq -> 161
    //   155: iconst_0
    //   156: istore #5
    //   158: goto -> 237
    //   161: aload_0
    //   162: getfield h : I
    //   165: iload #6
    //   167: isub
    //   168: iload #5
    //   170: invokestatic min : (II)I
    //   173: istore #5
    //   175: goto -> 237
    //   178: getstatic u/e$b.c : Lu/e$b;
    //   181: astore #11
    //   183: aload #11
    //   185: astore #9
    //   187: iload #8
    //   189: ifne -> 155
    //   192: iconst_0
    //   193: aload_0
    //   194: getfield f : I
    //   197: invokestatic max : (II)I
    //   200: istore #5
    //   202: aload #11
    //   204: astore #9
    //   206: goto -> 237
    //   209: getstatic u/e$b.c : Lu/e$b;
    //   212: astore #11
    //   214: aload #11
    //   216: astore #9
    //   218: iload #8
    //   220: ifne -> 237
    //   223: iconst_0
    //   224: aload_0
    //   225: getfield f : I
    //   228: invokestatic max : (II)I
    //   231: istore #5
    //   233: aload #11
    //   235: astore #9
    //   237: iload_3
    //   238: aload_1
    //   239: invokevirtual U : ()I
    //   242: if_icmpne -> 254
    //   245: iload #5
    //   247: aload_1
    //   248: invokevirtual v : ()I
    //   251: if_icmpeq -> 258
    //   254: aload_1
    //   255: invokevirtual J1 : ()V
    //   258: aload_1
    //   259: iconst_0
    //   260: invokevirtual j1 : (I)V
    //   263: aload_1
    //   264: iconst_0
    //   265: invokevirtual k1 : (I)V
    //   268: aload_1
    //   269: aload_0
    //   270: getfield g : I
    //   273: iload #7
    //   275: isub
    //   276: invokevirtual U0 : (I)V
    //   279: aload_1
    //   280: aload_0
    //   281: getfield h : I
    //   284: iload #6
    //   286: isub
    //   287: invokevirtual T0 : (I)V
    //   290: aload_1
    //   291: iconst_0
    //   292: invokevirtual X0 : (I)V
    //   295: aload_1
    //   296: iconst_0
    //   297: invokevirtual W0 : (I)V
    //   300: aload_1
    //   301: aload #10
    //   303: invokevirtual M0 : (Lu/e$b;)V
    //   306: aload_1
    //   307: iload_3
    //   308: invokevirtual h1 : (I)V
    //   311: aload_1
    //   312: aload #9
    //   314: invokevirtual d1 : (Lu/e$b;)V
    //   317: aload_1
    //   318: iload #5
    //   320: invokevirtual I0 : (I)V
    //   323: aload_1
    //   324: aload_0
    //   325: getfield e : I
    //   328: iload #7
    //   330: isub
    //   331: invokevirtual X0 : (I)V
    //   334: aload_1
    //   335: aload_0
    //   336: getfield f : I
    //   339: iload #6
    //   341: isub
    //   342: invokevirtual W0 : (I)V
    //   345: return
  }
  
  public static class b extends ViewGroup.MarginLayoutParams {
    public int A = Integer.MIN_VALUE;
    
    public int B = Integer.MIN_VALUE;
    
    public int C = Integer.MIN_VALUE;
    
    public int D = 0;
    
    boolean E = true;
    
    boolean F = true;
    
    public float G = 0.5F;
    
    public float H = 0.5F;
    
    public String I = null;
    
    float J = 0.0F;
    
    int K = 1;
    
    public float L = -1.0F;
    
    public float M = -1.0F;
    
    public int N = 0;
    
    public int O = 0;
    
    public int P = 0;
    
    public int Q = 0;
    
    public int R = 0;
    
    public int S = 0;
    
    public int T = 0;
    
    public int U = 0;
    
    public float V = 1.0F;
    
    public float W = 1.0F;
    
    public int X = -1;
    
    public int Y = -1;
    
    public int Z = -1;
    
    public int a = -1;
    
    public boolean a0 = false;
    
    public int b = -1;
    
    public boolean b0 = false;
    
    public float c = -1.0F;
    
    public String c0 = null;
    
    public boolean d = true;
    
    public int d0 = 0;
    
    public int e = -1;
    
    boolean e0 = true;
    
    public int f = -1;
    
    boolean f0 = true;
    
    public int g = -1;
    
    boolean g0 = false;
    
    public int h = -1;
    
    boolean h0 = false;
    
    public int i = -1;
    
    boolean i0 = false;
    
    public int j = -1;
    
    boolean j0 = false;
    
    public int k = -1;
    
    boolean k0 = false;
    
    public int l = -1;
    
    int l0 = -1;
    
    public int m = -1;
    
    int m0 = -1;
    
    public int n = -1;
    
    int n0 = -1;
    
    public int o = -1;
    
    int o0 = -1;
    
    public int p = -1;
    
    int p0 = Integer.MIN_VALUE;
    
    public int q = 0;
    
    int q0 = Integer.MIN_VALUE;
    
    public float r = 0.0F;
    
    float r0 = 0.5F;
    
    public int s = -1;
    
    int s0;
    
    public int t = -1;
    
    int t0;
    
    public int u = -1;
    
    float u0;
    
    public int v = -1;
    
    e v0 = new e();
    
    public int w = Integer.MIN_VALUE;
    
    public boolean w0 = false;
    
    public int x = Integer.MIN_VALUE;
    
    public int y = Integer.MIN_VALUE;
    
    public int z = Integer.MIN_VALUE;
    
    public b(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public b(Context param1Context, AttributeSet param1AttributeSet) {
      // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: aload_2
      //   3: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
      //   6: aload_0
      //   7: iconst_m1
      //   8: putfield a : I
      //   11: aload_0
      //   12: iconst_m1
      //   13: putfield b : I
      //   16: aload_0
      //   17: ldc -1.0
      //   19: putfield c : F
      //   22: aload_0
      //   23: iconst_1
      //   24: putfield d : Z
      //   27: aload_0
      //   28: iconst_m1
      //   29: putfield e : I
      //   32: aload_0
      //   33: iconst_m1
      //   34: putfield f : I
      //   37: aload_0
      //   38: iconst_m1
      //   39: putfield g : I
      //   42: aload_0
      //   43: iconst_m1
      //   44: putfield h : I
      //   47: aload_0
      //   48: iconst_m1
      //   49: putfield i : I
      //   52: aload_0
      //   53: iconst_m1
      //   54: putfield j : I
      //   57: aload_0
      //   58: iconst_m1
      //   59: putfield k : I
      //   62: aload_0
      //   63: iconst_m1
      //   64: putfield l : I
      //   67: aload_0
      //   68: iconst_m1
      //   69: putfield m : I
      //   72: aload_0
      //   73: iconst_m1
      //   74: putfield n : I
      //   77: aload_0
      //   78: iconst_m1
      //   79: putfield o : I
      //   82: aload_0
      //   83: iconst_m1
      //   84: putfield p : I
      //   87: aload_0
      //   88: iconst_0
      //   89: putfield q : I
      //   92: aload_0
      //   93: fconst_0
      //   94: putfield r : F
      //   97: aload_0
      //   98: iconst_m1
      //   99: putfield s : I
      //   102: aload_0
      //   103: iconst_m1
      //   104: putfield t : I
      //   107: aload_0
      //   108: iconst_m1
      //   109: putfield u : I
      //   112: aload_0
      //   113: iconst_m1
      //   114: putfield v : I
      //   117: aload_0
      //   118: ldc -2147483648
      //   120: putfield w : I
      //   123: aload_0
      //   124: ldc -2147483648
      //   126: putfield x : I
      //   129: aload_0
      //   130: ldc -2147483648
      //   132: putfield y : I
      //   135: aload_0
      //   136: ldc -2147483648
      //   138: putfield z : I
      //   141: aload_0
      //   142: ldc -2147483648
      //   144: putfield A : I
      //   147: aload_0
      //   148: ldc -2147483648
      //   150: putfield B : I
      //   153: aload_0
      //   154: ldc -2147483648
      //   156: putfield C : I
      //   159: aload_0
      //   160: iconst_0
      //   161: putfield D : I
      //   164: aload_0
      //   165: iconst_1
      //   166: putfield E : Z
      //   169: aload_0
      //   170: iconst_1
      //   171: putfield F : Z
      //   174: aload_0
      //   175: ldc 0.5
      //   177: putfield G : F
      //   180: aload_0
      //   181: ldc 0.5
      //   183: putfield H : F
      //   186: aload_0
      //   187: aconst_null
      //   188: putfield I : Ljava/lang/String;
      //   191: aload_0
      //   192: fconst_0
      //   193: putfield J : F
      //   196: aload_0
      //   197: iconst_1
      //   198: putfield K : I
      //   201: aload_0
      //   202: ldc -1.0
      //   204: putfield L : F
      //   207: aload_0
      //   208: ldc -1.0
      //   210: putfield M : F
      //   213: aload_0
      //   214: iconst_0
      //   215: putfield N : I
      //   218: aload_0
      //   219: iconst_0
      //   220: putfield O : I
      //   223: aload_0
      //   224: iconst_0
      //   225: putfield P : I
      //   228: aload_0
      //   229: iconst_0
      //   230: putfield Q : I
      //   233: aload_0
      //   234: iconst_0
      //   235: putfield R : I
      //   238: aload_0
      //   239: iconst_0
      //   240: putfield S : I
      //   243: aload_0
      //   244: iconst_0
      //   245: putfield T : I
      //   248: aload_0
      //   249: iconst_0
      //   250: putfield U : I
      //   253: aload_0
      //   254: fconst_1
      //   255: putfield V : F
      //   258: aload_0
      //   259: fconst_1
      //   260: putfield W : F
      //   263: aload_0
      //   264: iconst_m1
      //   265: putfield X : I
      //   268: aload_0
      //   269: iconst_m1
      //   270: putfield Y : I
      //   273: aload_0
      //   274: iconst_m1
      //   275: putfield Z : I
      //   278: aload_0
      //   279: iconst_0
      //   280: putfield a0 : Z
      //   283: aload_0
      //   284: iconst_0
      //   285: putfield b0 : Z
      //   288: aload_0
      //   289: aconst_null
      //   290: putfield c0 : Ljava/lang/String;
      //   293: aload_0
      //   294: iconst_0
      //   295: putfield d0 : I
      //   298: aload_0
      //   299: iconst_1
      //   300: putfield e0 : Z
      //   303: aload_0
      //   304: iconst_1
      //   305: putfield f0 : Z
      //   308: aload_0
      //   309: iconst_0
      //   310: putfield g0 : Z
      //   313: aload_0
      //   314: iconst_0
      //   315: putfield h0 : Z
      //   318: aload_0
      //   319: iconst_0
      //   320: putfield i0 : Z
      //   323: aload_0
      //   324: iconst_0
      //   325: putfield j0 : Z
      //   328: aload_0
      //   329: iconst_0
      //   330: putfield k0 : Z
      //   333: aload_0
      //   334: iconst_m1
      //   335: putfield l0 : I
      //   338: aload_0
      //   339: iconst_m1
      //   340: putfield m0 : I
      //   343: aload_0
      //   344: iconst_m1
      //   345: putfield n0 : I
      //   348: aload_0
      //   349: iconst_m1
      //   350: putfield o0 : I
      //   353: aload_0
      //   354: ldc -2147483648
      //   356: putfield p0 : I
      //   359: aload_0
      //   360: ldc -2147483648
      //   362: putfield q0 : I
      //   365: aload_0
      //   366: ldc 0.5
      //   368: putfield r0 : F
      //   371: aload_0
      //   372: new u/e
      //   375: dup
      //   376: invokespecial <init> : ()V
      //   379: putfield v0 : Lu/e;
      //   382: aload_0
      //   383: iconst_0
      //   384: putfield w0 : Z
      //   387: aload_1
      //   388: aload_2
      //   389: getstatic androidx/constraintlayout/widget/k.n1 : [I
      //   392: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
      //   395: astore_1
      //   396: aload_1
      //   397: invokevirtual getIndexCount : ()I
      //   400: istore #5
      //   402: iconst_0
      //   403: istore #4
      //   405: iload #4
      //   407: iload #5
      //   409: if_icmpge -> 2116
      //   412: aload_1
      //   413: iload #4
      //   415: invokevirtual getIndex : (I)I
      //   418: istore #6
      //   420: getstatic androidx/constraintlayout/widget/ConstraintLayout$b$a.a : Landroid/util/SparseIntArray;
      //   423: iload #6
      //   425: invokevirtual get : (I)I
      //   428: istore #7
      //   430: iload #7
      //   432: tableswitch default -> 600, 1 -> 2093, 2 -> 2055, 3 -> 2038, 4 -> 1996, 5 -> 1979, 6 -> 1962, 7 -> 1945, 8 -> 1907, 9 -> 1869, 10 -> 1831, 11 -> 1793, 12 -> 1755, 13 -> 1717, 14 -> 1679, 15 -> 1641, 16 -> 1603, 17 -> 1565, 18 -> 1527, 19 -> 1489, 20 -> 1451, 21 -> 1434, 22 -> 1417, 23 -> 1400, 24 -> 1383, 25 -> 1366, 26 -> 1349, 27 -> 1332, 28 -> 1315, 29 -> 1298, 30 -> 1281, 31 -> 1247, 32 -> 1213, 33 -> 1172, 34 -> 1131, 35 -> 1105, 36 -> 1064, 37 -> 1023, 38 -> 997
      //   600: iload #7
      //   602: tableswitch default -> 664, 44 -> 984, 45 -> 967, 46 -> 950, 47 -> 936, 48 -> 922, 49 -> 905, 50 -> 888, 51 -> 875, 52 -> 837, 53 -> 799, 54 -> 782, 55 -> 765
      //   664: iload #7
      //   666: tableswitch default -> 696, 64 -> 749, 65 -> 733, 66 -> 716, 67 -> 699
      //   696: goto -> 2107
      //   699: aload_0
      //   700: aload_1
      //   701: iload #6
      //   703: aload_0
      //   704: getfield d : Z
      //   707: invokevirtual getBoolean : (IZ)Z
      //   710: putfield d : Z
      //   713: goto -> 2107
      //   716: aload_0
      //   717: aload_1
      //   718: iload #6
      //   720: aload_0
      //   721: getfield d0 : I
      //   724: invokevirtual getInt : (II)I
      //   727: putfield d0 : I
      //   730: goto -> 2107
      //   733: aload_0
      //   734: aload_1
      //   735: iload #6
      //   737: iconst_1
      //   738: invokestatic m : (Ljava/lang/Object;Landroid/content/res/TypedArray;II)V
      //   741: aload_0
      //   742: iconst_1
      //   743: putfield F : Z
      //   746: goto -> 2107
      //   749: aload_0
      //   750: aload_1
      //   751: iload #6
      //   753: iconst_0
      //   754: invokestatic m : (Ljava/lang/Object;Landroid/content/res/TypedArray;II)V
      //   757: aload_0
      //   758: iconst_1
      //   759: putfield E : Z
      //   762: goto -> 2107
      //   765: aload_0
      //   766: aload_1
      //   767: iload #6
      //   769: aload_0
      //   770: getfield C : I
      //   773: invokevirtual getDimensionPixelSize : (II)I
      //   776: putfield C : I
      //   779: goto -> 2107
      //   782: aload_0
      //   783: aload_1
      //   784: iload #6
      //   786: aload_0
      //   787: getfield D : I
      //   790: invokevirtual getDimensionPixelSize : (II)I
      //   793: putfield D : I
      //   796: goto -> 2107
      //   799: aload_1
      //   800: iload #6
      //   802: aload_0
      //   803: getfield o : I
      //   806: invokevirtual getResourceId : (II)I
      //   809: istore #7
      //   811: aload_0
      //   812: iload #7
      //   814: putfield o : I
      //   817: iload #7
      //   819: iconst_m1
      //   820: if_icmpne -> 2107
      //   823: aload_0
      //   824: aload_1
      //   825: iload #6
      //   827: iconst_m1
      //   828: invokevirtual getInt : (II)I
      //   831: putfield o : I
      //   834: goto -> 2107
      //   837: aload_1
      //   838: iload #6
      //   840: aload_0
      //   841: getfield n : I
      //   844: invokevirtual getResourceId : (II)I
      //   847: istore #7
      //   849: aload_0
      //   850: iload #7
      //   852: putfield n : I
      //   855: iload #7
      //   857: iconst_m1
      //   858: if_icmpne -> 2107
      //   861: aload_0
      //   862: aload_1
      //   863: iload #6
      //   865: iconst_m1
      //   866: invokevirtual getInt : (II)I
      //   869: putfield n : I
      //   872: goto -> 2107
      //   875: aload_0
      //   876: aload_1
      //   877: iload #6
      //   879: invokevirtual getString : (I)Ljava/lang/String;
      //   882: putfield c0 : Ljava/lang/String;
      //   885: goto -> 2107
      //   888: aload_0
      //   889: aload_1
      //   890: iload #6
      //   892: aload_0
      //   893: getfield Y : I
      //   896: invokevirtual getDimensionPixelOffset : (II)I
      //   899: putfield Y : I
      //   902: goto -> 2107
      //   905: aload_0
      //   906: aload_1
      //   907: iload #6
      //   909: aload_0
      //   910: getfield X : I
      //   913: invokevirtual getDimensionPixelOffset : (II)I
      //   916: putfield X : I
      //   919: goto -> 2107
      //   922: aload_0
      //   923: aload_1
      //   924: iload #6
      //   926: iconst_0
      //   927: invokevirtual getInt : (II)I
      //   930: putfield O : I
      //   933: goto -> 2107
      //   936: aload_0
      //   937: aload_1
      //   938: iload #6
      //   940: iconst_0
      //   941: invokevirtual getInt : (II)I
      //   944: putfield N : I
      //   947: goto -> 2107
      //   950: aload_0
      //   951: aload_1
      //   952: iload #6
      //   954: aload_0
      //   955: getfield M : F
      //   958: invokevirtual getFloat : (IF)F
      //   961: putfield M : F
      //   964: goto -> 2107
      //   967: aload_0
      //   968: aload_1
      //   969: iload #6
      //   971: aload_0
      //   972: getfield L : F
      //   975: invokevirtual getFloat : (IF)F
      //   978: putfield L : F
      //   981: goto -> 2107
      //   984: aload_0
      //   985: aload_1
      //   986: iload #6
      //   988: invokevirtual getString : (I)Ljava/lang/String;
      //   991: invokestatic o : (Landroidx/constraintlayout/widget/ConstraintLayout$b;Ljava/lang/String;)V
      //   994: goto -> 2107
      //   997: aload_0
      //   998: fconst_0
      //   999: aload_1
      //   1000: iload #6
      //   1002: aload_0
      //   1003: getfield W : F
      //   1006: invokevirtual getFloat : (IF)F
      //   1009: invokestatic max : (FF)F
      //   1012: putfield W : F
      //   1015: aload_0
      //   1016: iconst_2
      //   1017: putfield Q : I
      //   1020: goto -> 2107
      //   1023: aload_0
      //   1024: aload_1
      //   1025: iload #6
      //   1027: aload_0
      //   1028: getfield U : I
      //   1031: invokevirtual getDimensionPixelSize : (II)I
      //   1034: putfield U : I
      //   1037: goto -> 2107
      //   1040: aload_1
      //   1041: iload #6
      //   1043: aload_0
      //   1044: getfield U : I
      //   1047: invokevirtual getInt : (II)I
      //   1050: bipush #-2
      //   1052: if_icmpne -> 2107
      //   1055: aload_0
      //   1056: bipush #-2
      //   1058: putfield U : I
      //   1061: goto -> 2107
      //   1064: aload_0
      //   1065: aload_1
      //   1066: iload #6
      //   1068: aload_0
      //   1069: getfield S : I
      //   1072: invokevirtual getDimensionPixelSize : (II)I
      //   1075: putfield S : I
      //   1078: goto -> 2107
      //   1081: aload_1
      //   1082: iload #6
      //   1084: aload_0
      //   1085: getfield S : I
      //   1088: invokevirtual getInt : (II)I
      //   1091: bipush #-2
      //   1093: if_icmpne -> 2107
      //   1096: aload_0
      //   1097: bipush #-2
      //   1099: putfield S : I
      //   1102: goto -> 2107
      //   1105: aload_0
      //   1106: fconst_0
      //   1107: aload_1
      //   1108: iload #6
      //   1110: aload_0
      //   1111: getfield V : F
      //   1114: invokevirtual getFloat : (IF)F
      //   1117: invokestatic max : (FF)F
      //   1120: putfield V : F
      //   1123: aload_0
      //   1124: iconst_2
      //   1125: putfield P : I
      //   1128: goto -> 2107
      //   1131: aload_0
      //   1132: aload_1
      //   1133: iload #6
      //   1135: aload_0
      //   1136: getfield T : I
      //   1139: invokevirtual getDimensionPixelSize : (II)I
      //   1142: putfield T : I
      //   1145: goto -> 2107
      //   1148: aload_1
      //   1149: iload #6
      //   1151: aload_0
      //   1152: getfield T : I
      //   1155: invokevirtual getInt : (II)I
      //   1158: bipush #-2
      //   1160: if_icmpne -> 2107
      //   1163: aload_0
      //   1164: bipush #-2
      //   1166: putfield T : I
      //   1169: goto -> 2107
      //   1172: aload_0
      //   1173: aload_1
      //   1174: iload #6
      //   1176: aload_0
      //   1177: getfield R : I
      //   1180: invokevirtual getDimensionPixelSize : (II)I
      //   1183: putfield R : I
      //   1186: goto -> 2107
      //   1189: aload_1
      //   1190: iload #6
      //   1192: aload_0
      //   1193: getfield R : I
      //   1196: invokevirtual getInt : (II)I
      //   1199: bipush #-2
      //   1201: if_icmpne -> 2107
      //   1204: aload_0
      //   1205: bipush #-2
      //   1207: putfield R : I
      //   1210: goto -> 2107
      //   1213: aload_1
      //   1214: iload #6
      //   1216: iconst_0
      //   1217: invokevirtual getInt : (II)I
      //   1220: istore #6
      //   1222: aload_0
      //   1223: iload #6
      //   1225: putfield Q : I
      //   1228: iload #6
      //   1230: iconst_1
      //   1231: if_icmpne -> 2107
      //   1234: ldc_w 'ConstraintLayout'
      //   1237: ldc_w 'layout_constraintHeight_default="wrap" is deprecated.\\nUse layout_height="WRAP_CONTENT" and layout_constrainedHeight="true" instead.'
      //   1240: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
      //   1243: pop
      //   1244: goto -> 2107
      //   1247: aload_1
      //   1248: iload #6
      //   1250: iconst_0
      //   1251: invokevirtual getInt : (II)I
      //   1254: istore #6
      //   1256: aload_0
      //   1257: iload #6
      //   1259: putfield P : I
      //   1262: iload #6
      //   1264: iconst_1
      //   1265: if_icmpne -> 2107
      //   1268: ldc_w 'ConstraintLayout'
      //   1271: ldc_w 'layout_constraintWidth_default="wrap" is deprecated.\\nUse layout_width="WRAP_CONTENT" and layout_constrainedWidth="true" instead.'
      //   1274: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
      //   1277: pop
      //   1278: goto -> 2107
      //   1281: aload_0
      //   1282: aload_1
      //   1283: iload #6
      //   1285: aload_0
      //   1286: getfield H : F
      //   1289: invokevirtual getFloat : (IF)F
      //   1292: putfield H : F
      //   1295: goto -> 2107
      //   1298: aload_0
      //   1299: aload_1
      //   1300: iload #6
      //   1302: aload_0
      //   1303: getfield G : F
      //   1306: invokevirtual getFloat : (IF)F
      //   1309: putfield G : F
      //   1312: goto -> 2107
      //   1315: aload_0
      //   1316: aload_1
      //   1317: iload #6
      //   1319: aload_0
      //   1320: getfield b0 : Z
      //   1323: invokevirtual getBoolean : (IZ)Z
      //   1326: putfield b0 : Z
      //   1329: goto -> 2107
      //   1332: aload_0
      //   1333: aload_1
      //   1334: iload #6
      //   1336: aload_0
      //   1337: getfield a0 : Z
      //   1340: invokevirtual getBoolean : (IZ)Z
      //   1343: putfield a0 : Z
      //   1346: goto -> 2107
      //   1349: aload_0
      //   1350: aload_1
      //   1351: iload #6
      //   1353: aload_0
      //   1354: getfield B : I
      //   1357: invokevirtual getDimensionPixelSize : (II)I
      //   1360: putfield B : I
      //   1363: goto -> 2107
      //   1366: aload_0
      //   1367: aload_1
      //   1368: iload #6
      //   1370: aload_0
      //   1371: getfield A : I
      //   1374: invokevirtual getDimensionPixelSize : (II)I
      //   1377: putfield A : I
      //   1380: goto -> 2107
      //   1383: aload_0
      //   1384: aload_1
      //   1385: iload #6
      //   1387: aload_0
      //   1388: getfield z : I
      //   1391: invokevirtual getDimensionPixelSize : (II)I
      //   1394: putfield z : I
      //   1397: goto -> 2107
      //   1400: aload_0
      //   1401: aload_1
      //   1402: iload #6
      //   1404: aload_0
      //   1405: getfield y : I
      //   1408: invokevirtual getDimensionPixelSize : (II)I
      //   1411: putfield y : I
      //   1414: goto -> 2107
      //   1417: aload_0
      //   1418: aload_1
      //   1419: iload #6
      //   1421: aload_0
      //   1422: getfield x : I
      //   1425: invokevirtual getDimensionPixelSize : (II)I
      //   1428: putfield x : I
      //   1431: goto -> 2107
      //   1434: aload_0
      //   1435: aload_1
      //   1436: iload #6
      //   1438: aload_0
      //   1439: getfield w : I
      //   1442: invokevirtual getDimensionPixelSize : (II)I
      //   1445: putfield w : I
      //   1448: goto -> 2107
      //   1451: aload_1
      //   1452: iload #6
      //   1454: aload_0
      //   1455: getfield v : I
      //   1458: invokevirtual getResourceId : (II)I
      //   1461: istore #7
      //   1463: aload_0
      //   1464: iload #7
      //   1466: putfield v : I
      //   1469: iload #7
      //   1471: iconst_m1
      //   1472: if_icmpne -> 2107
      //   1475: aload_0
      //   1476: aload_1
      //   1477: iload #6
      //   1479: iconst_m1
      //   1480: invokevirtual getInt : (II)I
      //   1483: putfield v : I
      //   1486: goto -> 2107
      //   1489: aload_1
      //   1490: iload #6
      //   1492: aload_0
      //   1493: getfield u : I
      //   1496: invokevirtual getResourceId : (II)I
      //   1499: istore #7
      //   1501: aload_0
      //   1502: iload #7
      //   1504: putfield u : I
      //   1507: iload #7
      //   1509: iconst_m1
      //   1510: if_icmpne -> 2107
      //   1513: aload_0
      //   1514: aload_1
      //   1515: iload #6
      //   1517: iconst_m1
      //   1518: invokevirtual getInt : (II)I
      //   1521: putfield u : I
      //   1524: goto -> 2107
      //   1527: aload_1
      //   1528: iload #6
      //   1530: aload_0
      //   1531: getfield t : I
      //   1534: invokevirtual getResourceId : (II)I
      //   1537: istore #7
      //   1539: aload_0
      //   1540: iload #7
      //   1542: putfield t : I
      //   1545: iload #7
      //   1547: iconst_m1
      //   1548: if_icmpne -> 2107
      //   1551: aload_0
      //   1552: aload_1
      //   1553: iload #6
      //   1555: iconst_m1
      //   1556: invokevirtual getInt : (II)I
      //   1559: putfield t : I
      //   1562: goto -> 2107
      //   1565: aload_1
      //   1566: iload #6
      //   1568: aload_0
      //   1569: getfield s : I
      //   1572: invokevirtual getResourceId : (II)I
      //   1575: istore #7
      //   1577: aload_0
      //   1578: iload #7
      //   1580: putfield s : I
      //   1583: iload #7
      //   1585: iconst_m1
      //   1586: if_icmpne -> 2107
      //   1589: aload_0
      //   1590: aload_1
      //   1591: iload #6
      //   1593: iconst_m1
      //   1594: invokevirtual getInt : (II)I
      //   1597: putfield s : I
      //   1600: goto -> 2107
      //   1603: aload_1
      //   1604: iload #6
      //   1606: aload_0
      //   1607: getfield m : I
      //   1610: invokevirtual getResourceId : (II)I
      //   1613: istore #7
      //   1615: aload_0
      //   1616: iload #7
      //   1618: putfield m : I
      //   1621: iload #7
      //   1623: iconst_m1
      //   1624: if_icmpne -> 2107
      //   1627: aload_0
      //   1628: aload_1
      //   1629: iload #6
      //   1631: iconst_m1
      //   1632: invokevirtual getInt : (II)I
      //   1635: putfield m : I
      //   1638: goto -> 2107
      //   1641: aload_1
      //   1642: iload #6
      //   1644: aload_0
      //   1645: getfield l : I
      //   1648: invokevirtual getResourceId : (II)I
      //   1651: istore #7
      //   1653: aload_0
      //   1654: iload #7
      //   1656: putfield l : I
      //   1659: iload #7
      //   1661: iconst_m1
      //   1662: if_icmpne -> 2107
      //   1665: aload_0
      //   1666: aload_1
      //   1667: iload #6
      //   1669: iconst_m1
      //   1670: invokevirtual getInt : (II)I
      //   1673: putfield l : I
      //   1676: goto -> 2107
      //   1679: aload_1
      //   1680: iload #6
      //   1682: aload_0
      //   1683: getfield k : I
      //   1686: invokevirtual getResourceId : (II)I
      //   1689: istore #7
      //   1691: aload_0
      //   1692: iload #7
      //   1694: putfield k : I
      //   1697: iload #7
      //   1699: iconst_m1
      //   1700: if_icmpne -> 2107
      //   1703: aload_0
      //   1704: aload_1
      //   1705: iload #6
      //   1707: iconst_m1
      //   1708: invokevirtual getInt : (II)I
      //   1711: putfield k : I
      //   1714: goto -> 2107
      //   1717: aload_1
      //   1718: iload #6
      //   1720: aload_0
      //   1721: getfield j : I
      //   1724: invokevirtual getResourceId : (II)I
      //   1727: istore #7
      //   1729: aload_0
      //   1730: iload #7
      //   1732: putfield j : I
      //   1735: iload #7
      //   1737: iconst_m1
      //   1738: if_icmpne -> 2107
      //   1741: aload_0
      //   1742: aload_1
      //   1743: iload #6
      //   1745: iconst_m1
      //   1746: invokevirtual getInt : (II)I
      //   1749: putfield j : I
      //   1752: goto -> 2107
      //   1755: aload_1
      //   1756: iload #6
      //   1758: aload_0
      //   1759: getfield i : I
      //   1762: invokevirtual getResourceId : (II)I
      //   1765: istore #7
      //   1767: aload_0
      //   1768: iload #7
      //   1770: putfield i : I
      //   1773: iload #7
      //   1775: iconst_m1
      //   1776: if_icmpne -> 2107
      //   1779: aload_0
      //   1780: aload_1
      //   1781: iload #6
      //   1783: iconst_m1
      //   1784: invokevirtual getInt : (II)I
      //   1787: putfield i : I
      //   1790: goto -> 2107
      //   1793: aload_1
      //   1794: iload #6
      //   1796: aload_0
      //   1797: getfield h : I
      //   1800: invokevirtual getResourceId : (II)I
      //   1803: istore #7
      //   1805: aload_0
      //   1806: iload #7
      //   1808: putfield h : I
      //   1811: iload #7
      //   1813: iconst_m1
      //   1814: if_icmpne -> 2107
      //   1817: aload_0
      //   1818: aload_1
      //   1819: iload #6
      //   1821: iconst_m1
      //   1822: invokevirtual getInt : (II)I
      //   1825: putfield h : I
      //   1828: goto -> 2107
      //   1831: aload_1
      //   1832: iload #6
      //   1834: aload_0
      //   1835: getfield g : I
      //   1838: invokevirtual getResourceId : (II)I
      //   1841: istore #7
      //   1843: aload_0
      //   1844: iload #7
      //   1846: putfield g : I
      //   1849: iload #7
      //   1851: iconst_m1
      //   1852: if_icmpne -> 2107
      //   1855: aload_0
      //   1856: aload_1
      //   1857: iload #6
      //   1859: iconst_m1
      //   1860: invokevirtual getInt : (II)I
      //   1863: putfield g : I
      //   1866: goto -> 2107
      //   1869: aload_1
      //   1870: iload #6
      //   1872: aload_0
      //   1873: getfield f : I
      //   1876: invokevirtual getResourceId : (II)I
      //   1879: istore #7
      //   1881: aload_0
      //   1882: iload #7
      //   1884: putfield f : I
      //   1887: iload #7
      //   1889: iconst_m1
      //   1890: if_icmpne -> 2107
      //   1893: aload_0
      //   1894: aload_1
      //   1895: iload #6
      //   1897: iconst_m1
      //   1898: invokevirtual getInt : (II)I
      //   1901: putfield f : I
      //   1904: goto -> 2107
      //   1907: aload_1
      //   1908: iload #6
      //   1910: aload_0
      //   1911: getfield e : I
      //   1914: invokevirtual getResourceId : (II)I
      //   1917: istore #7
      //   1919: aload_0
      //   1920: iload #7
      //   1922: putfield e : I
      //   1925: iload #7
      //   1927: iconst_m1
      //   1928: if_icmpne -> 2107
      //   1931: aload_0
      //   1932: aload_1
      //   1933: iload #6
      //   1935: iconst_m1
      //   1936: invokevirtual getInt : (II)I
      //   1939: putfield e : I
      //   1942: goto -> 2107
      //   1945: aload_0
      //   1946: aload_1
      //   1947: iload #6
      //   1949: aload_0
      //   1950: getfield c : F
      //   1953: invokevirtual getFloat : (IF)F
      //   1956: putfield c : F
      //   1959: goto -> 2107
      //   1962: aload_0
      //   1963: aload_1
      //   1964: iload #6
      //   1966: aload_0
      //   1967: getfield b : I
      //   1970: invokevirtual getDimensionPixelOffset : (II)I
      //   1973: putfield b : I
      //   1976: goto -> 2107
      //   1979: aload_0
      //   1980: aload_1
      //   1981: iload #6
      //   1983: aload_0
      //   1984: getfield a : I
      //   1987: invokevirtual getDimensionPixelOffset : (II)I
      //   1990: putfield a : I
      //   1993: goto -> 2107
      //   1996: aload_1
      //   1997: iload #6
      //   1999: aload_0
      //   2000: getfield r : F
      //   2003: invokevirtual getFloat : (IF)F
      //   2006: ldc_w 360.0
      //   2009: frem
      //   2010: fstore_3
      //   2011: aload_0
      //   2012: fload_3
      //   2013: putfield r : F
      //   2016: fload_3
      //   2017: fconst_0
      //   2018: fcmpg
      //   2019: ifge -> 2107
      //   2022: aload_0
      //   2023: ldc_w 360.0
      //   2026: fload_3
      //   2027: fsub
      //   2028: ldc_w 360.0
      //   2031: frem
      //   2032: putfield r : F
      //   2035: goto -> 2107
      //   2038: aload_0
      //   2039: aload_1
      //   2040: iload #6
      //   2042: aload_0
      //   2043: getfield q : I
      //   2046: invokevirtual getDimensionPixelSize : (II)I
      //   2049: putfield q : I
      //   2052: goto -> 2107
      //   2055: aload_1
      //   2056: iload #6
      //   2058: aload_0
      //   2059: getfield p : I
      //   2062: invokevirtual getResourceId : (II)I
      //   2065: istore #7
      //   2067: aload_0
      //   2068: iload #7
      //   2070: putfield p : I
      //   2073: iload #7
      //   2075: iconst_m1
      //   2076: if_icmpne -> 2107
      //   2079: aload_0
      //   2080: aload_1
      //   2081: iload #6
      //   2083: iconst_m1
      //   2084: invokevirtual getInt : (II)I
      //   2087: putfield p : I
      //   2090: goto -> 2107
      //   2093: aload_0
      //   2094: aload_1
      //   2095: iload #6
      //   2097: aload_0
      //   2098: getfield Z : I
      //   2101: invokevirtual getInt : (II)I
      //   2104: putfield Z : I
      //   2107: iload #4
      //   2109: iconst_1
      //   2110: iadd
      //   2111: istore #4
      //   2113: goto -> 405
      //   2116: aload_1
      //   2117: invokevirtual recycle : ()V
      //   2120: aload_0
      //   2121: invokevirtual a : ()V
      //   2124: return
      //   2125: astore_2
      //   2126: goto -> 1040
      //   2129: astore_2
      //   2130: goto -> 1081
      //   2133: astore_2
      //   2134: goto -> 1148
      //   2137: astore_2
      //   2138: goto -> 1189
      // Exception table:
      //   from	to	target	type
      //   1023	1037	2125	java/lang/Exception
      //   1064	1078	2129	java/lang/Exception
      //   1131	1145	2133	java/lang/Exception
      //   1172	1186	2137	java/lang/Exception
    }
    
    public b(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public void a() {
      this.h0 = false;
      this.e0 = true;
      this.f0 = true;
      int i = this.width;
      if (i == -2 && this.a0) {
        this.e0 = false;
        if (this.P == 0)
          this.P = 1; 
      } 
      int j = this.height;
      if (j == -2 && this.b0) {
        this.f0 = false;
        if (this.Q == 0)
          this.Q = 1; 
      } 
      if (i == 0 || i == -1) {
        this.e0 = false;
        if (i == 0 && this.P == 1) {
          this.width = -2;
          this.a0 = true;
        } 
      } 
      if (j == 0 || j == -1) {
        this.f0 = false;
        if (j == 0 && this.Q == 1) {
          this.height = -2;
          this.b0 = true;
        } 
      } 
      if (this.c != -1.0F || this.a != -1 || this.b != -1) {
        this.h0 = true;
        this.e0 = true;
        this.f0 = true;
        if (!(this.v0 instanceof g))
          this.v0 = (e)new g(); 
        ((g)this.v0).x1(this.Z);
      } 
    }
    
    public void resolveLayoutDirection(int param1Int) {
      // Byte code:
      //   0: aload_0
      //   1: getfield leftMargin : I
      //   4: istore #5
      //   6: aload_0
      //   7: getfield rightMargin : I
      //   10: istore #6
      //   12: aload_0
      //   13: iload_1
      //   14: invokespecial resolveLayoutDirection : (I)V
      //   17: aload_0
      //   18: invokevirtual getLayoutDirection : ()I
      //   21: istore_1
      //   22: iconst_0
      //   23: istore #4
      //   25: iconst_1
      //   26: iload_1
      //   27: if_icmpne -> 35
      //   30: iconst_1
      //   31: istore_1
      //   32: goto -> 37
      //   35: iconst_0
      //   36: istore_1
      //   37: aload_0
      //   38: iconst_m1
      //   39: putfield n0 : I
      //   42: aload_0
      //   43: iconst_m1
      //   44: putfield o0 : I
      //   47: aload_0
      //   48: iconst_m1
      //   49: putfield l0 : I
      //   52: aload_0
      //   53: iconst_m1
      //   54: putfield m0 : I
      //   57: aload_0
      //   58: aload_0
      //   59: getfield w : I
      //   62: putfield p0 : I
      //   65: aload_0
      //   66: aload_0
      //   67: getfield y : I
      //   70: putfield q0 : I
      //   73: aload_0
      //   74: getfield G : F
      //   77: fstore_2
      //   78: aload_0
      //   79: fload_2
      //   80: putfield r0 : F
      //   83: aload_0
      //   84: getfield a : I
      //   87: istore #7
      //   89: aload_0
      //   90: iload #7
      //   92: putfield s0 : I
      //   95: aload_0
      //   96: getfield b : I
      //   99: istore #8
      //   101: aload_0
      //   102: iload #8
      //   104: putfield t0 : I
      //   107: aload_0
      //   108: getfield c : F
      //   111: fstore_3
      //   112: aload_0
      //   113: fload_3
      //   114: putfield u0 : F
      //   117: iload_1
      //   118: ifeq -> 355
      //   121: aload_0
      //   122: getfield s : I
      //   125: istore_1
      //   126: iload_1
      //   127: iconst_m1
      //   128: if_icmpeq -> 141
      //   131: aload_0
      //   132: iload_1
      //   133: putfield n0 : I
      //   136: iconst_1
      //   137: istore_1
      //   138: goto -> 165
      //   141: aload_0
      //   142: getfield t : I
      //   145: istore #9
      //   147: iload #4
      //   149: istore_1
      //   150: iload #9
      //   152: iconst_m1
      //   153: if_icmpeq -> 165
      //   156: aload_0
      //   157: iload #9
      //   159: putfield o0 : I
      //   162: goto -> 136
      //   165: aload_0
      //   166: getfield u : I
      //   169: istore #4
      //   171: iload #4
      //   173: iconst_m1
      //   174: if_icmpeq -> 185
      //   177: aload_0
      //   178: iload #4
      //   180: putfield m0 : I
      //   183: iconst_1
      //   184: istore_1
      //   185: aload_0
      //   186: getfield v : I
      //   189: istore #4
      //   191: iload #4
      //   193: iconst_m1
      //   194: if_icmpeq -> 205
      //   197: aload_0
      //   198: iload #4
      //   200: putfield l0 : I
      //   203: iconst_1
      //   204: istore_1
      //   205: aload_0
      //   206: getfield A : I
      //   209: istore #4
      //   211: iload #4
      //   213: ldc -2147483648
      //   215: if_icmpeq -> 224
      //   218: aload_0
      //   219: iload #4
      //   221: putfield q0 : I
      //   224: aload_0
      //   225: getfield B : I
      //   228: istore #4
      //   230: iload #4
      //   232: ldc -2147483648
      //   234: if_icmpeq -> 243
      //   237: aload_0
      //   238: iload #4
      //   240: putfield p0 : I
      //   243: iload_1
      //   244: ifeq -> 254
      //   247: aload_0
      //   248: fconst_1
      //   249: fload_2
      //   250: fsub
      //   251: putfield r0 : F
      //   254: aload_0
      //   255: getfield h0 : Z
      //   258: ifeq -> 447
      //   261: aload_0
      //   262: getfield Z : I
      //   265: iconst_1
      //   266: if_icmpne -> 447
      //   269: aload_0
      //   270: getfield d : Z
      //   273: ifeq -> 447
      //   276: fload_3
      //   277: ldc -1.0
      //   279: fcmpl
      //   280: ifeq -> 303
      //   283: aload_0
      //   284: fconst_1
      //   285: fload_3
      //   286: fsub
      //   287: putfield u0 : F
      //   290: aload_0
      //   291: iconst_m1
      //   292: putfield s0 : I
      //   295: aload_0
      //   296: iconst_m1
      //   297: putfield t0 : I
      //   300: goto -> 447
      //   303: iload #7
      //   305: iconst_m1
      //   306: if_icmpeq -> 329
      //   309: aload_0
      //   310: iload #7
      //   312: putfield t0 : I
      //   315: aload_0
      //   316: iconst_m1
      //   317: putfield s0 : I
      //   320: aload_0
      //   321: ldc -1.0
      //   323: putfield u0 : F
      //   326: goto -> 447
      //   329: iload #8
      //   331: iconst_m1
      //   332: if_icmpeq -> 447
      //   335: aload_0
      //   336: iload #8
      //   338: putfield s0 : I
      //   341: aload_0
      //   342: iconst_m1
      //   343: putfield t0 : I
      //   346: aload_0
      //   347: ldc -1.0
      //   349: putfield u0 : F
      //   352: goto -> 447
      //   355: aload_0
      //   356: getfield s : I
      //   359: istore_1
      //   360: iload_1
      //   361: iconst_m1
      //   362: if_icmpeq -> 370
      //   365: aload_0
      //   366: iload_1
      //   367: putfield m0 : I
      //   370: aload_0
      //   371: getfield t : I
      //   374: istore_1
      //   375: iload_1
      //   376: iconst_m1
      //   377: if_icmpeq -> 385
      //   380: aload_0
      //   381: iload_1
      //   382: putfield l0 : I
      //   385: aload_0
      //   386: getfield u : I
      //   389: istore_1
      //   390: iload_1
      //   391: iconst_m1
      //   392: if_icmpeq -> 400
      //   395: aload_0
      //   396: iload_1
      //   397: putfield n0 : I
      //   400: aload_0
      //   401: getfield v : I
      //   404: istore_1
      //   405: iload_1
      //   406: iconst_m1
      //   407: if_icmpeq -> 415
      //   410: aload_0
      //   411: iload_1
      //   412: putfield o0 : I
      //   415: aload_0
      //   416: getfield A : I
      //   419: istore_1
      //   420: iload_1
      //   421: ldc -2147483648
      //   423: if_icmpeq -> 431
      //   426: aload_0
      //   427: iload_1
      //   428: putfield p0 : I
      //   431: aload_0
      //   432: getfield B : I
      //   435: istore_1
      //   436: iload_1
      //   437: ldc -2147483648
      //   439: if_icmpeq -> 447
      //   442: aload_0
      //   443: iload_1
      //   444: putfield q0 : I
      //   447: aload_0
      //   448: getfield u : I
      //   451: iconst_m1
      //   452: if_icmpne -> 615
      //   455: aload_0
      //   456: getfield v : I
      //   459: iconst_m1
      //   460: if_icmpne -> 615
      //   463: aload_0
      //   464: getfield t : I
      //   467: iconst_m1
      //   468: if_icmpne -> 615
      //   471: aload_0
      //   472: getfield s : I
      //   475: iconst_m1
      //   476: if_icmpne -> 615
      //   479: aload_0
      //   480: getfield g : I
      //   483: istore_1
      //   484: iload_1
      //   485: iconst_m1
      //   486: if_icmpeq -> 515
      //   489: aload_0
      //   490: iload_1
      //   491: putfield n0 : I
      //   494: aload_0
      //   495: getfield rightMargin : I
      //   498: ifgt -> 548
      //   501: iload #6
      //   503: ifle -> 548
      //   506: aload_0
      //   507: iload #6
      //   509: putfield rightMargin : I
      //   512: goto -> 548
      //   515: aload_0
      //   516: getfield h : I
      //   519: istore_1
      //   520: iload_1
      //   521: iconst_m1
      //   522: if_icmpeq -> 548
      //   525: aload_0
      //   526: iload_1
      //   527: putfield o0 : I
      //   530: aload_0
      //   531: getfield rightMargin : I
      //   534: ifgt -> 548
      //   537: iload #6
      //   539: ifle -> 548
      //   542: aload_0
      //   543: iload #6
      //   545: putfield rightMargin : I
      //   548: aload_0
      //   549: getfield e : I
      //   552: istore_1
      //   553: iload_1
      //   554: iconst_m1
      //   555: if_icmpeq -> 582
      //   558: aload_0
      //   559: iload_1
      //   560: putfield l0 : I
      //   563: aload_0
      //   564: getfield leftMargin : I
      //   567: ifgt -> 615
      //   570: iload #5
      //   572: ifle -> 615
      //   575: aload_0
      //   576: iload #5
      //   578: putfield leftMargin : I
      //   581: return
      //   582: aload_0
      //   583: getfield f : I
      //   586: istore_1
      //   587: iload_1
      //   588: iconst_m1
      //   589: if_icmpeq -> 615
      //   592: aload_0
      //   593: iload_1
      //   594: putfield m0 : I
      //   597: aload_0
      //   598: getfield leftMargin : I
      //   601: ifgt -> 615
      //   604: iload #5
      //   606: ifle -> 615
      //   609: aload_0
      //   610: iload #5
      //   612: putfield leftMargin : I
      //   615: return
    }
    
    private static class a {
      public static final SparseIntArray a;
      
      static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        a = sparseIntArray;
        sparseIntArray.append(k.s2, 64);
        sparseIntArray.append(k.V1, 65);
        sparseIntArray.append(k.e2, 8);
        sparseIntArray.append(k.f2, 9);
        sparseIntArray.append(k.h2, 10);
        sparseIntArray.append(k.i2, 11);
        sparseIntArray.append(k.o2, 12);
        sparseIntArray.append(k.n2, 13);
        sparseIntArray.append(k.L1, 14);
        sparseIntArray.append(k.K1, 15);
        sparseIntArray.append(k.G1, 16);
        sparseIntArray.append(k.I1, 52);
        sparseIntArray.append(k.H1, 53);
        sparseIntArray.append(k.M1, 2);
        sparseIntArray.append(k.O1, 3);
        sparseIntArray.append(k.N1, 4);
        sparseIntArray.append(k.x2, 49);
        sparseIntArray.append(k.y2, 50);
        sparseIntArray.append(k.S1, 5);
        sparseIntArray.append(k.T1, 6);
        sparseIntArray.append(k.U1, 7);
        sparseIntArray.append(k.B1, 67);
        sparseIntArray.append(k.o1, 1);
        sparseIntArray.append(k.j2, 17);
        sparseIntArray.append(k.k2, 18);
        sparseIntArray.append(k.R1, 19);
        sparseIntArray.append(k.Q1, 20);
        sparseIntArray.append(k.C2, 21);
        sparseIntArray.append(k.F2, 22);
        sparseIntArray.append(k.D2, 23);
        sparseIntArray.append(k.A2, 24);
        sparseIntArray.append(k.E2, 25);
        sparseIntArray.append(k.B2, 26);
        sparseIntArray.append(k.z2, 55);
        sparseIntArray.append(k.G2, 54);
        sparseIntArray.append(k.a2, 29);
        sparseIntArray.append(k.p2, 30);
        sparseIntArray.append(k.P1, 44);
        sparseIntArray.append(k.c2, 45);
        sparseIntArray.append(k.r2, 46);
        sparseIntArray.append(k.b2, 47);
        sparseIntArray.append(k.q2, 48);
        sparseIntArray.append(k.E1, 27);
        sparseIntArray.append(k.D1, 28);
        sparseIntArray.append(k.t2, 31);
        sparseIntArray.append(k.W1, 32);
        sparseIntArray.append(k.v2, 33);
        sparseIntArray.append(k.u2, 34);
        sparseIntArray.append(k.w2, 35);
        sparseIntArray.append(k.Y1, 36);
        sparseIntArray.append(k.X1, 37);
        sparseIntArray.append(k.Z1, 38);
        sparseIntArray.append(k.d2, 39);
        sparseIntArray.append(k.m2, 40);
        sparseIntArray.append(k.g2, 41);
        sparseIntArray.append(k.J1, 42);
        sparseIntArray.append(k.F1, 43);
        sparseIntArray.append(k.l2, 51);
        sparseIntArray.append(k.I2, 66);
      }
    }
  }
  
  private static class a {
    public static final SparseIntArray a;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      a = sparseIntArray;
      sparseIntArray.append(k.s2, 64);
      sparseIntArray.append(k.V1, 65);
      sparseIntArray.append(k.e2, 8);
      sparseIntArray.append(k.f2, 9);
      sparseIntArray.append(k.h2, 10);
      sparseIntArray.append(k.i2, 11);
      sparseIntArray.append(k.o2, 12);
      sparseIntArray.append(k.n2, 13);
      sparseIntArray.append(k.L1, 14);
      sparseIntArray.append(k.K1, 15);
      sparseIntArray.append(k.G1, 16);
      sparseIntArray.append(k.I1, 52);
      sparseIntArray.append(k.H1, 53);
      sparseIntArray.append(k.M1, 2);
      sparseIntArray.append(k.O1, 3);
      sparseIntArray.append(k.N1, 4);
      sparseIntArray.append(k.x2, 49);
      sparseIntArray.append(k.y2, 50);
      sparseIntArray.append(k.S1, 5);
      sparseIntArray.append(k.T1, 6);
      sparseIntArray.append(k.U1, 7);
      sparseIntArray.append(k.B1, 67);
      sparseIntArray.append(k.o1, 1);
      sparseIntArray.append(k.j2, 17);
      sparseIntArray.append(k.k2, 18);
      sparseIntArray.append(k.R1, 19);
      sparseIntArray.append(k.Q1, 20);
      sparseIntArray.append(k.C2, 21);
      sparseIntArray.append(k.F2, 22);
      sparseIntArray.append(k.D2, 23);
      sparseIntArray.append(k.A2, 24);
      sparseIntArray.append(k.E2, 25);
      sparseIntArray.append(k.B2, 26);
      sparseIntArray.append(k.z2, 55);
      sparseIntArray.append(k.G2, 54);
      sparseIntArray.append(k.a2, 29);
      sparseIntArray.append(k.p2, 30);
      sparseIntArray.append(k.P1, 44);
      sparseIntArray.append(k.c2, 45);
      sparseIntArray.append(k.r2, 46);
      sparseIntArray.append(k.b2, 47);
      sparseIntArray.append(k.q2, 48);
      sparseIntArray.append(k.E1, 27);
      sparseIntArray.append(k.D1, 28);
      sparseIntArray.append(k.t2, 31);
      sparseIntArray.append(k.W1, 32);
      sparseIntArray.append(k.v2, 33);
      sparseIntArray.append(k.u2, 34);
      sparseIntArray.append(k.w2, 35);
      sparseIntArray.append(k.Y1, 36);
      sparseIntArray.append(k.X1, 37);
      sparseIntArray.append(k.Z1, 38);
      sparseIntArray.append(k.d2, 39);
      sparseIntArray.append(k.m2, 40);
      sparseIntArray.append(k.g2, 41);
      sparseIntArray.append(k.J1, 42);
      sparseIntArray.append(k.F1, 43);
      sparseIntArray.append(k.l2, 51);
      sparseIntArray.append(k.I2, 66);
    }
  }
  
  class c implements v.b.b {
    ConstraintLayout a;
    
    int b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    int g;
    
    public c(ConstraintLayout this$0, ConstraintLayout param1ConstraintLayout1) {
      this.a = param1ConstraintLayout1;
    }
    
    private boolean d(int param1Int1, int param1Int2, int param1Int3) {
      if (param1Int1 == param1Int2)
        return true; 
      int i = View.MeasureSpec.getMode(param1Int1);
      View.MeasureSpec.getSize(param1Int1);
      param1Int1 = View.MeasureSpec.getMode(param1Int2);
      param1Int2 = View.MeasureSpec.getSize(param1Int2);
      return (param1Int1 == 1073741824 && (i == Integer.MIN_VALUE || i == 0) && param1Int3 == param1Int2);
    }
    
    public final void a() {
      int j = this.a.getChildCount();
      boolean bool = false;
      int i;
      for (i = 0; i < j; i++) {
        View view = this.a.getChildAt(i);
        if (view instanceof i)
          ((i)view).a(this.a); 
      } 
      j = ConstraintLayout.b(this.a).size();
      if (j > 0)
        for (i = bool; i < j; i++)
          ((c)ConstraintLayout.b(this.a).get(i)).p(this.a);  
    }
    
    public final void b(e param1e, v.b.a param1a) {
      // Byte code:
      //   0: aload_1
      //   1: ifnonnull -> 5
      //   4: return
      //   5: aload_1
      //   6: invokevirtual T : ()I
      //   9: bipush #8
      //   11: if_icmpne -> 37
      //   14: aload_1
      //   15: invokevirtual h0 : ()Z
      //   18: ifne -> 37
      //   21: aload_2
      //   22: iconst_0
      //   23: putfield e : I
      //   26: aload_2
      //   27: iconst_0
      //   28: putfield f : I
      //   31: aload_2
      //   32: iconst_0
      //   33: putfield g : I
      //   36: return
      //   37: aload_1
      //   38: invokevirtual I : ()Lu/e;
      //   41: ifnonnull -> 45
      //   44: return
      //   45: aload_2
      //   46: getfield a : Lu/e$b;
      //   49: astore #20
      //   51: aload_2
      //   52: getfield b : Lu/e$b;
      //   55: astore #21
      //   57: aload_2
      //   58: getfield c : I
      //   61: istore #4
      //   63: aload_2
      //   64: getfield d : I
      //   67: istore #7
      //   69: aload_0
      //   70: getfield b : I
      //   73: aload_0
      //   74: getfield c : I
      //   77: iadd
      //   78: istore #8
      //   80: aload_0
      //   81: getfield d : I
      //   84: istore #5
      //   86: aload_1
      //   87: invokevirtual q : ()Ljava/lang/Object;
      //   90: checkcast android/view/View
      //   93: astore #19
      //   95: getstatic androidx/constraintlayout/widget/ConstraintLayout$a.a : [I
      //   98: astore #22
      //   100: aload #22
      //   102: aload #20
      //   104: invokevirtual ordinal : ()I
      //   107: iaload
      //   108: istore #6
      //   110: iload #6
      //   112: iconst_1
      //   113: if_icmpeq -> 328
      //   116: iload #6
      //   118: iconst_2
      //   119: if_icmpeq -> 312
      //   122: iload #6
      //   124: iconst_3
      //   125: if_icmpeq -> 292
      //   128: iload #6
      //   130: iconst_4
      //   131: if_icmpeq -> 140
      //   134: iconst_0
      //   135: istore #4
      //   137: goto -> 337
      //   140: aload_0
      //   141: getfield f : I
      //   144: iload #5
      //   146: bipush #-2
      //   148: invokestatic getChildMeasureSpec : (III)I
      //   151: istore #6
      //   153: aload_1
      //   154: getfield w : I
      //   157: iconst_1
      //   158: if_icmpne -> 167
      //   161: iconst_1
      //   162: istore #5
      //   164: goto -> 170
      //   167: iconst_0
      //   168: istore #5
      //   170: aload_2
      //   171: getfield j : I
      //   174: istore #9
      //   176: iload #9
      //   178: getstatic v/b$a.l : I
      //   181: if_icmpeq -> 196
      //   184: iload #6
      //   186: istore #4
      //   188: iload #9
      //   190: getstatic v/b$a.m : I
      //   193: if_icmpne -> 337
      //   196: aload #19
      //   198: invokevirtual getMeasuredHeight : ()I
      //   201: aload_1
      //   202: invokevirtual v : ()I
      //   205: if_icmpne -> 214
      //   208: iconst_1
      //   209: istore #4
      //   211: goto -> 217
      //   214: iconst_0
      //   215: istore #4
      //   217: aload_2
      //   218: getfield j : I
      //   221: getstatic v/b$a.m : I
      //   224: if_icmpeq -> 266
      //   227: iload #5
      //   229: ifeq -> 266
      //   232: iload #5
      //   234: ifeq -> 242
      //   237: iload #4
      //   239: ifne -> 266
      //   242: aload #19
      //   244: instanceof androidx/constraintlayout/widget/i
      //   247: ifne -> 266
      //   250: aload_1
      //   251: invokevirtual l0 : ()Z
      //   254: ifeq -> 260
      //   257: goto -> 266
      //   260: iconst_0
      //   261: istore #5
      //   263: goto -> 269
      //   266: iconst_1
      //   267: istore #5
      //   269: iload #6
      //   271: istore #4
      //   273: iload #5
      //   275: ifeq -> 337
      //   278: aload_1
      //   279: invokevirtual U : ()I
      //   282: ldc 1073741824
      //   284: invokestatic makeMeasureSpec : (II)I
      //   287: istore #4
      //   289: goto -> 337
      //   292: aload_0
      //   293: getfield f : I
      //   296: iload #5
      //   298: aload_1
      //   299: invokevirtual z : ()I
      //   302: iadd
      //   303: iconst_m1
      //   304: invokestatic getChildMeasureSpec : (III)I
      //   307: istore #4
      //   309: goto -> 337
      //   312: aload_0
      //   313: getfield f : I
      //   316: iload #5
      //   318: bipush #-2
      //   320: invokestatic getChildMeasureSpec : (III)I
      //   323: istore #4
      //   325: goto -> 337
      //   328: iload #4
      //   330: ldc 1073741824
      //   332: invokestatic makeMeasureSpec : (II)I
      //   335: istore #4
      //   337: aload #22
      //   339: aload #21
      //   341: invokevirtual ordinal : ()I
      //   344: iaload
      //   345: istore #5
      //   347: iload #5
      //   349: iconst_1
      //   350: if_icmpeq -> 565
      //   353: iload #5
      //   355: iconst_2
      //   356: if_icmpeq -> 549
      //   359: iload #5
      //   361: iconst_3
      //   362: if_icmpeq -> 529
      //   365: iload #5
      //   367: iconst_4
      //   368: if_icmpeq -> 377
      //   371: iconst_0
      //   372: istore #5
      //   374: goto -> 574
      //   377: aload_0
      //   378: getfield g : I
      //   381: iload #8
      //   383: bipush #-2
      //   385: invokestatic getChildMeasureSpec : (III)I
      //   388: istore #7
      //   390: aload_1
      //   391: getfield x : I
      //   394: iconst_1
      //   395: if_icmpne -> 404
      //   398: iconst_1
      //   399: istore #6
      //   401: goto -> 407
      //   404: iconst_0
      //   405: istore #6
      //   407: aload_2
      //   408: getfield j : I
      //   411: istore #8
      //   413: iload #8
      //   415: getstatic v/b$a.l : I
      //   418: if_icmpeq -> 433
      //   421: iload #7
      //   423: istore #5
      //   425: iload #8
      //   427: getstatic v/b$a.m : I
      //   430: if_icmpne -> 574
      //   433: aload #19
      //   435: invokevirtual getMeasuredWidth : ()I
      //   438: aload_1
      //   439: invokevirtual U : ()I
      //   442: if_icmpne -> 451
      //   445: iconst_1
      //   446: istore #5
      //   448: goto -> 454
      //   451: iconst_0
      //   452: istore #5
      //   454: aload_2
      //   455: getfield j : I
      //   458: getstatic v/b$a.m : I
      //   461: if_icmpeq -> 503
      //   464: iload #6
      //   466: ifeq -> 503
      //   469: iload #6
      //   471: ifeq -> 479
      //   474: iload #5
      //   476: ifne -> 503
      //   479: aload #19
      //   481: instanceof androidx/constraintlayout/widget/i
      //   484: ifne -> 503
      //   487: aload_1
      //   488: invokevirtual m0 : ()Z
      //   491: ifeq -> 497
      //   494: goto -> 503
      //   497: iconst_0
      //   498: istore #6
      //   500: goto -> 506
      //   503: iconst_1
      //   504: istore #6
      //   506: iload #7
      //   508: istore #5
      //   510: iload #6
      //   512: ifeq -> 574
      //   515: aload_1
      //   516: invokevirtual v : ()I
      //   519: ldc 1073741824
      //   521: invokestatic makeMeasureSpec : (II)I
      //   524: istore #5
      //   526: goto -> 574
      //   529: aload_0
      //   530: getfield g : I
      //   533: iload #8
      //   535: aload_1
      //   536: invokevirtual S : ()I
      //   539: iadd
      //   540: iconst_m1
      //   541: invokestatic getChildMeasureSpec : (III)I
      //   544: istore #5
      //   546: goto -> 574
      //   549: aload_0
      //   550: getfield g : I
      //   553: iload #8
      //   555: bipush #-2
      //   557: invokestatic getChildMeasureSpec : (III)I
      //   560: istore #5
      //   562: goto -> 574
      //   565: iload #7
      //   567: ldc 1073741824
      //   569: invokestatic makeMeasureSpec : (II)I
      //   572: istore #5
      //   574: aload_1
      //   575: invokevirtual I : ()Lu/e;
      //   578: checkcast u/f
      //   581: astore #22
      //   583: aload #22
      //   585: ifnull -> 746
      //   588: aload_0
      //   589: getfield h : Landroidx/constraintlayout/widget/ConstraintLayout;
      //   592: invokestatic a : (Landroidx/constraintlayout/widget/ConstraintLayout;)I
      //   595: sipush #256
      //   598: invokestatic b : (II)Z
      //   601: ifeq -> 746
      //   604: aload #19
      //   606: invokevirtual getMeasuredWidth : ()I
      //   609: aload_1
      //   610: invokevirtual U : ()I
      //   613: if_icmpne -> 746
      //   616: aload #19
      //   618: invokevirtual getMeasuredWidth : ()I
      //   621: aload #22
      //   623: invokevirtual U : ()I
      //   626: if_icmpge -> 746
      //   629: aload #19
      //   631: invokevirtual getMeasuredHeight : ()I
      //   634: aload_1
      //   635: invokevirtual v : ()I
      //   638: if_icmpne -> 746
      //   641: aload #19
      //   643: invokevirtual getMeasuredHeight : ()I
      //   646: aload #22
      //   648: invokevirtual v : ()I
      //   651: if_icmpge -> 746
      //   654: aload #19
      //   656: invokevirtual getBaseline : ()I
      //   659: aload_1
      //   660: invokevirtual n : ()I
      //   663: if_icmpne -> 746
      //   666: aload_1
      //   667: invokevirtual k0 : ()Z
      //   670: ifne -> 746
      //   673: aload_0
      //   674: aload_1
      //   675: invokevirtual A : ()I
      //   678: iload #4
      //   680: aload_1
      //   681: invokevirtual U : ()I
      //   684: invokespecial d : (III)Z
      //   687: ifeq -> 713
      //   690: aload_0
      //   691: aload_1
      //   692: invokevirtual B : ()I
      //   695: iload #5
      //   697: aload_1
      //   698: invokevirtual v : ()I
      //   701: invokespecial d : (III)Z
      //   704: ifeq -> 713
      //   707: iconst_1
      //   708: istore #6
      //   710: goto -> 716
      //   713: iconst_0
      //   714: istore #6
      //   716: iload #6
      //   718: ifeq -> 746
      //   721: aload_2
      //   722: aload_1
      //   723: invokevirtual U : ()I
      //   726: putfield e : I
      //   729: aload_2
      //   730: aload_1
      //   731: invokevirtual v : ()I
      //   734: putfield f : I
      //   737: aload_2
      //   738: aload_1
      //   739: invokevirtual n : ()I
      //   742: putfield g : I
      //   745: return
      //   746: getstatic u/e$b.d : Lu/e$b;
      //   749: astore #22
      //   751: aload #20
      //   753: aload #22
      //   755: if_acmpne -> 764
      //   758: iconst_1
      //   759: istore #6
      //   761: goto -> 767
      //   764: iconst_0
      //   765: istore #6
      //   767: aload #21
      //   769: aload #22
      //   771: if_acmpne -> 780
      //   774: iconst_1
      //   775: istore #7
      //   777: goto -> 783
      //   780: iconst_0
      //   781: istore #7
      //   783: getstatic u/e$b.e : Lu/e$b;
      //   786: astore #22
      //   788: aload #21
      //   790: aload #22
      //   792: if_acmpeq -> 812
      //   795: aload #21
      //   797: getstatic u/e$b.b : Lu/e$b;
      //   800: if_acmpne -> 806
      //   803: goto -> 812
      //   806: iconst_0
      //   807: istore #10
      //   809: goto -> 815
      //   812: iconst_1
      //   813: istore #10
      //   815: aload #20
      //   817: aload #22
      //   819: if_acmpeq -> 839
      //   822: aload #20
      //   824: getstatic u/e$b.b : Lu/e$b;
      //   827: if_acmpne -> 833
      //   830: goto -> 839
      //   833: iconst_0
      //   834: istore #11
      //   836: goto -> 842
      //   839: iconst_1
      //   840: istore #11
      //   842: iload #6
      //   844: ifeq -> 862
      //   847: aload_1
      //   848: getfield d0 : F
      //   851: fconst_0
      //   852: fcmpl
      //   853: ifle -> 862
      //   856: iconst_1
      //   857: istore #12
      //   859: goto -> 865
      //   862: iconst_0
      //   863: istore #12
      //   865: iload #7
      //   867: ifeq -> 885
      //   870: aload_1
      //   871: getfield d0 : F
      //   874: fconst_0
      //   875: fcmpl
      //   876: ifle -> 885
      //   879: iconst_1
      //   880: istore #13
      //   882: goto -> 888
      //   885: iconst_0
      //   886: istore #13
      //   888: aload #19
      //   890: ifnonnull -> 894
      //   893: return
      //   894: aload #19
      //   896: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
      //   899: checkcast androidx/constraintlayout/widget/ConstraintLayout$b
      //   902: astore #20
      //   904: aload_2
      //   905: getfield j : I
      //   908: istore #8
      //   910: iload #8
      //   912: getstatic v/b$a.l : I
      //   915: if_icmpeq -> 965
      //   918: iload #8
      //   920: getstatic v/b$a.m : I
      //   923: if_icmpeq -> 965
      //   926: iload #6
      //   928: ifeq -> 965
      //   931: aload_1
      //   932: getfield w : I
      //   935: ifne -> 965
      //   938: iload #7
      //   940: ifeq -> 965
      //   943: aload_1
      //   944: getfield x : I
      //   947: ifeq -> 953
      //   950: goto -> 965
      //   953: iconst_0
      //   954: istore #6
      //   956: iconst_0
      //   957: istore #9
      //   959: iconst_0
      //   960: istore #10
      //   962: goto -> 1352
      //   965: aload #19
      //   967: instanceof androidx/constraintlayout/widget/m
      //   970: ifeq -> 1003
      //   973: aload_1
      //   974: instanceof u/k
      //   977: ifeq -> 1003
      //   980: aload_1
      //   981: checkcast u/k
      //   984: astore #21
      //   986: aload #19
      //   988: checkcast androidx/constraintlayout/widget/m
      //   991: aload #21
      //   993: iload #4
      //   995: iload #5
      //   997: invokevirtual t : (Lu/k;II)V
      //   1000: goto -> 1012
      //   1003: aload #19
      //   1005: iload #4
      //   1007: iload #5
      //   1009: invokevirtual measure : (II)V
      //   1012: aload_1
      //   1013: iload #4
      //   1015: iload #5
      //   1017: invokevirtual S0 : (II)V
      //   1020: aload #19
      //   1022: invokevirtual getMeasuredWidth : ()I
      //   1025: istore #15
      //   1027: aload #19
      //   1029: invokevirtual getMeasuredHeight : ()I
      //   1032: istore #14
      //   1034: aload #19
      //   1036: invokevirtual getBaseline : ()I
      //   1039: istore #16
      //   1041: aload_1
      //   1042: getfield z : I
      //   1045: istore #6
      //   1047: iload #6
      //   1049: ifle -> 1064
      //   1052: iload #6
      //   1054: iload #15
      //   1056: invokestatic max : (II)I
      //   1059: istore #7
      //   1061: goto -> 1068
      //   1064: iload #15
      //   1066: istore #7
      //   1068: aload_1
      //   1069: getfield A : I
      //   1072: istore #8
      //   1074: iload #7
      //   1076: istore #6
      //   1078: iload #8
      //   1080: ifle -> 1092
      //   1083: iload #8
      //   1085: iload #7
      //   1087: invokestatic min : (II)I
      //   1090: istore #6
      //   1092: aload_1
      //   1093: getfield C : I
      //   1096: istore #7
      //   1098: iload #7
      //   1100: ifle -> 1115
      //   1103: iload #7
      //   1105: iload #14
      //   1107: invokestatic max : (II)I
      //   1110: istore #7
      //   1112: goto -> 1119
      //   1115: iload #14
      //   1117: istore #7
      //   1119: aload_1
      //   1120: getfield D : I
      //   1123: istore #8
      //   1125: iload #7
      //   1127: istore #9
      //   1129: iload #8
      //   1131: ifle -> 1143
      //   1134: iload #8
      //   1136: iload #7
      //   1138: invokestatic min : (II)I
      //   1141: istore #9
      //   1143: iload #9
      //   1145: istore #7
      //   1147: iload #6
      //   1149: istore #8
      //   1151: aload_0
      //   1152: getfield h : Landroidx/constraintlayout/widget/ConstraintLayout;
      //   1155: invokestatic a : (Landroidx/constraintlayout/widget/ConstraintLayout;)I
      //   1158: iconst_1
      //   1159: invokestatic b : (II)Z
      //   1162: ifne -> 1244
      //   1165: iload #12
      //   1167: ifeq -> 1198
      //   1170: iload #10
      //   1172: ifeq -> 1198
      //   1175: aload_1
      //   1176: getfield d0 : F
      //   1179: fstore_3
      //   1180: iload #9
      //   1182: i2f
      //   1183: fload_3
      //   1184: fmul
      //   1185: ldc 0.5
      //   1187: fadd
      //   1188: f2i
      //   1189: istore #8
      //   1191: iload #9
      //   1193: istore #7
      //   1195: goto -> 1244
      //   1198: iload #9
      //   1200: istore #7
      //   1202: iload #6
      //   1204: istore #8
      //   1206: iload #13
      //   1208: ifeq -> 1244
      //   1211: iload #9
      //   1213: istore #7
      //   1215: iload #6
      //   1217: istore #8
      //   1219: iload #11
      //   1221: ifeq -> 1244
      //   1224: aload_1
      //   1225: getfield d0 : F
      //   1228: fstore_3
      //   1229: iload #6
      //   1231: i2f
      //   1232: fload_3
      //   1233: fdiv
      //   1234: ldc 0.5
      //   1236: fadd
      //   1237: f2i
      //   1238: istore #7
      //   1240: iload #6
      //   1242: istore #8
      //   1244: iload #15
      //   1246: iload #8
      //   1248: if_icmpne -> 1276
      //   1251: iload #7
      //   1253: istore #6
      //   1255: iload #16
      //   1257: istore #9
      //   1259: iload #8
      //   1261: istore #10
      //   1263: iload #14
      //   1265: iload #7
      //   1267: if_icmpeq -> 1273
      //   1270: goto -> 1276
      //   1273: goto -> 1352
      //   1276: iload #15
      //   1278: iload #8
      //   1280: if_icmpeq -> 1295
      //   1283: iload #8
      //   1285: ldc 1073741824
      //   1287: invokestatic makeMeasureSpec : (II)I
      //   1290: istore #4
      //   1292: goto -> 1295
      //   1295: iload #14
      //   1297: iload #7
      //   1299: if_icmpeq -> 1311
      //   1302: iload #7
      //   1304: ldc 1073741824
      //   1306: invokestatic makeMeasureSpec : (II)I
      //   1309: istore #5
      //   1311: aload #19
      //   1313: iload #4
      //   1315: iload #5
      //   1317: invokevirtual measure : (II)V
      //   1320: aload_1
      //   1321: iload #4
      //   1323: iload #5
      //   1325: invokevirtual S0 : (II)V
      //   1328: aload #19
      //   1330: invokevirtual getMeasuredWidth : ()I
      //   1333: istore #10
      //   1335: aload #19
      //   1337: invokevirtual getMeasuredHeight : ()I
      //   1340: istore #6
      //   1342: aload #19
      //   1344: invokevirtual getBaseline : ()I
      //   1347: istore #9
      //   1349: goto -> 1273
      //   1352: iload #9
      //   1354: iconst_m1
      //   1355: if_icmpeq -> 1364
      //   1358: iconst_1
      //   1359: istore #17
      //   1361: goto -> 1367
      //   1364: iconst_0
      //   1365: istore #17
      //   1367: iload #10
      //   1369: aload_2
      //   1370: getfield c : I
      //   1373: if_icmpne -> 1394
      //   1376: iload #6
      //   1378: aload_2
      //   1379: getfield d : I
      //   1382: if_icmpeq -> 1388
      //   1385: goto -> 1394
      //   1388: iconst_0
      //   1389: istore #18
      //   1391: goto -> 1397
      //   1394: iconst_1
      //   1395: istore #18
      //   1397: aload_2
      //   1398: iload #18
      //   1400: putfield i : Z
      //   1403: aload #20
      //   1405: getfield g0 : Z
      //   1408: ifeq -> 1414
      //   1411: iconst_1
      //   1412: istore #17
      //   1414: iload #17
      //   1416: ifeq -> 1439
      //   1419: iload #9
      //   1421: iconst_m1
      //   1422: if_icmpeq -> 1439
      //   1425: aload_1
      //   1426: invokevirtual n : ()I
      //   1429: iload #9
      //   1431: if_icmpeq -> 1439
      //   1434: aload_2
      //   1435: iconst_1
      //   1436: putfield i : Z
      //   1439: aload_2
      //   1440: iload #10
      //   1442: putfield e : I
      //   1445: aload_2
      //   1446: iload #6
      //   1448: putfield f : I
      //   1451: aload_2
      //   1452: iload #17
      //   1454: putfield h : Z
      //   1457: aload_2
      //   1458: iload #9
      //   1460: putfield g : I
      //   1463: return
    }
    
    public void c(int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
      this.b = param1Int3;
      this.c = param1Int4;
      this.d = param1Int5;
      this.e = param1Int6;
      this.f = param1Int1;
      this.g = param1Int2;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\constraintlayout\widget\ConstraintLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */