package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import android.view.View;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import org.xmlpull.v1.XmlPullParser;

public class b {
  private boolean a;
  
  String b;
  
  private b c;
  
  private int d;
  
  private float e;
  
  private String f;
  
  boolean g;
  
  private int h;
  
  public b(b paramb, Object paramObject) {
    this.a = false;
    this.b = paramb.b;
    this.c = paramb.c;
    f(paramObject);
  }
  
  public b(String paramString, b paramb, Object paramObject, boolean paramBoolean) {
    this.b = paramString;
    this.c = paramb;
    this.a = paramBoolean;
    f(paramObject);
  }
  
  public static HashMap<String, b> a(HashMap<String, b> paramHashMap, View paramView) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Class<?> clazz = paramView.getClass();
    for (String str : paramHashMap.keySet()) {
      b b1 = paramHashMap.get(str);
      try {
        if (str.equals("BackgroundColor")) {
          hashMap.put(str, new b(b1, Integer.valueOf(((ColorDrawable)paramView.getBackground()).getColor())));
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("getMap");
        stringBuilder.append(str);
        hashMap.put(str, new b(b1, clazz.getMethod(stringBuilder.toString(), new Class[0]).invoke(paramView, new Object[0])));
      } catch (NoSuchMethodException noSuchMethodException) {
        noSuchMethodException.printStackTrace();
      } catch (IllegalAccessException illegalAccessException) {
        illegalAccessException.printStackTrace();
      } catch (InvocationTargetException invocationTargetException) {
        invocationTargetException.printStackTrace();
      } 
    } 
    return (HashMap)hashMap;
  }
  
  public static void d(Context paramContext, XmlPullParser paramXmlPullParser, HashMap<String, b> paramHashMap) {
    Object object1;
    String str;
    TypedArray typedArray = paramContext.obtainStyledAttributes(Xml.asAttributeSet(paramXmlPullParser), k.y4);
    int j = typedArray.getIndexCount();
    XmlPullParser xmlPullParser = null;
    Object object3 = null;
    Object object2 = object3;
    int i = 0;
    boolean bool = false;
    while (i < j) {
      b b1;
      int k = typedArray.getIndex(i);
      if (k == k.z4) {
        str = typedArray.getString(k);
        String str2 = str;
        Object object5 = object3;
        Object object6 = object2;
        Object object4 = object1;
        if (str != null) {
          str2 = str;
          object5 = object3;
          object6 = object2;
          object4 = object1;
          if (str.length() > 0) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Character.toUpperCase(str.charAt(0)));
            stringBuilder.append(str.substring(1));
            String str3 = stringBuilder.toString();
            object5 = object3;
            object6 = object2;
            object4 = object1;
          } 
        } 
        continue;
      } 
      if (k == k.J4) {
        String str2 = typedArray.getString(k);
        boolean bool1 = true;
        Object object4 = object3;
        Object object5 = object2;
        continue;
      } 
      if (k == k.A4) {
        Boolean bool1 = Boolean.valueOf(typedArray.getBoolean(k, false));
        b b3 = b.g;
        String str2 = str;
        Object object4 = object1;
        continue;
      } 
      if (k == k.C4) {
        b1 = b.d;
        Integer integer = Integer.valueOf(typedArray.getColor(k, 0));
      } else if (k == k.B4) {
        b1 = b.e;
        Integer integer = Integer.valueOf(typedArray.getColor(k, 0));
      } else if (k == k.G4) {
        b1 = b.h;
        Float float_ = Float.valueOf(TypedValue.applyDimension(1, typedArray.getDimension(k, 0.0F), paramContext.getResources().getDisplayMetrics()));
      } else if (k == k.D4) {
        b1 = b.h;
        Float float_ = Float.valueOf(typedArray.getDimension(k, 0.0F));
      } else if (k == k.E4) {
        b1 = b.c;
        Float float_ = Float.valueOf(typedArray.getFloat(k, Float.NaN));
      } else if (k == k.F4) {
        b1 = b.b;
        Integer integer = Integer.valueOf(typedArray.getInteger(k, -1));
      } else if (k == k.I4) {
        b1 = b.f;
        String str2 = typedArray.getString(k);
      } else {
        String str2 = str;
        Object object5 = object3;
        Object object6 = object2;
        Object object4 = object1;
        if (k == k.H4) {
          b1 = b.i;
          int n = typedArray.getResourceId(k, -1);
          int m = n;
          if (n == -1)
            m = typedArray.getInt(k, -1); 
          object5 = Integer.valueOf(m);
        } else {
          continue;
        } 
      } 
      b b2 = b1;
      String str1 = str;
      Object object = object1;
      continue;
      i++;
      xmlPullParser = paramXmlPullParser;
      object3 = SYNTHETIC_LOCAL_VARIABLE_10;
      object2 = SYNTHETIC_LOCAL_VARIABLE_11;
      object1 = SYNTHETIC_LOCAL_VARIABLE_9;
    } 
    if (str != null && object3 != null)
      paramHashMap.put(str, new b(str, (b)object2, object3, object1)); 
    typedArray.recycle();
  }
  
  public static void e(View paramView, HashMap<String, b> paramHashMap) {
    Class<?> clazz = paramView.getClass();
    for (String str2 : paramHashMap.keySet()) {
      String str1;
      StringBuilder stringBuilder;
      b b1 = paramHashMap.get(str2);
      if (!b1.a) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("set");
        stringBuilder1.append(str2);
        str1 = stringBuilder1.toString();
      } else {
        str1 = str2;
      } 
      try {
        Method method;
        ColorDrawable colorDrawable;
        switch (a.a[b1.c.ordinal()]) {
          case 8:
            clazz.getMethod(str1, new Class[] { float.class }).invoke(paramView, new Object[] { Float.valueOf(b1.e) });
          case 7:
            clazz.getMethod(str1, new Class[] { float.class }).invoke(paramView, new Object[] { Float.valueOf(b1.e) });
          case 6:
            clazz.getMethod(str1, new Class[] { int.class }).invoke(paramView, new Object[] { Integer.valueOf(b1.d) });
          case 5:
            method = clazz.getMethod(str1, new Class[] { Drawable.class });
            colorDrawable = new ColorDrawable();
            colorDrawable.setColor(b1.h);
            method.invoke(paramView, new Object[] { colorDrawable });
          case 4:
            clazz.getMethod(str1, new Class[] { int.class }).invoke(paramView, new Object[] { Integer.valueOf(b1.h) });
          case 3:
            clazz.getMethod(str1, new Class[] { CharSequence.class }).invoke(paramView, new Object[] { b1.f });
          case 2:
            clazz.getMethod(str1, new Class[] { boolean.class }).invoke(paramView, new Object[] { Boolean.valueOf(b1.g) });
          case 1:
            clazz.getMethod(str1, new Class[] { int.class }).invoke(paramView, new Object[] { Integer.valueOf(b1.d) });
        } 
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.e("TransitionLayout", noSuchMethodException.getMessage());
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(" Custom Attribute \"");
        stringBuilder1.append(str2);
        stringBuilder1.append("\" not found on ");
        stringBuilder1.append(clazz.getName());
        Log.e("TransitionLayout", stringBuilder1.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append(clazz.getName());
        stringBuilder.append(" must have a method ");
        stringBuilder.append(str1);
        Log.e("TransitionLayout", stringBuilder.toString());
      } catch (IllegalAccessException illegalAccessException) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(" Custom Attribute \"");
        stringBuilder1.append((String)stringBuilder);
        stringBuilder1.append("\" not found on ");
        stringBuilder1.append(clazz.getName());
        Log.e("TransitionLayout", stringBuilder1.toString());
        illegalAccessException.printStackTrace();
      } catch (InvocationTargetException invocationTargetException) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(" Custom Attribute \"");
        stringBuilder1.append((String)stringBuilder);
        stringBuilder1.append("\" not found on ");
        stringBuilder1.append(clazz.getName());
        Log.e("TransitionLayout", stringBuilder1.toString());
        invocationTargetException.printStackTrace();
      } 
    } 
  }
  
  public String b() {
    return this.b;
  }
  
  public b c() {
    return this.c;
  }
  
  public void f(Object paramObject) {
    switch (a.a[this.c.ordinal()]) {
      default:
        return;
      case 8:
        this.e = ((Float)paramObject).floatValue();
        return;
      case 7:
        this.e = ((Float)paramObject).floatValue();
        return;
      case 4:
      case 5:
        this.h = ((Integer)paramObject).intValue();
        return;
      case 3:
        this.f = (String)paramObject;
        return;
      case 2:
        this.g = ((Boolean)paramObject).booleanValue();
        return;
      case 1:
      case 6:
        break;
    } 
    this.d = ((Integer)paramObject).intValue();
  }
  
  public enum b {
    b, c, d, e, f, g, h, i;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\constraintlayout\widget\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */