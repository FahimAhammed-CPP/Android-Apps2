package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import u.e;
import u.h;

public class a extends c {
  private int k;
  
  private int l;
  
  private u.a m;
  
  public a(Context paramContext) {
    super(paramContext);
    setVisibility(8);
  }
  
  private void t(e parame, int paramInt, boolean paramBoolean) {
    this.l = paramInt;
    if (paramBoolean) {
      paramInt = this.k;
      if (paramInt == 5) {
        this.l = 1;
      } else if (paramInt == 6) {
        this.l = 0;
      } 
    } else {
      paramInt = this.k;
      if (paramInt == 5) {
        this.l = 0;
      } else if (paramInt == 6) {
        this.l = 1;
      } 
    } 
    if (parame instanceof u.a)
      ((u.a)parame).x1(this.l); 
  }
  
  public boolean getAllowsGoneWidget() {
    return this.m.r1();
  }
  
  public int getMargin() {
    return this.m.t1();
  }
  
  public int getType() {
    return this.k;
  }
  
  protected void m(AttributeSet paramAttributeSet) {
    super.m(paramAttributeSet);
    this.m = new u.a();
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, k.n1);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == k.w1) {
          setType(typedArray.getInt(k, 0));
        } else if (k == k.v1) {
          this.m.w1(typedArray.getBoolean(k, true));
        } else if (k == k.x1) {
          k = typedArray.getDimensionPixelSize(k, 0);
          this.m.y1(k);
        } 
      } 
      typedArray.recycle();
    } 
    this.e = (h)this.m;
    s();
  }
  
  public void n(e parame, boolean paramBoolean) {
    t(parame, this.k, paramBoolean);
  }
  
  public void setAllowsGoneWidget(boolean paramBoolean) {
    this.m.w1(paramBoolean);
  }
  
  public void setDpMargin(int paramInt) {
    float f = (getResources().getDisplayMetrics()).density;
    paramInt = (int)(paramInt * f + 0.5F);
    this.m.y1(paramInt);
  }
  
  public void setMargin(int paramInt) {
    this.m.y1(paramInt);
  }
  
  public void setType(int paramInt) {
    this.k = paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\constraintlayout\widget\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */