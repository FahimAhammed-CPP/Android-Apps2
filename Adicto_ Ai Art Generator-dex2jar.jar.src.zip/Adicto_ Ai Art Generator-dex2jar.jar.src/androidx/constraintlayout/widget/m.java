package androidx.constraintlayout.widget;

import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewParent;
import u.k;

public abstract class m extends c {
  private boolean k;
  
  private boolean l;
  
  protected void i(ConstraintLayout paramConstraintLayout) {
    h(paramConstraintLayout);
  }
  
  protected void m(AttributeSet paramAttributeSet) {
    super.m(paramAttributeSet);
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, k.n1);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == k.p1) {
          this.k = true;
        } else if (k == k.u1) {
          this.l = true;
        } 
      } 
      typedArray.recycle();
    } 
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (this.k || this.l) {
      ViewParent viewParent = getParent();
      if (viewParent instanceof ConstraintLayout) {
        ConstraintLayout constraintLayout = (ConstraintLayout)viewParent;
        int j = getVisibility();
        float f = getElevation();
        for (int i = 0; i < this.c; i++) {
          View view = constraintLayout.h(this.b[i]);
          if (view != null) {
            if (this.k)
              view.setVisibility(j); 
            if (this.l && f > 0.0F)
              view.setTranslationZ(view.getTranslationZ() + f); 
          } 
        } 
      } 
    } 
  }
  
  public void setElevation(float paramFloat) {
    super.setElevation(paramFloat);
    g();
  }
  
  public void setVisibility(int paramInt) {
    super.setVisibility(paramInt);
    g();
  }
  
  public void t(k paramk, int paramInt1, int paramInt2) {}
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\constraintlayout\widget\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */