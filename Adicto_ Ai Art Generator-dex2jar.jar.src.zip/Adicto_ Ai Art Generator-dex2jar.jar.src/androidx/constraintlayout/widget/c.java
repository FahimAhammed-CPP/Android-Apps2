package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.util.Arrays;
import java.util.HashMap;
import u.e;
import u.h;

public abstract class c extends View {
  protected int[] b = new int[32];
  
  protected int c;
  
  protected Context d;
  
  protected h e;
  
  protected boolean f = false;
  
  protected String g;
  
  protected String h;
  
  private View[] i = null;
  
  protected HashMap<Integer, String> j = new HashMap<Integer, String>();
  
  public c(Context paramContext) {
    super(paramContext);
    this.d = paramContext;
    m(null);
  }
  
  private void d(String paramString) {
    if (paramString != null) {
      if (paramString.length() == 0)
        return; 
      if (this.d == null)
        return; 
      paramString = paramString.trim();
      if (getParent() instanceof ConstraintLayout)
        ConstraintLayout constraintLayout = (ConstraintLayout)getParent(); 
      int i = k(paramString);
      if (i != 0) {
        this.j.put(Integer.valueOf(i), paramString);
        e(i);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not find id of \"");
      stringBuilder.append(paramString);
      stringBuilder.append("\"");
      Log.w("ConstraintHelper", stringBuilder.toString());
    } 
  }
  
  private void e(int paramInt) {
    if (paramInt == getId())
      return; 
    int i = this.c;
    int[] arrayOfInt = this.b;
    if (i + 1 > arrayOfInt.length)
      this.b = Arrays.copyOf(arrayOfInt, arrayOfInt.length * 2); 
    arrayOfInt = this.b;
    i = this.c;
    arrayOfInt[i] = paramInt;
    this.c = i + 1;
  }
  
  private void f(String paramString) {
    if (paramString != null) {
      ConstraintLayout constraintLayout;
      if (paramString.length() == 0)
        return; 
      if (this.d == null)
        return; 
      String str = paramString.trim();
      paramString = null;
      if (getParent() instanceof ConstraintLayout)
        constraintLayout = (ConstraintLayout)getParent(); 
      if (constraintLayout == null) {
        Log.w("ConstraintHelper", "Parent not a ConstraintLayout");
        return;
      } 
      int j = constraintLayout.getChildCount();
      for (int i = 0; i < j; i++) {
        View view = constraintLayout.getChildAt(i);
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams instanceof ConstraintLayout.b && str.equals(((ConstraintLayout.b)layoutParams).c0))
          if (view.getId() == -1) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("to use ConstraintTag view ");
            stringBuilder.append(view.getClass().getSimpleName());
            stringBuilder.append(" must have an ID");
            Log.w("ConstraintHelper", stringBuilder.toString());
          } else {
            e(view.getId());
          }  
      } 
    } 
  }
  
  private int j(ConstraintLayout paramConstraintLayout, String paramString) {
    if (paramString != null) {
      if (paramConstraintLayout == null)
        return 0; 
      Resources resources = this.d.getResources();
      if (resources == null)
        return 0; 
      int j = paramConstraintLayout.getChildCount();
      int i = 0;
      while (true) {
        if (i < j) {
          View view = paramConstraintLayout.getChildAt(i);
          if (view.getId() != -1) {
            String str = null;
            try {
              String str1 = resources.getResourceEntryName(view.getId());
              str = str1;
            } catch (android.content.res.Resources.NotFoundException notFoundException) {}
            if (paramString.equals(str))
              return view.getId(); 
          } 
          i++;
          continue;
        } 
        return 0;
      } 
    } 
    return 0;
  }
  
  private int k(String paramString) {
    ConstraintLayout constraintLayout;
    if (getParent() instanceof ConstraintLayout) {
      constraintLayout = (ConstraintLayout)getParent();
    } else {
      constraintLayout = null;
    } 
    boolean bool = isInEditMode();
    int i = 0;
    int j = i;
    if (bool) {
      j = i;
      if (constraintLayout != null) {
        Object object = constraintLayout.f(0, paramString);
        j = i;
        if (object instanceof Integer)
          j = ((Integer)object).intValue(); 
      } 
    } 
    i = j;
    if (j == 0) {
      i = j;
      if (constraintLayout != null)
        i = j(constraintLayout, paramString); 
    } 
    j = i;
    if (i == 0)
      try {
        j = j.class.getField(paramString).getInt(null);
      } catch (Exception exception) {
        j = i;
      }  
    i = j;
    if (j == 0)
      i = this.d.getResources().getIdentifier(paramString, "id", this.d.getPackageName()); 
    return i;
  }
  
  protected void g() {
    ViewParent viewParent = getParent();
    if (viewParent != null && viewParent instanceof ConstraintLayout)
      h((ConstraintLayout)viewParent); 
  }
  
  public int[] getReferencedIds() {
    return Arrays.copyOf(this.b, this.c);
  }
  
  protected void h(ConstraintLayout paramConstraintLayout) {
    int j = getVisibility();
    float f = getElevation();
    for (int i = 0; i < this.c; i++) {
      View view = paramConstraintLayout.h(this.b[i]);
      if (view != null) {
        view.setVisibility(j);
        if (f > 0.0F)
          view.setTranslationZ(view.getTranslationZ() + f); 
      } 
    } 
  }
  
  protected void i(ConstraintLayout paramConstraintLayout) {}
  
  protected View[] l(ConstraintLayout paramConstraintLayout) {
    View[] arrayOfView = this.i;
    if (arrayOfView == null || arrayOfView.length != this.c)
      this.i = new View[this.c]; 
    for (int i = 0; i < this.c; i++) {
      int j = this.b[i];
      this.i[i] = paramConstraintLayout.h(j);
    } 
    return this.i;
  }
  
  protected void m(AttributeSet paramAttributeSet) {
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, k.n1);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == k.z1) {
          String str = typedArray.getString(k);
          this.g = str;
          setIds(str);
        } else if (k == k.A1) {
          String str = typedArray.getString(k);
          this.h = str;
          setReferenceTags(str);
        } 
      } 
      typedArray.recycle();
    } 
  }
  
  public void n(e parame, boolean paramBoolean) {}
  
  public void o(ConstraintLayout paramConstraintLayout) {}
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    String str = this.g;
    if (str != null)
      setIds(str); 
    str = this.h;
    if (str != null)
      setReferenceTags(str); 
  }
  
  public void onDraw(Canvas paramCanvas) {}
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.f) {
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    setMeasuredDimension(0, 0);
  }
  
  public void p(ConstraintLayout paramConstraintLayout) {}
  
  public void q(ConstraintLayout paramConstraintLayout) {}
  
  public void r(ConstraintLayout paramConstraintLayout) {
    if (isInEditMode())
      setIds(this.g); 
    h h1 = this.e;
    if (h1 == null)
      return; 
    h1.b();
    for (int i = 0; i < this.c; i++) {
      int j = this.b[i];
      View view2 = paramConstraintLayout.h(j);
      View view1 = view2;
      if (view2 == null) {
        String str = this.j.get(Integer.valueOf(j));
        j = j(paramConstraintLayout, str);
        view1 = view2;
        if (j != 0) {
          this.b[i] = j;
          this.j.put(Integer.valueOf(j), str);
          view1 = paramConstraintLayout.h(j);
        } 
      } 
      if (view1 != null)
        this.e.a(paramConstraintLayout.l(view1)); 
    } 
    this.e.c(paramConstraintLayout.d);
  }
  
  public void s() {
    if (this.e == null)
      return; 
    ViewGroup.LayoutParams layoutParams = getLayoutParams();
    if (layoutParams instanceof ConstraintLayout.b)
      ((ConstraintLayout.b)layoutParams).v0 = (e)this.e; 
  }
  
  protected void setIds(String paramString) {
    this.g = paramString;
    if (paramString == null)
      return; 
    int i = 0;
    this.c = 0;
    while (true) {
      int j = paramString.indexOf(',', i);
      if (j == -1) {
        d(paramString.substring(i));
        return;
      } 
      d(paramString.substring(i, j));
      i = j + 1;
    } 
  }
  
  protected void setReferenceTags(String paramString) {
    this.h = paramString;
    if (paramString == null)
      return; 
    int i = 0;
    this.c = 0;
    while (true) {
      int j = paramString.indexOf(',', i);
      if (j == -1) {
        f(paramString.substring(i));
        return;
      } 
      f(paramString.substring(i, j));
      i = j + 1;
    } 
  }
  
  public void setReferencedIds(int[] paramArrayOfint) {
    this.g = null;
    int i = 0;
    this.c = 0;
    while (i < paramArrayOfint.length) {
      e(paramArrayOfint[i]);
      i++;
    } 
  }
  
  public void setTag(int paramInt, Object paramObject) {
    super.setTag(paramInt, paramObject);
    if (paramObject == null && this.g == null)
      e(paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\constraintlayout\widget\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */