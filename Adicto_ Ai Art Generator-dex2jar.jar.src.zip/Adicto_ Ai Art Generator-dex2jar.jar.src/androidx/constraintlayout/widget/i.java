package androidx.constraintlayout.widget;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.view.View;
import u.e;

public class i extends View {
  private int b;
  
  private View c;
  
  private int d;
  
  public void a(ConstraintLayout paramConstraintLayout) {
    if (this.c == null)
      return; 
    ConstraintLayout.b b1 = (ConstraintLayout.b)getLayoutParams();
    ConstraintLayout.b b2 = (ConstraintLayout.b)this.c.getLayoutParams();
    b2.v0.g1(0);
    e.b b3 = b1.v0.y();
    e.b b4 = e.b.b;
    if (b3 != b4)
      b1.v0.h1(b2.v0.U()); 
    if (b1.v0.R() != b4)
      b1.v0.I0(b2.v0.v()); 
    b2.v0.g1(8);
  }
  
  public void b(ConstraintLayout paramConstraintLayout) {
    if (this.b == -1 && !isInEditMode())
      setVisibility(this.d); 
    View view = paramConstraintLayout.findViewById(this.b);
    this.c = view;
    if (view != null) {
      ((ConstraintLayout.b)view.getLayoutParams()).j0 = true;
      this.c.setVisibility(0);
      setVisibility(0);
    } 
  }
  
  public View getContent() {
    return this.c;
  }
  
  public int getEmptyVisibility() {
    return this.d;
  }
  
  public void onDraw(Canvas paramCanvas) {
    if (isInEditMode()) {
      paramCanvas.drawRGB(223, 223, 223);
      Paint paint = new Paint();
      paint.setARGB(255, 210, 210, 210);
      paint.setTextAlign(Paint.Align.CENTER);
      paint.setTypeface(Typeface.create(Typeface.DEFAULT, 0));
      Rect rect = new Rect();
      paramCanvas.getClipBounds(rect);
      paint.setTextSize(rect.height());
      int j = rect.height();
      int k = rect.width();
      paint.setTextAlign(Paint.Align.LEFT);
      paint.getTextBounds("?", 0, 1, rect);
      paramCanvas.drawText("?", k / 2.0F - rect.width() / 2.0F - rect.left, j / 2.0F + rect.height() / 2.0F - rect.bottom, paint);
    } 
  }
  
  public void setContentId(int paramInt) {
    if (this.b == paramInt)
      return; 
    View view = this.c;
    if (view != null) {
      view.setVisibility(0);
      ((ConstraintLayout.b)this.c.getLayoutParams()).j0 = false;
      this.c = null;
    } 
    this.b = paramInt;
    if (paramInt != -1) {
      view = ((View)getParent()).findViewById(paramInt);
      if (view != null)
        view.setVisibility(8); 
    } 
  }
  
  public void setEmptyVisibility(int paramInt) {
    this.d = paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\constraintlayout\widget\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */