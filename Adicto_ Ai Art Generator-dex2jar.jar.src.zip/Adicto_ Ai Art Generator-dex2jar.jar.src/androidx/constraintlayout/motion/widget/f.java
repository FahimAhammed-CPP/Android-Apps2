package androidx.constraintlayout.motion.widget;

class f implements Comparable<f> {
  int b;
  
  int c;
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\constraintlayout\motion\widget\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */