package androidx.constraintlayout.motion.widget;

import android.view.View;
import android.view.animation.Interpolator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import s.a;
import s.b;
import s.c;
import w.b;
import w.c;
import w.d;

public class g {
  boolean a;
  
  private k b;
  
  private k c;
  
  private f d;
  
  private f e;
  
  private a[] f;
  
  private a g;
  
  float h;
  
  float i;
  
  private int[] j;
  
  private double[] k;
  
  private double[] l;
  
  private String[] m;
  
  private float[] n;
  
  private ArrayList<k> o;
  
  private HashMap<String, d> p;
  
  private HashMap<String, c> q;
  
  private HashMap<String, b> r;
  
  private e[] s;
  
  private int t;
  
  private View u;
  
  private int v;
  
  private float w;
  
  private Interpolator x;
  
  private boolean y;
  
  private float a(float paramFloat, float[] paramArrayOffloat) {
    float f1;
    float f3 = 0.0F;
    float f4 = 1.0F;
    if (paramArrayOffloat != null) {
      paramArrayOffloat[0] = 1.0F;
      f1 = paramFloat;
    } else {
      float f5 = this.i;
      f1 = paramFloat;
      if (f5 != 1.0D) {
        float f7 = this.h;
        float f6 = paramFloat;
        if (paramFloat < f7)
          f6 = 0.0F; 
        f1 = f6;
        if (f6 > f7) {
          f1 = f6;
          if (f6 < 1.0D)
            f1 = Math.min((f6 - f7) * f5, 1.0F); 
        } 
      } 
    } 
    b b = this.b.b;
    paramFloat = Float.NaN;
    Iterator<k> iterator = this.o.iterator();
    float f2 = f3;
    while (iterator.hasNext()) {
      k k1 = iterator.next();
      b b1 = k1.b;
      if (b1 != null) {
        f3 = k1.d;
        if (f3 < f1) {
          b = b1;
          f2 = f3;
          continue;
        } 
        if (Float.isNaN(paramFloat))
          paramFloat = k1.d; 
      } 
    } 
    f3 = f1;
    if (b != null) {
      if (Float.isNaN(paramFloat))
        paramFloat = f4; 
      paramFloat -= f2;
      double d = ((f1 - f2) / paramFloat);
      paramFloat = (float)b.a(d) * paramFloat + f2;
      f3 = paramFloat;
      if (paramArrayOffloat != null) {
        paramArrayOffloat[0] = (float)b.b(d);
        f3 = paramFloat;
      } 
    } 
    return f3;
  }
  
  public void b(double paramDouble, float[] paramArrayOffloat1, float[] paramArrayOffloat2) {
    double[] arrayOfDouble1 = new double[4];
    double[] arrayOfDouble2 = new double[4];
    this.f[0].b(paramDouble, arrayOfDouble1);
    this.f[0].d(paramDouble, arrayOfDouble2);
    Arrays.fill(paramArrayOffloat2, 0.0F);
    this.b.b(paramDouble, this.j, arrayOfDouble1, paramArrayOffloat1, arrayOfDouble2, paramArrayOffloat2);
  }
  
  boolean c(View paramView, float paramFloat, long paramLong, c paramc) {
    // Byte code:
    //   0: aload_0
    //   1: fload_2
    //   2: aconst_null
    //   3: invokespecial a : (F[F)F
    //   6: fstore #8
    //   8: aload_0
    //   9: getfield v : I
    //   12: istore #16
    //   14: fload #8
    //   16: fstore_2
    //   17: iload #16
    //   19: getstatic androidx/constraintlayout/motion/widget/d.a : I
    //   22: if_icmpeq -> 127
    //   25: fconst_1
    //   26: iload #16
    //   28: i2f
    //   29: fdiv
    //   30: fstore #9
    //   32: fload #8
    //   34: fload #9
    //   36: fdiv
    //   37: f2d
    //   38: invokestatic floor : (D)D
    //   41: d2f
    //   42: fstore #10
    //   44: fload #8
    //   46: fload #9
    //   48: frem
    //   49: fload #9
    //   51: fdiv
    //   52: fstore #8
    //   54: fload #8
    //   56: fstore_2
    //   57: aload_0
    //   58: getfield w : F
    //   61: invokestatic isNaN : (F)Z
    //   64: ifne -> 77
    //   67: fload #8
    //   69: aload_0
    //   70: getfield w : F
    //   73: fadd
    //   74: fconst_1
    //   75: frem
    //   76: fstore_2
    //   77: aload_0
    //   78: getfield x : Landroid/view/animation/Interpolator;
    //   81: astore #22
    //   83: aload #22
    //   85: ifnull -> 100
    //   88: aload #22
    //   90: fload_2
    //   91: invokeinterface getInterpolation : (F)F
    //   96: fstore_2
    //   97: goto -> 116
    //   100: fload_2
    //   101: f2d
    //   102: ldc2_w 0.5
    //   105: dcmpl
    //   106: ifle -> 114
    //   109: fconst_1
    //   110: fstore_2
    //   111: goto -> 116
    //   114: fconst_0
    //   115: fstore_2
    //   116: fload_2
    //   117: fload #9
    //   119: fmul
    //   120: fload #10
    //   122: fload #9
    //   124: fmul
    //   125: fadd
    //   126: fstore_2
    //   127: aload_0
    //   128: getfield q : Ljava/util/HashMap;
    //   131: astore #22
    //   133: aload #22
    //   135: ifnull -> 178
    //   138: aload #22
    //   140: invokevirtual values : ()Ljava/util/Collection;
    //   143: invokeinterface iterator : ()Ljava/util/Iterator;
    //   148: astore #22
    //   150: aload #22
    //   152: invokeinterface hasNext : ()Z
    //   157: ifeq -> 178
    //   160: aload #22
    //   162: invokeinterface next : ()Ljava/lang/Object;
    //   167: checkcast w/c
    //   170: aload_1
    //   171: fload_2
    //   172: invokevirtual b : (Landroid/view/View;F)V
    //   175: goto -> 150
    //   178: aload_0
    //   179: getfield p : Ljava/util/HashMap;
    //   182: astore #22
    //   184: aload #22
    //   186: ifnull -> 268
    //   189: aload #22
    //   191: invokevirtual values : ()Ljava/util/Collection;
    //   194: invokeinterface iterator : ()Ljava/util/Iterator;
    //   199: astore #23
    //   201: aconst_null
    //   202: astore #22
    //   204: iconst_0
    //   205: istore #20
    //   207: aload #23
    //   209: invokeinterface hasNext : ()Z
    //   214: ifeq -> 265
    //   217: aload #23
    //   219: invokeinterface next : ()Ljava/lang/Object;
    //   224: checkcast w/d
    //   227: astore #24
    //   229: aload #24
    //   231: instanceof w/d$a
    //   234: ifeq -> 247
    //   237: aload #24
    //   239: checkcast w/d$a
    //   242: astore #22
    //   244: goto -> 207
    //   247: iload #20
    //   249: aload #24
    //   251: aload_1
    //   252: fload_2
    //   253: lload_3
    //   254: aload #5
    //   256: invokevirtual b : (Landroid/view/View;FJLs/c;)Z
    //   259: ior
    //   260: istore #20
    //   262: goto -> 207
    //   265: goto -> 274
    //   268: aconst_null
    //   269: astore #22
    //   271: iconst_0
    //   272: istore #20
    //   274: aload_0
    //   275: getfield f : [Ls/a;
    //   278: astore #23
    //   280: aload #23
    //   282: ifnull -> 864
    //   285: aload #23
    //   287: iconst_0
    //   288: aaload
    //   289: astore #23
    //   291: fload_2
    //   292: f2d
    //   293: dstore #6
    //   295: aload #23
    //   297: dload #6
    //   299: aload_0
    //   300: getfield k : [D
    //   303: invokevirtual b : (D[D)V
    //   306: aload_0
    //   307: getfield f : [Ls/a;
    //   310: iconst_0
    //   311: aaload
    //   312: dload #6
    //   314: aload_0
    //   315: getfield l : [D
    //   318: invokevirtual d : (D[D)V
    //   321: aload_0
    //   322: getfield g : Ls/a;
    //   325: astore #23
    //   327: aload #23
    //   329: ifnull -> 366
    //   332: aload_0
    //   333: getfield k : [D
    //   336: astore #24
    //   338: aload #24
    //   340: arraylength
    //   341: ifle -> 366
    //   344: aload #23
    //   346: dload #6
    //   348: aload #24
    //   350: invokevirtual b : (D[D)V
    //   353: aload_0
    //   354: getfield g : Ls/a;
    //   357: dload #6
    //   359: aload_0
    //   360: getfield l : [D
    //   363: invokevirtual d : (D[D)V
    //   366: aload_0
    //   367: getfield y : Z
    //   370: ifne -> 407
    //   373: aload_0
    //   374: getfield b : Landroidx/constraintlayout/motion/widget/k;
    //   377: fload_2
    //   378: aload_1
    //   379: aload_0
    //   380: getfield j : [I
    //   383: aload_0
    //   384: getfield k : [D
    //   387: aload_0
    //   388: getfield l : [D
    //   391: aconst_null
    //   392: aload_0
    //   393: getfield a : Z
    //   396: invokevirtual d : (FLandroid/view/View;[I[D[D[DZ)V
    //   399: aload_0
    //   400: iconst_0
    //   401: putfield a : Z
    //   404: goto -> 407
    //   407: aload_0
    //   408: getfield t : I
    //   411: getstatic androidx/constraintlayout/motion/widget/d.a : I
    //   414: if_icmpeq -> 547
    //   417: aload_0
    //   418: getfield u : Landroid/view/View;
    //   421: ifnonnull -> 442
    //   424: aload_0
    //   425: aload_1
    //   426: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   429: checkcast android/view/View
    //   432: aload_0
    //   433: getfield t : I
    //   436: invokevirtual findViewById : (I)Landroid/view/View;
    //   439: putfield u : Landroid/view/View;
    //   442: aload_0
    //   443: getfield u : Landroid/view/View;
    //   446: astore #23
    //   448: aload #23
    //   450: ifnull -> 547
    //   453: aload #23
    //   455: invokevirtual getTop : ()I
    //   458: aload_0
    //   459: getfield u : Landroid/view/View;
    //   462: invokevirtual getBottom : ()I
    //   465: iadd
    //   466: i2f
    //   467: fconst_2
    //   468: fdiv
    //   469: fstore #8
    //   471: aload_0
    //   472: getfield u : Landroid/view/View;
    //   475: invokevirtual getLeft : ()I
    //   478: aload_0
    //   479: getfield u : Landroid/view/View;
    //   482: invokevirtual getRight : ()I
    //   485: iadd
    //   486: i2f
    //   487: fconst_2
    //   488: fdiv
    //   489: fstore #9
    //   491: aload_1
    //   492: invokevirtual getRight : ()I
    //   495: aload_1
    //   496: invokevirtual getLeft : ()I
    //   499: isub
    //   500: ifle -> 547
    //   503: aload_1
    //   504: invokevirtual getBottom : ()I
    //   507: aload_1
    //   508: invokevirtual getTop : ()I
    //   511: isub
    //   512: ifle -> 547
    //   515: aload_1
    //   516: invokevirtual getLeft : ()I
    //   519: i2f
    //   520: fstore #10
    //   522: aload_1
    //   523: invokevirtual getTop : ()I
    //   526: i2f
    //   527: fstore #11
    //   529: aload_1
    //   530: fload #9
    //   532: fload #10
    //   534: fsub
    //   535: invokevirtual setPivotX : (F)V
    //   538: aload_1
    //   539: fload #8
    //   541: fload #11
    //   543: fsub
    //   544: invokevirtual setPivotY : (F)V
    //   547: aload_0
    //   548: getfield q : Ljava/util/HashMap;
    //   551: astore #23
    //   553: aload #23
    //   555: ifnull -> 634
    //   558: aload #23
    //   560: invokevirtual values : ()Ljava/util/Collection;
    //   563: invokeinterface iterator : ()Ljava/util/Iterator;
    //   568: astore #23
    //   570: aload #23
    //   572: invokeinterface hasNext : ()Z
    //   577: ifeq -> 634
    //   580: aload #23
    //   582: invokeinterface next : ()Ljava/lang/Object;
    //   587: checkcast s/e
    //   590: astore #24
    //   592: aload #24
    //   594: instanceof w/c$a
    //   597: ifeq -> 570
    //   600: aload_0
    //   601: getfield l : [D
    //   604: astore #25
    //   606: aload #25
    //   608: arraylength
    //   609: iconst_1
    //   610: if_icmple -> 570
    //   613: aload #24
    //   615: checkcast w/c$a
    //   618: aload_1
    //   619: fload_2
    //   620: aload #25
    //   622: iconst_0
    //   623: daload
    //   624: aload #25
    //   626: iconst_1
    //   627: daload
    //   628: invokevirtual c : (Landroid/view/View;FDD)V
    //   631: goto -> 570
    //   634: aload #22
    //   636: ifnull -> 671
    //   639: aload_0
    //   640: getfield l : [D
    //   643: astore #23
    //   645: iload #20
    //   647: aload #22
    //   649: aload_1
    //   650: aload #5
    //   652: fload_2
    //   653: lload_3
    //   654: aload #23
    //   656: iconst_0
    //   657: daload
    //   658: aload #23
    //   660: iconst_1
    //   661: daload
    //   662: invokevirtual c : (Landroid/view/View;Ls/c;FJDD)Z
    //   665: ior
    //   666: istore #20
    //   668: goto -> 671
    //   671: iconst_1
    //   672: istore #16
    //   674: aload_0
    //   675: getfield f : [Ls/a;
    //   678: astore #5
    //   680: iload #16
    //   682: aload #5
    //   684: arraylength
    //   685: if_icmpge -> 741
    //   688: aload #5
    //   690: iload #16
    //   692: aaload
    //   693: dload #6
    //   695: aload_0
    //   696: getfield n : [F
    //   699: invokevirtual c : (D[F)V
    //   702: aload_0
    //   703: getfield b : Landroidx/constraintlayout/motion/widget/k;
    //   706: getfield p : Ljava/util/LinkedHashMap;
    //   709: aload_0
    //   710: getfield m : [Ljava/lang/String;
    //   713: iload #16
    //   715: iconst_1
    //   716: isub
    //   717: aaload
    //   718: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   721: checkcast androidx/constraintlayout/widget/b
    //   724: aload_1
    //   725: aload_0
    //   726: getfield n : [F
    //   729: invokestatic b : (Landroidx/constraintlayout/widget/b;Landroid/view/View;[F)V
    //   732: iload #16
    //   734: iconst_1
    //   735: iadd
    //   736: istore #16
    //   738: goto -> 674
    //   741: aload_0
    //   742: getfield d : Landroidx/constraintlayout/motion/widget/f;
    //   745: astore #5
    //   747: aload #5
    //   749: getfield b : I
    //   752: ifne -> 813
    //   755: fload_2
    //   756: fconst_0
    //   757: fcmpg
    //   758: ifgt -> 773
    //   761: aload_1
    //   762: aload #5
    //   764: getfield c : I
    //   767: invokevirtual setVisibility : (I)V
    //   770: goto -> 813
    //   773: fload_2
    //   774: fconst_1
    //   775: fcmpl
    //   776: iflt -> 793
    //   779: aload_1
    //   780: aload_0
    //   781: getfield e : Landroidx/constraintlayout/motion/widget/f;
    //   784: getfield c : I
    //   787: invokevirtual setVisibility : (I)V
    //   790: goto -> 813
    //   793: aload_0
    //   794: getfield e : Landroidx/constraintlayout/motion/widget/f;
    //   797: getfield c : I
    //   800: aload #5
    //   802: getfield c : I
    //   805: if_icmpeq -> 813
    //   808: aload_1
    //   809: iconst_0
    //   810: invokevirtual setVisibility : (I)V
    //   813: iload #20
    //   815: istore #21
    //   817: aload_0
    //   818: getfield s : [Landroidx/constraintlayout/motion/widget/e;
    //   821: ifnull -> 1076
    //   824: iconst_0
    //   825: istore #16
    //   827: aload_0
    //   828: getfield s : [Landroidx/constraintlayout/motion/widget/e;
    //   831: astore #5
    //   833: iload #20
    //   835: istore #21
    //   837: iload #16
    //   839: aload #5
    //   841: arraylength
    //   842: if_icmpge -> 1076
    //   845: aload #5
    //   847: iload #16
    //   849: aaload
    //   850: fload_2
    //   851: aload_1
    //   852: invokevirtual a : (FLandroid/view/View;)V
    //   855: iload #16
    //   857: iconst_1
    //   858: iadd
    //   859: istore #16
    //   861: goto -> 827
    //   864: aload_0
    //   865: getfield b : Landroidx/constraintlayout/motion/widget/k;
    //   868: astore #5
    //   870: aload #5
    //   872: getfield f : F
    //   875: fstore #14
    //   877: aload_0
    //   878: getfield c : Landroidx/constraintlayout/motion/widget/k;
    //   881: astore #22
    //   883: aload #22
    //   885: getfield f : F
    //   888: fstore #15
    //   890: aload #5
    //   892: getfield g : F
    //   895: fstore #12
    //   897: aload #22
    //   899: getfield g : F
    //   902: fstore #13
    //   904: aload #5
    //   906: getfield h : F
    //   909: fstore #8
    //   911: aload #22
    //   913: getfield h : F
    //   916: fstore #9
    //   918: aload #5
    //   920: getfield i : F
    //   923: fstore #10
    //   925: aload #22
    //   927: getfield i : F
    //   930: fstore #11
    //   932: fload #14
    //   934: fload #15
    //   936: fload #14
    //   938: fsub
    //   939: fload_2
    //   940: fmul
    //   941: fadd
    //   942: ldc_w 0.5
    //   945: fadd
    //   946: fstore #14
    //   948: fload #14
    //   950: f2i
    //   951: istore #16
    //   953: fload #12
    //   955: fload #13
    //   957: fload #12
    //   959: fsub
    //   960: fload_2
    //   961: fmul
    //   962: fadd
    //   963: ldc_w 0.5
    //   966: fadd
    //   967: fstore #12
    //   969: fload #12
    //   971: f2i
    //   972: istore #17
    //   974: fload #14
    //   976: fload #9
    //   978: fload #8
    //   980: fsub
    //   981: fload_2
    //   982: fmul
    //   983: fload #8
    //   985: fadd
    //   986: fadd
    //   987: f2i
    //   988: istore #18
    //   990: fload #12
    //   992: fload #11
    //   994: fload #10
    //   996: fsub
    //   997: fload_2
    //   998: fmul
    //   999: fload #10
    //   1001: fadd
    //   1002: fadd
    //   1003: f2i
    //   1004: istore #19
    //   1006: fload #9
    //   1008: fload #8
    //   1010: fcmpl
    //   1011: ifne -> 1029
    //   1014: fload #11
    //   1016: fload #10
    //   1018: fcmpl
    //   1019: ifne -> 1029
    //   1022: aload_0
    //   1023: getfield a : Z
    //   1026: ifeq -> 1060
    //   1029: aload_1
    //   1030: iload #18
    //   1032: iload #16
    //   1034: isub
    //   1035: ldc_w 1073741824
    //   1038: invokestatic makeMeasureSpec : (II)I
    //   1041: iload #19
    //   1043: iload #17
    //   1045: isub
    //   1046: ldc_w 1073741824
    //   1049: invokestatic makeMeasureSpec : (II)I
    //   1052: invokevirtual measure : (II)V
    //   1055: aload_0
    //   1056: iconst_0
    //   1057: putfield a : Z
    //   1060: aload_1
    //   1061: iload #16
    //   1063: iload #17
    //   1065: iload #18
    //   1067: iload #19
    //   1069: invokevirtual layout : (IIII)V
    //   1072: iload #20
    //   1074: istore #21
    //   1076: aload_0
    //   1077: getfield r : Ljava/util/HashMap;
    //   1080: astore #5
    //   1082: aload #5
    //   1084: ifnull -> 1170
    //   1087: aload #5
    //   1089: invokevirtual values : ()Ljava/util/Collection;
    //   1092: invokeinterface iterator : ()Ljava/util/Iterator;
    //   1097: astore #5
    //   1099: aload #5
    //   1101: invokeinterface hasNext : ()Z
    //   1106: ifeq -> 1170
    //   1109: aload #5
    //   1111: invokeinterface next : ()Ljava/lang/Object;
    //   1116: checkcast w/b
    //   1119: astore #22
    //   1121: aload #22
    //   1123: instanceof w/b$a
    //   1126: ifeq -> 1160
    //   1129: aload #22
    //   1131: checkcast w/b$a
    //   1134: astore #22
    //   1136: aload_0
    //   1137: getfield l : [D
    //   1140: astore #23
    //   1142: aload #22
    //   1144: aload_1
    //   1145: fload_2
    //   1146: aload #23
    //   1148: iconst_0
    //   1149: daload
    //   1150: aload #23
    //   1152: iconst_1
    //   1153: daload
    //   1154: invokevirtual c : (Landroid/view/View;FDD)V
    //   1157: goto -> 1099
    //   1160: aload #22
    //   1162: aload_1
    //   1163: fload_2
    //   1164: invokevirtual b : (Landroid/view/View;F)V
    //   1167: goto -> 1099
    //   1170: iload #21
    //   1172: ireturn
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(" start: x: ");
    stringBuilder.append(this.b.f);
    stringBuilder.append(" y: ");
    stringBuilder.append(this.b.g);
    stringBuilder.append(" end: x: ");
    stringBuilder.append(this.c.f);
    stringBuilder.append(" y: ");
    stringBuilder.append(this.c.g);
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\constraintlayout\motion\widget\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */