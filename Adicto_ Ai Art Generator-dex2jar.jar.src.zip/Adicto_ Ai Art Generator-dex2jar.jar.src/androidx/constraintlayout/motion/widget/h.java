package androidx.constraintlayout.motion.widget;

import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.c;
import androidx.constraintlayout.widget.k;

public class h extends c implements j.d {
  private boolean k;
  
  private boolean l;
  
  private float m;
  
  protected View[] n;
  
  public void a(j paramj, int paramInt1, int paramInt2, float paramFloat) {}
  
  public void b(j paramj, int paramInt) {}
  
  public void c(j paramj, int paramInt1, int paramInt2) {}
  
  public float getProgress() {
    return this.m;
  }
  
  protected void m(AttributeSet paramAttributeSet) {
    super.m(paramAttributeSet);
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, k.B6);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == k.D6) {
          this.k = typedArray.getBoolean(k, this.k);
        } else if (k == k.C6) {
          this.l = typedArray.getBoolean(k, this.l);
        } 
      } 
      typedArray.recycle();
    } 
  }
  
  public void setProgress(float paramFloat) {
    this.m = paramFloat;
    int k = this.c;
    int i = 0;
    int j = 0;
    if (k > 0) {
      this.n = l((ConstraintLayout)getParent());
      for (i = j; i < this.c; i++)
        x(this.n[i], paramFloat); 
    } else {
      ViewGroup viewGroup = (ViewGroup)getParent();
      j = viewGroup.getChildCount();
      while (i < j) {
        View view = viewGroup.getChildAt(i);
        if (!(view instanceof h))
          x(view, paramFloat); 
        i++;
      } 
    } 
  }
  
  public boolean t() {
    return false;
  }
  
  public boolean u() {
    return this.l;
  }
  
  public boolean v() {
    return this.k;
  }
  
  public void w(Canvas paramCanvas) {}
  
  public void x(View paramView, float paramFloat) {}
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\constraintlayout\motion\widget\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */