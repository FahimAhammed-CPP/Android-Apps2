package androidx.constraintlayout.motion.widget;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.b;
import java.util.LinkedHashMap;
import s.b;

class k implements Comparable<k> {
  static String[] t = new String[] { "position", "x", "y", "width", "height", "pathRotate" };
  
  b b;
  
  int c = 0;
  
  float d;
  
  float e;
  
  float f;
  
  float g;
  
  float h;
  
  float i;
  
  float j = Float.NaN;
  
  float k = Float.NaN;
  
  int l;
  
  int m;
  
  float n;
  
  g o;
  
  LinkedHashMap<String, b> p;
  
  int q;
  
  double[] r;
  
  double[] s;
  
  public k() {
    int i = d.a;
    this.l = i;
    this.m = i;
    this.n = Float.NaN;
    this.o = null;
    this.p = new LinkedHashMap<String, b>();
    this.q = 0;
    this.r = new double[18];
    this.s = new double[18];
  }
  
  public int a(@NonNull k paramk) {
    return Float.compare(this.e, paramk.e);
  }
  
  void b(double paramDouble, int[] paramArrayOfint, double[] paramArrayOfdouble1, float[] paramArrayOffloat1, double[] paramArrayOfdouble2, float[] paramArrayOffloat2) {
    float f3 = this.f;
    float f4 = this.g;
    float f6 = this.h;
    float f5 = this.i;
    int i = 0;
    float f8 = 0.0F;
    float f10 = 0.0F;
    float f7 = 0.0F;
    float f9 = 0.0F;
    while (i < paramArrayOfint.length) {
      float f12 = (float)paramArrayOfdouble1[i];
      float f11 = (float)paramArrayOfdouble2[i];
      int j = paramArrayOfint[i];
      if (j != 1) {
        if (j != 2) {
          if (j != 3) {
            if (j == 4) {
              f5 = f12;
              f9 = f11;
            } 
          } else {
            f6 = f12;
            f10 = f11;
          } 
        } else {
          f4 = f12;
          f7 = f11;
        } 
      } else {
        f8 = f11;
        f3 = f12;
      } 
      i++;
    } 
    float f1 = f10 / 2.0F + f8;
    float f2 = f9 / 2.0F + f7;
    g g1 = this.o;
    if (g1 != null) {
      float[] arrayOfFloat1 = new float[2];
      float[] arrayOfFloat2 = new float[2];
      g1.b(paramDouble, arrayOfFloat1, arrayOfFloat2);
      f10 = arrayOfFloat1[0];
      f9 = arrayOfFloat1[1];
      f1 = arrayOfFloat2[0];
      f2 = arrayOfFloat2[1];
      double d1 = f10;
      double d2 = f3;
      paramDouble = f4;
      f3 = (float)(d1 + Math.sin(paramDouble) * d2 - (f6 / 2.0F));
      f4 = (float)(f9 - d2 * Math.cos(paramDouble) - (f5 / 2.0F));
      d1 = f1;
      d2 = f8;
      double d3 = Math.sin(paramDouble);
      double d4 = Math.cos(paramDouble);
      double d5 = f7;
      f1 = (float)(d1 + d3 * d2 + d4 * d5);
      f2 = (float)(f2 - d2 * Math.cos(paramDouble) + Math.sin(paramDouble) * d5);
    } 
    paramArrayOffloat1[0] = f3 + f6 / 2.0F + 0.0F;
    paramArrayOffloat1[1] = f4 + f5 / 2.0F + 0.0F;
    paramArrayOffloat2[0] = f1;
    paramArrayOffloat2[1] = f2;
  }
  
  void d(float paramFloat, View paramView, int[] paramArrayOfint, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield f : F
    //   4: fstore #28
    //   6: aload_0
    //   7: getfield g : F
    //   10: fstore #27
    //   12: aload_0
    //   13: getfield h : F
    //   16: fstore #29
    //   18: aload_0
    //   19: getfield i : F
    //   22: fstore #26
    //   24: aload_3
    //   25: arraylength
    //   26: ifeq -> 69
    //   29: aload_0
    //   30: getfield r : [D
    //   33: arraylength
    //   34: aload_3
    //   35: aload_3
    //   36: arraylength
    //   37: iconst_1
    //   38: isub
    //   39: iaload
    //   40: if_icmpgt -> 69
    //   43: aload_3
    //   44: aload_3
    //   45: arraylength
    //   46: iconst_1
    //   47: isub
    //   48: iaload
    //   49: iconst_1
    //   50: iadd
    //   51: istore #34
    //   53: aload_0
    //   54: iload #34
    //   56: newarray double
    //   58: putfield r : [D
    //   61: aload_0
    //   62: iload #34
    //   64: newarray double
    //   66: putfield s : [D
    //   69: aload_0
    //   70: getfield r : [D
    //   73: ldc2_w NaN
    //   76: invokestatic fill : ([DD)V
    //   79: iconst_0
    //   80: istore #34
    //   82: iload #34
    //   84: aload_3
    //   85: arraylength
    //   86: if_icmpge -> 132
    //   89: aload_0
    //   90: getfield r : [D
    //   93: astore #42
    //   95: aload_3
    //   96: iload #34
    //   98: iaload
    //   99: istore #35
    //   101: aload #42
    //   103: iload #35
    //   105: aload #4
    //   107: iload #34
    //   109: daload
    //   110: dastore
    //   111: aload_0
    //   112: getfield s : [D
    //   115: iload #35
    //   117: aload #5
    //   119: iload #34
    //   121: daload
    //   122: dastore
    //   123: iload #34
    //   125: iconst_1
    //   126: iadd
    //   127: istore #34
    //   129: goto -> 82
    //   132: ldc NaN
    //   134: fstore #24
    //   136: iconst_0
    //   137: istore #34
    //   139: fconst_0
    //   140: fstore #31
    //   142: fconst_0
    //   143: fstore #30
    //   145: fconst_0
    //   146: fstore #33
    //   148: fconst_0
    //   149: fstore #32
    //   151: aload_0
    //   152: getfield r : [D
    //   155: astore_3
    //   156: iload #34
    //   158: aload_3
    //   159: arraylength
    //   160: if_icmpge -> 367
    //   163: aload_3
    //   164: iload #34
    //   166: daload
    //   167: invokestatic isNaN : (D)Z
    //   170: istore #41
    //   172: dconst_0
    //   173: dstore #8
    //   175: iload #41
    //   177: ifeq -> 198
    //   180: aload #6
    //   182: ifnull -> 195
    //   185: aload #6
    //   187: iload #34
    //   189: daload
    //   190: dconst_0
    //   191: dcmpl
    //   192: ifne -> 198
    //   195: goto -> 287
    //   198: aload #6
    //   200: ifnull -> 210
    //   203: aload #6
    //   205: iload #34
    //   207: daload
    //   208: dstore #8
    //   210: aload_0
    //   211: getfield r : [D
    //   214: iload #34
    //   216: daload
    //   217: invokestatic isNaN : (D)Z
    //   220: ifeq -> 226
    //   223: goto -> 238
    //   226: aload_0
    //   227: getfield r : [D
    //   230: iload #34
    //   232: daload
    //   233: dload #8
    //   235: dadd
    //   236: dstore #8
    //   238: fload #24
    //   240: fstore #23
    //   242: dload #8
    //   244: d2f
    //   245: fstore #22
    //   247: aload_0
    //   248: getfield s : [D
    //   251: iload #34
    //   253: daload
    //   254: d2f
    //   255: fstore #25
    //   257: iload #34
    //   259: iconst_1
    //   260: if_icmpeq -> 342
    //   263: iload #34
    //   265: iconst_2
    //   266: if_icmpeq -> 327
    //   269: iload #34
    //   271: iconst_3
    //   272: if_icmpeq -> 312
    //   275: iload #34
    //   277: iconst_4
    //   278: if_icmpeq -> 297
    //   281: iload #34
    //   283: iconst_5
    //   284: if_icmpeq -> 294
    //   287: fload #24
    //   289: fstore #22
    //   291: goto -> 354
    //   294: goto -> 354
    //   297: fload #22
    //   299: fstore #26
    //   301: fload #23
    //   303: fstore #22
    //   305: fload #25
    //   307: fstore #32
    //   309: goto -> 354
    //   312: fload #22
    //   314: fstore #29
    //   316: fload #23
    //   318: fstore #22
    //   320: fload #25
    //   322: fstore #33
    //   324: goto -> 354
    //   327: fload #22
    //   329: fstore #27
    //   331: fload #23
    //   333: fstore #22
    //   335: fload #25
    //   337: fstore #30
    //   339: goto -> 354
    //   342: fload #22
    //   344: fstore #28
    //   346: fload #25
    //   348: fstore #31
    //   350: fload #23
    //   352: fstore #22
    //   354: iload #34
    //   356: iconst_1
    //   357: iadd
    //   358: istore #34
    //   360: fload #22
    //   362: fstore #24
    //   364: goto -> 151
    //   367: aload_0
    //   368: getfield o : Landroidx/constraintlayout/motion/widget/g;
    //   371: astore_3
    //   372: aload_3
    //   373: ifnull -> 605
    //   376: iconst_2
    //   377: newarray float
    //   379: astore #4
    //   381: iconst_2
    //   382: newarray float
    //   384: astore #6
    //   386: aload_3
    //   387: fload_1
    //   388: f2d
    //   389: aload #4
    //   391: aload #6
    //   393: invokevirtual b : (D[F[F)V
    //   396: aload #4
    //   398: iconst_0
    //   399: faload
    //   400: fstore_1
    //   401: aload #4
    //   403: iconst_1
    //   404: faload
    //   405: fstore #22
    //   407: aload #6
    //   409: iconst_0
    //   410: faload
    //   411: fstore #25
    //   413: aload #6
    //   415: iconst_1
    //   416: faload
    //   417: fstore #23
    //   419: fload_1
    //   420: f2d
    //   421: dstore #12
    //   423: fload #28
    //   425: f2d
    //   426: dstore #8
    //   428: fload #27
    //   430: f2d
    //   431: dstore #10
    //   433: dload #12
    //   435: dload #10
    //   437: invokestatic sin : (D)D
    //   440: dload #8
    //   442: dmul
    //   443: dadd
    //   444: fload #29
    //   446: fconst_2
    //   447: fdiv
    //   448: f2d
    //   449: dsub
    //   450: d2f
    //   451: fstore_1
    //   452: fload #22
    //   454: f2d
    //   455: dload #10
    //   457: invokestatic cos : (D)D
    //   460: dload #8
    //   462: dmul
    //   463: dsub
    //   464: fload #26
    //   466: fconst_2
    //   467: fdiv
    //   468: f2d
    //   469: dsub
    //   470: d2f
    //   471: fstore #22
    //   473: fload #25
    //   475: f2d
    //   476: dstore #12
    //   478: fload #31
    //   480: f2d
    //   481: dstore #14
    //   483: dload #10
    //   485: invokestatic sin : (D)D
    //   488: dstore #16
    //   490: dload #10
    //   492: invokestatic cos : (D)D
    //   495: dstore #18
    //   497: fload #30
    //   499: f2d
    //   500: dstore #20
    //   502: dload #12
    //   504: dload #16
    //   506: dload #14
    //   508: dmul
    //   509: dadd
    //   510: dload #18
    //   512: dload #8
    //   514: dmul
    //   515: dload #20
    //   517: dmul
    //   518: dadd
    //   519: d2f
    //   520: fstore #25
    //   522: fload #23
    //   524: f2d
    //   525: dload #14
    //   527: dload #10
    //   529: invokestatic cos : (D)D
    //   532: dmul
    //   533: dsub
    //   534: dload #8
    //   536: dload #10
    //   538: invokestatic sin : (D)D
    //   541: dmul
    //   542: dload #20
    //   544: dmul
    //   545: dadd
    //   546: d2f
    //   547: fstore #23
    //   549: aload #5
    //   551: arraylength
    //   552: iconst_2
    //   553: if_icmplt -> 573
    //   556: aload #5
    //   558: iconst_0
    //   559: fload #25
    //   561: f2d
    //   562: dastore
    //   563: aload #5
    //   565: iconst_1
    //   566: fload #23
    //   568: f2d
    //   569: dastore
    //   570: goto -> 573
    //   573: fload #24
    //   575: invokestatic isNaN : (F)Z
    //   578: ifne -> 602
    //   581: aload_2
    //   582: fload #24
    //   584: f2d
    //   585: fload #23
    //   587: f2d
    //   588: fload #25
    //   590: f2d
    //   591: invokestatic atan2 : (DD)D
    //   594: invokestatic toDegrees : (D)D
    //   597: dadd
    //   598: d2f
    //   599: invokevirtual setRotation : (F)V
    //   602: goto -> 667
    //   605: fload #28
    //   607: fstore_1
    //   608: fload #27
    //   610: fstore #22
    //   612: fload #24
    //   614: invokestatic isNaN : (F)Z
    //   617: ifne -> 667
    //   620: fload #33
    //   622: fconst_2
    //   623: fdiv
    //   624: fstore_1
    //   625: fload #32
    //   627: fconst_2
    //   628: fdiv
    //   629: fstore #22
    //   631: aload_2
    //   632: fconst_0
    //   633: f2d
    //   634: fload #24
    //   636: f2d
    //   637: fload #30
    //   639: fload #22
    //   641: fadd
    //   642: f2d
    //   643: fload #31
    //   645: fload_1
    //   646: fadd
    //   647: f2d
    //   648: invokestatic atan2 : (DD)D
    //   651: invokestatic toDegrees : (D)D
    //   654: dadd
    //   655: dadd
    //   656: d2f
    //   657: invokevirtual setRotation : (F)V
    //   660: fload #27
    //   662: fstore #22
    //   664: fload #28
    //   666: fstore_1
    //   667: iconst_0
    //   668: istore #34
    //   670: aload_2
    //   671: instanceof androidx/constraintlayout/motion/widget/c
    //   674: ifeq -> 699
    //   677: aload_2
    //   678: checkcast androidx/constraintlayout/motion/widget/c
    //   681: fload_1
    //   682: fload #22
    //   684: fload #29
    //   686: fload_1
    //   687: fadd
    //   688: fload #22
    //   690: fload #26
    //   692: fadd
    //   693: invokeinterface a : (FFFF)V
    //   698: return
    //   699: fload_1
    //   700: ldc 0.5
    //   702: fadd
    //   703: fstore_1
    //   704: fload_1
    //   705: f2i
    //   706: istore #35
    //   708: fload #22
    //   710: ldc 0.5
    //   712: fadd
    //   713: fstore #22
    //   715: fload #22
    //   717: f2i
    //   718: istore #36
    //   720: fload_1
    //   721: fload #29
    //   723: fadd
    //   724: f2i
    //   725: istore #37
    //   727: fload #22
    //   729: fload #26
    //   731: fadd
    //   732: f2i
    //   733: istore #38
    //   735: iload #37
    //   737: iload #35
    //   739: isub
    //   740: istore #39
    //   742: iload #38
    //   744: iload #36
    //   746: isub
    //   747: istore #40
    //   749: iload #39
    //   751: aload_2
    //   752: invokevirtual getMeasuredWidth : ()I
    //   755: if_icmpne -> 767
    //   758: iload #40
    //   760: aload_2
    //   761: invokevirtual getMeasuredHeight : ()I
    //   764: if_icmpeq -> 770
    //   767: iconst_1
    //   768: istore #34
    //   770: iload #34
    //   772: ifne -> 780
    //   775: iload #7
    //   777: ifeq -> 798
    //   780: aload_2
    //   781: iload #39
    //   783: ldc 1073741824
    //   785: invokestatic makeMeasureSpec : (II)I
    //   788: iload #40
    //   790: ldc 1073741824
    //   792: invokestatic makeMeasureSpec : (II)I
    //   795: invokevirtual measure : (II)V
    //   798: aload_2
    //   799: iload #35
    //   801: iload #36
    //   803: iload #37
    //   805: iload #38
    //   807: invokevirtual layout : (IIII)V
    //   810: return
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\constraintlayout\motion\widget\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */