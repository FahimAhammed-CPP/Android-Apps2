package androidx.core.app;

import android.content.res.Configuration;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

public final class r {
  private final boolean a;
  
  private final Configuration b;
  
  public r(boolean paramBoolean) {
    this.a = paramBoolean;
    this.b = null;
  }
  
  @RequiresApi(26)
  public r(boolean paramBoolean, @NonNull Configuration paramConfiguration) {
    this.a = paramBoolean;
    this.b = paramConfiguration;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\core\app\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */