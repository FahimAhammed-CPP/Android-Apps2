package androidx.core.app;

import android.app.Notification;

public interface t {
  Notification.Builder a();
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\core\app\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */