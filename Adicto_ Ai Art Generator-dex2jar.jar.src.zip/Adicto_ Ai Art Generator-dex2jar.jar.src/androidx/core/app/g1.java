package androidx.core.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Person;
import android.app.RemoteInput;
import android.content.Context;
import android.content.LocusId;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.RemoteViews;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

class g1 implements t {
  private final Context a;
  
  private final Notification.Builder b;
  
  private final NotificationCompat.m c;
  
  private RemoteViews d;
  
  private RemoteViews e;
  
  private final List<Bundle> f;
  
  private final Bundle g;
  
  private int h;
  
  private RemoteViews i;
  
  g1(NotificationCompat.m paramm) {
    boolean bool;
    List<String> list;
    this.f = new ArrayList<Bundle>();
    this.g = new Bundle();
    this.c = paramm;
    Context context = paramm.a;
    this.a = context;
    if (Build.VERSION.SDK_INT >= 26) {
      this.b = h.a(context, paramm.L);
    } else {
      this.b = new Notification.Builder(paramm.a);
    } 
    Notification notification = paramm.U;
    Notification.Builder builder = this.b.setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, paramm.i).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS);
    if ((notification.flags & 0x2) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOngoing(bool);
    if ((notification.flags & 0x8) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOnlyAlertOnce(bool);
    if ((notification.flags & 0x10) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setAutoCancel(bool).setDefaults(notification.defaults).setContentTitle(paramm.e).setContentText(paramm.f).setContentInfo(paramm.k).setContentIntent(paramm.g).setDeleteIntent(notification.deleteIntent);
    PendingIntent pendingIntent = paramm.h;
    if ((notification.flags & 0x80) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder.setFullScreenIntent(pendingIntent, bool).setLargeIcon(paramm.j).setNumber(paramm.l).setProgress(paramm.u, paramm.v, paramm.w);
    a.b(a.d(a.c(this.b, paramm.r), paramm.o), paramm.m);
    Iterator<NotificationCompat.b> iterator = paramm.b.iterator();
    while (iterator.hasNext())
      b(iterator.next()); 
    Bundle bundle = paramm.E;
    if (bundle != null)
      this.g.putAll(bundle); 
    int i = Build.VERSION.SDK_INT;
    this.d = paramm.I;
    this.e = paramm.J;
    b.a(this.b, paramm.n);
    d.i(this.b, paramm.A);
    d.g(this.b, paramm.x);
    d.j(this.b, paramm.z);
    d.h(this.b, paramm.y);
    this.h = paramm.Q;
    e.b(this.b, paramm.D);
    e.c(this.b, paramm.F);
    e.f(this.b, paramm.G);
    e.d(this.b, paramm.H);
    e.e(this.b, notification.sound, notification.audioAttributes);
    if (i < 28) {
      list = e(g(paramm.c), paramm.X);
    } else {
      list = paramm.X;
    } 
    if (list != null && !list.isEmpty())
      for (String str : list)
        e.a(this.b, str);  
    this.i = paramm.K;
    if (paramm.d.size() > 0) {
      Bundle bundle2 = paramm.g().getBundle("android.car.EXTENSIONS");
      Bundle bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle2 = new Bundle(bundle1);
      Bundle bundle3 = new Bundle();
      for (i = 0; i < paramm.d.size(); i++)
        bundle3.putBundle(Integer.toString(i), y1.e(paramm.d.get(i))); 
      bundle1.putBundle("invisible_actions", bundle3);
      bundle2.putBundle("invisible_actions", bundle3);
      paramm.g().putBundle("android.car.EXTENSIONS", bundle1);
      this.g.putBundle("android.car.EXTENSIONS", bundle2);
    } 
    i = Build.VERSION.SDK_INT;
    if (i >= 23) {
      Object object = paramm.W;
      if (object != null)
        f.b(this.b, object); 
    } 
    if (i >= 24) {
      c.a(this.b, paramm.E);
      g.e(this.b, paramm.t);
      RemoteViews remoteViews = paramm.I;
      if (remoteViews != null)
        g.c(this.b, remoteViews); 
      remoteViews = paramm.J;
      if (remoteViews != null)
        g.b(this.b, remoteViews); 
      remoteViews = paramm.K;
      if (remoteViews != null)
        g.d(this.b, remoteViews); 
    } 
    if (i >= 26) {
      h.b(this.b, paramm.M);
      h.e(this.b, paramm.s);
      h.f(this.b, paramm.N);
      h.g(this.b, paramm.P);
      h.d(this.b, paramm.Q);
      if (paramm.C)
        h.c(this.b, paramm.B); 
      if (!TextUtils.isEmpty(paramm.L))
        this.b.setSound(null).setDefaults(0).setLights(0, 0, 0).setVibrate(null); 
    } 
    if (i >= 28)
      for (m2 m2 : paramm.c)
        i.a(this.b, m2.j());  
    i = Build.VERSION.SDK_INT;
    if (i >= 29) {
      j.a(this.b, paramm.S);
      j.b(this.b, NotificationCompat.l.k(paramm.T));
      androidx.core.content.k k = paramm.O;
      if (k != null)
        j.d(this.b, k.b()); 
    } 
    if (i >= 31) {
      int j = paramm.R;
      if (j != 0)
        k.b(this.b, j); 
    } 
    if (paramm.V) {
      if (this.c.y) {
        this.h = 2;
      } else {
        this.h = 1;
      } 
      this.b.setVibrate(null);
      this.b.setSound(null);
      int j = notification.defaults & 0xFFFFFFFE & 0xFFFFFFFD;
      notification.defaults = j;
      this.b.setDefaults(j);
      if (i >= 26) {
        if (TextUtils.isEmpty(this.c.x))
          d.g(this.b, "silent"); 
        h.d(this.b, this.h);
      } 
    } 
  }
  
  private void b(NotificationCompat.b paramb) {
    Notification.Action.Builder builder;
    Bundle bundle;
    int i = Build.VERSION.SDK_INT;
    IconCompat iconCompat = paramb.d();
    boolean bool = false;
    if (i >= 23) {
      if (iconCompat != null) {
        Icon icon = iconCompat.z();
      } else {
        iconCompat = null;
      } 
      builder = f.a((Icon)iconCompat, paramb.h(), paramb.a());
    } else {
      if (builder != null) {
        i = builder.o();
      } else {
        i = 0;
      } 
      builder = d.e(i, paramb.h(), paramb.a());
    } 
    if (paramb.e() != null) {
      RemoteInput[] arrayOfRemoteInput = o2.b(paramb.e());
      int j = arrayOfRemoteInput.length;
      for (i = bool; i < j; i++)
        d.c(builder, arrayOfRemoteInput[i]); 
    } 
    if (paramb.c() != null) {
      bundle = new Bundle(paramb.c());
    } else {
      bundle = new Bundle();
    } 
    bundle.putBoolean("android.support.allowGeneratedReplies", paramb.b());
    i = Build.VERSION.SDK_INT;
    if (i >= 24)
      g.a(builder, paramb.b()); 
    bundle.putInt("android.support.action.semanticAction", paramb.f());
    if (i >= 28)
      i.b(builder, paramb.f()); 
    if (i >= 29)
      j.c(builder, paramb.j()); 
    if (i >= 31)
      k.a(builder, paramb.i()); 
    bundle.putBoolean("android.support.action.showsUserInterface", paramb.g());
    d.b(builder, bundle);
    d.a(this.b, d.d(builder));
  }
  
  @Nullable
  private static List<String> e(@Nullable List<String> paramList1, @Nullable List<String> paramList2) {
    if (paramList1 == null)
      return paramList2; 
    if (paramList2 == null)
      return paramList1; 
    androidx.collection.b b = new androidx.collection.b(paramList1.size() + paramList2.size());
    b.addAll(paramList1);
    b.addAll(paramList2);
    return new ArrayList<String>((Collection<? extends String>)b);
  }
  
  @Nullable
  private static List<String> g(@Nullable List<m2> paramList) {
    if (paramList == null)
      return null; 
    ArrayList<String> arrayList = new ArrayList(paramList.size());
    Iterator<m2> iterator = paramList.iterator();
    while (iterator.hasNext())
      arrayList.add(((m2)iterator.next()).i()); 
    return arrayList;
  }
  
  private void h(Notification paramNotification) {
    paramNotification.sound = null;
    paramNotification.vibrate = null;
    paramNotification.defaults = paramNotification.defaults & 0xFFFFFFFE & 0xFFFFFFFD;
  }
  
  public Notification.Builder a() {
    return this.b;
  }
  
  public Notification c() {
    RemoteViews remoteViews;
    NotificationCompat.r r = this.c.q;
    if (r != null)
      r.b(this); 
    if (r != null) {
      remoteViews = r.s(this);
    } else {
      remoteViews = null;
    } 
    Notification notification = d();
    if (remoteViews != null) {
      notification.contentView = remoteViews;
    } else {
      remoteViews = this.c.I;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
    } 
    if (r != null) {
      remoteViews = r.r(this);
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
    } 
    if (r != null) {
      remoteViews = this.c.q.t(this);
      if (remoteViews != null)
        notification.headsUpContentView = remoteViews; 
    } 
    if (r != null) {
      Bundle bundle = NotificationCompat.getExtras(notification);
      if (bundle != null)
        r.a(bundle); 
    } 
    return notification;
  }
  
  protected Notification d() {
    int i = Build.VERSION.SDK_INT;
    if (i >= 26)
      return a.a(this.b); 
    if (i >= 24) {
      Notification notification1 = a.a(this.b);
      if (this.h != 0) {
        if (d.f(notification1) != null && (notification1.flags & 0x200) != 0 && this.h == 2)
          h(notification1); 
        if (d.f(notification1) != null && (notification1.flags & 0x200) == 0 && this.h == 1)
          h(notification1); 
      } 
      return notification1;
    } 
    c.a(this.b, this.g);
    Notification notification = a.a(this.b);
    RemoteViews remoteViews = this.d;
    if (remoteViews != null)
      notification.contentView = remoteViews; 
    remoteViews = this.e;
    if (remoteViews != null)
      notification.bigContentView = remoteViews; 
    remoteViews = this.i;
    if (remoteViews != null)
      notification.headsUpContentView = remoteViews; 
    if (this.h != 0) {
      if (d.f(notification) != null && (notification.flags & 0x200) != 0 && this.h == 2)
        h(notification); 
      if (d.f(notification) != null && (notification.flags & 0x200) == 0 && this.h == 1)
        h(notification); 
    } 
    return notification;
  }
  
  Context f() {
    return this.a;
  }
  
  @RequiresApi(16)
  static class a {
    static Notification a(Notification.Builder param1Builder) {
      return param1Builder.build();
    }
    
    static Notification.Builder b(Notification.Builder param1Builder, int param1Int) {
      return param1Builder.setPriority(param1Int);
    }
    
    static Notification.Builder c(Notification.Builder param1Builder, CharSequence param1CharSequence) {
      return param1Builder.setSubText(param1CharSequence);
    }
    
    static Notification.Builder d(Notification.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setUsesChronometer(param1Boolean);
    }
  }
  
  @RequiresApi(17)
  static class b {
    static Notification.Builder a(Notification.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setShowWhen(param1Boolean);
    }
  }
  
  @RequiresApi(19)
  static class c {
    static Notification.Builder a(Notification.Builder param1Builder, Bundle param1Bundle) {
      return param1Builder.setExtras(param1Bundle);
    }
  }
  
  @RequiresApi(20)
  static class d {
    static Notification.Builder a(Notification.Builder param1Builder, Notification.Action param1Action) {
      return param1Builder.addAction(param1Action);
    }
    
    static Notification.Action.Builder b(Notification.Action.Builder param1Builder, Bundle param1Bundle) {
      return param1Builder.addExtras(param1Bundle);
    }
    
    static Notification.Action.Builder c(Notification.Action.Builder param1Builder, RemoteInput param1RemoteInput) {
      return param1Builder.addRemoteInput(param1RemoteInput);
    }
    
    static Notification.Action d(Notification.Action.Builder param1Builder) {
      return param1Builder.build();
    }
    
    static Notification.Action.Builder e(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      return new Notification.Action.Builder(param1Int, param1CharSequence, param1PendingIntent);
    }
    
    static String f(Notification param1Notification) {
      return param1Notification.getGroup();
    }
    
    static Notification.Builder g(Notification.Builder param1Builder, String param1String) {
      return param1Builder.setGroup(param1String);
    }
    
    static Notification.Builder h(Notification.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setGroupSummary(param1Boolean);
    }
    
    static Notification.Builder i(Notification.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setLocalOnly(param1Boolean);
    }
    
    static Notification.Builder j(Notification.Builder param1Builder, String param1String) {
      return param1Builder.setSortKey(param1String);
    }
  }
  
  @RequiresApi(21)
  static class e {
    static Notification.Builder a(Notification.Builder param1Builder, String param1String) {
      return param1Builder.addPerson(param1String);
    }
    
    static Notification.Builder b(Notification.Builder param1Builder, String param1String) {
      return param1Builder.setCategory(param1String);
    }
    
    static Notification.Builder c(Notification.Builder param1Builder, int param1Int) {
      return param1Builder.setColor(param1Int);
    }
    
    static Notification.Builder d(Notification.Builder param1Builder, Notification param1Notification) {
      return param1Builder.setPublicVersion(param1Notification);
    }
    
    static Notification.Builder e(Notification.Builder param1Builder, Uri param1Uri, Object param1Object) {
      return param1Builder.setSound(param1Uri, (AudioAttributes)param1Object);
    }
    
    static Notification.Builder f(Notification.Builder param1Builder, int param1Int) {
      return param1Builder.setVisibility(param1Int);
    }
  }
  
  @RequiresApi(23)
  static class f {
    static Notification.Action.Builder a(Icon param1Icon, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      return new Notification.Action.Builder(param1Icon, param1CharSequence, param1PendingIntent);
    }
    
    static Notification.Builder b(Notification.Builder param1Builder, Object param1Object) {
      return h1.a(param1Builder, (Icon)param1Object);
    }
  }
  
  @RequiresApi(24)
  static class g {
    static Notification.Action.Builder a(Notification.Action.Builder param1Builder, boolean param1Boolean) {
      return a1.a(param1Builder, param1Boolean);
    }
    
    static Notification.Builder b(Notification.Builder param1Builder, RemoteViews param1RemoteViews) {
      return j1.a(param1Builder, param1RemoteViews);
    }
    
    static Notification.Builder c(Notification.Builder param1Builder, RemoteViews param1RemoteViews) {
      return k1.a(param1Builder, param1RemoteViews);
    }
    
    static Notification.Builder d(Notification.Builder param1Builder, RemoteViews param1RemoteViews) {
      return i1.a(param1Builder, param1RemoteViews);
    }
    
    static Notification.Builder e(Notification.Builder param1Builder, CharSequence[] param1ArrayOfCharSequence) {
      return l1.a(param1Builder, param1ArrayOfCharSequence);
    }
  }
  
  @RequiresApi(26)
  static class h {
    static Notification.Builder a(Context param1Context, String param1String) {
      return new Notification.Builder(param1Context, param1String);
    }
    
    static Notification.Builder b(Notification.Builder param1Builder, int param1Int) {
      return o1.a(param1Builder, param1Int);
    }
    
    static Notification.Builder c(Notification.Builder param1Builder, boolean param1Boolean) {
      return q1.a(param1Builder, param1Boolean);
    }
    
    static Notification.Builder d(Notification.Builder param1Builder, int param1Int) {
      return n1.a(param1Builder, param1Int);
    }
    
    static Notification.Builder e(Notification.Builder param1Builder, CharSequence param1CharSequence) {
      return m1.a(param1Builder, param1CharSequence);
    }
    
    static Notification.Builder f(Notification.Builder param1Builder, String param1String) {
      return r1.a(param1Builder, param1String);
    }
    
    static Notification.Builder g(Notification.Builder param1Builder, long param1Long) {
      return p1.a(param1Builder, param1Long);
    }
  }
  
  @RequiresApi(28)
  static class i {
    static Notification.Builder a(Notification.Builder param1Builder, Person param1Person) {
      return b1.a(param1Builder, param1Person);
    }
    
    static Notification.Action.Builder b(Notification.Action.Builder param1Builder, int param1Int) {
      return s1.a(param1Builder, param1Int);
    }
  }
  
  @RequiresApi(29)
  static class j {
    static Notification.Builder a(Notification.Builder param1Builder, boolean param1Boolean) {
      return v1.a(param1Builder, param1Boolean);
    }
    
    static Notification.Builder b(Notification.Builder param1Builder, Notification.BubbleMetadata param1BubbleMetadata) {
      return t1.a(param1Builder, param1BubbleMetadata);
    }
    
    static Notification.Action.Builder c(Notification.Action.Builder param1Builder, boolean param1Boolean) {
      return u1.a(param1Builder, param1Boolean);
    }
    
    static Notification.Builder d(Notification.Builder param1Builder, Object param1Object) {
      return w1.a(param1Builder, (LocusId)param1Object);
    }
  }
  
  @RequiresApi(31)
  static class k {
    static Notification.Action.Builder a(Notification.Action.Builder param1Builder, boolean param1Boolean) {
      return c1.a(param1Builder, param1Boolean);
    }
    
    static Notification.Builder b(Notification.Builder param1Builder, int param1Int) {
      return x1.a(param1Builder, param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\core\app\g1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */