package androidx.core.app;

import android.app.PendingIntent;
import android.os.Bundle;
import android.os.Parcelable;
import androidx.annotation.RequiresApi;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

@RequiresApi(16)
class y1 {
  private static final Object a = new Object();
  
  private static final Object b = new Object();
  
  private static o2 a(Bundle paramBundle) {
    ArrayList arrayList = paramBundle.getStringArrayList("allowedDataTypes");
    HashSet<String> hashSet = new HashSet();
    if (arrayList != null) {
      Iterator<String> iterator = arrayList.iterator();
      while (iterator.hasNext())
        hashSet.add(iterator.next()); 
    } 
    return new o2(paramBundle.getString("resultKey"), paramBundle.getCharSequence("label"), paramBundle.getCharSequenceArray("choices"), paramBundle.getBoolean("allowFreeFormInput"), 0, paramBundle.getBundle("extras"), hashSet);
  }
  
  private static o2[] b(Bundle[] paramArrayOfBundle) {
    if (paramArrayOfBundle == null)
      return null; 
    o2[] arrayOfO2 = new o2[paramArrayOfBundle.length];
    for (int i = 0; i < paramArrayOfBundle.length; i++)
      arrayOfO2[i] = a(paramArrayOfBundle[i]); 
    return arrayOfO2;
  }
  
  static NotificationCompat.b c(Bundle paramBundle) {
    boolean bool;
    Bundle bundle = paramBundle.getBundle("extras");
    if (bundle != null) {
      bool = bundle.getBoolean("android.support.allowGeneratedReplies", false);
    } else {
      bool = false;
    } 
    return new NotificationCompat.b(paramBundle.getInt("icon"), paramBundle.getCharSequence("title"), (PendingIntent)paramBundle.getParcelable("actionIntent"), paramBundle.getBundle("extras"), b(d(paramBundle, "remoteInputs")), b(d(paramBundle, "dataOnlyRemoteInputs")), bool, paramBundle.getInt("semanticAction"), paramBundle.getBoolean("showsUserInterface"), false, false);
  }
  
  private static Bundle[] d(Bundle paramBundle, String paramString) {
    Parcelable[] arrayOfParcelable = paramBundle.getParcelableArray(paramString);
    if (arrayOfParcelable instanceof Bundle[] || arrayOfParcelable == null)
      return (Bundle[])arrayOfParcelable; 
    Bundle[] arrayOfBundle = Arrays.<Bundle, Parcelable>copyOf(arrayOfParcelable, arrayOfParcelable.length, Bundle[].class);
    paramBundle.putParcelableArray(paramString, (Parcelable[])arrayOfBundle);
    return arrayOfBundle;
  }
  
  static Bundle e(NotificationCompat.b paramb) {
    boolean bool;
    Bundle bundle1;
    Bundle bundle2 = new Bundle();
    IconCompat iconCompat = paramb.d();
    if (iconCompat != null) {
      bool = iconCompat.o();
    } else {
      bool = false;
    } 
    bundle2.putInt("icon", bool);
    bundle2.putCharSequence("title", paramb.h());
    bundle2.putParcelable("actionIntent", (Parcelable)paramb.a());
    if (paramb.c() != null) {
      bundle1 = new Bundle(paramb.c());
    } else {
      bundle1 = new Bundle();
    } 
    bundle1.putBoolean("android.support.allowGeneratedReplies", paramb.b());
    bundle2.putBundle("extras", bundle1);
    bundle2.putParcelableArray("remoteInputs", (Parcelable[])g(paramb.e()));
    bundle2.putBoolean("showsUserInterface", paramb.g());
    bundle2.putInt("semanticAction", paramb.f());
    return bundle2;
  }
  
  private static Bundle f(o2 paramo2) {
    Bundle bundle = new Bundle();
    bundle.putString("resultKey", paramo2.i());
    bundle.putCharSequence("label", paramo2.h());
    bundle.putCharSequenceArray("choices", paramo2.e());
    bundle.putBoolean("allowFreeFormInput", paramo2.c());
    bundle.putBundle("extras", paramo2.g());
    Set<String> set = paramo2.d();
    if (set != null && !set.isEmpty()) {
      ArrayList<String> arrayList = new ArrayList(set.size());
      Iterator<String> iterator = set.iterator();
      while (iterator.hasNext())
        arrayList.add(iterator.next()); 
      bundle.putStringArrayList("allowedDataTypes", arrayList);
    } 
    return bundle;
  }
  
  private static Bundle[] g(o2[] paramArrayOfo2) {
    if (paramArrayOfo2 == null)
      return null; 
    Bundle[] arrayOfBundle = new Bundle[paramArrayOfo2.length];
    for (int i = 0; i < paramArrayOfo2.length; i++)
      arrayOfBundle[i] = f(paramArrayOfo2[i]); 
    return arrayOfBundle;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\core\app\y1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */