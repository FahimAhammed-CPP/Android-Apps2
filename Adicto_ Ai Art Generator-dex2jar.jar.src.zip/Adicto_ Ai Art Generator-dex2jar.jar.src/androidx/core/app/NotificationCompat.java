package androidx.core.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Person;
import android.app.RemoteInput;
import android.content.Context;
import android.content.LocusId;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.text.style.TextAppearanceSpan;
import android.util.Log;
import android.widget.RemoteViews;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.graphics.drawable.IconCompat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class NotificationCompat {
  public static final int BADGE_ICON_LARGE = 2;
  
  public static final int BADGE_ICON_NONE = 0;
  
  public static final int BADGE_ICON_SMALL = 1;
  
  public static final String CATEGORY_ALARM = "alarm";
  
  public static final String CATEGORY_CALL = "call";
  
  public static final String CATEGORY_EMAIL = "email";
  
  public static final String CATEGORY_ERROR = "err";
  
  public static final String CATEGORY_EVENT = "event";
  
  public static final String CATEGORY_LOCATION_SHARING = "location_sharing";
  
  public static final String CATEGORY_MESSAGE = "msg";
  
  public static final String CATEGORY_MISSED_CALL = "missed_call";
  
  public static final String CATEGORY_NAVIGATION = "navigation";
  
  public static final String CATEGORY_PROGRESS = "progress";
  
  public static final String CATEGORY_PROMO = "promo";
  
  public static final String CATEGORY_RECOMMENDATION = "recommendation";
  
  public static final String CATEGORY_REMINDER = "reminder";
  
  public static final String CATEGORY_SERVICE = "service";
  
  public static final String CATEGORY_SOCIAL = "social";
  
  public static final String CATEGORY_STATUS = "status";
  
  public static final String CATEGORY_STOPWATCH = "stopwatch";
  
  public static final String CATEGORY_SYSTEM = "sys";
  
  public static final String CATEGORY_TRANSPORT = "transport";
  
  public static final String CATEGORY_WORKOUT = "workout";
  
  public static final int COLOR_DEFAULT = 0;
  
  public static final int DEFAULT_ALL = -1;
  
  public static final int DEFAULT_LIGHTS = 4;
  
  public static final int DEFAULT_SOUND = 1;
  
  public static final int DEFAULT_VIBRATE = 2;
  
  public static final String EXTRA_ANSWER_COLOR = "android.answerColor";
  
  public static final String EXTRA_ANSWER_INTENT = "android.answerIntent";
  
  public static final String EXTRA_AUDIO_CONTENTS_URI = "android.audioContents";
  
  public static final String EXTRA_BACKGROUND_IMAGE_URI = "android.backgroundImageUri";
  
  public static final String EXTRA_BIG_TEXT = "android.bigText";
  
  public static final String EXTRA_CALL_IS_VIDEO = "android.callIsVideo";
  
  public static final String EXTRA_CALL_PERSON = "android.callPerson";
  
  public static final String EXTRA_CALL_PERSON_COMPAT = "android.callPersonCompat";
  
  public static final String EXTRA_CALL_TYPE = "android.callType";
  
  public static final String EXTRA_CHANNEL_GROUP_ID = "android.intent.extra.CHANNEL_GROUP_ID";
  
  public static final String EXTRA_CHANNEL_ID = "android.intent.extra.CHANNEL_ID";
  
  public static final String EXTRA_CHRONOMETER_COUNT_DOWN = "android.chronometerCountDown";
  
  public static final String EXTRA_COLORIZED = "android.colorized";
  
  public static final String EXTRA_COMPACT_ACTIONS = "android.compactActions";
  
  public static final String EXTRA_COMPAT_TEMPLATE = "androidx.core.app.extra.COMPAT_TEMPLATE";
  
  public static final String EXTRA_CONVERSATION_TITLE = "android.conversationTitle";
  
  public static final String EXTRA_DECLINE_COLOR = "android.declineColor";
  
  public static final String EXTRA_DECLINE_INTENT = "android.declineIntent";
  
  public static final String EXTRA_HANG_UP_INTENT = "android.hangUpIntent";
  
  public static final String EXTRA_HIDDEN_CONVERSATION_TITLE = "android.hiddenConversationTitle";
  
  public static final String EXTRA_HISTORIC_MESSAGES = "android.messages.historic";
  
  public static final String EXTRA_INFO_TEXT = "android.infoText";
  
  public static final String EXTRA_IS_GROUP_CONVERSATION = "android.isGroupConversation";
  
  public static final String EXTRA_LARGE_ICON = "android.largeIcon";
  
  public static final String EXTRA_LARGE_ICON_BIG = "android.largeIcon.big";
  
  public static final String EXTRA_MEDIA_SESSION = "android.mediaSession";
  
  public static final String EXTRA_MESSAGES = "android.messages";
  
  public static final String EXTRA_MESSAGING_STYLE_USER = "android.messagingStyleUser";
  
  public static final String EXTRA_NOTIFICATION_ID = "android.intent.extra.NOTIFICATION_ID";
  
  public static final String EXTRA_NOTIFICATION_TAG = "android.intent.extra.NOTIFICATION_TAG";
  
  @Deprecated
  public static final String EXTRA_PEOPLE = "android.people";
  
  public static final String EXTRA_PEOPLE_LIST = "android.people.list";
  
  public static final String EXTRA_PICTURE = "android.picture";
  
  public static final String EXTRA_PICTURE_CONTENT_DESCRIPTION = "android.pictureContentDescription";
  
  public static final String EXTRA_PICTURE_ICON = "android.pictureIcon";
  
  public static final String EXTRA_PROGRESS = "android.progress";
  
  public static final String EXTRA_PROGRESS_INDETERMINATE = "android.progressIndeterminate";
  
  public static final String EXTRA_PROGRESS_MAX = "android.progressMax";
  
  public static final String EXTRA_REMOTE_INPUT_HISTORY = "android.remoteInputHistory";
  
  public static final String EXTRA_SELF_DISPLAY_NAME = "android.selfDisplayName";
  
  public static final String EXTRA_SHOW_BIG_PICTURE_WHEN_COLLAPSED = "android.showBigPictureWhenCollapsed";
  
  public static final String EXTRA_SHOW_CHRONOMETER = "android.showChronometer";
  
  public static final String EXTRA_SHOW_WHEN = "android.showWhen";
  
  public static final String EXTRA_SMALL_ICON = "android.icon";
  
  public static final String EXTRA_SUB_TEXT = "android.subText";
  
  public static final String EXTRA_SUMMARY_TEXT = "android.summaryText";
  
  public static final String EXTRA_TEMPLATE = "android.template";
  
  public static final String EXTRA_TEXT = "android.text";
  
  public static final String EXTRA_TEXT_LINES = "android.textLines";
  
  public static final String EXTRA_TITLE = "android.title";
  
  public static final String EXTRA_TITLE_BIG = "android.title.big";
  
  public static final String EXTRA_VERIFICATION_ICON = "android.verificationIcon";
  
  public static final String EXTRA_VERIFICATION_ICON_COMPAT = "android.verificationIconCompat";
  
  public static final String EXTRA_VERIFICATION_TEXT = "android.verificationText";
  
  public static final int FLAG_AUTO_CANCEL = 16;
  
  public static final int FLAG_BUBBLE = 4096;
  
  public static final int FLAG_FOREGROUND_SERVICE = 64;
  
  public static final int FLAG_GROUP_SUMMARY = 512;
  
  @Deprecated
  public static final int FLAG_HIGH_PRIORITY = 128;
  
  public static final int FLAG_INSISTENT = 4;
  
  public static final int FLAG_LOCAL_ONLY = 256;
  
  public static final int FLAG_NO_CLEAR = 32;
  
  public static final int FLAG_ONGOING_EVENT = 2;
  
  public static final int FLAG_ONLY_ALERT_ONCE = 8;
  
  public static final int FLAG_SHOW_LIGHTS = 1;
  
  public static final int FOREGROUND_SERVICE_DEFAULT = 0;
  
  public static final int FOREGROUND_SERVICE_DEFERRED = 2;
  
  public static final int FOREGROUND_SERVICE_IMMEDIATE = 1;
  
  public static final int GROUP_ALERT_ALL = 0;
  
  public static final int GROUP_ALERT_CHILDREN = 2;
  
  public static final int GROUP_ALERT_SUMMARY = 1;
  
  public static final String GROUP_KEY_SILENT = "silent";
  
  public static final String INTENT_CATEGORY_NOTIFICATION_PREFERENCES = "android.intent.category.NOTIFICATION_PREFERENCES";
  
  public static final int MAX_ACTION_BUTTONS = 3;
  
  public static final int PRIORITY_DEFAULT = 0;
  
  public static final int PRIORITY_HIGH = 1;
  
  public static final int PRIORITY_LOW = -1;
  
  public static final int PRIORITY_MAX = 2;
  
  public static final int PRIORITY_MIN = -2;
  
  public static final int STREAM_DEFAULT = -1;
  
  private static final String TAG = "NotifCompat";
  
  public static final int VISIBILITY_PRIVATE = 0;
  
  public static final int VISIBILITY_PUBLIC = 1;
  
  public static final int VISIBILITY_SECRET = -1;
  
  @Nullable
  public static b getAction(@NonNull Notification paramNotification, int paramInt) {
    return getActionCompatFromAction(paramNotification.actions[paramInt]);
  }
  
  @NonNull
  @RequiresApi(20)
  static b getActionCompatFromAction(@NonNull Notification.Action paramAction) {
    int i;
    boolean bool1;
    boolean bool2;
    boolean bool3;
    o2[] arrayOfO2;
    RemoteInput[] arrayOfRemoteInput = c.g(paramAction);
    IconCompat iconCompat = null;
    if (arrayOfRemoteInput == null) {
      arrayOfO2 = null;
    } else {
      arrayOfO2 = new o2[arrayOfRemoteInput.length];
      for (i = 0; i < arrayOfRemoteInput.length; i++) {
        boolean bool;
        RemoteInput remoteInput = arrayOfRemoteInput[i];
        String str = c.h(remoteInput);
        CharSequence charSequence = c.f(remoteInput);
        CharSequence[] arrayOfCharSequence = c.b(remoteInput);
        bool1 = c.a(remoteInput);
        if (Build.VERSION.SDK_INT >= 29) {
          bool = h.c(remoteInput);
        } else {
          bool = false;
        } 
        arrayOfO2[i] = new o2(str, charSequence, arrayOfCharSequence, bool1, bool, c.d(remoteInput), null);
      } 
    } 
    int j = Build.VERSION.SDK_INT;
    if (j >= 24) {
      if (c.c(paramAction).getBoolean("android.support.allowGeneratedReplies") || e.a(paramAction)) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
    } else {
      bool1 = c.c(paramAction).getBoolean("android.support.allowGeneratedReplies");
    } 
    boolean bool4 = c.c(paramAction).getBoolean("android.support.action.showsUserInterface", true);
    if (j >= 28) {
      i = g.a(paramAction);
    } else {
      i = c.c(paramAction).getInt("android.support.action.semanticAction", 0);
    } 
    if (j >= 29) {
      bool2 = h.e(paramAction);
    } else {
      bool2 = false;
    } 
    if (j >= 31) {
      bool3 = i.a(paramAction);
    } else {
      bool3 = false;
    } 
    if (j >= 23) {
      if (d.a(paramAction) == null) {
        j = paramAction.icon;
        if (j != 0)
          return new b(j, paramAction.title, paramAction.actionIntent, c.c(paramAction), arrayOfO2, null, bool1, i, bool4, bool2, bool3); 
      } 
      if (d.a(paramAction) != null)
        iconCompat = IconCompat.d(d.a(paramAction)); 
      return new b(iconCompat, paramAction.title, paramAction.actionIntent, c.c(paramAction), arrayOfO2, null, bool1, i, bool4, bool2, bool3);
    } 
    return new b(paramAction.icon, paramAction.title, paramAction.actionIntent, c.c(paramAction), arrayOfO2, null, bool1, i, bool4, bool2, bool3);
  }
  
  public static int getActionCount(@NonNull Notification paramNotification) {
    Notification.Action[] arrayOfAction = paramNotification.actions;
    return (arrayOfAction != null) ? arrayOfAction.length : 0;
  }
  
  public static boolean getAllowSystemGeneratedContextualActions(@NonNull Notification paramNotification) {
    return (Build.VERSION.SDK_INT >= 29) ? h.a(paramNotification) : false;
  }
  
  public static boolean getAutoCancel(@NonNull Notification paramNotification) {
    return ((paramNotification.flags & 0x10) != 0);
  }
  
  public static int getBadgeIconType(@NonNull Notification paramNotification) {
    return (Build.VERSION.SDK_INT >= 26) ? f.a(paramNotification) : 0;
  }
  
  @Nullable
  public static l getBubbleMetadata(@NonNull Notification paramNotification) {
    return (Build.VERSION.SDK_INT >= 29) ? l.a(h.b(paramNotification)) : null;
  }
  
  @Nullable
  public static String getCategory(@NonNull Notification paramNotification) {
    return paramNotification.category;
  }
  
  @Nullable
  public static String getChannelId(@NonNull Notification paramNotification) {
    return (Build.VERSION.SDK_INT >= 26) ? f.b(paramNotification) : null;
  }
  
  public static int getColor(@NonNull Notification paramNotification) {
    return paramNotification.color;
  }
  
  @Nullable
  @RequiresApi(19)
  public static CharSequence getContentInfo(@NonNull Notification paramNotification) {
    return paramNotification.extras.getCharSequence("android.infoText");
  }
  
  @Nullable
  @RequiresApi(19)
  public static CharSequence getContentText(@NonNull Notification paramNotification) {
    return paramNotification.extras.getCharSequence("android.text");
  }
  
  @Nullable
  @RequiresApi(19)
  public static CharSequence getContentTitle(@NonNull Notification paramNotification) {
    return paramNotification.extras.getCharSequence("android.title");
  }
  
  @Nullable
  public static Bundle getExtras(@NonNull Notification paramNotification) {
    return paramNotification.extras;
  }
  
  @Nullable
  public static String getGroup(@NonNull Notification paramNotification) {
    return c.e(paramNotification);
  }
  
  public static int getGroupAlertBehavior(@NonNull Notification paramNotification) {
    return (Build.VERSION.SDK_INT >= 26) ? f.c(paramNotification) : 0;
  }
  
  static boolean getHighPriority(@NonNull Notification paramNotification) {
    return ((paramNotification.flags & 0x80) != 0);
  }
  
  @NonNull
  @RequiresApi(21)
  public static List<b> getInvisibleActions(@NonNull Notification paramNotification) {
    ArrayList<b> arrayList = new ArrayList();
    Bundle bundle = paramNotification.extras.getBundle("android.car.EXTENSIONS");
    if (bundle == null)
      return arrayList; 
    bundle = bundle.getBundle("invisible_actions");
    if (bundle != null)
      for (int i = 0; i < bundle.size(); i++)
        arrayList.add(y1.c(bundle.getBundle(Integer.toString(i))));  
    return arrayList;
  }
  
  public static boolean getLocalOnly(@NonNull Notification paramNotification) {
    return ((paramNotification.flags & 0x100) != 0);
  }
  
  @Nullable
  public static androidx.core.content.k getLocusId(@NonNull Notification paramNotification) {
    int i = Build.VERSION.SDK_INT;
    androidx.core.content.k k = null;
    if (i >= 29) {
      LocusId locusId = h.d(paramNotification);
      if (locusId == null)
        return null; 
      k = androidx.core.content.k.c(locusId);
    } 
    return k;
  }
  
  @NonNull
  static Notification[] getNotificationArrayFromBundle(@NonNull Bundle paramBundle, @NonNull String paramString) {
    Parcelable[] arrayOfParcelable = paramBundle.getParcelableArray(paramString);
    if (arrayOfParcelable instanceof Notification[] || arrayOfParcelable == null)
      return (Notification[])arrayOfParcelable; 
    Notification[] arrayOfNotification = new Notification[arrayOfParcelable.length];
    for (int i = 0; i < arrayOfParcelable.length; i++)
      arrayOfNotification[i] = (Notification)arrayOfParcelable[i]; 
    paramBundle.putParcelableArray(paramString, (Parcelable[])arrayOfNotification);
    return arrayOfNotification;
  }
  
  public static boolean getOngoing(@NonNull Notification paramNotification) {
    return ((paramNotification.flags & 0x2) != 0);
  }
  
  public static boolean getOnlyAlertOnce(@NonNull Notification paramNotification) {
    return ((paramNotification.flags & 0x8) != 0);
  }
  
  @NonNull
  public static List<m2> getPeople(@NonNull Notification paramNotification) {
    Iterator<Person> iterator;
    ArrayList<m2> arrayList = new ArrayList();
    if (Build.VERSION.SDK_INT >= 28) {
      ArrayList arrayList1 = paramNotification.extras.getParcelableArrayList("android.people.list");
      if (arrayList1 != null && !arrayList1.isEmpty()) {
        iterator = arrayList1.iterator();
        while (iterator.hasNext())
          arrayList.add(m2.a(iterator.next())); 
      } 
    } else {
      String[] arrayOfString = ((Notification)iterator).extras.getStringArray("android.people");
      if (arrayOfString != null && arrayOfString.length != 0) {
        int j = arrayOfString.length;
        for (int i = 0; i < j; i++) {
          String str = arrayOfString[i];
          arrayList.add((new m2.b()).g(str).a());
        } 
      } 
    } 
    return arrayList;
  }
  
  @Nullable
  public static Notification getPublicVersion(@NonNull Notification paramNotification) {
    return paramNotification.publicVersion;
  }
  
  @Nullable
  public static CharSequence getSettingsText(@NonNull Notification paramNotification) {
    return (Build.VERSION.SDK_INT >= 26) ? f.d(paramNotification) : null;
  }
  
  @Nullable
  public static String getShortcutId(@NonNull Notification paramNotification) {
    return (Build.VERSION.SDK_INT >= 26) ? f.e(paramNotification) : null;
  }
  
  @RequiresApi(19)
  public static boolean getShowWhen(@NonNull Notification paramNotification) {
    return paramNotification.extras.getBoolean("android.showWhen");
  }
  
  @Nullable
  public static String getSortKey(@NonNull Notification paramNotification) {
    return c.i(paramNotification);
  }
  
  @Nullable
  @RequiresApi(19)
  public static CharSequence getSubText(@NonNull Notification paramNotification) {
    return paramNotification.extras.getCharSequence("android.subText");
  }
  
  public static long getTimeoutAfter(@NonNull Notification paramNotification) {
    return (Build.VERSION.SDK_INT >= 26) ? f.f(paramNotification) : 0L;
  }
  
  @RequiresApi(19)
  public static boolean getUsesChronometer(@NonNull Notification paramNotification) {
    return paramNotification.extras.getBoolean("android.showChronometer");
  }
  
  public static int getVisibility(@NonNull Notification paramNotification) {
    return paramNotification.visibility;
  }
  
  public static boolean isGroupSummary(@NonNull Notification paramNotification) {
    return ((paramNotification.flags & 0x200) != 0);
  }
  
  public static class b {
    final Bundle a;
    
    @Nullable
    private IconCompat b;
    
    private final o2[] c;
    
    private final o2[] d;
    
    private boolean e;
    
    boolean f = true;
    
    private final int g;
    
    private final boolean h;
    
    @Deprecated
    public int i;
    
    public CharSequence j;
    
    @Nullable
    public PendingIntent k;
    
    private boolean l;
    
    public b(int param1Int, @Nullable CharSequence param1CharSequence, @Nullable PendingIntent param1PendingIntent) {
      this(iconCompat, param1CharSequence, param1PendingIntent);
    }
    
    b(int param1Int1, @Nullable CharSequence param1CharSequence, @Nullable PendingIntent param1PendingIntent, @Nullable Bundle param1Bundle, @Nullable o2[] param1ArrayOfo21, @Nullable o2[] param1ArrayOfo22, boolean param1Boolean1, int param1Int2, boolean param1Boolean2, boolean param1Boolean3, boolean param1Boolean4) {
      this(iconCompat, param1CharSequence, param1PendingIntent, param1Bundle, param1ArrayOfo21, param1ArrayOfo22, param1Boolean1, param1Int2, param1Boolean2, param1Boolean3, param1Boolean4);
    }
    
    public b(@Nullable IconCompat param1IconCompat, @Nullable CharSequence param1CharSequence, @Nullable PendingIntent param1PendingIntent) {
      this(param1IconCompat, param1CharSequence, param1PendingIntent, new Bundle(), (o2[])null, (o2[])null, true, 0, true, false, false);
    }
    
    b(@Nullable IconCompat param1IconCompat, @Nullable CharSequence param1CharSequence, @Nullable PendingIntent param1PendingIntent, @Nullable Bundle param1Bundle, @Nullable o2[] param1ArrayOfo21, @Nullable o2[] param1ArrayOfo22, boolean param1Boolean1, int param1Int, boolean param1Boolean2, boolean param1Boolean3, boolean param1Boolean4) {
      this.b = param1IconCompat;
      if (param1IconCompat != null && param1IconCompat.r() == 2)
        this.i = param1IconCompat.o(); 
      this.j = NotificationCompat.m.k(param1CharSequence);
      this.k = param1PendingIntent;
      if (param1Bundle == null)
        param1Bundle = new Bundle(); 
      this.a = param1Bundle;
      this.c = param1ArrayOfo21;
      this.d = param1ArrayOfo22;
      this.e = param1Boolean1;
      this.g = param1Int;
      this.f = param1Boolean2;
      this.h = param1Boolean3;
      this.l = param1Boolean4;
    }
    
    @Nullable
    public PendingIntent a() {
      return this.k;
    }
    
    public boolean b() {
      return this.e;
    }
    
    @NonNull
    public Bundle c() {
      return this.a;
    }
    
    @Nullable
    public IconCompat d() {
      if (this.b == null) {
        int i = this.i;
        if (i != 0)
          this.b = IconCompat.m(null, "", i); 
      } 
      return this.b;
    }
    
    @Nullable
    public o2[] e() {
      return this.c;
    }
    
    public int f() {
      return this.g;
    }
    
    public boolean g() {
      return this.f;
    }
    
    @Nullable
    public CharSequence h() {
      return this.j;
    }
    
    public boolean i() {
      return this.l;
    }
    
    public boolean j() {
      return this.h;
    }
    
    public static final class a {
      private final IconCompat a;
      
      private final CharSequence b;
      
      private final PendingIntent c;
      
      private boolean d;
      
      private final Bundle e;
      
      private ArrayList<o2> f;
      
      private int g;
      
      private boolean h;
      
      private boolean i;
      
      private boolean j;
      
      public a(@Nullable IconCompat param2IconCompat, @Nullable CharSequence param2CharSequence, @Nullable PendingIntent param2PendingIntent) {
        this(param2IconCompat, param2CharSequence, param2PendingIntent, new Bundle(), null, true, 0, true, false, false);
      }
      
      private a(@Nullable IconCompat param2IconCompat, @Nullable CharSequence param2CharSequence, @Nullable PendingIntent param2PendingIntent, @NonNull Bundle param2Bundle, @Nullable o2[] param2ArrayOfo2, boolean param2Boolean1, int param2Int, boolean param2Boolean2, boolean param2Boolean3, boolean param2Boolean4) {
        ArrayList<o2> arrayList;
        this.d = true;
        this.h = true;
        this.a = param2IconCompat;
        this.b = NotificationCompat.m.k(param2CharSequence);
        this.c = param2PendingIntent;
        this.e = param2Bundle;
        if (param2ArrayOfo2 == null) {
          param2IconCompat = null;
        } else {
          arrayList = new ArrayList(Arrays.asList((Object[])param2ArrayOfo2));
        } 
        this.f = arrayList;
        this.d = param2Boolean1;
        this.g = param2Int;
        this.h = param2Boolean2;
        this.i = param2Boolean3;
        this.j = param2Boolean4;
      }
      
      private void c() {
        if (!this.i)
          return; 
        if (this.c != null)
          return; 
        throw new NullPointerException("Contextual Actions must contain a valid PendingIntent");
      }
      
      @NonNull
      public a a(@Nullable o2 param2o2) {
        if (this.f == null)
          this.f = new ArrayList<o2>(); 
        if (param2o2 != null)
          this.f.add(param2o2); 
        return this;
      }
      
      @NonNull
      public NotificationCompat.b b() {
        o2[] arrayOfO21;
        o2[] arrayOfO22;
        c();
        ArrayList<o2> arrayList1 = new ArrayList();
        ArrayList<o2> arrayList3 = new ArrayList();
        ArrayList<o2> arrayList2 = this.f;
        if (arrayList2 != null)
          for (o2 o2 : arrayList2) {
            if (o2.k()) {
              arrayList1.add(o2);
              continue;
            } 
            arrayList3.add(o2);
          }  
        boolean bool = arrayList1.isEmpty();
        arrayList2 = null;
        if (bool) {
          arrayList1 = null;
        } else {
          arrayOfO21 = arrayList1.<o2>toArray(new o2[arrayList1.size()]);
        } 
        if (!arrayList3.isEmpty())
          arrayOfO22 = arrayList3.<o2>toArray(new o2[arrayList3.size()]); 
        return new NotificationCompat.b(this.a, this.b, this.c, this.e, arrayOfO22, arrayOfO21, this.d, this.g, this.h, this.i, this.j);
      }
      
      @NonNull
      public a d(boolean param2Boolean) {
        this.d = param2Boolean;
        return this;
      }
      
      @NonNull
      public a e(boolean param2Boolean) {
        this.i = param2Boolean;
        return this;
      }
      
      @NonNull
      public a f(boolean param2Boolean) {
        this.h = param2Boolean;
        return this;
      }
    }
  }
  
  public static final class a {
    private final IconCompat a;
    
    private final CharSequence b;
    
    private final PendingIntent c;
    
    private boolean d;
    
    private final Bundle e;
    
    private ArrayList<o2> f;
    
    private int g;
    
    private boolean h;
    
    private boolean i;
    
    private boolean j;
    
    public a(@Nullable IconCompat param1IconCompat, @Nullable CharSequence param1CharSequence, @Nullable PendingIntent param1PendingIntent) {
      this(param1IconCompat, param1CharSequence, param1PendingIntent, new Bundle(), null, true, 0, true, false, false);
    }
    
    private a(@Nullable IconCompat param1IconCompat, @Nullable CharSequence param1CharSequence, @Nullable PendingIntent param1PendingIntent, @NonNull Bundle param1Bundle, @Nullable o2[] param1ArrayOfo2, boolean param1Boolean1, int param1Int, boolean param1Boolean2, boolean param1Boolean3, boolean param1Boolean4) {
      ArrayList<o2> arrayList;
      this.d = true;
      this.h = true;
      this.a = param1IconCompat;
      this.b = NotificationCompat.m.k(param1CharSequence);
      this.c = param1PendingIntent;
      this.e = param1Bundle;
      if (param1ArrayOfo2 == null) {
        param1IconCompat = null;
      } else {
        arrayList = new ArrayList(Arrays.asList((Object[])param1ArrayOfo2));
      } 
      this.f = arrayList;
      this.d = param1Boolean1;
      this.g = param1Int;
      this.h = param1Boolean2;
      this.i = param1Boolean3;
      this.j = param1Boolean4;
    }
    
    private void c() {
      if (!this.i)
        return; 
      if (this.c != null)
        return; 
      throw new NullPointerException("Contextual Actions must contain a valid PendingIntent");
    }
    
    @NonNull
    public a a(@Nullable o2 param1o2) {
      if (this.f == null)
        this.f = new ArrayList<o2>(); 
      if (param1o2 != null)
        this.f.add(param1o2); 
      return this;
    }
    
    @NonNull
    public NotificationCompat.b b() {
      o2[] arrayOfO21;
      o2[] arrayOfO22;
      c();
      ArrayList<o2> arrayList1 = new ArrayList();
      ArrayList<o2> arrayList3 = new ArrayList();
      ArrayList<o2> arrayList2 = this.f;
      if (arrayList2 != null)
        for (o2 o2 : arrayList2) {
          if (o2.k()) {
            arrayList1.add(o2);
            continue;
          } 
          arrayList3.add(o2);
        }  
      boolean bool = arrayList1.isEmpty();
      arrayList2 = null;
      if (bool) {
        arrayList1 = null;
      } else {
        arrayOfO21 = arrayList1.<o2>toArray(new o2[arrayList1.size()]);
      } 
      if (!arrayList3.isEmpty())
        arrayOfO22 = arrayList3.<o2>toArray(new o2[arrayList3.size()]); 
      return new NotificationCompat.b(this.a, this.b, this.c, this.e, arrayOfO22, arrayOfO21, this.d, this.g, this.h, this.i, this.j);
    }
    
    @NonNull
    public a d(boolean param1Boolean) {
      this.d = param1Boolean;
      return this;
    }
    
    @NonNull
    public a e(boolean param1Boolean) {
      this.i = param1Boolean;
      return this;
    }
    
    @NonNull
    public a f(boolean param1Boolean) {
      this.h = param1Boolean;
      return this;
    }
  }
  
  @RequiresApi(20)
  static class c {
    static boolean a(RemoteInput param1RemoteInput) {
      return param1RemoteInput.getAllowFreeFormInput();
    }
    
    static CharSequence[] b(RemoteInput param1RemoteInput) {
      return param1RemoteInput.getChoices();
    }
    
    static Bundle c(Notification.Action param1Action) {
      return param1Action.getExtras();
    }
    
    static Bundle d(RemoteInput param1RemoteInput) {
      return param1RemoteInput.getExtras();
    }
    
    static String e(Notification param1Notification) {
      return param1Notification.getGroup();
    }
    
    static CharSequence f(RemoteInput param1RemoteInput) {
      return param1RemoteInput.getLabel();
    }
    
    static RemoteInput[] g(Notification.Action param1Action) {
      return param1Action.getRemoteInputs();
    }
    
    static String h(RemoteInput param1RemoteInput) {
      return param1RemoteInput.getResultKey();
    }
    
    static String i(Notification param1Notification) {
      return param1Notification.getSortKey();
    }
  }
  
  @RequiresApi(23)
  static class d {
    static Icon a(Notification.Action param1Action) {
      return e0.a(param1Action);
    }
  }
  
  @RequiresApi(24)
  static class e {
    static boolean a(Notification.Action param1Action) {
      return f0.a(param1Action);
    }
  }
  
  @RequiresApi(26)
  static class f {
    static int a(Notification param1Notification) {
      return l0.a(param1Notification);
    }
    
    static String b(Notification param1Notification) {
      return j0.a(param1Notification);
    }
    
    static int c(Notification param1Notification) {
      return g0.a(param1Notification);
    }
    
    static CharSequence d(Notification param1Notification) {
      return k0.a(param1Notification);
    }
    
    static String e(Notification param1Notification) {
      return i0.a(param1Notification);
    }
    
    static long f(Notification param1Notification) {
      return h0.a(param1Notification);
    }
  }
  
  @RequiresApi(28)
  static class g {
    static int a(Notification.Action param1Action) {
      return m0.a(param1Action);
    }
  }
  
  @RequiresApi(29)
  static class h {
    static boolean a(Notification param1Notification) {
      return q0.a(param1Notification);
    }
    
    static Notification.BubbleMetadata b(Notification param1Notification) {
      return n0.a(param1Notification);
    }
    
    static int c(RemoteInput param1RemoteInput) {
      return r0.a(param1RemoteInput);
    }
    
    static LocusId d(Notification param1Notification) {
      return p0.a(param1Notification);
    }
    
    static boolean e(Notification.Action param1Action) {
      return o0.a(param1Action);
    }
  }
  
  @RequiresApi(31)
  static class i {
    static boolean a(Notification.Action param1Action) {
      return s0.a(param1Action);
    }
  }
  
  public static class j extends r {
    private IconCompat e;
    
    private IconCompat f;
    
    private boolean g;
    
    private CharSequence h;
    
    private boolean i;
    
    @Nullable
    private static IconCompat w(@Nullable Parcelable param1Parcelable) {
      if (param1Parcelable != null) {
        if (Build.VERSION.SDK_INT >= 23 && param1Parcelable instanceof Icon)
          return IconCompat.c((Icon)param1Parcelable); 
        if (param1Parcelable instanceof Bitmap)
          return IconCompat.h((Bitmap)param1Parcelable); 
      } 
      return null;
    }
    
    @Nullable
    public static IconCompat z(@Nullable Bundle param1Bundle) {
      if (param1Bundle == null)
        return null; 
      Parcelable parcelable = param1Bundle.getParcelable("android.picture");
      return (parcelable != null) ? w(parcelable) : w(param1Bundle.getParcelable("android.pictureIcon"));
    }
    
    @NonNull
    public j A(@Nullable CharSequence param1CharSequence) {
      this.b = NotificationCompat.m.k(param1CharSequence);
      return this;
    }
    
    @NonNull
    public j B(@Nullable CharSequence param1CharSequence) {
      this.c = NotificationCompat.m.k(param1CharSequence);
      this.d = true;
      return this;
    }
    
    public void b(t param1t) {
      int i = Build.VERSION.SDK_INT;
      Notification.BigPictureStyle bigPictureStyle2 = a.c(a.b(param1t.a()), this.b);
      IconCompat iconCompat = this.e;
      Context context = null;
      Notification.BigPictureStyle bigPictureStyle1 = bigPictureStyle2;
      if (iconCompat != null)
        if (i >= 31) {
          if (param1t instanceof g1) {
            Context context1 = ((g1)param1t).f();
          } else {
            bigPictureStyle1 = null;
          } 
          c.a(bigPictureStyle2, this.e.A((Context)bigPictureStyle1));
          bigPictureStyle1 = bigPictureStyle2;
        } else {
          bigPictureStyle1 = bigPictureStyle2;
          if (iconCompat.r() == 1)
            bigPictureStyle1 = a.a(bigPictureStyle2, this.e.n()); 
        }  
      if (this.g) {
        IconCompat iconCompat1 = this.f;
        if (iconCompat1 == null) {
          a.d(bigPictureStyle1, null);
        } else if (i >= 23) {
          if (param1t instanceof g1)
            context = ((g1)param1t).f(); 
          b.a(bigPictureStyle1, this.f.A(context));
        } else if (iconCompat1.r() == 1) {
          a.d(bigPictureStyle1, this.f.n());
        } else {
          a.d(bigPictureStyle1, null);
        } 
      } 
      if (this.d)
        a.e(bigPictureStyle1, this.c); 
      if (i >= 31) {
        c.c(bigPictureStyle1, this.i);
        c.b(bigPictureStyle1, this.h);
      } 
    }
    
    @NonNull
    protected String p() {
      return "androidx.core.app.NotificationCompat$BigPictureStyle";
    }
    
    protected void u(@NonNull Bundle param1Bundle) {
      super.u(param1Bundle);
      if (param1Bundle.containsKey("android.largeIcon.big")) {
        this.f = w(param1Bundle.getParcelable("android.largeIcon.big"));
        this.g = true;
      } 
      this.e = z(param1Bundle);
      this.i = param1Bundle.getBoolean("android.showBigPictureWhenCollapsed");
    }
    
    @NonNull
    public j x(@Nullable Bitmap param1Bitmap) {
      IconCompat iconCompat;
      if (param1Bitmap == null) {
        param1Bitmap = null;
      } else {
        iconCompat = IconCompat.h(param1Bitmap);
      } 
      this.f = iconCompat;
      this.g = true;
      return this;
    }
    
    @NonNull
    public j y(@Nullable Bitmap param1Bitmap) {
      IconCompat iconCompat;
      if (param1Bitmap == null) {
        param1Bitmap = null;
      } else {
        iconCompat = IconCompat.h(param1Bitmap);
      } 
      this.e = iconCompat;
      return this;
    }
    
    @RequiresApi(16)
    private static class a {
      static Notification.BigPictureStyle a(Notification.BigPictureStyle param2BigPictureStyle, Bitmap param2Bitmap) {
        return param2BigPictureStyle.bigPicture(param2Bitmap);
      }
      
      static Notification.BigPictureStyle b(Notification.Builder param2Builder) {
        return new Notification.BigPictureStyle(param2Builder);
      }
      
      static Notification.BigPictureStyle c(Notification.BigPictureStyle param2BigPictureStyle, CharSequence param2CharSequence) {
        return param2BigPictureStyle.setBigContentTitle(param2CharSequence);
      }
      
      @RequiresApi(16)
      static void d(Notification.BigPictureStyle param2BigPictureStyle, Bitmap param2Bitmap) {
        param2BigPictureStyle.bigLargeIcon(param2Bitmap);
      }
      
      @RequiresApi(16)
      static void e(Notification.BigPictureStyle param2BigPictureStyle, CharSequence param2CharSequence) {
        param2BigPictureStyle.setSummaryText(param2CharSequence);
      }
    }
    
    @RequiresApi(23)
    private static class b {
      @RequiresApi(23)
      static void a(Notification.BigPictureStyle param2BigPictureStyle, Icon param2Icon) {
        t0.a(param2BigPictureStyle, param2Icon);
      }
    }
    
    @RequiresApi(31)
    private static class c {
      @RequiresApi(31)
      static void a(Notification.BigPictureStyle param2BigPictureStyle, Icon param2Icon) {
        v0.a(param2BigPictureStyle, param2Icon);
      }
      
      @RequiresApi(31)
      static void b(Notification.BigPictureStyle param2BigPictureStyle, CharSequence param2CharSequence) {
        w0.a(param2BigPictureStyle, param2CharSequence);
      }
      
      @RequiresApi(31)
      static void c(Notification.BigPictureStyle param2BigPictureStyle, boolean param2Boolean) {
        u0.a(param2BigPictureStyle, param2Boolean);
      }
    }
  }
  
  @RequiresApi(16)
  private static class a {
    static Notification.BigPictureStyle a(Notification.BigPictureStyle param1BigPictureStyle, Bitmap param1Bitmap) {
      return param1BigPictureStyle.bigPicture(param1Bitmap);
    }
    
    static Notification.BigPictureStyle b(Notification.Builder param1Builder) {
      return new Notification.BigPictureStyle(param1Builder);
    }
    
    static Notification.BigPictureStyle c(Notification.BigPictureStyle param1BigPictureStyle, CharSequence param1CharSequence) {
      return param1BigPictureStyle.setBigContentTitle(param1CharSequence);
    }
    
    @RequiresApi(16)
    static void d(Notification.BigPictureStyle param1BigPictureStyle, Bitmap param1Bitmap) {
      param1BigPictureStyle.bigLargeIcon(param1Bitmap);
    }
    
    @RequiresApi(16)
    static void e(Notification.BigPictureStyle param1BigPictureStyle, CharSequence param1CharSequence) {
      param1BigPictureStyle.setSummaryText(param1CharSequence);
    }
  }
  
  @RequiresApi(23)
  private static class b {
    @RequiresApi(23)
    static void a(Notification.BigPictureStyle param1BigPictureStyle, Icon param1Icon) {
      t0.a(param1BigPictureStyle, param1Icon);
    }
  }
  
  @RequiresApi(31)
  private static class c {
    @RequiresApi(31)
    static void a(Notification.BigPictureStyle param1BigPictureStyle, Icon param1Icon) {
      v0.a(param1BigPictureStyle, param1Icon);
    }
    
    @RequiresApi(31)
    static void b(Notification.BigPictureStyle param1BigPictureStyle, CharSequence param1CharSequence) {
      w0.a(param1BigPictureStyle, param1CharSequence);
    }
    
    @RequiresApi(31)
    static void c(Notification.BigPictureStyle param1BigPictureStyle, boolean param1Boolean) {
      u0.a(param1BigPictureStyle, param1Boolean);
    }
  }
  
  public static class k extends r {
    private CharSequence e;
    
    public void a(@NonNull Bundle param1Bundle) {
      super.a(param1Bundle);
    }
    
    public void b(t param1t) {
      Notification.BigTextStyle bigTextStyle = a.a(a.c(a.b(param1t.a()), this.b), this.e);
      if (this.d)
        a.d(bigTextStyle, this.c); 
    }
    
    @NonNull
    protected String p() {
      return "androidx.core.app.NotificationCompat$BigTextStyle";
    }
    
    protected void u(@NonNull Bundle param1Bundle) {
      super.u(param1Bundle);
      this.e = param1Bundle.getCharSequence("android.bigText");
    }
    
    @NonNull
    public k w(@Nullable CharSequence param1CharSequence) {
      this.e = NotificationCompat.m.k(param1CharSequence);
      return this;
    }
    
    @NonNull
    public k x(@Nullable CharSequence param1CharSequence) {
      this.b = NotificationCompat.m.k(param1CharSequence);
      return this;
    }
    
    @NonNull
    public k y(@Nullable CharSequence param1CharSequence) {
      this.c = NotificationCompat.m.k(param1CharSequence);
      this.d = true;
      return this;
    }
    
    @RequiresApi(16)
    static class a {
      static Notification.BigTextStyle a(Notification.BigTextStyle param2BigTextStyle, CharSequence param2CharSequence) {
        return param2BigTextStyle.bigText(param2CharSequence);
      }
      
      static Notification.BigTextStyle b(Notification.Builder param2Builder) {
        return new Notification.BigTextStyle(param2Builder);
      }
      
      static Notification.BigTextStyle c(Notification.BigTextStyle param2BigTextStyle, CharSequence param2CharSequence) {
        return param2BigTextStyle.setBigContentTitle(param2CharSequence);
      }
      
      static Notification.BigTextStyle d(Notification.BigTextStyle param2BigTextStyle, CharSequence param2CharSequence) {
        return param2BigTextStyle.setSummaryText(param2CharSequence);
      }
    }
  }
  
  @RequiresApi(16)
  static class a {
    static Notification.BigTextStyle a(Notification.BigTextStyle param1BigTextStyle, CharSequence param1CharSequence) {
      return param1BigTextStyle.bigText(param1CharSequence);
    }
    
    static Notification.BigTextStyle b(Notification.Builder param1Builder) {
      return new Notification.BigTextStyle(param1Builder);
    }
    
    static Notification.BigTextStyle c(Notification.BigTextStyle param1BigTextStyle, CharSequence param1CharSequence) {
      return param1BigTextStyle.setBigContentTitle(param1CharSequence);
    }
    
    static Notification.BigTextStyle d(Notification.BigTextStyle param1BigTextStyle, CharSequence param1CharSequence) {
      return param1BigTextStyle.setSummaryText(param1CharSequence);
    }
  }
  
  public static final class l {
    private PendingIntent a;
    
    private PendingIntent b;
    
    private IconCompat c;
    
    private int d;
    
    private int e;
    
    private int f;
    
    private String g;
    
    private l(@Nullable PendingIntent param1PendingIntent1, @Nullable PendingIntent param1PendingIntent2, @Nullable IconCompat param1IconCompat, int param1Int1, int param1Int2, int param1Int3, @Nullable String param1String) {
      this.a = param1PendingIntent1;
      this.c = param1IconCompat;
      this.d = param1Int1;
      this.e = param1Int2;
      this.b = param1PendingIntent2;
      this.f = param1Int3;
      this.g = param1String;
    }
    
    @Nullable
    public static l a(@Nullable Notification.BubbleMetadata param1BubbleMetadata) {
      if (param1BubbleMetadata == null)
        return null; 
      int i = Build.VERSION.SDK_INT;
      return (i >= 30) ? b.a(param1BubbleMetadata) : ((i == 29) ? a.a(param1BubbleMetadata) : null);
    }
    
    @Nullable
    public static Notification.BubbleMetadata k(@Nullable l param1l) {
      if (param1l == null)
        return null; 
      int i = Build.VERSION.SDK_INT;
      return (i >= 30) ? b.b(param1l) : ((i == 29) ? a.b(param1l) : null);
    }
    
    public boolean b() {
      return ((this.f & 0x1) != 0);
    }
    
    @Nullable
    public PendingIntent c() {
      return this.b;
    }
    
    public int d() {
      return this.d;
    }
    
    public int e() {
      return this.e;
    }
    
    @Nullable
    public IconCompat f() {
      return this.c;
    }
    
    @Nullable
    public PendingIntent g() {
      return this.a;
    }
    
    @Nullable
    public String h() {
      return this.g;
    }
    
    public boolean i() {
      return ((this.f & 0x2) != 0);
    }
    
    public void j(int param1Int) {
      this.f = param1Int;
    }
    
    @RequiresApi(29)
    private static class a {
      @Nullable
      @RequiresApi(29)
      static NotificationCompat.l a(@Nullable Notification.BubbleMetadata param2BubbleMetadata) {
        if (param2BubbleMetadata == null)
          return null; 
        if (param2BubbleMetadata.getIntent() == null)
          return null; 
        NotificationCompat.l.c c = (new NotificationCompat.l.c(param2BubbleMetadata.getIntent(), IconCompat.c(param2BubbleMetadata.getIcon()))).b(param2BubbleMetadata.getAutoExpandBubble()).c(param2BubbleMetadata.getDeleteIntent()).g(param2BubbleMetadata.isNotificationSuppressed());
        if (param2BubbleMetadata.getDesiredHeight() != 0)
          c.d(param2BubbleMetadata.getDesiredHeight()); 
        if (param2BubbleMetadata.getDesiredHeightResId() != 0)
          c.e(param2BubbleMetadata.getDesiredHeightResId()); 
        return c.a();
      }
      
      @Nullable
      @RequiresApi(29)
      static Notification.BubbleMetadata b(@Nullable NotificationCompat.l param2l) {
        if (param2l == null)
          return null; 
        if (param2l.g() == null)
          return null; 
        Notification.BubbleMetadata.Builder builder = (new Notification.BubbleMetadata.Builder()).setIcon(param2l.f().z()).setIntent(param2l.g()).setDeleteIntent(param2l.c()).setAutoExpandBubble(param2l.b()).setSuppressNotification(param2l.i());
        if (param2l.d() != 0)
          builder.setDesiredHeight(param2l.d()); 
        if (param2l.e() != 0)
          builder.setDesiredHeightResId(param2l.e()); 
        return builder.build();
      }
    }
    
    @RequiresApi(30)
    private static class b {
      @Nullable
      @RequiresApi(30)
      static NotificationCompat.l a(@Nullable Notification.BubbleMetadata param2BubbleMetadata) {
        NotificationCompat.l.c c;
        if (param2BubbleMetadata == null)
          return null; 
        if (x0.a(param2BubbleMetadata) != null) {
          c = new NotificationCompat.l.c(x0.a(param2BubbleMetadata));
        } else {
          c = new NotificationCompat.l.c(param2BubbleMetadata.getIntent(), IconCompat.c(param2BubbleMetadata.getIcon()));
        } 
        c.b(param2BubbleMetadata.getAutoExpandBubble()).c(param2BubbleMetadata.getDeleteIntent()).g(param2BubbleMetadata.isNotificationSuppressed());
        if (param2BubbleMetadata.getDesiredHeight() != 0)
          c.d(param2BubbleMetadata.getDesiredHeight()); 
        if (param2BubbleMetadata.getDesiredHeightResId() != 0)
          c.e(param2BubbleMetadata.getDesiredHeightResId()); 
        return c.a();
      }
      
      @Nullable
      @RequiresApi(30)
      static Notification.BubbleMetadata b(@Nullable NotificationCompat.l param2l) {
        Notification.BubbleMetadata.Builder builder;
        if (param2l == null)
          return null; 
        if (param2l.h() != null) {
          builder = new Notification.BubbleMetadata.Builder(param2l.h());
        } else {
          builder = new Notification.BubbleMetadata.Builder(param2l.g(), param2l.f().z());
        } 
        builder.setDeleteIntent(param2l.c()).setAutoExpandBubble(param2l.b()).setSuppressNotification(param2l.i());
        if (param2l.d() != 0)
          builder.setDesiredHeight(param2l.d()); 
        if (param2l.e() != 0)
          builder.setDesiredHeightResId(param2l.e()); 
        return builder.build();
      }
    }
    
    public static final class c {
      private PendingIntent a;
      
      private IconCompat b;
      
      private int c;
      
      private int d;
      
      private int e;
      
      private PendingIntent f;
      
      private String g;
      
      public c(@NonNull PendingIntent param2PendingIntent, @NonNull IconCompat param2IconCompat) {
        if (param2PendingIntent != null) {
          if (param2IconCompat != null) {
            this.a = param2PendingIntent;
            this.b = param2IconCompat;
            return;
          } 
          throw new NullPointerException("Bubbles require non-null icon");
        } 
        throw new NullPointerException("Bubble requires non-null pending intent");
      }
      
      @RequiresApi(30)
      public c(@NonNull String param2String) {
        if (!TextUtils.isEmpty(param2String)) {
          this.g = param2String;
          return;
        } 
        throw new NullPointerException("Bubble requires a non-null shortcut id");
      }
      
      @NonNull
      private c f(int param2Int, boolean param2Boolean) {
        if (param2Boolean) {
          this.e = param2Int | this.e;
          return this;
        } 
        this.e = param2Int & this.e;
        return this;
      }
      
      @NonNull
      public NotificationCompat.l a() {
        String str = this.g;
        if (str != null || this.a != null) {
          if (str != null || this.b != null) {
            NotificationCompat.l l = new NotificationCompat.l(this.a, this.f, this.b, this.c, this.d, this.e, str, null);
            l.j(this.e);
            return l;
          } 
          throw new NullPointerException("Must supply an icon or shortcut for the bubble");
        } 
        throw new NullPointerException("Must supply pending intent or shortcut to bubble");
      }
      
      @NonNull
      public c b(boolean param2Boolean) {
        f(1, param2Boolean);
        return this;
      }
      
      @NonNull
      public c c(@Nullable PendingIntent param2PendingIntent) {
        this.f = param2PendingIntent;
        return this;
      }
      
      @NonNull
      public c d(int param2Int) {
        this.c = Math.max(param2Int, 0);
        this.d = 0;
        return this;
      }
      
      @NonNull
      public c e(int param2Int) {
        this.d = param2Int;
        this.c = 0;
        return this;
      }
      
      @NonNull
      public c g(boolean param2Boolean) {
        f(2, param2Boolean);
        return this;
      }
    }
  }
  
  @RequiresApi(29)
  private static class a {
    @Nullable
    @RequiresApi(29)
    static NotificationCompat.l a(@Nullable Notification.BubbleMetadata param1BubbleMetadata) {
      if (param1BubbleMetadata == null)
        return null; 
      if (param1BubbleMetadata.getIntent() == null)
        return null; 
      NotificationCompat.l.c c = (new NotificationCompat.l.c(param1BubbleMetadata.getIntent(), IconCompat.c(param1BubbleMetadata.getIcon()))).b(param1BubbleMetadata.getAutoExpandBubble()).c(param1BubbleMetadata.getDeleteIntent()).g(param1BubbleMetadata.isNotificationSuppressed());
      if (param1BubbleMetadata.getDesiredHeight() != 0)
        c.d(param1BubbleMetadata.getDesiredHeight()); 
      if (param1BubbleMetadata.getDesiredHeightResId() != 0)
        c.e(param1BubbleMetadata.getDesiredHeightResId()); 
      return c.a();
    }
    
    @Nullable
    @RequiresApi(29)
    static Notification.BubbleMetadata b(@Nullable NotificationCompat.l param1l) {
      if (param1l == null)
        return null; 
      if (param1l.g() == null)
        return null; 
      Notification.BubbleMetadata.Builder builder = (new Notification.BubbleMetadata.Builder()).setIcon(param1l.f().z()).setIntent(param1l.g()).setDeleteIntent(param1l.c()).setAutoExpandBubble(param1l.b()).setSuppressNotification(param1l.i());
      if (param1l.d() != 0)
        builder.setDesiredHeight(param1l.d()); 
      if (param1l.e() != 0)
        builder.setDesiredHeightResId(param1l.e()); 
      return builder.build();
    }
  }
  
  @RequiresApi(30)
  private static class b {
    @Nullable
    @RequiresApi(30)
    static NotificationCompat.l a(@Nullable Notification.BubbleMetadata param1BubbleMetadata) {
      NotificationCompat.l.c c;
      if (param1BubbleMetadata == null)
        return null; 
      if (x0.a(param1BubbleMetadata) != null) {
        c = new NotificationCompat.l.c(x0.a(param1BubbleMetadata));
      } else {
        c = new NotificationCompat.l.c(param1BubbleMetadata.getIntent(), IconCompat.c(param1BubbleMetadata.getIcon()));
      } 
      c.b(param1BubbleMetadata.getAutoExpandBubble()).c(param1BubbleMetadata.getDeleteIntent()).g(param1BubbleMetadata.isNotificationSuppressed());
      if (param1BubbleMetadata.getDesiredHeight() != 0)
        c.d(param1BubbleMetadata.getDesiredHeight()); 
      if (param1BubbleMetadata.getDesiredHeightResId() != 0)
        c.e(param1BubbleMetadata.getDesiredHeightResId()); 
      return c.a();
    }
    
    @Nullable
    @RequiresApi(30)
    static Notification.BubbleMetadata b(@Nullable NotificationCompat.l param1l) {
      Notification.BubbleMetadata.Builder builder;
      if (param1l == null)
        return null; 
      if (param1l.h() != null) {
        builder = new Notification.BubbleMetadata.Builder(param1l.h());
      } else {
        builder = new Notification.BubbleMetadata.Builder(param1l.g(), param1l.f().z());
      } 
      builder.setDeleteIntent(param1l.c()).setAutoExpandBubble(param1l.b()).setSuppressNotification(param1l.i());
      if (param1l.d() != 0)
        builder.setDesiredHeight(param1l.d()); 
      if (param1l.e() != 0)
        builder.setDesiredHeightResId(param1l.e()); 
      return builder.build();
    }
  }
  
  public static final class c {
    private PendingIntent a;
    
    private IconCompat b;
    
    private int c;
    
    private int d;
    
    private int e;
    
    private PendingIntent f;
    
    private String g;
    
    public c(@NonNull PendingIntent param1PendingIntent, @NonNull IconCompat param1IconCompat) {
      if (param1PendingIntent != null) {
        if (param1IconCompat != null) {
          this.a = param1PendingIntent;
          this.b = param1IconCompat;
          return;
        } 
        throw new NullPointerException("Bubbles require non-null icon");
      } 
      throw new NullPointerException("Bubble requires non-null pending intent");
    }
    
    @RequiresApi(30)
    public c(@NonNull String param1String) {
      if (!TextUtils.isEmpty(param1String)) {
        this.g = param1String;
        return;
      } 
      throw new NullPointerException("Bubble requires a non-null shortcut id");
    }
    
    @NonNull
    private c f(int param1Int, boolean param1Boolean) {
      if (param1Boolean) {
        this.e = param1Int | this.e;
        return this;
      } 
      this.e = param1Int & this.e;
      return this;
    }
    
    @NonNull
    public NotificationCompat.l a() {
      String str = this.g;
      if (str != null || this.a != null) {
        if (str != null || this.b != null) {
          NotificationCompat.l l = new NotificationCompat.l(this.a, this.f, this.b, this.c, this.d, this.e, str, null);
          l.j(this.e);
          return l;
        } 
        throw new NullPointerException("Must supply an icon or shortcut for the bubble");
      } 
      throw new NullPointerException("Must supply pending intent or shortcut to bubble");
    }
    
    @NonNull
    public c b(boolean param1Boolean) {
      f(1, param1Boolean);
      return this;
    }
    
    @NonNull
    public c c(@Nullable PendingIntent param1PendingIntent) {
      this.f = param1PendingIntent;
      return this;
    }
    
    @NonNull
    public c d(int param1Int) {
      this.c = Math.max(param1Int, 0);
      this.d = 0;
      return this;
    }
    
    @NonNull
    public c e(int param1Int) {
      this.d = param1Int;
      this.c = 0;
      return this;
    }
    
    @NonNull
    public c g(boolean param1Boolean) {
      f(2, param1Boolean);
      return this;
    }
  }
  
  public static class m {
    boolean A = false;
    
    boolean B;
    
    boolean C;
    
    String D;
    
    Bundle E;
    
    int F = 0;
    
    int G = 0;
    
    Notification H;
    
    RemoteViews I;
    
    RemoteViews J;
    
    RemoteViews K;
    
    String L;
    
    int M = 0;
    
    String N;
    
    androidx.core.content.k O;
    
    long P;
    
    int Q = 0;
    
    int R = 0;
    
    boolean S;
    
    NotificationCompat.l T;
    
    Notification U;
    
    boolean V;
    
    Object W;
    
    @Deprecated
    public ArrayList<String> X;
    
    public Context a;
    
    public ArrayList<NotificationCompat.b> b = new ArrayList<NotificationCompat.b>();
    
    @NonNull
    public ArrayList<m2> c = new ArrayList<m2>();
    
    ArrayList<NotificationCompat.b> d = new ArrayList<NotificationCompat.b>();
    
    CharSequence e;
    
    CharSequence f;
    
    PendingIntent g;
    
    PendingIntent h;
    
    RemoteViews i;
    
    Bitmap j;
    
    CharSequence k;
    
    int l;
    
    int m;
    
    boolean n = true;
    
    boolean o;
    
    boolean p;
    
    NotificationCompat.r q;
    
    CharSequence r;
    
    CharSequence s;
    
    CharSequence[] t;
    
    int u;
    
    int v;
    
    boolean w;
    
    String x;
    
    boolean y;
    
    String z;
    
    @Deprecated
    public m(@NonNull Context param1Context) {
      this(param1Context, null);
    }
    
    public m(@NonNull Context param1Context, @NonNull String param1String) {
      Notification notification = new Notification();
      this.U = notification;
      this.a = param1Context;
      this.L = param1String;
      notification.when = System.currentTimeMillis();
      this.U.audioStreamType = -1;
      this.m = 0;
      this.X = new ArrayList<String>();
      this.S = true;
    }
    
    @Nullable
    protected static CharSequence k(@Nullable CharSequence param1CharSequence) {
      if (param1CharSequence == null)
        return param1CharSequence; 
      CharSequence charSequence = param1CharSequence;
      if (param1CharSequence.length() > 5120)
        charSequence = param1CharSequence.subSequence(0, 5120); 
      return charSequence;
    }
    
    @Nullable
    private Bitmap l(@Nullable Bitmap param1Bitmap) {
      Bitmap bitmap = param1Bitmap;
      if (param1Bitmap != null) {
        if (Build.VERSION.SDK_INT >= 27)
          return param1Bitmap; 
        Resources resources = this.a.getResources();
        int i = resources.getDimensionPixelSize(x.c.b);
        int j = resources.getDimensionPixelSize(x.c.a);
        if (param1Bitmap.getWidth() <= i && param1Bitmap.getHeight() <= j)
          return param1Bitmap; 
        double d = Math.min(i / Math.max(1, param1Bitmap.getWidth()), j / Math.max(1, param1Bitmap.getHeight()));
        bitmap = Bitmap.createScaledBitmap(param1Bitmap, (int)Math.ceil(param1Bitmap.getWidth() * d), (int)Math.ceil(param1Bitmap.getHeight() * d), true);
      } 
      return bitmap;
    }
    
    private void x(int param1Int, boolean param1Boolean) {
      if (param1Boolean) {
        Notification notification1 = this.U;
        notification1.flags = param1Int | notification1.flags;
        return;
      } 
      Notification notification = this.U;
      notification.flags = param1Int & notification.flags;
    }
    
    @NonNull
    public m A(int param1Int) {
      this.Q = param1Int;
      return this;
    }
    
    @NonNull
    public m B(boolean param1Boolean) {
      this.y = param1Boolean;
      return this;
    }
    
    @NonNull
    public m C(@Nullable Bitmap param1Bitmap) {
      this.j = l(param1Bitmap);
      return this;
    }
    
    @NonNull
    public m D(int param1Int1, int param1Int2, int param1Int3) {
      Notification notification = this.U;
      notification.ledARGB = param1Int1;
      notification.ledOnMS = param1Int2;
      notification.ledOffMS = param1Int3;
      if (param1Int2 != 0 && param1Int3 != 0) {
        param1Int1 = 1;
      } else {
        param1Int1 = 0;
      } 
      notification.flags = param1Int1 | notification.flags & 0xFFFFFFFE;
      return this;
    }
    
    @NonNull
    public m E(boolean param1Boolean) {
      this.A = param1Boolean;
      return this;
    }
    
    @NonNull
    public m F(int param1Int) {
      this.l = param1Int;
      return this;
    }
    
    @NonNull
    public m G(boolean param1Boolean) {
      x(2, param1Boolean);
      return this;
    }
    
    @NonNull
    public m H(boolean param1Boolean) {
      x(8, param1Boolean);
      return this;
    }
    
    @NonNull
    public m I(int param1Int) {
      this.m = param1Int;
      return this;
    }
    
    @NonNull
    public m J(int param1Int1, int param1Int2, boolean param1Boolean) {
      this.u = param1Int1;
      this.v = param1Int2;
      this.w = param1Boolean;
      return this;
    }
    
    @NonNull
    public m K(@Nullable String param1String) {
      this.N = param1String;
      return this;
    }
    
    @NonNull
    public m L(boolean param1Boolean) {
      this.n = param1Boolean;
      return this;
    }
    
    @NonNull
    public m M(int param1Int) {
      this.U.icon = param1Int;
      return this;
    }
    
    @NonNull
    public m N(@Nullable Uri param1Uri) {
      Notification notification = this.U;
      notification.sound = param1Uri;
      notification.audioStreamType = -1;
      AudioAttributes.Builder builder = a.e(a.c(a.b(), 4), 5);
      this.U.audioAttributes = a.a(builder);
      return this;
    }
    
    @NonNull
    public m O(@Nullable NotificationCompat.r param1r) {
      if (this.q != param1r) {
        this.q = param1r;
        if (param1r != null)
          param1r.v(this); 
      } 
      return this;
    }
    
    @NonNull
    public m P(@Nullable CharSequence param1CharSequence) {
      this.r = k(param1CharSequence);
      return this;
    }
    
    @NonNull
    public m Q(@Nullable CharSequence param1CharSequence) {
      this.U.tickerText = k(param1CharSequence);
      return this;
    }
    
    @NonNull
    public m R(long param1Long) {
      this.P = param1Long;
      return this;
    }
    
    @NonNull
    public m S(boolean param1Boolean) {
      this.o = param1Boolean;
      return this;
    }
    
    @NonNull
    public m T(@Nullable long[] param1ArrayOflong) {
      this.U.vibrate = param1ArrayOflong;
      return this;
    }
    
    @NonNull
    public m U(int param1Int) {
      this.G = param1Int;
      return this;
    }
    
    @NonNull
    public m V(long param1Long) {
      this.U.when = param1Long;
      return this;
    }
    
    @NonNull
    public m a(int param1Int, @Nullable CharSequence param1CharSequence, @Nullable PendingIntent param1PendingIntent) {
      this.b.add(new NotificationCompat.b(param1Int, param1CharSequence, param1PendingIntent));
      return this;
    }
    
    @NonNull
    public m b(@Nullable NotificationCompat.b param1b) {
      if (param1b != null)
        this.b.add(param1b); 
      return this;
    }
    
    @NonNull
    public Notification c() {
      return (new g1(this)).c();
    }
    
    public RemoteViews d() {
      return this.J;
    }
    
    public int e() {
      return this.F;
    }
    
    public RemoteViews f() {
      return this.I;
    }
    
    @NonNull
    public Bundle g() {
      if (this.E == null)
        this.E = new Bundle(); 
      return this.E;
    }
    
    public RemoteViews h() {
      return this.K;
    }
    
    public int i() {
      return this.m;
    }
    
    public long j() {
      return this.n ? this.U.when : 0L;
    }
    
    @NonNull
    public m m(boolean param1Boolean) {
      x(16, param1Boolean);
      return this;
    }
    
    @NonNull
    public m n(@Nullable String param1String) {
      this.D = param1String;
      return this;
    }
    
    @NonNull
    public m o(@NonNull String param1String) {
      this.L = param1String;
      return this;
    }
    
    @NonNull
    @RequiresApi(24)
    public m p(boolean param1Boolean) {
      this.p = param1Boolean;
      g().putBoolean("android.chronometerCountDown", param1Boolean);
      return this;
    }
    
    @NonNull
    public m q(int param1Int) {
      this.F = param1Int;
      return this;
    }
    
    @NonNull
    public m r(boolean param1Boolean) {
      this.B = param1Boolean;
      this.C = true;
      return this;
    }
    
    @NonNull
    public m s(@Nullable PendingIntent param1PendingIntent) {
      this.g = param1PendingIntent;
      return this;
    }
    
    @NonNull
    public m t(@Nullable CharSequence param1CharSequence) {
      this.f = k(param1CharSequence);
      return this;
    }
    
    @NonNull
    public m u(@Nullable CharSequence param1CharSequence) {
      this.e = k(param1CharSequence);
      return this;
    }
    
    @NonNull
    public m v(int param1Int) {
      Notification notification = this.U;
      notification.defaults = param1Int;
      if ((param1Int & 0x4) != 0)
        notification.flags |= 0x1; 
      return this;
    }
    
    @NonNull
    public m w(@Nullable PendingIntent param1PendingIntent) {
      this.U.deleteIntent = param1PendingIntent;
      return this;
    }
    
    @NonNull
    public m y(@Nullable PendingIntent param1PendingIntent, boolean param1Boolean) {
      this.h = param1PendingIntent;
      x(128, param1Boolean);
      return this;
    }
    
    @NonNull
    public m z(@Nullable String param1String) {
      this.x = param1String;
      return this;
    }
    
    @RequiresApi(21)
    static class a {
      static AudioAttributes a(AudioAttributes.Builder param2Builder) {
        return param2Builder.build();
      }
      
      static AudioAttributes.Builder b() {
        return new AudioAttributes.Builder();
      }
      
      static AudioAttributes.Builder c(AudioAttributes.Builder param2Builder, int param2Int) {
        return param2Builder.setContentType(param2Int);
      }
      
      static AudioAttributes.Builder d(AudioAttributes.Builder param2Builder, int param2Int) {
        return param2Builder.setLegacyStreamType(param2Int);
      }
      
      static AudioAttributes.Builder e(AudioAttributes.Builder param2Builder, int param2Int) {
        return param2Builder.setUsage(param2Int);
      }
    }
  }
  
  @RequiresApi(21)
  static class a {
    static AudioAttributes a(AudioAttributes.Builder param1Builder) {
      return param1Builder.build();
    }
    
    static AudioAttributes.Builder b() {
      return new AudioAttributes.Builder();
    }
    
    static AudioAttributes.Builder c(AudioAttributes.Builder param1Builder, int param1Int) {
      return param1Builder.setContentType(param1Int);
    }
    
    static AudioAttributes.Builder d(AudioAttributes.Builder param1Builder, int param1Int) {
      return param1Builder.setLegacyStreamType(param1Int);
    }
    
    static AudioAttributes.Builder e(AudioAttributes.Builder param1Builder, int param1Int) {
      return param1Builder.setUsage(param1Int);
    }
  }
  
  public static class n extends r {
    private int e;
    
    private m2 f;
    
    private PendingIntent g;
    
    private PendingIntent h;
    
    private PendingIntent i;
    
    private boolean j;
    
    private Integer k;
    
    private Integer l;
    
    private IconCompat m;
    
    private CharSequence n;
    
    @NonNull
    @RequiresApi(20)
    private NotificationCompat.b A(int param1Int1, int param1Int2, Integer param1Integer, int param1Int3, PendingIntent param1PendingIntent) {
      Integer integer = param1Integer;
      if (param1Integer == null)
        integer = Integer.valueOf(androidx.core.content.a.getColor(this.a.a, param1Int3)); 
      SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
      spannableStringBuilder.append(this.a.a.getResources().getString(param1Int2));
      spannableStringBuilder.setSpan(new ForegroundColorSpan(integer.intValue()), 0, spannableStringBuilder.length(), 18);
      NotificationCompat.b b = (new NotificationCompat.b.a(IconCompat.l(this.a.a, param1Int1), (CharSequence)spannableStringBuilder, param1PendingIntent)).b();
      b.c().putBoolean("key_action_priority", true);
      return b;
    }
    
    @Nullable
    @RequiresApi(20)
    private NotificationCompat.b B() {
      int i = x.d.b;
      int j = x.d.a;
      PendingIntent pendingIntent = this.g;
      if (pendingIntent == null)
        return null; 
      boolean bool = this.j;
      if (!bool)
        i = j; 
      if (bool) {
        j = x.h.b;
      } else {
        j = x.h.a;
      } 
      return A(i, j, this.k, x.b.a, pendingIntent);
    }
    
    @NonNull
    @RequiresApi(20)
    private NotificationCompat.b C() {
      int i = x.d.c;
      PendingIntent pendingIntent = this.h;
      return (pendingIntent == null) ? A(i, x.h.d, this.l, x.b.b, this.i) : A(i, x.h.c, this.l, x.b.b, pendingIntent);
    }
    
    @RequiresApi(20)
    private static Notification.Action w(NotificationCompat.b param1b) {
      Notification.Action.Builder builder;
      Bundle bundle;
      int i = Build.VERSION.SDK_INT;
      byte b1 = 0;
      if (i >= 23) {
        Icon icon;
        IconCompat iconCompat = param1b.d();
        if (iconCompat == null) {
          iconCompat = null;
        } else {
          icon = iconCompat.z();
        } 
        builder = d.a(icon, param1b.h(), param1b.a());
      } else {
        boolean bool;
        IconCompat iconCompat = param1b.d();
        if (iconCompat != null && iconCompat.r() == 2) {
          bool = iconCompat.o();
        } else {
          bool = false;
        } 
        builder = b.e(bool, param1b.h(), param1b.a());
      } 
      if (param1b.c() != null) {
        bundle = new Bundle(param1b.c());
      } else {
        bundle = new Bundle();
      } 
      bundle.putBoolean("android.support.allowGeneratedReplies", param1b.b());
      if (i >= 24)
        e.b(builder, param1b.b()); 
      if (i >= 31)
        g.e(builder, param1b.i()); 
      b.b(builder, bundle);
      o2[] arrayOfO2 = param1b.e();
      if (arrayOfO2 != null) {
        RemoteInput[] arrayOfRemoteInput = o2.b(arrayOfO2);
        i = arrayOfRemoteInput.length;
        for (int j = b1; j < i; j++)
          b.c(builder, arrayOfRemoteInput[j]); 
      } 
      return b.d(builder);
    }
    
    @Nullable
    private String y() {
      int i = this.e;
      return (i != 1) ? ((i != 2) ? ((i != 3) ? null : this.a.a.getResources().getString(x.h.g)) : this.a.a.getResources().getString(x.h.f)) : this.a.a.getResources().getString(x.h.e);
    }
    
    private boolean z(NotificationCompat.b param1b) {
      return (param1b != null && param1b.c().getBoolean("key_action_priority"));
    }
    
    public void a(@NonNull Bundle param1Bundle) {
      super.a(param1Bundle);
      param1Bundle.putInt("android.callType", this.e);
      param1Bundle.putBoolean("android.callIsVideo", this.j);
      m2 m21 = this.f;
      if (m21 != null)
        if (Build.VERSION.SDK_INT >= 28) {
          param1Bundle.putParcelable("android.callPerson", (Parcelable)m21.j());
        } else {
          param1Bundle.putParcelable("android.callPersonCompat", (Parcelable)m21.k());
        }  
      IconCompat iconCompat = this.m;
      if (iconCompat != null)
        if (Build.VERSION.SDK_INT >= 23) {
          param1Bundle.putParcelable("android.verificationIcon", (Parcelable)iconCompat.A(this.a.a));
        } else {
          param1Bundle.putParcelable("android.verificationIconCompat", (Parcelable)iconCompat.y());
        }  
      param1Bundle.putCharSequence("android.verificationText", this.n);
      param1Bundle.putParcelable("android.answerIntent", (Parcelable)this.g);
      param1Bundle.putParcelable("android.declineIntent", (Parcelable)this.h);
      param1Bundle.putParcelable("android.hangUpIntent", (Parcelable)this.i);
      Integer integer = this.k;
      if (integer != null)
        param1Bundle.putInt("android.answerColor", integer.intValue()); 
      integer = this.l;
      if (integer != null)
        param1Bundle.putInt("android.declineColor", integer.intValue()); 
    }
    
    public void b(t param1t) {
      IconCompat iconCompat;
      Notification.CallStyle callStyle;
      int i = Build.VERSION.SDK_INT;
      StringBuilder stringBuilder1 = null;
      StringBuilder stringBuilder2 = null;
      if (i >= 31) {
        i = this.e;
        if (i != 1) {
          if (i != 2) {
            if (i != 3) {
              stringBuilder1 = stringBuilder2;
              if (Log.isLoggable("NotifCompat", 3)) {
                stringBuilder1 = new StringBuilder();
                stringBuilder1.append("Unrecognized call type in CallStyle: ");
                stringBuilder1.append(String.valueOf(this.e));
                Log.d("NotifCompat", stringBuilder1.toString());
                stringBuilder1 = stringBuilder2;
              } 
            } else {
              callStyle = g.c(this.f.j(), this.i, this.g);
            } 
          } else {
            callStyle = g.b(this.f.j(), this.i);
          } 
        } else {
          callStyle = g.a(this.f.j(), this.h, this.g);
        } 
        if (callStyle != null) {
          e.a(param1t.a());
          a.a(callStyle, param1t.a());
          Integer integer = this.k;
          if (integer != null)
            g.d(callStyle, integer.intValue()); 
          integer = this.l;
          if (integer != null)
            g.f(callStyle, integer.intValue()); 
          g.i(callStyle, this.n);
          iconCompat = this.m;
          if (iconCompat != null)
            g.h(callStyle, iconCompat.A(this.a.a)); 
          g.g(callStyle, this.j);
          return;
        } 
      } else {
        CharSequence charSequence1;
        Notification.Builder builder = iconCompat.a();
        m2 m22 = this.f;
        if (m22 != null) {
          charSequence1 = m22.e();
        } else {
          m22 = null;
        } 
        builder.setContentTitle((CharSequence)m22);
        Bundle bundle = this.a.E;
        Notification.CallStyle callStyle1 = callStyle;
        if (bundle != null) {
          callStyle1 = callStyle;
          if (bundle.containsKey("android.text"))
            charSequence1 = this.a.E.getCharSequence("android.text"); 
        } 
        CharSequence charSequence2 = charSequence1;
        if (charSequence1 == null)
          charSequence2 = y(); 
        builder.setContentText(charSequence2);
        m2 m21 = this.f;
        if (m21 != null) {
          if (i >= 23 && m21.c() != null)
            d.b(builder, this.f.c().A(this.a.a)); 
          if (i >= 28) {
            f.a(builder, this.f.j());
          } else {
            c.a(builder, this.f.f());
          } 
        } 
        ArrayList<NotificationCompat.b> arrayList = x();
        if (i >= 24)
          e.a(builder); 
        Iterator<NotificationCompat.b> iterator = arrayList.iterator();
        while (iterator.hasNext())
          b.a(builder, w(iterator.next())); 
        c.b(builder, "call");
      } 
    }
    
    @NonNull
    protected String p() {
      return "androidx.core.app.NotificationCompat$CallStyle";
    }
    
    protected void u(@NonNull Bundle param1Bundle) {
      super.u(param1Bundle);
      this.e = param1Bundle.getInt("android.callType");
      this.j = param1Bundle.getBoolean("android.callIsVideo");
      int i = Build.VERSION.SDK_INT;
      if (i >= 28 && param1Bundle.containsKey("android.callPerson")) {
        this.f = m2.a((Person)param1Bundle.getParcelable("android.callPerson"));
      } else if (param1Bundle.containsKey("android.callPersonCompat")) {
        this.f = m2.b(param1Bundle.getBundle("android.callPersonCompat"));
      } 
      if (i >= 23 && param1Bundle.containsKey("android.verificationIcon")) {
        this.m = IconCompat.c((Icon)param1Bundle.getParcelable("android.verificationIcon"));
      } else if (param1Bundle.containsKey("android.verificationIconCompat")) {
        this.m = IconCompat.b(param1Bundle.getBundle("android.verificationIconCompat"));
      } 
      this.n = param1Bundle.getCharSequence("android.verificationText");
      this.g = (PendingIntent)param1Bundle.getParcelable("android.answerIntent");
      this.h = (PendingIntent)param1Bundle.getParcelable("android.declineIntent");
      this.i = (PendingIntent)param1Bundle.getParcelable("android.hangUpIntent");
      boolean bool = param1Bundle.containsKey("android.answerColor");
      Integer integer2 = null;
      if (bool) {
        integer1 = Integer.valueOf(param1Bundle.getInt("android.answerColor"));
      } else {
        integer1 = null;
      } 
      this.k = integer1;
      Integer integer1 = integer2;
      if (param1Bundle.containsKey("android.declineColor"))
        integer1 = Integer.valueOf(param1Bundle.getInt("android.declineColor")); 
      this.l = integer1;
    }
    
    @NonNull
    @RequiresApi(20)
    public ArrayList<NotificationCompat.b> x() {
      NotificationCompat.b b2 = C();
      NotificationCompat.b b1 = B();
      ArrayList<NotificationCompat.b> arrayList1 = new ArrayList(3);
      arrayList1.add(b2);
      int i = 2;
      ArrayList<NotificationCompat.b> arrayList2 = this.a.b;
      int j = i;
      if (arrayList2 != null) {
        Iterator<NotificationCompat.b> iterator = arrayList2.iterator();
        while (true) {
          j = i;
          if (iterator.hasNext()) {
            NotificationCompat.b b = iterator.next();
            if (b.j()) {
              arrayList1.add(b);
              j = i;
            } else if (z(b)) {
              j = i;
            } else {
              j = i;
              if (i > 1) {
                arrayList1.add(b);
                j = i - 1;
              } 
            } 
            i = j;
            if (b1 != null) {
              i = j;
              if (j == 1) {
                arrayList1.add(b1);
                i = j - 1;
              } 
            } 
            continue;
          } 
          break;
        } 
      } 
      if (b1 != null && j >= 1)
        arrayList1.add(b1); 
      return arrayList1;
    }
    
    @RequiresApi(16)
    static class a {
      static void a(Notification.CallStyle param2CallStyle, Notification.Builder param2Builder) {
        param2CallStyle.setBuilder(param2Builder);
      }
    }
    
    @RequiresApi(20)
    static class b {
      static Notification.Builder a(Notification.Builder param2Builder, Notification.Action param2Action) {
        return param2Builder.addAction(param2Action);
      }
      
      static Notification.Action.Builder b(Notification.Action.Builder param2Builder, Bundle param2Bundle) {
        return param2Builder.addExtras(param2Bundle);
      }
      
      static Notification.Action.Builder c(Notification.Action.Builder param2Builder, RemoteInput param2RemoteInput) {
        return param2Builder.addRemoteInput(param2RemoteInput);
      }
      
      static Notification.Action d(Notification.Action.Builder param2Builder) {
        return param2Builder.build();
      }
      
      static Notification.Action.Builder e(int param2Int, CharSequence param2CharSequence, PendingIntent param2PendingIntent) {
        return new Notification.Action.Builder(param2Int, param2CharSequence, param2PendingIntent);
      }
    }
    
    @RequiresApi(21)
    static class c {
      static Notification.Builder a(Notification.Builder param2Builder, String param2String) {
        return param2Builder.addPerson(param2String);
      }
      
      static Notification.Builder b(Notification.Builder param2Builder, String param2String) {
        return param2Builder.setCategory(param2String);
      }
    }
    
    @RequiresApi(23)
    static class d {
      static Notification.Action.Builder a(Icon param2Icon, CharSequence param2CharSequence, PendingIntent param2PendingIntent) {
        return new Notification.Action.Builder(param2Icon, param2CharSequence, param2PendingIntent);
      }
      
      static void b(Notification.Builder param2Builder, Icon param2Icon) {
        y0.a(param2Builder, param2Icon);
      }
    }
    
    @RequiresApi(24)
    static class e {
      static Notification.Builder a(Notification.Builder param2Builder) {
        return z0.a(param2Builder, new Notification.Action[0]);
      }
      
      static Notification.Action.Builder b(Notification.Action.Builder param2Builder, boolean param2Boolean) {
        return a1.a(param2Builder, param2Boolean);
      }
    }
    
    @RequiresApi(28)
    static class f {
      static Notification.Builder a(Notification.Builder param2Builder, Person param2Person) {
        return b1.a(param2Builder, param2Person);
      }
    }
    
    @RequiresApi(31)
    static class g {
      static Notification.CallStyle a(@NonNull Person param2Person, @NonNull PendingIntent param2PendingIntent1, @NonNull PendingIntent param2PendingIntent2) {
        return Notification.CallStyle.forIncomingCall(param2Person, param2PendingIntent1, param2PendingIntent2);
      }
      
      static Notification.CallStyle b(@NonNull Person param2Person, @NonNull PendingIntent param2PendingIntent) {
        return Notification.CallStyle.forOngoingCall(param2Person, param2PendingIntent);
      }
      
      static Notification.CallStyle c(@NonNull Person param2Person, @NonNull PendingIntent param2PendingIntent1, @NonNull PendingIntent param2PendingIntent2) {
        return Notification.CallStyle.forScreeningCall(param2Person, param2PendingIntent1, param2PendingIntent2);
      }
      
      static Notification.CallStyle d(Notification.CallStyle param2CallStyle, int param2Int) {
        return param2CallStyle.setAnswerButtonColorHint(param2Int);
      }
      
      static Notification.Action.Builder e(Notification.Action.Builder param2Builder, boolean param2Boolean) {
        return c1.a(param2Builder, param2Boolean);
      }
      
      static Notification.CallStyle f(Notification.CallStyle param2CallStyle, int param2Int) {
        return param2CallStyle.setDeclineButtonColorHint(param2Int);
      }
      
      static Notification.CallStyle g(Notification.CallStyle param2CallStyle, boolean param2Boolean) {
        return param2CallStyle.setIsVideo(param2Boolean);
      }
      
      static Notification.CallStyle h(Notification.CallStyle param2CallStyle, @Nullable Icon param2Icon) {
        return param2CallStyle.setVerificationIcon(param2Icon);
      }
      
      static Notification.CallStyle i(Notification.CallStyle param2CallStyle, @Nullable CharSequence param2CharSequence) {
        return param2CallStyle.setVerificationText(param2CharSequence);
      }
    }
  }
  
  @RequiresApi(16)
  static class a {
    static void a(Notification.CallStyle param1CallStyle, Notification.Builder param1Builder) {
      param1CallStyle.setBuilder(param1Builder);
    }
  }
  
  @RequiresApi(20)
  static class b {
    static Notification.Builder a(Notification.Builder param1Builder, Notification.Action param1Action) {
      return param1Builder.addAction(param1Action);
    }
    
    static Notification.Action.Builder b(Notification.Action.Builder param1Builder, Bundle param1Bundle) {
      return param1Builder.addExtras(param1Bundle);
    }
    
    static Notification.Action.Builder c(Notification.Action.Builder param1Builder, RemoteInput param1RemoteInput) {
      return param1Builder.addRemoteInput(param1RemoteInput);
    }
    
    static Notification.Action d(Notification.Action.Builder param1Builder) {
      return param1Builder.build();
    }
    
    static Notification.Action.Builder e(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      return new Notification.Action.Builder(param1Int, param1CharSequence, param1PendingIntent);
    }
  }
  
  @RequiresApi(21)
  static class c {
    static Notification.Builder a(Notification.Builder param1Builder, String param1String) {
      return param1Builder.addPerson(param1String);
    }
    
    static Notification.Builder b(Notification.Builder param1Builder, String param1String) {
      return param1Builder.setCategory(param1String);
    }
  }
  
  @RequiresApi(23)
  static class d {
    static Notification.Action.Builder a(Icon param1Icon, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      return new Notification.Action.Builder(param1Icon, param1CharSequence, param1PendingIntent);
    }
    
    static void b(Notification.Builder param1Builder, Icon param1Icon) {
      y0.a(param1Builder, param1Icon);
    }
  }
  
  @RequiresApi(24)
  static class e {
    static Notification.Builder a(Notification.Builder param1Builder) {
      return z0.a(param1Builder, new Notification.Action[0]);
    }
    
    static Notification.Action.Builder b(Notification.Action.Builder param1Builder, boolean param1Boolean) {
      return a1.a(param1Builder, param1Boolean);
    }
  }
  
  @RequiresApi(28)
  static class f {
    static Notification.Builder a(Notification.Builder param1Builder, Person param1Person) {
      return b1.a(param1Builder, param1Person);
    }
  }
  
  @RequiresApi(31)
  static class g {
    static Notification.CallStyle a(@NonNull Person param1Person, @NonNull PendingIntent param1PendingIntent1, @NonNull PendingIntent param1PendingIntent2) {
      return Notification.CallStyle.forIncomingCall(param1Person, param1PendingIntent1, param1PendingIntent2);
    }
    
    static Notification.CallStyle b(@NonNull Person param1Person, @NonNull PendingIntent param1PendingIntent) {
      return Notification.CallStyle.forOngoingCall(param1Person, param1PendingIntent);
    }
    
    static Notification.CallStyle c(@NonNull Person param1Person, @NonNull PendingIntent param1PendingIntent1, @NonNull PendingIntent param1PendingIntent2) {
      return Notification.CallStyle.forScreeningCall(param1Person, param1PendingIntent1, param1PendingIntent2);
    }
    
    static Notification.CallStyle d(Notification.CallStyle param1CallStyle, int param1Int) {
      return param1CallStyle.setAnswerButtonColorHint(param1Int);
    }
    
    static Notification.Action.Builder e(Notification.Action.Builder param1Builder, boolean param1Boolean) {
      return c1.a(param1Builder, param1Boolean);
    }
    
    static Notification.CallStyle f(Notification.CallStyle param1CallStyle, int param1Int) {
      return param1CallStyle.setDeclineButtonColorHint(param1Int);
    }
    
    static Notification.CallStyle g(Notification.CallStyle param1CallStyle, boolean param1Boolean) {
      return param1CallStyle.setIsVideo(param1Boolean);
    }
    
    static Notification.CallStyle h(Notification.CallStyle param1CallStyle, @Nullable Icon param1Icon) {
      return param1CallStyle.setVerificationIcon(param1Icon);
    }
    
    static Notification.CallStyle i(Notification.CallStyle param1CallStyle, @Nullable CharSequence param1CharSequence) {
      return param1CallStyle.setVerificationText(param1CharSequence);
    }
  }
  
  public static class o extends r {
    private RemoteViews w(RemoteViews param1RemoteViews, boolean param1Boolean) {
      // Byte code:
      //   0: getstatic x/g.c : I
      //   3: istore_3
      //   4: iconst_1
      //   5: istore #6
      //   7: iconst_0
      //   8: istore #5
      //   10: aload_0
      //   11: iconst_1
      //   12: iload_3
      //   13: iconst_0
      //   14: invokevirtual c : (ZIZ)Landroid/widget/RemoteViews;
      //   17: astore #8
      //   19: aload #8
      //   21: getstatic x/e.L : I
      //   24: invokevirtual removeAllViews : (I)V
      //   27: aload_0
      //   28: getfield a : Landroidx/core/app/NotificationCompat$m;
      //   31: getfield b : Ljava/util/ArrayList;
      //   34: invokestatic y : (Ljava/util/List;)Ljava/util/List;
      //   37: astore #9
      //   39: iload_2
      //   40: ifeq -> 112
      //   43: aload #9
      //   45: ifnull -> 112
      //   48: aload #9
      //   50: invokeinterface size : ()I
      //   55: iconst_3
      //   56: invokestatic min : (II)I
      //   59: istore #7
      //   61: iload #7
      //   63: ifle -> 112
      //   66: iconst_0
      //   67: istore_3
      //   68: iload #6
      //   70: istore #4
      //   72: iload_3
      //   73: iload #7
      //   75: if_icmpge -> 115
      //   78: aload_0
      //   79: aload #9
      //   81: iload_3
      //   82: invokeinterface get : (I)Ljava/lang/Object;
      //   87: checkcast androidx/core/app/NotificationCompat$b
      //   90: invokespecial x : (Landroidx/core/app/NotificationCompat$b;)Landroid/widget/RemoteViews;
      //   93: astore #10
      //   95: aload #8
      //   97: getstatic x/e.L : I
      //   100: aload #10
      //   102: invokevirtual addView : (ILandroid/widget/RemoteViews;)V
      //   105: iload_3
      //   106: iconst_1
      //   107: iadd
      //   108: istore_3
      //   109: goto -> 68
      //   112: iconst_0
      //   113: istore #4
      //   115: iload #4
      //   117: ifeq -> 126
      //   120: iload #5
      //   122: istore_3
      //   123: goto -> 129
      //   126: bipush #8
      //   128: istore_3
      //   129: aload #8
      //   131: getstatic x/e.L : I
      //   134: iload_3
      //   135: invokevirtual setViewVisibility : (II)V
      //   138: aload #8
      //   140: getstatic x/e.I : I
      //   143: iload_3
      //   144: invokevirtual setViewVisibility : (II)V
      //   147: aload_0
      //   148: aload #8
      //   150: aload_1
      //   151: invokevirtual d : (Landroid/widget/RemoteViews;Landroid/widget/RemoteViews;)V
      //   154: aload #8
      //   156: areturn
    }
    
    private RemoteViews x(NotificationCompat.b param1b) {
      boolean bool;
      int i;
      if (param1b.k == null) {
        bool = true;
      } else {
        bool = false;
      } 
      String str = this.a.a.getPackageName();
      if (bool) {
        i = x.g.b;
      } else {
        i = x.g.a;
      } 
      RemoteViews remoteViews = new RemoteViews(str, i);
      IconCompat iconCompat = param1b.d();
      if (iconCompat != null)
        remoteViews.setImageViewBitmap(x.e.J, l(iconCompat, x.b.c)); 
      remoteViews.setTextViewText(x.e.K, param1b.j);
      if (!bool)
        remoteViews.setOnClickPendingIntent(x.e.H, param1b.k); 
      a.a(remoteViews, x.e.H, param1b.j);
      return remoteViews;
    }
    
    private static List<NotificationCompat.b> y(List<NotificationCompat.b> param1List) {
      if (param1List == null)
        return null; 
      ArrayList<NotificationCompat.b> arrayList = new ArrayList();
      for (NotificationCompat.b b : param1List) {
        if (!b.j())
          arrayList.add(b); 
      } 
      return arrayList;
    }
    
    public void b(t param1t) {
      if (Build.VERSION.SDK_INT >= 24)
        b.a(param1t.a(), c.a()); 
    }
    
    @NonNull
    protected String p() {
      return "androidx.core.app.NotificationCompat$DecoratedCustomViewStyle";
    }
    
    public RemoteViews r(t param1t) {
      if (Build.VERSION.SDK_INT >= 24)
        return null; 
      RemoteViews remoteViews = this.a.d();
      if (remoteViews == null)
        remoteViews = this.a.f(); 
      return (remoteViews == null) ? null : w(remoteViews, true);
    }
    
    public RemoteViews s(t param1t) {
      return (Build.VERSION.SDK_INT >= 24) ? null : ((this.a.f() == null) ? null : w(this.a.f(), false));
    }
    
    public RemoteViews t(t param1t) {
      RemoteViews remoteViews1;
      if (Build.VERSION.SDK_INT >= 24)
        return null; 
      RemoteViews remoteViews2 = this.a.h();
      if (remoteViews2 != null) {
        remoteViews1 = remoteViews2;
      } else {
        remoteViews1 = this.a.f();
      } 
      return (remoteViews2 == null) ? null : w(remoteViews1, true);
    }
    
    @RequiresApi(15)
    static class a {
      static void a(RemoteViews param2RemoteViews, int param2Int, CharSequence param2CharSequence) {
        param2RemoteViews.setContentDescription(param2Int, param2CharSequence);
      }
    }
    
    @RequiresApi(16)
    static class b {
      static Notification.Builder a(Notification.Builder param2Builder, Object param2Object) {
        return param2Builder.setStyle((Notification.Style)param2Object);
      }
    }
    
    @RequiresApi(24)
    static class c {
      static Notification.DecoratedCustomViewStyle a() {
        return new Notification.DecoratedCustomViewStyle();
      }
    }
  }
  
  @RequiresApi(15)
  static class a {
    static void a(RemoteViews param1RemoteViews, int param1Int, CharSequence param1CharSequence) {
      param1RemoteViews.setContentDescription(param1Int, param1CharSequence);
    }
  }
  
  @RequiresApi(16)
  static class b {
    static Notification.Builder a(Notification.Builder param1Builder, Object param1Object) {
      return param1Builder.setStyle((Notification.Style)param1Object);
    }
  }
  
  @RequiresApi(24)
  static class c {
    static Notification.DecoratedCustomViewStyle a() {
      return new Notification.DecoratedCustomViewStyle();
    }
  }
  
  public static class p extends r {
    private ArrayList<CharSequence> e = new ArrayList<CharSequence>();
    
    public void b(t param1t) {
      Notification.InboxStyle inboxStyle = a.c(a.b(param1t.a()), this.b);
      if (this.d)
        a.d(inboxStyle, this.c); 
      Iterator<CharSequence> iterator = this.e.iterator();
      while (iterator.hasNext())
        a.a(inboxStyle, iterator.next()); 
    }
    
    @NonNull
    protected String p() {
      return "androidx.core.app.NotificationCompat$InboxStyle";
    }
    
    protected void u(@NonNull Bundle param1Bundle) {
      super.u(param1Bundle);
      this.e.clear();
      if (param1Bundle.containsKey("android.textLines"))
        Collections.addAll(this.e, param1Bundle.getCharSequenceArray("android.textLines")); 
    }
    
    @NonNull
    public p w(@Nullable CharSequence param1CharSequence) {
      if (param1CharSequence != null)
        this.e.add(NotificationCompat.m.k(param1CharSequence)); 
      return this;
    }
    
    @NonNull
    public p x(@Nullable CharSequence param1CharSequence) {
      this.b = NotificationCompat.m.k(param1CharSequence);
      return this;
    }
    
    @NonNull
    public p y(@Nullable CharSequence param1CharSequence) {
      this.c = NotificationCompat.m.k(param1CharSequence);
      this.d = true;
      return this;
    }
    
    @RequiresApi(16)
    static class a {
      static Notification.InboxStyle a(Notification.InboxStyle param2InboxStyle, CharSequence param2CharSequence) {
        return param2InboxStyle.addLine(param2CharSequence);
      }
      
      static Notification.InboxStyle b(Notification.Builder param2Builder) {
        return new Notification.InboxStyle(param2Builder);
      }
      
      static Notification.InboxStyle c(Notification.InboxStyle param2InboxStyle, CharSequence param2CharSequence) {
        return param2InboxStyle.setBigContentTitle(param2CharSequence);
      }
      
      static Notification.InboxStyle d(Notification.InboxStyle param2InboxStyle, CharSequence param2CharSequence) {
        return param2InboxStyle.setSummaryText(param2CharSequence);
      }
    }
  }
  
  @RequiresApi(16)
  static class a {
    static Notification.InboxStyle a(Notification.InboxStyle param1InboxStyle, CharSequence param1CharSequence) {
      return param1InboxStyle.addLine(param1CharSequence);
    }
    
    static Notification.InboxStyle b(Notification.Builder param1Builder) {
      return new Notification.InboxStyle(param1Builder);
    }
    
    static Notification.InboxStyle c(Notification.InboxStyle param1InboxStyle, CharSequence param1CharSequence) {
      return param1InboxStyle.setBigContentTitle(param1CharSequence);
    }
    
    static Notification.InboxStyle d(Notification.InboxStyle param1InboxStyle, CharSequence param1CharSequence) {
      return param1InboxStyle.setSummaryText(param1CharSequence);
    }
  }
  
  public static class q extends r {
    private final List<e> e = new ArrayList<e>();
    
    private final List<e> f = new ArrayList<e>();
    
    private m2 g;
    
    @Nullable
    private CharSequence h;
    
    @Nullable
    private Boolean i;
    
    q() {}
    
    public q(@NonNull m2 param1m2) {
      if (!TextUtils.isEmpty(param1m2.e())) {
        this.g = param1m2;
        return;
      } 
      throw new IllegalArgumentException("User's name must not be empty.");
    }
    
    private boolean C() {
      for (int i = this.e.size() - 1; i >= 0; i--) {
        e e = this.e.get(i);
        if (e.g() != null && e.g().e() == null)
          return true; 
      } 
      return false;
    }
    
    @NonNull
    private TextAppearanceSpan E(int param1Int) {
      return new TextAppearanceSpan(null, 0, 0, ColorStateList.valueOf(param1Int), null);
    }
    
    private CharSequence F(@NonNull e param1e) {
      CharSequence charSequence1;
      androidx.core.text.a a = androidx.core.text.a.c();
      SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
      int j = -16777216;
      m2 m21 = param1e.g();
      String str = "";
      if (m21 == null) {
        charSequence2 = "";
      } else {
        charSequence2 = param1e.g().e();
      } 
      int i = j;
      CharSequence charSequence3 = charSequence2;
      if (TextUtils.isEmpty(charSequence2)) {
        charSequence2 = this.g.e();
        i = j;
        charSequence3 = charSequence2;
        if (this.a.e() != 0) {
          i = this.a.e();
          charSequence3 = charSequence2;
        } 
      } 
      CharSequence charSequence2 = a.h(charSequence3);
      spannableStringBuilder.append(charSequence2);
      spannableStringBuilder.setSpan(E(i), spannableStringBuilder.length() - charSequence2.length(), spannableStringBuilder.length(), 33);
      if (param1e.h() == null) {
        charSequence1 = str;
      } else {
        charSequence1 = charSequence1.h();
      } 
      spannableStringBuilder.append("  ").append(a.h(charSequence1));
      return (CharSequence)spannableStringBuilder;
    }
    
    @Nullable
    public static q x(@NonNull Notification param1Notification) {
      NotificationCompat.r r1 = NotificationCompat.r.o(param1Notification);
      return (r1 instanceof q) ? (q)r1 : null;
    }
    
    @Nullable
    private e y() {
      for (int i = this.e.size() - 1; i >= 0; i--) {
        e e = this.e.get(i);
        if (e.g() != null && !TextUtils.isEmpty(e.g().e()))
          return e; 
      } 
      if (!this.e.isEmpty()) {
        List<e> list = this.e;
        return list.get(list.size() - 1);
      } 
      return null;
    }
    
    @NonNull
    public List<e> A() {
      return this.e;
    }
    
    @NonNull
    public m2 B() {
      return this.g;
    }
    
    public boolean D() {
      NotificationCompat.m m = this.a;
      boolean bool2 = false;
      boolean bool1 = false;
      if (m != null && (m.a.getApplicationInfo()).targetSdkVersion < 28 && this.i == null) {
        if (this.h != null)
          bool1 = true; 
        return bool1;
      } 
      Boolean bool = this.i;
      bool1 = bool2;
      if (bool != null)
        bool1 = bool.booleanValue(); 
      return bool1;
    }
    
    @NonNull
    public q G(@Nullable CharSequence param1CharSequence) {
      this.h = param1CharSequence;
      return this;
    }
    
    @NonNull
    public q H(boolean param1Boolean) {
      this.i = Boolean.valueOf(param1Boolean);
      return this;
    }
    
    public void a(@NonNull Bundle param1Bundle) {
      super.a(param1Bundle);
      param1Bundle.putCharSequence("android.selfDisplayName", this.g.e());
      param1Bundle.putBundle("android.messagingStyleUser", this.g.k());
      param1Bundle.putCharSequence("android.hiddenConversationTitle", this.h);
      if (this.h != null && this.i.booleanValue())
        param1Bundle.putCharSequence("android.conversationTitle", this.h); 
      if (!this.e.isEmpty())
        param1Bundle.putParcelableArray("android.messages", (Parcelable[])e.a(this.e)); 
      if (!this.f.isEmpty())
        param1Bundle.putParcelableArray("android.messages.historic", (Parcelable[])e.a(this.f)); 
      Boolean bool = this.i;
      if (bool != null)
        param1Bundle.putBoolean("android.isGroupConversation", bool.booleanValue()); 
    }
    
    public void b(t param1t) {
      H(D());
      int i = Build.VERSION.SDK_INT;
      if (i >= 24) {
        Notification.MessagingStyle messagingStyle;
        if (i >= 28) {
          messagingStyle = d.a(this.g.j());
        } else {
          messagingStyle = b.b(this.g.e());
        } 
        Iterator<e> iterator = this.e.iterator();
        while (iterator.hasNext())
          b.a(messagingStyle, ((e)iterator.next()).k()); 
        if (Build.VERSION.SDK_INT >= 26) {
          iterator = this.f.iterator();
          while (iterator.hasNext())
            c.a(messagingStyle, ((e)iterator.next()).k()); 
        } 
        if (this.i.booleanValue() || Build.VERSION.SDK_INT >= 28)
          b.c(messagingStyle, this.h); 
        if (Build.VERSION.SDK_INT >= 28)
          d.b(messagingStyle, this.i.booleanValue()); 
        a.d((Notification.Style)messagingStyle, param1t.a());
        return;
      } 
      e e = y();
      if (this.h != null && this.i.booleanValue()) {
        param1t.a().setContentTitle(this.h);
      } else if (e != null) {
        param1t.a().setContentTitle("");
        if (e.g() != null)
          param1t.a().setContentTitle(e.g().e()); 
      } 
      if (e != null) {
        CharSequence charSequence;
        Notification.Builder builder = param1t.a();
        if (this.h != null) {
          charSequence = F(e);
        } else {
          charSequence = charSequence.h();
        } 
        builder.setContentText(charSequence);
      } 
      SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
      if (this.h != null || C()) {
        i = 1;
      } else {
        i = 0;
      } 
      for (int j = this.e.size() - 1; j >= 0; j--) {
        CharSequence charSequence;
        e = this.e.get(j);
        if (i != 0) {
          charSequence = F(e);
        } else {
          charSequence = charSequence.h();
        } 
        if (j != this.e.size() - 1)
          spannableStringBuilder.insert(0, "\n"); 
        spannableStringBuilder.insert(0, charSequence);
      } 
      a.a(a.c(a.b(param1t.a()), null), (CharSequence)spannableStringBuilder);
    }
    
    @NonNull
    protected String p() {
      return "androidx.core.app.NotificationCompat$MessagingStyle";
    }
    
    protected void u(@NonNull Bundle param1Bundle) {
      super.u(param1Bundle);
      this.e.clear();
      if (param1Bundle.containsKey("android.messagingStyleUser")) {
        this.g = m2.b(param1Bundle.getBundle("android.messagingStyleUser"));
      } else {
        this.g = (new m2.b()).f(param1Bundle.getString("android.selfDisplayName")).a();
      } 
      CharSequence charSequence = param1Bundle.getCharSequence("android.conversationTitle");
      this.h = charSequence;
      if (charSequence == null)
        this.h = param1Bundle.getCharSequence("android.hiddenConversationTitle"); 
      Parcelable[] arrayOfParcelable = param1Bundle.getParcelableArray("android.messages");
      if (arrayOfParcelable != null)
        this.e.addAll(e.f(arrayOfParcelable)); 
      arrayOfParcelable = param1Bundle.getParcelableArray("android.messages.historic");
      if (arrayOfParcelable != null)
        this.f.addAll(e.f(arrayOfParcelable)); 
      if (param1Bundle.containsKey("android.isGroupConversation"))
        this.i = Boolean.valueOf(param1Bundle.getBoolean("android.isGroupConversation")); 
    }
    
    @NonNull
    public q w(@Nullable e param1e) {
      if (param1e != null) {
        this.e.add(param1e);
        if (this.e.size() > 25)
          this.e.remove(0); 
      } 
      return this;
    }
    
    @Nullable
    public CharSequence z() {
      return this.h;
    }
    
    @RequiresApi(16)
    static class a {
      static Notification.BigTextStyle a(Notification.BigTextStyle param2BigTextStyle, CharSequence param2CharSequence) {
        return param2BigTextStyle.bigText(param2CharSequence);
      }
      
      static Notification.BigTextStyle b(Notification.Builder param2Builder) {
        return new Notification.BigTextStyle(param2Builder);
      }
      
      static Notification.BigTextStyle c(Notification.BigTextStyle param2BigTextStyle, CharSequence param2CharSequence) {
        return param2BigTextStyle.setBigContentTitle(param2CharSequence);
      }
      
      static void d(Notification.Style param2Style, Notification.Builder param2Builder) {
        param2Style.setBuilder(param2Builder);
      }
    }
    
    @RequiresApi(24)
    static class b {
      static Notification.MessagingStyle a(Notification.MessagingStyle param2MessagingStyle, Notification.MessagingStyle.Message param2Message) {
        return param2MessagingStyle.addMessage(param2Message);
      }
      
      static Notification.MessagingStyle b(CharSequence param2CharSequence) {
        return new Notification.MessagingStyle(param2CharSequence);
      }
      
      static Notification.MessagingStyle c(Notification.MessagingStyle param2MessagingStyle, CharSequence param2CharSequence) {
        return param2MessagingStyle.setConversationTitle(param2CharSequence);
      }
    }
    
    @RequiresApi(26)
    static class c {
      static Notification.MessagingStyle a(Notification.MessagingStyle param2MessagingStyle, Notification.MessagingStyle.Message param2Message) {
        return d1.a(param2MessagingStyle, param2Message);
      }
    }
    
    @RequiresApi(28)
    static class d {
      static Notification.MessagingStyle a(Person param2Person) {
        return new Notification.MessagingStyle(param2Person);
      }
      
      static Notification.MessagingStyle b(Notification.MessagingStyle param2MessagingStyle, boolean param2Boolean) {
        return e1.a(param2MessagingStyle, param2Boolean);
      }
    }
    
    public static final class e {
      private final CharSequence a;
      
      private final long b;
      
      @Nullable
      private final m2 c;
      
      private Bundle d = new Bundle();
      
      @Nullable
      private String e;
      
      @Nullable
      private Uri f;
      
      public e(@Nullable CharSequence param2CharSequence, long param2Long, @Nullable m2 param2m2) {
        this.a = param2CharSequence;
        this.b = param2Long;
        this.c = param2m2;
      }
      
      @NonNull
      static Bundle[] a(@NonNull List<e> param2List) {
        Bundle[] arrayOfBundle = new Bundle[param2List.size()];
        int j = param2List.size();
        for (int i = 0; i < j; i++)
          arrayOfBundle[i] = ((e)param2List.get(i)).l(); 
        return arrayOfBundle;
      }
      
      @Nullable
      static e e(@NonNull Bundle param2Bundle) {
        try {
          if (param2Bundle.containsKey("text")) {
            if (!param2Bundle.containsKey("time"))
              return null; 
            if (param2Bundle.containsKey("person")) {
              e1 = (e)m2.b(param2Bundle.getBundle("person"));
            } else if (param2Bundle.containsKey("sender_person") && Build.VERSION.SDK_INT >= 28) {
              e1 = (e)m2.a((Person)param2Bundle.getParcelable("sender_person"));
            } else if (param2Bundle.containsKey("sender")) {
              e1 = (e)(new m2.b()).f(param2Bundle.getCharSequence("sender")).a();
            } else {
              e1 = null;
            } 
            e e1 = new e(param2Bundle.getCharSequence("text"), param2Bundle.getLong("time"), (m2)e1);
            if (param2Bundle.containsKey("type") && param2Bundle.containsKey("uri"))
              e1.j(param2Bundle.getString("type"), (Uri)param2Bundle.getParcelable("uri")); 
            if (param2Bundle.containsKey("extras"))
              e1.d().putAll(param2Bundle.getBundle("extras")); 
            return e1;
          } 
          return null;
        } catch (ClassCastException classCastException) {
          return null;
        } 
      }
      
      @NonNull
      static List<e> f(@NonNull Parcelable[] param2ArrayOfParcelable) {
        ArrayList<e> arrayList = new ArrayList(param2ArrayOfParcelable.length);
        for (int i = 0; i < param2ArrayOfParcelable.length; i++) {
          Parcelable parcelable = param2ArrayOfParcelable[i];
          if (parcelable instanceof Bundle) {
            e e1 = e((Bundle)parcelable);
            if (e1 != null)
              arrayList.add(e1); 
          } 
        } 
        return arrayList;
      }
      
      @NonNull
      private Bundle l() {
        Bundle bundle1 = new Bundle();
        CharSequence charSequence = this.a;
        if (charSequence != null)
          bundle1.putCharSequence("text", charSequence); 
        bundle1.putLong("time", this.b);
        m2 m21 = this.c;
        if (m21 != null) {
          bundle1.putCharSequence("sender", m21.e());
          if (Build.VERSION.SDK_INT >= 28) {
            bundle1.putParcelable("sender_person", (Parcelable)this.c.j());
          } else {
            bundle1.putBundle("person", this.c.k());
          } 
        } 
        String str = this.e;
        if (str != null)
          bundle1.putString("type", str); 
        Uri uri = this.f;
        if (uri != null)
          bundle1.putParcelable("uri", (Parcelable)uri); 
        Bundle bundle2 = this.d;
        if (bundle2 != null)
          bundle1.putBundle("extras", bundle2); 
        return bundle1;
      }
      
      @Nullable
      public String b() {
        return this.e;
      }
      
      @Nullable
      public Uri c() {
        return this.f;
      }
      
      @NonNull
      public Bundle d() {
        return this.d;
      }
      
      @Nullable
      public m2 g() {
        return this.c;
      }
      
      @Nullable
      public CharSequence h() {
        return this.a;
      }
      
      public long i() {
        return this.b;
      }
      
      @NonNull
      public e j(@Nullable String param2String, @Nullable Uri param2Uri) {
        this.e = param2String;
        this.f = param2Uri;
        return this;
      }
      
      @NonNull
      @RequiresApi(24)
      Notification.MessagingStyle.Message k() {
        Notification.MessagingStyle.Message message;
        m2 m21 = g();
        int i = Build.VERSION.SDK_INT;
        CharSequence charSequence = null;
        Person person = null;
        if (i >= 28) {
          charSequence = h();
          long l = i();
          if (m21 != null)
            person = m21.j(); 
          message = b.a(charSequence, l, person);
        } else {
          CharSequence charSequence1;
          CharSequence charSequence2 = h();
          long l = i();
          if (m21 == null) {
            charSequence1 = charSequence;
          } else {
            charSequence1 = m21.e();
          } 
          message = a.a(charSequence2, l, charSequence1);
        } 
        if (b() != null)
          a.b(message, b(), c()); 
        return message;
      }
      
      @RequiresApi(24)
      static class a {
        static Notification.MessagingStyle.Message a(CharSequence param3CharSequence1, long param3Long, CharSequence param3CharSequence2) {
          return new Notification.MessagingStyle.Message(param3CharSequence1, param3Long, param3CharSequence2);
        }
        
        static Notification.MessagingStyle.Message b(Notification.MessagingStyle.Message param3Message, String param3String, Uri param3Uri) {
          return param3Message.setData(param3String, param3Uri);
        }
      }
      
      @RequiresApi(28)
      static class b {
        static Notification.MessagingStyle.Message a(CharSequence param3CharSequence, long param3Long, Person param3Person) {
          return new Notification.MessagingStyle.Message(param3CharSequence, param3Long, param3Person);
        }
      }
    }
    
    @RequiresApi(24)
    static class a {
      static Notification.MessagingStyle.Message a(CharSequence param2CharSequence1, long param2Long, CharSequence param2CharSequence2) {
        return new Notification.MessagingStyle.Message(param2CharSequence1, param2Long, param2CharSequence2);
      }
      
      static Notification.MessagingStyle.Message b(Notification.MessagingStyle.Message param2Message, String param2String, Uri param2Uri) {
        return param2Message.setData(param2String, param2Uri);
      }
    }
    
    @RequiresApi(28)
    static class b {
      static Notification.MessagingStyle.Message a(CharSequence param2CharSequence, long param2Long, Person param2Person) {
        return new Notification.MessagingStyle.Message(param2CharSequence, param2Long, param2Person);
      }
    }
  }
  
  @RequiresApi(16)
  static class a {
    static Notification.BigTextStyle a(Notification.BigTextStyle param1BigTextStyle, CharSequence param1CharSequence) {
      return param1BigTextStyle.bigText(param1CharSequence);
    }
    
    static Notification.BigTextStyle b(Notification.Builder param1Builder) {
      return new Notification.BigTextStyle(param1Builder);
    }
    
    static Notification.BigTextStyle c(Notification.BigTextStyle param1BigTextStyle, CharSequence param1CharSequence) {
      return param1BigTextStyle.setBigContentTitle(param1CharSequence);
    }
    
    static void d(Notification.Style param1Style, Notification.Builder param1Builder) {
      param1Style.setBuilder(param1Builder);
    }
  }
  
  @RequiresApi(24)
  static class b {
    static Notification.MessagingStyle a(Notification.MessagingStyle param1MessagingStyle, Notification.MessagingStyle.Message param1Message) {
      return param1MessagingStyle.addMessage(param1Message);
    }
    
    static Notification.MessagingStyle b(CharSequence param1CharSequence) {
      return new Notification.MessagingStyle(param1CharSequence);
    }
    
    static Notification.MessagingStyle c(Notification.MessagingStyle param1MessagingStyle, CharSequence param1CharSequence) {
      return param1MessagingStyle.setConversationTitle(param1CharSequence);
    }
  }
  
  @RequiresApi(26)
  static class c {
    static Notification.MessagingStyle a(Notification.MessagingStyle param1MessagingStyle, Notification.MessagingStyle.Message param1Message) {
      return d1.a(param1MessagingStyle, param1Message);
    }
  }
  
  @RequiresApi(28)
  static class d {
    static Notification.MessagingStyle a(Person param1Person) {
      return new Notification.MessagingStyle(param1Person);
    }
    
    static Notification.MessagingStyle b(Notification.MessagingStyle param1MessagingStyle, boolean param1Boolean) {
      return e1.a(param1MessagingStyle, param1Boolean);
    }
  }
  
  public static final class e {
    private final CharSequence a;
    
    private final long b;
    
    @Nullable
    private final m2 c;
    
    private Bundle d = new Bundle();
    
    @Nullable
    private String e;
    
    @Nullable
    private Uri f;
    
    public e(@Nullable CharSequence param1CharSequence, long param1Long, @Nullable m2 param1m2) {
      this.a = param1CharSequence;
      this.b = param1Long;
      this.c = param1m2;
    }
    
    @NonNull
    static Bundle[] a(@NonNull List<e> param1List) {
      Bundle[] arrayOfBundle = new Bundle[param1List.size()];
      int j = param1List.size();
      for (int i = 0; i < j; i++)
        arrayOfBundle[i] = ((e)param1List.get(i)).l(); 
      return arrayOfBundle;
    }
    
    @Nullable
    static e e(@NonNull Bundle param1Bundle) {
      try {
        if (param1Bundle.containsKey("text")) {
          if (!param1Bundle.containsKey("time"))
            return null; 
          if (param1Bundle.containsKey("person")) {
            e1 = (e)m2.b(param1Bundle.getBundle("person"));
          } else if (param1Bundle.containsKey("sender_person") && Build.VERSION.SDK_INT >= 28) {
            e1 = (e)m2.a((Person)param1Bundle.getParcelable("sender_person"));
          } else if (param1Bundle.containsKey("sender")) {
            e1 = (e)(new m2.b()).f(param1Bundle.getCharSequence("sender")).a();
          } else {
            e1 = null;
          } 
          e e1 = new e(param1Bundle.getCharSequence("text"), param1Bundle.getLong("time"), (m2)e1);
          if (param1Bundle.containsKey("type") && param1Bundle.containsKey("uri"))
            e1.j(param1Bundle.getString("type"), (Uri)param1Bundle.getParcelable("uri")); 
          if (param1Bundle.containsKey("extras"))
            e1.d().putAll(param1Bundle.getBundle("extras")); 
          return e1;
        } 
        return null;
      } catch (ClassCastException classCastException) {
        return null;
      } 
    }
    
    @NonNull
    static List<e> f(@NonNull Parcelable[] param1ArrayOfParcelable) {
      ArrayList<e> arrayList = new ArrayList(param1ArrayOfParcelable.length);
      for (int i = 0; i < param1ArrayOfParcelable.length; i++) {
        Parcelable parcelable = param1ArrayOfParcelable[i];
        if (parcelable instanceof Bundle) {
          e e1 = e((Bundle)parcelable);
          if (e1 != null)
            arrayList.add(e1); 
        } 
      } 
      return arrayList;
    }
    
    @NonNull
    private Bundle l() {
      Bundle bundle1 = new Bundle();
      CharSequence charSequence = this.a;
      if (charSequence != null)
        bundle1.putCharSequence("text", charSequence); 
      bundle1.putLong("time", this.b);
      m2 m21 = this.c;
      if (m21 != null) {
        bundle1.putCharSequence("sender", m21.e());
        if (Build.VERSION.SDK_INT >= 28) {
          bundle1.putParcelable("sender_person", (Parcelable)this.c.j());
        } else {
          bundle1.putBundle("person", this.c.k());
        } 
      } 
      String str = this.e;
      if (str != null)
        bundle1.putString("type", str); 
      Uri uri = this.f;
      if (uri != null)
        bundle1.putParcelable("uri", (Parcelable)uri); 
      Bundle bundle2 = this.d;
      if (bundle2 != null)
        bundle1.putBundle("extras", bundle2); 
      return bundle1;
    }
    
    @Nullable
    public String b() {
      return this.e;
    }
    
    @Nullable
    public Uri c() {
      return this.f;
    }
    
    @NonNull
    public Bundle d() {
      return this.d;
    }
    
    @Nullable
    public m2 g() {
      return this.c;
    }
    
    @Nullable
    public CharSequence h() {
      return this.a;
    }
    
    public long i() {
      return this.b;
    }
    
    @NonNull
    public e j(@Nullable String param1String, @Nullable Uri param1Uri) {
      this.e = param1String;
      this.f = param1Uri;
      return this;
    }
    
    @NonNull
    @RequiresApi(24)
    Notification.MessagingStyle.Message k() {
      Notification.MessagingStyle.Message message;
      m2 m21 = g();
      int i = Build.VERSION.SDK_INT;
      CharSequence charSequence = null;
      Person person = null;
      if (i >= 28) {
        charSequence = h();
        long l = i();
        if (m21 != null)
          person = m21.j(); 
        message = b.a(charSequence, l, person);
      } else {
        CharSequence charSequence1;
        CharSequence charSequence2 = h();
        long l = i();
        if (m21 == null) {
          charSequence1 = charSequence;
        } else {
          charSequence1 = m21.e();
        } 
        message = a.a(charSequence2, l, charSequence1);
      } 
      if (b() != null)
        a.b(message, b(), c()); 
      return message;
    }
    
    @RequiresApi(24)
    static class a {
      static Notification.MessagingStyle.Message a(CharSequence param3CharSequence1, long param3Long, CharSequence param3CharSequence2) {
        return new Notification.MessagingStyle.Message(param3CharSequence1, param3Long, param3CharSequence2);
      }
      
      static Notification.MessagingStyle.Message b(Notification.MessagingStyle.Message param3Message, String param3String, Uri param3Uri) {
        return param3Message.setData(param3String, param3Uri);
      }
    }
    
    @RequiresApi(28)
    static class b {
      static Notification.MessagingStyle.Message a(CharSequence param3CharSequence, long param3Long, Person param3Person) {
        return new Notification.MessagingStyle.Message(param3CharSequence, param3Long, param3Person);
      }
    }
  }
  
  @RequiresApi(24)
  static class a {
    static Notification.MessagingStyle.Message a(CharSequence param1CharSequence1, long param1Long, CharSequence param1CharSequence2) {
      return new Notification.MessagingStyle.Message(param1CharSequence1, param1Long, param1CharSequence2);
    }
    
    static Notification.MessagingStyle.Message b(Notification.MessagingStyle.Message param1Message, String param1String, Uri param1Uri) {
      return param1Message.setData(param1String, param1Uri);
    }
  }
  
  @RequiresApi(28)
  static class b {
    static Notification.MessagingStyle.Message a(CharSequence param1CharSequence, long param1Long, Person param1Person) {
      return new Notification.MessagingStyle.Message(param1CharSequence, param1Long, param1Person);
    }
  }
  
  public static abstract class r {
    protected NotificationCompat.m a;
    
    CharSequence b;
    
    CharSequence c;
    
    boolean d = false;
    
    private int e() {
      Resources resources = this.a.a.getResources();
      int i = resources.getDimensionPixelSize(x.c.i);
      int j = resources.getDimensionPixelSize(x.c.j);
      float f = (f((resources.getConfiguration()).fontScale, 1.0F, 1.3F) - 1.0F) / 0.29999995F;
      return Math.round((1.0F - f) * i + f * j);
    }
    
    private static float f(float param1Float1, float param1Float2, float param1Float3) {
      if (param1Float1 < param1Float2)
        return param1Float2; 
      param1Float2 = param1Float1;
      if (param1Float1 > param1Float3)
        param1Float2 = param1Float3; 
      return param1Float2;
    }
    
    @Nullable
    static r g(@Nullable String param1String) {
      if (param1String != null) {
        byte b = -1;
        switch (param1String.hashCode()) {
          case 2090799565:
            if (!param1String.equals("androidx.core.app.NotificationCompat$MessagingStyle"))
              break; 
            b = 5;
            break;
          case 919595044:
            if (!param1String.equals("androidx.core.app.NotificationCompat$BigTextStyle"))
              break; 
            b = 4;
            break;
          case 912942987:
            if (!param1String.equals("androidx.core.app.NotificationCompat$InboxStyle"))
              break; 
            b = 3;
            break;
          case 714386739:
            if (!param1String.equals("androidx.core.app.NotificationCompat$CallStyle"))
              break; 
            b = 2;
            break;
          case -171946061:
            if (!param1String.equals("androidx.core.app.NotificationCompat$BigPictureStyle"))
              break; 
            b = 1;
            break;
          case -716705180:
            if (!param1String.equals("androidx.core.app.NotificationCompat$DecoratedCustomViewStyle"))
              break; 
            b = 0;
            break;
        } 
        switch (b) {
          default:
            return null;
          case 5:
            return new NotificationCompat.q();
          case 4:
            return new NotificationCompat.k();
          case 3:
            return new NotificationCompat.p();
          case 2:
            return new NotificationCompat.n();
          case 1:
            return new NotificationCompat.j();
          case 0:
            break;
        } 
        return new NotificationCompat.o();
      } 
    }
    
    @Nullable
    private static r h(@Nullable String param1String) {
      if (param1String == null)
        return null; 
      int i = Build.VERSION.SDK_INT;
      if (param1String.equals(Notification.BigPictureStyle.class.getName()))
        return new NotificationCompat.j(); 
      if (param1String.equals(Notification.BigTextStyle.class.getName()))
        return new NotificationCompat.k(); 
      if (param1String.equals(Notification.InboxStyle.class.getName()))
        return new NotificationCompat.p(); 
      if (i >= 24) {
        if (param1String.equals(Notification.MessagingStyle.class.getName()))
          return new NotificationCompat.q(); 
        if (param1String.equals(Notification.DecoratedCustomViewStyle.class.getName()))
          return new NotificationCompat.o(); 
      } 
      return null;
    }
    
    @Nullable
    static r i(@NonNull Bundle param1Bundle) {
      r r1 = g(param1Bundle.getString("androidx.core.app.extra.COMPAT_TEMPLATE"));
      return (r1 != null) ? r1 : ((param1Bundle.containsKey("android.selfDisplayName") || param1Bundle.containsKey("android.messagingStyleUser")) ? new NotificationCompat.q() : ((param1Bundle.containsKey("android.picture") || param1Bundle.containsKey("android.pictureIcon")) ? new NotificationCompat.j() : (param1Bundle.containsKey("android.bigText") ? new NotificationCompat.k() : (param1Bundle.containsKey("android.textLines") ? new NotificationCompat.p() : (param1Bundle.containsKey("android.callType") ? new NotificationCompat.n() : h(param1Bundle.getString("android.template")))))));
    }
    
    @Nullable
    static r j(@NonNull Bundle param1Bundle) {
      r r1 = i(param1Bundle);
      if (r1 == null)
        return null; 
      try {
        r1.u(param1Bundle);
        return r1;
      } catch (ClassCastException classCastException) {
        return null;
      } 
    }
    
    private Bitmap k(int param1Int1, int param1Int2, int param1Int3) {
      return m(IconCompat.l(this.a.a, param1Int1), param1Int2, param1Int3);
    }
    
    private Bitmap m(@NonNull IconCompat param1IconCompat, int param1Int1, int param1Int2) {
      int i;
      Drawable drawable = param1IconCompat.u(this.a.a);
      if (param1Int2 == 0) {
        i = drawable.getIntrinsicWidth();
      } else {
        i = param1Int2;
      } 
      int j = param1Int2;
      if (param1Int2 == 0)
        j = drawable.getIntrinsicHeight(); 
      Bitmap bitmap = Bitmap.createBitmap(i, j, Bitmap.Config.ARGB_8888);
      drawable.setBounds(0, 0, i, j);
      if (param1Int1 != 0)
        drawable.mutate().setColorFilter((ColorFilter)new PorterDuffColorFilter(param1Int1, PorterDuff.Mode.SRC_IN)); 
      drawable.draw(new Canvas(bitmap));
      return bitmap;
    }
    
    private Bitmap n(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      int j = x.d.d;
      int i = param1Int4;
      if (param1Int4 == 0)
        i = 0; 
      Bitmap bitmap = k(j, i, param1Int2);
      Canvas canvas = new Canvas(bitmap);
      Drawable drawable = this.a.a.getResources().getDrawable(param1Int1).mutate();
      drawable.setFilterBitmap(true);
      param1Int1 = (param1Int2 - param1Int3) / 2;
      param1Int2 = param1Int3 + param1Int1;
      drawable.setBounds(param1Int1, param1Int1, param1Int2, param1Int2);
      drawable.setColorFilter((ColorFilter)new PorterDuffColorFilter(-1, PorterDuff.Mode.SRC_ATOP));
      drawable.draw(canvas);
      return bitmap;
    }
    
    @Nullable
    public static r o(@NonNull Notification param1Notification) {
      Bundle bundle = NotificationCompat.getExtras(param1Notification);
      return (bundle == null) ? null : j(bundle);
    }
    
    private void q(RemoteViews param1RemoteViews) {
      param1RemoteViews.setViewVisibility(x.e.k0, 8);
      param1RemoteViews.setViewVisibility(x.e.i0, 8);
      param1RemoteViews.setViewVisibility(x.e.h0, 8);
    }
    
    public void a(@NonNull Bundle param1Bundle) {
      if (this.d)
        param1Bundle.putCharSequence("android.summaryText", this.c); 
      CharSequence charSequence = this.b;
      if (charSequence != null)
        param1Bundle.putCharSequence("android.title.big", charSequence); 
      charSequence = p();
      if (charSequence != null)
        param1Bundle.putString("androidx.core.app.extra.COMPAT_TEMPLATE", (String)charSequence); 
    }
    
    public abstract void b(t param1t);
    
    @NonNull
    public RemoteViews c(boolean param1Boolean1, int param1Int, boolean param1Boolean2) {
      Bitmap bitmap1;
      Resources resources = this.a.a.getResources();
      RemoteViews remoteViews = new RemoteViews(this.a.a.getPackageName(), param1Int);
      this.a.i();
      int i = Build.VERSION.SDK_INT;
      NotificationCompat.m m2 = this.a;
      Bitmap bitmap2 = m2.j;
      boolean bool2 = false;
      if (bitmap2 != null) {
        param1Int = x.e.N;
        remoteViews.setViewVisibility(param1Int, 0);
        remoteViews.setImageViewBitmap(param1Int, this.a.j);
        if (param1Boolean1 && this.a.U.icon != 0) {
          param1Int = resources.getDimensionPixelSize(x.c.e);
          int j = resources.getDimensionPixelSize(x.c.f);
          m2 = this.a;
          bitmap1 = n(m2.U.icon, param1Int, param1Int - j * 2, m2.e());
          param1Int = x.e.T;
          remoteViews.setImageViewBitmap(param1Int, bitmap1);
          remoteViews.setViewVisibility(param1Int, 0);
        } 
      } else if (param1Boolean1 && ((NotificationCompat.m)bitmap1).U.icon != 0) {
        param1Int = x.e.N;
        remoteViews.setViewVisibility(param1Int, 0);
        int j = resources.getDimensionPixelSize(x.c.d);
        int k = resources.getDimensionPixelSize(x.c.c);
        int n = resources.getDimensionPixelSize(x.c.g);
        NotificationCompat.m m3 = this.a;
        remoteViews.setImageViewBitmap(param1Int, n(m3.U.icon, j - k, n, m3.e()));
      } 
      CharSequence charSequence2 = this.a.e;
      if (charSequence2 != null)
        remoteViews.setTextViewText(x.e.k0, charSequence2); 
      charSequence2 = this.a.f;
      boolean bool3 = true;
      if (charSequence2 != null) {
        remoteViews.setTextViewText(x.e.h0, charSequence2);
        param1Int = 1;
      } else {
        param1Int = 0;
      } 
      NotificationCompat.m m1 = this.a;
      CharSequence charSequence3 = m1.k;
      if (charSequence3 != null) {
        param1Int = x.e.O;
        remoteViews.setTextViewText(param1Int, charSequence3);
        remoteViews.setViewVisibility(param1Int, 0);
      } else if (m1.l > 0) {
        param1Int = resources.getInteger(x.f.a);
        if (this.a.l > param1Int) {
          remoteViews.setTextViewText(x.e.O, resources.getString(x.h.h));
        } else {
          NumberFormat numberFormat = NumberFormat.getIntegerInstance();
          remoteViews.setTextViewText(x.e.O, numberFormat.format(this.a.l));
        } 
        remoteViews.setViewVisibility(x.e.O, 0);
      } else {
        remoteViews.setViewVisibility(x.e.O, 8);
        boolean bool = false;
        int j = param1Int;
        param1Int = bool;
        CharSequence charSequence = this.a.r;
      } 
      boolean bool1 = true;
      param1Int = 1;
      CharSequence charSequence1 = this.a.r;
    }
    
    public void d(RemoteViews param1RemoteViews1, RemoteViews param1RemoteViews2) {
      q(param1RemoteViews1);
      int i = x.e.R;
      param1RemoteViews1.removeAllViews(i);
      param1RemoteViews1.addView(i, param1RemoteViews2.clone());
      param1RemoteViews1.setViewVisibility(i, 0);
      a.b(param1RemoteViews1, x.e.S, 0, e(), 0, 0);
    }
    
    Bitmap l(@NonNull IconCompat param1IconCompat, int param1Int) {
      return m(param1IconCompat, param1Int, 0);
    }
    
    @Nullable
    protected String p() {
      return null;
    }
    
    public RemoteViews r(t param1t) {
      return null;
    }
    
    public RemoteViews s(t param1t) {
      return null;
    }
    
    public RemoteViews t(t param1t) {
      return null;
    }
    
    protected void u(@NonNull Bundle param1Bundle) {
      if (param1Bundle.containsKey("android.summaryText")) {
        this.c = param1Bundle.getCharSequence("android.summaryText");
        this.d = true;
      } 
      this.b = param1Bundle.getCharSequence("android.title.big");
    }
    
    public void v(@Nullable NotificationCompat.m param1m) {
      if (this.a != param1m) {
        this.a = param1m;
        if (param1m != null)
          param1m.O(this); 
      } 
    }
    
    @RequiresApi(16)
    static class a {
      static void a(RemoteViews param2RemoteViews, int param2Int1, int param2Int2, float param2Float) {
        param2RemoteViews.setTextViewTextSize(param2Int1, param2Int2, param2Float);
      }
      
      static void b(RemoteViews param2RemoteViews, int param2Int1, int param2Int2, int param2Int3, int param2Int4, int param2Int5) {
        param2RemoteViews.setViewPadding(param2Int1, param2Int2, param2Int3, param2Int4, param2Int5);
      }
    }
    
    @RequiresApi(24)
    static class b {
      static void a(RemoteViews param2RemoteViews, int param2Int, boolean param2Boolean) {
        f1.a(param2RemoteViews, param2Int, param2Boolean);
      }
    }
  }
  
  @RequiresApi(16)
  static class a {
    static void a(RemoteViews param1RemoteViews, int param1Int1, int param1Int2, float param1Float) {
      param1RemoteViews.setTextViewTextSize(param1Int1, param1Int2, param1Float);
    }
    
    static void b(RemoteViews param1RemoteViews, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5) {
      param1RemoteViews.setViewPadding(param1Int1, param1Int2, param1Int3, param1Int4, param1Int5);
    }
  }
  
  @RequiresApi(24)
  static class b {
    static void a(RemoteViews param1RemoteViews, int param1Int, boolean param1Boolean) {
      f1.a(param1RemoteViews, param1Int, param1Boolean);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\core\app\NotificationCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */