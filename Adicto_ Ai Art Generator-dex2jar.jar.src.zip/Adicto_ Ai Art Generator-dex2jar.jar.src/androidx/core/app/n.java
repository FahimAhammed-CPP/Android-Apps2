package androidx.core.app;

import android.app.AppOpsManager;
import android.content.Context;
import android.os.Binder;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import g.e;

public final class n {
  public static int a(@NonNull Context paramContext, int paramInt, @NonNull String paramString1, @NonNull String paramString2) {
    if (Build.VERSION.SDK_INT >= 29) {
      AppOpsManager appOpsManager = b.c(paramContext);
      int i = b.a(appOpsManager, paramString1, Binder.getCallingUid(), paramString2);
      return (i != 0) ? i : b.a(appOpsManager, paramString1, paramInt, b.b(paramContext));
    } 
    return b(paramContext, paramString1, paramString2);
  }
  
  public static int b(@NonNull Context paramContext, @NonNull String paramString1, @NonNull String paramString2) {
    return (Build.VERSION.SDK_INT >= 23) ? a.c(a.<AppOpsManager>a(paramContext, AppOpsManager.class), paramString1, paramString2) : 1;
  }
  
  @Nullable
  public static String c(@NonNull String paramString) {
    return (Build.VERSION.SDK_INT >= 23) ? a.d(paramString) : null;
  }
  
  @RequiresApi(23)
  static class a {
    static <T> T a(Context param1Context, Class<T> param1Class) {
      return (T)e.a(param1Context, param1Class);
    }
    
    static int b(AppOpsManager param1AppOpsManager, String param1String1, String param1String2) {
      return m.a(param1AppOpsManager, param1String1, param1String2);
    }
    
    static int c(AppOpsManager param1AppOpsManager, String param1String1, String param1String2) {
      return k.a(param1AppOpsManager, param1String1, param1String2);
    }
    
    static String d(String param1String) {
      return l.a(param1String);
    }
  }
  
  @RequiresApi(29)
  static class b {
    static int a(@Nullable AppOpsManager param1AppOpsManager, @NonNull String param1String1, int param1Int, @NonNull String param1String2) {
      return (param1AppOpsManager == null) ? 1 : param1AppOpsManager.checkOpNoThrow(param1String1, param1Int, param1String2);
    }
    
    @NonNull
    static String b(@NonNull Context param1Context) {
      return o.a(param1Context);
    }
    
    @Nullable
    static AppOpsManager c(@NonNull Context param1Context) {
      return (AppOpsManager)e.a(param1Context, AppOpsManager.class);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\core\app\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */