package androidx.core.app;

import android.app.RemoteInput;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class o2 {
  private final String a;
  
  private final CharSequence b;
  
  private final CharSequence[] c;
  
  private final boolean d;
  
  private final int e;
  
  private final Bundle f;
  
  private final Set<String> g;
  
  o2(String paramString, CharSequence paramCharSequence, CharSequence[] paramArrayOfCharSequence, boolean paramBoolean, int paramInt, Bundle paramBundle, Set<String> paramSet) {
    this.a = paramString;
    this.b = paramCharSequence;
    this.c = paramArrayOfCharSequence;
    this.d = paramBoolean;
    this.e = paramInt;
    this.f = paramBundle;
    this.g = paramSet;
    if (f() == 2) {
      if (c())
        return; 
      throw new IllegalArgumentException("setEditChoicesBeforeSending requires setAllowFreeFormInput");
    } 
  }
  
  @RequiresApi(20)
  static RemoteInput a(o2 paramo2) {
    return a.b(paramo2);
  }
  
  @RequiresApi(20)
  static RemoteInput[] b(o2[] paramArrayOfo2) {
    if (paramArrayOfo2 == null)
      return null; 
    RemoteInput[] arrayOfRemoteInput = new RemoteInput[paramArrayOfo2.length];
    for (int i = 0; i < paramArrayOfo2.length; i++)
      arrayOfRemoteInput[i] = a(paramArrayOfo2[i]); 
    return arrayOfRemoteInput;
  }
  
  @Nullable
  public static Bundle j(@NonNull Intent paramIntent) {
    return a.c(paramIntent);
  }
  
  public boolean c() {
    return this.d;
  }
  
  @Nullable
  public Set<String> d() {
    return this.g;
  }
  
  @Nullable
  public CharSequence[] e() {
    return this.c;
  }
  
  public int f() {
    return this.e;
  }
  
  @NonNull
  public Bundle g() {
    return this.f;
  }
  
  @Nullable
  public CharSequence h() {
    return this.b;
  }
  
  @NonNull
  public String i() {
    return this.a;
  }
  
  public boolean k() {
    return (!c() && (e() == null || (e()).length == 0) && d() != null && !d().isEmpty());
  }
  
  @RequiresApi(20)
  static class a {
    static void a(Object param1Object, Intent param1Intent, Bundle param1Bundle) {
      RemoteInput.addResultsToIntent((RemoteInput[])param1Object, param1Intent, param1Bundle);
    }
    
    public static RemoteInput b(o2 param1o2) {
      RemoteInput.Builder builder = (new RemoteInput.Builder(param1o2.i())).setLabel(param1o2.h()).setChoices(param1o2.e()).setAllowFreeFormInput(param1o2.c()).addExtras(param1o2.g());
      if (Build.VERSION.SDK_INT >= 26) {
        Set<String> set = param1o2.d();
        if (set != null) {
          Iterator<String> iterator = set.iterator();
          while (iterator.hasNext())
            o2.b.d(builder, iterator.next(), true); 
        } 
      } 
      if (Build.VERSION.SDK_INT >= 29)
        o2.c.b(builder, param1o2.f()); 
      return builder.build();
    }
    
    static Bundle c(Intent param1Intent) {
      return RemoteInput.getResultsFromIntent(param1Intent);
    }
  }
  
  @RequiresApi(26)
  static class b {
    static void a(o2 param1o2, Intent param1Intent, Map<String, Uri> param1Map) {
      p2.a(o2.a(param1o2), param1Intent, param1Map);
    }
    
    static Set<String> b(Object param1Object) {
      return q2.a((RemoteInput)param1Object);
    }
    
    static Map<String, Uri> c(Intent param1Intent, String param1String) {
      return r2.a(param1Intent, param1String);
    }
    
    static RemoteInput.Builder d(RemoteInput.Builder param1Builder, String param1String, boolean param1Boolean) {
      return s2.a(param1Builder, param1String, param1Boolean);
    }
  }
  
  @RequiresApi(29)
  static class c {
    static int a(Object param1Object) {
      return r0.a((RemoteInput)param1Object);
    }
    
    static RemoteInput.Builder b(RemoteInput.Builder param1Builder, int param1Int) {
      return t2.a(param1Builder, param1Int);
    }
  }
  
  public static final class d {
    private final String a;
    
    private final Set<String> b = new HashSet<String>();
    
    private final Bundle c = new Bundle();
    
    private CharSequence d;
    
    private CharSequence[] e;
    
    private boolean f = true;
    
    private int g = 0;
    
    public d(@NonNull String param1String) {
      if (param1String != null) {
        this.a = param1String;
        return;
      } 
      throw new IllegalArgumentException("Result key can't be null");
    }
    
    @NonNull
    public o2 a() {
      return new o2(this.a, this.d, this.e, this.f, this.g, this.c, this.b);
    }
    
    @NonNull
    public d b(@NonNull String param1String, boolean param1Boolean) {
      if (param1Boolean) {
        this.b.add(param1String);
        return this;
      } 
      this.b.remove(param1String);
      return this;
    }
    
    @NonNull
    public d c(boolean param1Boolean) {
      this.f = param1Boolean;
      return this;
    }
    
    @NonNull
    public d d(@Nullable CharSequence[] param1ArrayOfCharSequence) {
      this.e = param1ArrayOfCharSequence;
      return this;
    }
    
    @NonNull
    public d e(@Nullable CharSequence param1CharSequence) {
      this.d = param1CharSequence;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\core\app\o2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */