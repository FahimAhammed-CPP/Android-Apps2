package androidx.core.app;

import android.app.Person;
import android.graphics.drawable.Icon;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.graphics.drawable.IconCompat;

public class m2 {
  @Nullable
  CharSequence a;
  
  @Nullable
  IconCompat b;
  
  @Nullable
  String c;
  
  @Nullable
  String d;
  
  boolean e;
  
  boolean f;
  
  m2(b paramb) {
    this.a = paramb.a;
    this.b = paramb.b;
    this.c = paramb.c;
    this.d = paramb.d;
    this.e = paramb.e;
    this.f = paramb.f;
  }
  
  @NonNull
  @RequiresApi(28)
  public static m2 a(@NonNull Person paramPerson) {
    return a.a(paramPerson);
  }
  
  @NonNull
  public static m2 b(@NonNull Bundle paramBundle) {
    Bundle bundle = paramBundle.getBundle("icon");
    b b = (new b()).f(paramBundle.getCharSequence("name"));
    if (bundle != null) {
      IconCompat iconCompat = IconCompat.b(bundle);
    } else {
      bundle = null;
    } 
    return b.c((IconCompat)bundle).g(paramBundle.getString("uri")).e(paramBundle.getString("key")).b(paramBundle.getBoolean("isBot")).d(paramBundle.getBoolean("isImportant")).a();
  }
  
  @Nullable
  public IconCompat c() {
    return this.b;
  }
  
  @Nullable
  public String d() {
    return this.d;
  }
  
  @Nullable
  public CharSequence e() {
    return this.a;
  }
  
  @Nullable
  public String f() {
    return this.c;
  }
  
  public boolean g() {
    return this.e;
  }
  
  public boolean h() {
    return this.f;
  }
  
  @NonNull
  public String i() {
    String str = this.c;
    if (str != null)
      return str; 
    if (this.a != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("name:");
      stringBuilder.append(this.a);
      return stringBuilder.toString();
    } 
    return "";
  }
  
  @NonNull
  @RequiresApi(28)
  public Person j() {
    return a.b(this);
  }
  
  @NonNull
  public Bundle k() {
    Bundle bundle = new Bundle();
    bundle.putCharSequence("name", this.a);
    IconCompat iconCompat = this.b;
    if (iconCompat != null) {
      Bundle bundle1 = iconCompat.y();
    } else {
      iconCompat = null;
    } 
    bundle.putBundle("icon", (Bundle)iconCompat);
    bundle.putString("uri", this.c);
    bundle.putString("key", this.d);
    bundle.putBoolean("isBot", this.e);
    bundle.putBoolean("isImportant", this.f);
    return bundle;
  }
  
  @RequiresApi(28)
  static class a {
    static m2 a(Person param1Person) {
      IconCompat iconCompat;
      m2.b b = (new m2.b()).f(param1Person.getName());
      if (param1Person.getIcon() != null) {
        iconCompat = IconCompat.c(param1Person.getIcon());
      } else {
        iconCompat = null;
      } 
      return b.c(iconCompat).g(param1Person.getUri()).e(param1Person.getKey()).b(param1Person.isBot()).d(param1Person.isImportant()).a();
    }
    
    static Person b(m2 param1m2) {
      Icon icon;
      Person.Builder builder = (new Person.Builder()).setName(param1m2.e());
      if (param1m2.c() != null) {
        icon = param1m2.c().z();
      } else {
        icon = null;
      } 
      return builder.setIcon(icon).setUri(param1m2.f()).setKey(param1m2.d()).setBot(param1m2.g()).setImportant(param1m2.h()).build();
    }
  }
  
  public static class b {
    @Nullable
    CharSequence a;
    
    @Nullable
    IconCompat b;
    
    @Nullable
    String c;
    
    @Nullable
    String d;
    
    boolean e;
    
    boolean f;
    
    @NonNull
    public m2 a() {
      return new m2(this);
    }
    
    @NonNull
    public b b(boolean param1Boolean) {
      this.e = param1Boolean;
      return this;
    }
    
    @NonNull
    public b c(@Nullable IconCompat param1IconCompat) {
      this.b = param1IconCompat;
      return this;
    }
    
    @NonNull
    public b d(boolean param1Boolean) {
      this.f = param1Boolean;
      return this;
    }
    
    @NonNull
    public b e(@Nullable String param1String) {
      this.d = param1String;
      return this;
    }
    
    @NonNull
    public b f(@Nullable CharSequence param1CharSequence) {
      this.a = param1CharSequence;
      return this;
    }
    
    @NonNull
    public b g(@Nullable String param1String) {
      this.c = param1String;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\core\app\m2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */