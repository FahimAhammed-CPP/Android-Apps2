package androidx.core.app;

import android.app.Activity;
import android.app.SharedElementCallback;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.content.a;
import java.util.Arrays;
import java.util.HashSet;

public class b extends a {
  private static h a;
  
  public static void b(@NonNull Activity paramActivity) {
    b.a(paramActivity);
  }
  
  public static void c(@NonNull Activity paramActivity) {
    c.a(paramActivity);
  }
  
  public static void e(@NonNull Activity paramActivity) {
    c.b(paramActivity);
  }
  
  public static void f(@NonNull Activity paramActivity) {
    if (Build.VERSION.SDK_INT >= 28) {
      paramActivity.recreate();
      return;
    } 
    (new Handler(paramActivity.getMainLooper())).post(new a(paramActivity));
  }
  
  public static void g(@NonNull Activity paramActivity, @NonNull String[] paramArrayOfString, int paramInt) {
    StringBuilder stringBuilder;
    String[] arrayOfString;
    h h1 = a;
    if (h1 != null && h1.a(paramActivity, paramArrayOfString, paramInt))
      return; 
    HashSet<Integer> hashSet = new HashSet();
    int j = 0;
    int i = 0;
    while (i < paramArrayOfString.length) {
      if (!TextUtils.isEmpty(paramArrayOfString[i])) {
        if (!androidx.core.os.a.d() && TextUtils.equals(paramArrayOfString[i], "android.permission.POST_NOTIFICATIONS"))
          hashSet.add(Integer.valueOf(i)); 
        i++;
        continue;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Permission request for permissions ");
      stringBuilder.append(Arrays.toString((Object[])paramArrayOfString));
      stringBuilder.append(" must not contain null or empty values");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    i = hashSet.size();
    if (i > 0) {
      arrayOfString = new String[paramArrayOfString.length - i];
    } else {
      arrayOfString = paramArrayOfString;
    } 
    if (i > 0) {
      if (i == paramArrayOfString.length)
        return; 
      int k = 0;
      i = j;
      while (i < paramArrayOfString.length) {
        j = k;
        if (!hashSet.contains(Integer.valueOf(i))) {
          arrayOfString[k] = paramArrayOfString[i];
          j = k + 1;
        } 
        i++;
        k = j;
      } 
    } 
    if (Build.VERSION.SDK_INT >= 23) {
      if (stringBuilder instanceof i)
        ((i)stringBuilder).validateRequestPermissionsRequestCode(paramInt); 
      d.b((Activity)stringBuilder, paramArrayOfString, paramInt);
      return;
    } 
    if (stringBuilder instanceof g)
      (new Handler(Looper.getMainLooper())).post(new a(arrayOfString, (Activity)stringBuilder, paramInt)); 
  }
  
  public static void h(@NonNull Activity paramActivity, @Nullable u2 paramu2) {
    c.c(paramActivity, null);
  }
  
  public static void i(@NonNull Activity paramActivity, @Nullable u2 paramu2) {
    c.d(paramActivity, null);
  }
  
  public static boolean j(@NonNull Activity paramActivity, @NonNull String paramString) {
    if (!androidx.core.os.a.d() && TextUtils.equals("android.permission.POST_NOTIFICATIONS", paramString))
      return false; 
    int i = Build.VERSION.SDK_INT;
    return (i >= 32) ? f.a(paramActivity, paramString) : ((i == 31) ? e.b(paramActivity, paramString) : ((i >= 23) ? d.c(paramActivity, paramString) : false));
  }
  
  public static void k(@NonNull Activity paramActivity, @NonNull Intent paramIntent, int paramInt, @Nullable Bundle paramBundle) {
    b.b(paramActivity, paramIntent, paramInt, paramBundle);
  }
  
  public static void l(@NonNull Activity paramActivity, @NonNull IntentSender paramIntentSender, int paramInt1, @Nullable Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, @Nullable Bundle paramBundle) throws IntentSender.SendIntentException {
    b.c(paramActivity, paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  public static void m(@NonNull Activity paramActivity) {
    c.e(paramActivity);
  }
  
  class a implements Runnable {
    a(b this$0, Activity param1Activity, int param1Int) {}
    
    public void run() {
      int[] arrayOfInt = new int[this.b.length];
      PackageManager packageManager = this.c.getPackageManager();
      String str = this.c.getPackageName();
      int j = this.b.length;
      for (int i = 0; i < j; i++)
        arrayOfInt[i] = packageManager.checkPermission(this.b[i], str); 
      ((b.g)this.c).onRequestPermissionsResult(this.d, this.b, arrayOfInt);
    }
  }
  
  @RequiresApi(16)
  static class b {
    static void a(Activity param1Activity) {
      param1Activity.finishAffinity();
    }
    
    static void b(Activity param1Activity, Intent param1Intent, int param1Int, Bundle param1Bundle) {
      param1Activity.startActivityForResult(param1Intent, param1Int, param1Bundle);
    }
    
    static void c(Activity param1Activity, IntentSender param1IntentSender, int param1Int1, Intent param1Intent, int param1Int2, int param1Int3, int param1Int4, Bundle param1Bundle) throws IntentSender.SendIntentException {
      param1Activity.startIntentSenderForResult(param1IntentSender, param1Int1, param1Intent, param1Int2, param1Int3, param1Int4, param1Bundle);
    }
  }
  
  @RequiresApi(21)
  static class c {
    static void a(Activity param1Activity) {
      param1Activity.finishAfterTransition();
    }
    
    static void b(Activity param1Activity) {
      param1Activity.postponeEnterTransition();
    }
    
    static void c(Activity param1Activity, SharedElementCallback param1SharedElementCallback) {
      param1Activity.setEnterSharedElementCallback(param1SharedElementCallback);
    }
    
    static void d(Activity param1Activity, SharedElementCallback param1SharedElementCallback) {
      param1Activity.setExitSharedElementCallback(param1SharedElementCallback);
    }
    
    static void e(Activity param1Activity) {
      param1Activity.startPostponedEnterTransition();
    }
  }
  
  @RequiresApi(23)
  static class d {
    static void a(Object param1Object) {
      ((SharedElementCallback.OnSharedElementsReadyListener)param1Object).onSharedElementsReady();
    }
    
    static void b(Activity param1Activity, String[] param1ArrayOfString, int param1Int) {
      c.a(param1Activity, param1ArrayOfString, param1Int);
    }
    
    static boolean c(Activity param1Activity, String param1String) {
      return d.a(param1Activity, param1String);
    }
  }
  
  @RequiresApi(31)
  static class e {
    static boolean a(@NonNull Activity param1Activity) {
      return e.a(param1Activity);
    }
    
    static boolean b(Activity param1Activity, String param1String) {
      try {
        PackageManager packageManager = param1Activity.getApplication().getPackageManager();
        return ((Boolean)PackageManager.class.getMethod("shouldShowRequestPermissionRationale", new Class[] { String.class }).invoke(packageManager, new Object[] { param1String })).booleanValue();
      } catch (NoSuchMethodException|java.lang.reflect.InvocationTargetException|IllegalAccessException noSuchMethodException) {
        return d.a(param1Activity, param1String);
      } 
    }
  }
  
  @RequiresApi(32)
  static class f {
    static boolean a(Activity param1Activity, String param1String) {
      return d.a(param1Activity, param1String);
    }
  }
  
  public static interface g {
    void onRequestPermissionsResult(int param1Int, @NonNull String[] param1ArrayOfString, @NonNull int[] param1ArrayOfint);
  }
  
  public static interface h {
    boolean a(@NonNull Activity param1Activity, @NonNull String[] param1ArrayOfString, int param1Int);
  }
  
  public static interface i {
    void validateRequestPermissionsRequestCode(int param1Int);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\core\app\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */