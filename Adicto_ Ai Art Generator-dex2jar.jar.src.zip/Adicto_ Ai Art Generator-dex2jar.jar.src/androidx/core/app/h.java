package androidx.core.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

public final class h {
  public static void a(@NonNull AlarmManager paramAlarmManager, long paramLong, @NonNull PendingIntent paramPendingIntent1, @NonNull PendingIntent paramPendingIntent2) {
    b.b(paramAlarmManager, b.a(paramLong, paramPendingIntent1), paramPendingIntent2);
  }
  
  public static void b(@NonNull AlarmManager paramAlarmManager, int paramInt, long paramLong, @NonNull PendingIntent paramPendingIntent) {
    if (Build.VERSION.SDK_INT >= 23) {
      c.a(paramAlarmManager, paramInt, paramLong, paramPendingIntent);
      return;
    } 
    paramAlarmManager.set(paramInt, paramLong, paramPendingIntent);
  }
  
  public static void c(@NonNull AlarmManager paramAlarmManager, int paramInt, long paramLong, @NonNull PendingIntent paramPendingIntent) {
    a.a(paramAlarmManager, paramInt, paramLong, paramPendingIntent);
  }
  
  public static void d(@NonNull AlarmManager paramAlarmManager, int paramInt, long paramLong, @NonNull PendingIntent paramPendingIntent) {
    if (Build.VERSION.SDK_INT >= 23) {
      c.b(paramAlarmManager, paramInt, paramLong, paramPendingIntent);
      return;
    } 
    c(paramAlarmManager, paramInt, paramLong, paramPendingIntent);
  }
  
  @RequiresApi(19)
  static class a {
    static void a(AlarmManager param1AlarmManager, int param1Int, long param1Long, PendingIntent param1PendingIntent) {
      param1AlarmManager.setExact(param1Int, param1Long, param1PendingIntent);
    }
  }
  
  @RequiresApi(21)
  static class b {
    static AlarmManager.AlarmClockInfo a(long param1Long, PendingIntent param1PendingIntent) {
      return new AlarmManager.AlarmClockInfo(param1Long, param1PendingIntent);
    }
    
    static void b(AlarmManager param1AlarmManager, Object param1Object, PendingIntent param1PendingIntent) {
      param1AlarmManager.setAlarmClock((AlarmManager.AlarmClockInfo)param1Object, param1PendingIntent);
    }
  }
  
  @RequiresApi(23)
  static class c {
    static void a(AlarmManager param1AlarmManager, int param1Int, long param1Long, PendingIntent param1PendingIntent) {
      i.a(param1AlarmManager, param1Int, param1Long, param1PendingIntent);
    }
    
    static void b(AlarmManager param1AlarmManager, int param1Int, long param1Long, PendingIntent param1PendingIntent) {
      j.a(param1AlarmManager, param1Int, param1Long, param1PendingIntent);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\core\app\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */