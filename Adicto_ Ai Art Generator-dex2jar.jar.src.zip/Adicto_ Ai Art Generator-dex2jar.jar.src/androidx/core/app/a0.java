package androidx.core.app;

import android.app.NotificationChannel;
import android.app.NotificationChannelGroup;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.util.e;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class a0 {
  final String a;
  
  CharSequence b;
  
  String c;
  
  private boolean d;
  
  private List<u> e = Collections.emptyList();
  
  @RequiresApi(28)
  a0(@NonNull NotificationChannelGroup paramNotificationChannelGroup) {
    this(paramNotificationChannelGroup, Collections.emptyList());
  }
  
  @RequiresApi(26)
  a0(@NonNull NotificationChannelGroup paramNotificationChannelGroup, @NonNull List<NotificationChannel> paramList) {
    this(a.d(paramNotificationChannelGroup));
    this.b = a.e(paramNotificationChannelGroup);
    int i = Build.VERSION.SDK_INT;
    if (i >= 28)
      this.c = b.a(paramNotificationChannelGroup); 
    if (i >= 28) {
      this.d = b.b(paramNotificationChannelGroup);
      this.e = a(a.b(paramNotificationChannelGroup));
      return;
    } 
    this.e = a(paramList);
  }
  
  a0(@NonNull String paramString) {
    this.a = (String)e.d(paramString);
  }
  
  @RequiresApi(26)
  private List<u> a(List<NotificationChannel> paramList) {
    ArrayList<u> arrayList = new ArrayList();
    for (NotificationChannel notificationChannel : paramList) {
      if (this.a.equals(a.c(notificationChannel)))
        arrayList.add(new u(notificationChannel)); 
    } 
    return arrayList;
  }
  
  NotificationChannelGroup b() {
    int i = Build.VERSION.SDK_INT;
    if (i < 26)
      return null; 
    NotificationChannelGroup notificationChannelGroup = a.a(this.a, this.b);
    if (i >= 28)
      b.c(notificationChannelGroup, this.c); 
    return notificationChannelGroup;
  }
  
  @RequiresApi(26)
  static class a {
    static NotificationChannelGroup a(String param1String, CharSequence param1CharSequence) {
      return new NotificationChannelGroup(param1String, param1CharSequence);
    }
    
    static List<NotificationChannel> b(NotificationChannelGroup param1NotificationChannelGroup) {
      return param1NotificationChannelGroup.getChannels();
    }
    
    static String c(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getGroup();
    }
    
    static String d(NotificationChannelGroup param1NotificationChannelGroup) {
      return param1NotificationChannelGroup.getId();
    }
    
    static CharSequence e(NotificationChannelGroup param1NotificationChannelGroup) {
      return param1NotificationChannelGroup.getName();
    }
  }
  
  @RequiresApi(28)
  static class b {
    static String a(NotificationChannelGroup param1NotificationChannelGroup) {
      return d0.a(param1NotificationChannelGroup);
    }
    
    static boolean b(NotificationChannelGroup param1NotificationChannelGroup) {
      return b0.a(param1NotificationChannelGroup);
    }
    
    static void c(NotificationChannelGroup param1NotificationChannelGroup, String param1String) {
      c0.a(param1NotificationChannelGroup, param1String);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\core\app\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */