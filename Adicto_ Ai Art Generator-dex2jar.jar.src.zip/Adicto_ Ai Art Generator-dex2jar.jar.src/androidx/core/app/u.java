package androidx.core.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.util.e;

public class u {
  @NonNull
  final String a;
  
  CharSequence b;
  
  int c;
  
  String d;
  
  String e;
  
  boolean f = true;
  
  Uri g = Settings.System.DEFAULT_NOTIFICATION_URI;
  
  AudioAttributes h;
  
  boolean i;
  
  int j = 0;
  
  boolean k;
  
  long[] l;
  
  String m;
  
  String n;
  
  private boolean o;
  
  private int p;
  
  private boolean q;
  
  private boolean r;
  
  @RequiresApi(26)
  u(@NonNull NotificationChannel paramNotificationChannel) {
    this(a.i(paramNotificationChannel), a.j(paramNotificationChannel));
    this.b = a.m(paramNotificationChannel);
    this.d = a.g(paramNotificationChannel);
    this.e = a.h(paramNotificationChannel);
    this.f = a.b(paramNotificationChannel);
    this.g = a.n(paramNotificationChannel);
    this.h = a.f(paramNotificationChannel);
    this.i = a.v(paramNotificationChannel);
    this.j = a.k(paramNotificationChannel);
    this.k = a.w(paramNotificationChannel);
    this.l = a.o(paramNotificationChannel);
    int i = Build.VERSION.SDK_INT;
    if (i >= 30) {
      this.m = c.b(paramNotificationChannel);
      this.n = c.a(paramNotificationChannel);
    } 
    this.o = a.a(paramNotificationChannel);
    this.p = a.l(paramNotificationChannel);
    if (i >= 29)
      this.q = b.a(paramNotificationChannel); 
    if (i >= 30)
      this.r = c.c(paramNotificationChannel); 
  }
  
  u(@NonNull String paramString, int paramInt) {
    this.a = (String)e.d(paramString);
    this.c = paramInt;
    this.h = Notification.AUDIO_ATTRIBUTES_DEFAULT;
  }
  
  NotificationChannel a() {
    int i = Build.VERSION.SDK_INT;
    if (i < 26)
      return null; 
    NotificationChannel notificationChannel = a.c(this.a, this.b, this.c);
    a.p(notificationChannel, this.d);
    a.q(notificationChannel, this.e);
    a.s(notificationChannel, this.f);
    a.t(notificationChannel, this.g, this.h);
    a.d(notificationChannel, this.i);
    a.r(notificationChannel, this.j);
    a.u(notificationChannel, this.l);
    a.e(notificationChannel, this.k);
    if (i >= 30) {
      String str = this.m;
      if (str != null) {
        String str1 = this.n;
        if (str1 != null)
          c.d(notificationChannel, str, str1); 
      } 
    } 
    return notificationChannel;
  }
  
  @RequiresApi(26)
  static class a {
    static boolean a(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.canBypassDnd();
    }
    
    static boolean b(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.canShowBadge();
    }
    
    static NotificationChannel c(String param1String, CharSequence param1CharSequence, int param1Int) {
      return new NotificationChannel(param1String, param1CharSequence, param1Int);
    }
    
    static void d(NotificationChannel param1NotificationChannel, boolean param1Boolean) {
      param1NotificationChannel.enableLights(param1Boolean);
    }
    
    static void e(NotificationChannel param1NotificationChannel, boolean param1Boolean) {
      param1NotificationChannel.enableVibration(param1Boolean);
    }
    
    static AudioAttributes f(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getAudioAttributes();
    }
    
    static String g(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getDescription();
    }
    
    static String h(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getGroup();
    }
    
    static String i(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getId();
    }
    
    static int j(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getImportance();
    }
    
    static int k(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getLightColor();
    }
    
    static int l(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getLockscreenVisibility();
    }
    
    static CharSequence m(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getName();
    }
    
    static Uri n(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getSound();
    }
    
    static long[] o(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getVibrationPattern();
    }
    
    static void p(NotificationChannel param1NotificationChannel, String param1String) {
      param1NotificationChannel.setDescription(param1String);
    }
    
    static void q(NotificationChannel param1NotificationChannel, String param1String) {
      param1NotificationChannel.setGroup(param1String);
    }
    
    static void r(NotificationChannel param1NotificationChannel, int param1Int) {
      param1NotificationChannel.setLightColor(param1Int);
    }
    
    static void s(NotificationChannel param1NotificationChannel, boolean param1Boolean) {
      param1NotificationChannel.setShowBadge(param1Boolean);
    }
    
    static void t(NotificationChannel param1NotificationChannel, Uri param1Uri, AudioAttributes param1AudioAttributes) {
      param1NotificationChannel.setSound(param1Uri, param1AudioAttributes);
    }
    
    static void u(NotificationChannel param1NotificationChannel, long[] param1ArrayOflong) {
      param1NotificationChannel.setVibrationPattern(param1ArrayOflong);
    }
    
    static boolean v(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.shouldShowLights();
    }
    
    static boolean w(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.shouldVibrate();
    }
  }
  
  @RequiresApi(29)
  static class b {
    static boolean a(NotificationChannel param1NotificationChannel) {
      return v.a(param1NotificationChannel);
    }
  }
  
  @RequiresApi(30)
  static class c {
    static String a(NotificationChannel param1NotificationChannel) {
      return z.a(param1NotificationChannel);
    }
    
    static String b(NotificationChannel param1NotificationChannel) {
      return y.a(param1NotificationChannel);
    }
    
    static boolean c(NotificationChannel param1NotificationChannel) {
      return x.a(param1NotificationChannel);
    }
    
    static void d(NotificationChannel param1NotificationChannel, String param1String1, String param1String2) {
      w.a(param1NotificationChannel, param1String1, param1String2);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\core\ap\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */