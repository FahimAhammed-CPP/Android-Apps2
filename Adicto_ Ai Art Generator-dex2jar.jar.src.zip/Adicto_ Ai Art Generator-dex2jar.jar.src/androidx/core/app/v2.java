package androidx.core.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.ArrayList;
import java.util.Iterator;

public final class v2 implements Iterable<Intent> {
  private final ArrayList<Intent> b = new ArrayList<Intent>();
  
  private final Context c;
  
  private v2(Context paramContext) {
    this.c = paramContext;
  }
  
  @NonNull
  public static v2 f(@NonNull Context paramContext) {
    return new v2(paramContext);
  }
  
  @NonNull
  public v2 c(@NonNull Intent paramIntent) {
    this.b.add(paramIntent);
    return this;
  }
  
  @NonNull
  public v2 d(@NonNull Activity paramActivity) {
    Intent intent1;
    if (paramActivity instanceof a) {
      intent1 = ((a)paramActivity).a();
    } else {
      intent1 = null;
    } 
    Intent intent2 = intent1;
    if (intent1 == null)
      intent2 = s.a(paramActivity); 
    if (intent2 != null) {
      ComponentName componentName2 = intent2.getComponent();
      ComponentName componentName1 = componentName2;
      if (componentName2 == null)
        componentName1 = intent2.resolveActivity(this.c.getPackageManager()); 
      e(componentName1);
      c(intent2);
    } 
    return this;
  }
  
  @NonNull
  public v2 e(@NonNull ComponentName paramComponentName) {
    int i = this.b.size();
    try {
      for (Intent intent = s.b(this.c, paramComponentName); intent != null; intent = s.b(this.c, intent.getComponent()))
        this.b.add(i, intent); 
      return this;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      Log.e("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
      throw new IllegalArgumentException(nameNotFoundException);
    } 
  }
  
  public void g() {
    h(null);
  }
  
  public void h(@Nullable Bundle paramBundle) {
    if (!this.b.isEmpty()) {
      Intent[] arrayOfIntent = this.b.<Intent>toArray(new Intent[0]);
      arrayOfIntent[0] = (new Intent(arrayOfIntent[0])).addFlags(268484608);
      if (!androidx.core.content.a.startActivities(this.c, arrayOfIntent, paramBundle)) {
        Intent intent = new Intent(arrayOfIntent[arrayOfIntent.length - 1]);
        intent.addFlags(268435456);
        this.c.startActivity(intent);
      } 
      return;
    } 
    throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
  }
  
  @Deprecated
  @NonNull
  public Iterator<Intent> iterator() {
    return this.b.iterator();
  }
  
  public static interface a {
    @Nullable
    Intent a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\core\app\v2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */