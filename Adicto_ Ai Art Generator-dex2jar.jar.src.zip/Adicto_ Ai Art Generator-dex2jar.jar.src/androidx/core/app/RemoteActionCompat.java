package androidx.core.app;

import android.app.PendingIntent;
import androidx.annotation.NonNull;
import androidx.core.graphics.drawable.IconCompat;
import y0.b;

public final class RemoteActionCompat implements b {
  @NonNull
  public IconCompat a;
  
  @NonNull
  public CharSequence b;
  
  @NonNull
  public CharSequence c;
  
  @NonNull
  public PendingIntent d;
  
  public boolean e;
  
  public boolean f;
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\core\app\RemoteActionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */