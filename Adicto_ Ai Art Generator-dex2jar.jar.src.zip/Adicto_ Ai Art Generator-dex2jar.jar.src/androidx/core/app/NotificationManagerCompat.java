package androidx.core.app;

import android.app.AppOpsManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationChannelGroup;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RequiresPermission;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class NotificationManagerCompat {
  public static final String ACTION_BIND_SIDE_CHANNEL = "android.support.BIND_NOTIFICATION_SIDE_CHANNEL";
  
  private static final String CHECK_OP_NO_THROW = "checkOpNoThrow";
  
  public static final String EXTRA_USE_SIDE_CHANNEL = "android.support.useSideChannel";
  
  public static final int IMPORTANCE_DEFAULT = 3;
  
  public static final int IMPORTANCE_HIGH = 4;
  
  public static final int IMPORTANCE_LOW = 2;
  
  public static final int IMPORTANCE_MAX = 5;
  
  public static final int IMPORTANCE_MIN = 1;
  
  public static final int IMPORTANCE_NONE = 0;
  
  public static final int IMPORTANCE_UNSPECIFIED = -1000;
  
  static final int MAX_SIDE_CHANNEL_SDK_VERSION = 19;
  
  private static final String OP_POST_NOTIFICATION = "OP_POST_NOTIFICATION";
  
  private static final String SETTING_ENABLED_NOTIFICATION_LISTENERS = "enabled_notification_listeners";
  
  private static final int SIDE_CHANNEL_RETRY_BASE_INTERVAL_MS = 1000;
  
  private static final int SIDE_CHANNEL_RETRY_MAX_COUNT = 6;
  
  private static final String TAG = "NotifManCompat";
  
  private static Set<String> sEnabledNotificationListenerPackages;
  
  private static String sEnabledNotificationListeners;
  
  private static final Object sEnabledNotificationListenersLock = new Object();
  
  private static final Object sLock;
  
  private static g sSideChannelManager;
  
  private final Context mContext;
  
  private final NotificationManager mNotificationManager;
  
  static {
    sEnabledNotificationListenerPackages = new HashSet<String>();
    sLock = new Object();
  }
  
  private NotificationManagerCompat(Context paramContext) {
    this.mContext = paramContext;
    this.mNotificationManager = (NotificationManager)paramContext.getSystemService("notification");
  }
  
  @NonNull
  public static NotificationManagerCompat from(@NonNull Context paramContext) {
    return new NotificationManagerCompat(paramContext);
  }
  
  @NonNull
  public static Set<String> getEnabledListenerPackages(@NonNull Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   4: ldc 'enabled_notification_listeners'
    //   6: invokestatic getString : (Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;
    //   9: astore_3
    //   10: getstatic androidx/core/app/NotificationManagerCompat.sEnabledNotificationListenersLock : Ljava/lang/Object;
    //   13: astore_0
    //   14: aload_0
    //   15: monitorenter
    //   16: aload_3
    //   17: ifnull -> 101
    //   20: aload_3
    //   21: getstatic androidx/core/app/NotificationManagerCompat.sEnabledNotificationListeners : Ljava/lang/String;
    //   24: invokevirtual equals : (Ljava/lang/Object;)Z
    //   27: ifne -> 101
    //   30: aload_3
    //   31: ldc ':'
    //   33: iconst_m1
    //   34: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   37: astore #4
    //   39: new java/util/HashSet
    //   42: dup
    //   43: aload #4
    //   45: arraylength
    //   46: invokespecial <init> : (I)V
    //   49: astore #5
    //   51: aload #4
    //   53: arraylength
    //   54: istore_2
    //   55: iconst_0
    //   56: istore_1
    //   57: iload_1
    //   58: iload_2
    //   59: if_icmpge -> 92
    //   62: aload #4
    //   64: iload_1
    //   65: aaload
    //   66: invokestatic unflattenFromString : (Ljava/lang/String;)Landroid/content/ComponentName;
    //   69: astore #6
    //   71: aload #6
    //   73: ifnull -> 114
    //   76: aload #5
    //   78: aload #6
    //   80: invokevirtual getPackageName : ()Ljava/lang/String;
    //   83: invokeinterface add : (Ljava/lang/Object;)Z
    //   88: pop
    //   89: goto -> 114
    //   92: aload #5
    //   94: putstatic androidx/core/app/NotificationManagerCompat.sEnabledNotificationListenerPackages : Ljava/util/Set;
    //   97: aload_3
    //   98: putstatic androidx/core/app/NotificationManagerCompat.sEnabledNotificationListeners : Ljava/lang/String;
    //   101: getstatic androidx/core/app/NotificationManagerCompat.sEnabledNotificationListenerPackages : Ljava/util/Set;
    //   104: astore_3
    //   105: aload_0
    //   106: monitorexit
    //   107: aload_3
    //   108: areturn
    //   109: astore_3
    //   110: aload_0
    //   111: monitorexit
    //   112: aload_3
    //   113: athrow
    //   114: iload_1
    //   115: iconst_1
    //   116: iadd
    //   117: istore_1
    //   118: goto -> 57
    // Exception table:
    //   from	to	target	type
    //   20	55	109	finally
    //   62	71	109	finally
    //   76	89	109	finally
    //   92	101	109	finally
    //   101	107	109	finally
    //   110	112	109	finally
  }
  
  private void pushSideChannelQueue(h paramh) {
    synchronized (sLock) {
      if (sSideChannelManager == null)
        sSideChannelManager = new g(this.mContext.getApplicationContext()); 
      sSideChannelManager.h(paramh);
      return;
    } 
  }
  
  private static boolean useSideChannelForNotification(Notification paramNotification) {
    Bundle bundle = NotificationCompat.getExtras(paramNotification);
    return (bundle != null && bundle.getBoolean("android.support.useSideChannel"));
  }
  
  public boolean areNotificationsEnabled() {
    if (Build.VERSION.SDK_INT >= 24)
      return a.a(this.mNotificationManager); 
    AppOpsManager appOpsManager = (AppOpsManager)this.mContext.getSystemService("appops");
    ApplicationInfo applicationInfo = this.mContext.getApplicationInfo();
    String str = this.mContext.getApplicationContext().getPackageName();
    int i = applicationInfo.uid;
    try {
      Class<?> clazz = Class.forName(AppOpsManager.class.getName());
      Class<int> clazz1 = int.class;
      i = ((Integer)clazz.getMethod("checkOpNoThrow", new Class[] { clazz1, clazz1, String.class }).invoke(appOpsManager, new Object[] { Integer.valueOf(((Integer)clazz.getDeclaredField("OP_POST_NOTIFICATION").get(Integer.class)).intValue()), Integer.valueOf(i), str })).intValue();
      return (i == 0);
    } catch (ClassNotFoundException|NoSuchMethodException|NoSuchFieldException|java.lang.reflect.InvocationTargetException|IllegalAccessException|RuntimeException classNotFoundException) {
      return true;
    } 
  }
  
  public void cancel(int paramInt) {
    cancel(null, paramInt);
  }
  
  public void cancel(@Nullable String paramString, int paramInt) {
    this.mNotificationManager.cancel(paramString, paramInt);
  }
  
  public void cancelAll() {
    this.mNotificationManager.cancelAll();
  }
  
  public void createNotificationChannel(@NonNull NotificationChannel paramNotificationChannel) {
    if (Build.VERSION.SDK_INT >= 26)
      b.a(this.mNotificationManager, paramNotificationChannel); 
  }
  
  public void createNotificationChannel(@NonNull u paramu) {
    createNotificationChannel(paramu.a());
  }
  
  public void createNotificationChannelGroup(@NonNull NotificationChannelGroup paramNotificationChannelGroup) {
    if (Build.VERSION.SDK_INT >= 26)
      b.b(this.mNotificationManager, paramNotificationChannelGroup); 
  }
  
  public void createNotificationChannelGroup(@NonNull a0 parama0) {
    createNotificationChannelGroup(parama0.b());
  }
  
  public void createNotificationChannelGroups(@NonNull List<NotificationChannelGroup> paramList) {
    if (Build.VERSION.SDK_INT >= 26)
      b.c(this.mNotificationManager, paramList); 
  }
  
  public void createNotificationChannelGroupsCompat(@NonNull List<a0> paramList) {
    if (Build.VERSION.SDK_INT >= 26 && !paramList.isEmpty()) {
      ArrayList<NotificationChannelGroup> arrayList = new ArrayList(paramList.size());
      Iterator<a0> iterator = paramList.iterator();
      while (iterator.hasNext())
        arrayList.add(((a0)iterator.next()).b()); 
      b.c(this.mNotificationManager, arrayList);
    } 
  }
  
  public void createNotificationChannels(@NonNull List<NotificationChannel> paramList) {
    if (Build.VERSION.SDK_INT >= 26)
      b.d(this.mNotificationManager, paramList); 
  }
  
  public void createNotificationChannelsCompat(@NonNull List<u> paramList) {
    if (Build.VERSION.SDK_INT >= 26 && !paramList.isEmpty()) {
      ArrayList<NotificationChannel> arrayList = new ArrayList(paramList.size());
      Iterator<u> iterator = paramList.iterator();
      while (iterator.hasNext())
        arrayList.add(((u)iterator.next()).a()); 
      b.d(this.mNotificationManager, arrayList);
    } 
  }
  
  public void deleteNotificationChannel(@NonNull String paramString) {
    if (Build.VERSION.SDK_INT >= 26)
      b.e(this.mNotificationManager, paramString); 
  }
  
  public void deleteNotificationChannelGroup(@NonNull String paramString) {
    if (Build.VERSION.SDK_INT >= 26)
      b.f(this.mNotificationManager, paramString); 
  }
  
  public void deleteUnlistedNotificationChannels(@NonNull Collection<String> paramCollection) {
    if (Build.VERSION.SDK_INT >= 26)
      for (NotificationChannel notificationChannel : b.k(this.mNotificationManager)) {
        if (paramCollection.contains(b.g(notificationChannel)) || (Build.VERSION.SDK_INT >= 30 && paramCollection.contains(d.b(notificationChannel))))
          continue; 
        b.e(this.mNotificationManager, b.g(notificationChannel));
      }  
  }
  
  public int getImportance() {
    return (Build.VERSION.SDK_INT >= 24) ? a.b(this.mNotificationManager) : -1000;
  }
  
  @Nullable
  public NotificationChannel getNotificationChannel(@NonNull String paramString) {
    return (Build.VERSION.SDK_INT >= 26) ? b.i(this.mNotificationManager, paramString) : null;
  }
  
  @Nullable
  public NotificationChannel getNotificationChannel(@NonNull String paramString1, @NonNull String paramString2) {
    return (Build.VERSION.SDK_INT >= 30) ? d.a(this.mNotificationManager, paramString1, paramString2) : getNotificationChannel(paramString1);
  }
  
  @Nullable
  public u getNotificationChannelCompat(@NonNull String paramString) {
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationChannel notificationChannel = getNotificationChannel(paramString);
      if (notificationChannel != null)
        return new u(notificationChannel); 
    } 
    return null;
  }
  
  @Nullable
  public u getNotificationChannelCompat(@NonNull String paramString1, @NonNull String paramString2) {
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationChannel notificationChannel = getNotificationChannel(paramString1, paramString2);
      if (notificationChannel != null)
        return new u(notificationChannel); 
    } 
    return null;
  }
  
  @Nullable
  public NotificationChannelGroup getNotificationChannelGroup(@NonNull String paramString) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 28)
      return c.a(this.mNotificationManager, paramString); 
    if (i >= 26)
      for (NotificationChannelGroup notificationChannelGroup : getNotificationChannelGroups()) {
        if (b.h(notificationChannelGroup).equals(paramString))
          return notificationChannelGroup; 
      }  
    return null;
  }
  
  @Nullable
  public a0 getNotificationChannelGroupCompat(@NonNull String paramString) {
    NotificationChannelGroup notificationChannelGroup;
    int i = Build.VERSION.SDK_INT;
    if (i >= 28) {
      notificationChannelGroup = getNotificationChannelGroup(paramString);
      if (notificationChannelGroup != null)
        return new a0(notificationChannelGroup); 
    } else if (i >= 26) {
      notificationChannelGroup = getNotificationChannelGroup((String)notificationChannelGroup);
      if (notificationChannelGroup != null)
        return new a0(notificationChannelGroup, getNotificationChannels()); 
    } 
    return null;
  }
  
  @NonNull
  public List<NotificationChannelGroup> getNotificationChannelGroups() {
    return (Build.VERSION.SDK_INT >= 26) ? b.j(this.mNotificationManager) : Collections.emptyList();
  }
  
  @NonNull
  public List<a0> getNotificationChannelGroupsCompat() {
    int i = Build.VERSION.SDK_INT;
    if (i >= 26) {
      List<NotificationChannelGroup> list = getNotificationChannelGroups();
      if (!list.isEmpty()) {
        List<NotificationChannel> list1;
        if (i >= 28) {
          list1 = Collections.emptyList();
        } else {
          list1 = getNotificationChannels();
        } 
        ArrayList<a0> arrayList = new ArrayList(list.size());
        for (NotificationChannelGroup notificationChannelGroup : list) {
          if (Build.VERSION.SDK_INT >= 28) {
            arrayList.add(new a0(notificationChannelGroup));
            continue;
          } 
          arrayList.add(new a0(notificationChannelGroup, list1));
        } 
        return arrayList;
      } 
    } 
    return Collections.emptyList();
  }
  
  @NonNull
  public List<NotificationChannel> getNotificationChannels() {
    return (Build.VERSION.SDK_INT >= 26) ? b.k(this.mNotificationManager) : Collections.emptyList();
  }
  
  @NonNull
  public List<u> getNotificationChannelsCompat() {
    if (Build.VERSION.SDK_INT >= 26) {
      List<NotificationChannel> list = getNotificationChannels();
      if (!list.isEmpty()) {
        ArrayList<u> arrayList = new ArrayList(list.size());
        Iterator<NotificationChannel> iterator = list.iterator();
        while (iterator.hasNext())
          arrayList.add(new u(iterator.next())); 
        return arrayList;
      } 
    } 
    return Collections.emptyList();
  }
  
  @RequiresPermission("android.permission.POST_NOTIFICATIONS")
  public void notify(int paramInt, @NonNull Notification paramNotification) {
    notify(null, paramInt, paramNotification);
  }
  
  @RequiresPermission("android.permission.POST_NOTIFICATIONS")
  public void notify(@Nullable String paramString, int paramInt, @NonNull Notification paramNotification) {
    if (useSideChannelForNotification(paramNotification)) {
      pushSideChannelQueue(new e(this.mContext.getPackageName(), paramInt, paramString, paramNotification));
      this.mNotificationManager.cancel(paramString, paramInt);
      return;
    } 
    this.mNotificationManager.notify(paramString, paramInt, paramNotification);
  }
  
  @RequiresApi(24)
  static class a {
    static boolean a(NotificationManager param1NotificationManager) {
      return a2.a(param1NotificationManager);
    }
    
    static int b(NotificationManager param1NotificationManager) {
      return z1.a(param1NotificationManager);
    }
  }
  
  @RequiresApi(26)
  static class b {
    static void a(NotificationManager param1NotificationManager, NotificationChannel param1NotificationChannel) {
      j2.a(param1NotificationManager, param1NotificationChannel);
    }
    
    static void b(NotificationManager param1NotificationManager, NotificationChannelGroup param1NotificationChannelGroup) {
      h2.a(param1NotificationManager, param1NotificationChannelGroup);
    }
    
    static void c(NotificationManager param1NotificationManager, List<NotificationChannelGroup> param1List) {
      g2.a(param1NotificationManager, param1List);
    }
    
    static void d(NotificationManager param1NotificationManager, List<NotificationChannel> param1List) {
      i2.a(param1NotificationManager, param1List);
    }
    
    static void e(NotificationManager param1NotificationManager, String param1String) {
      b2.a(param1NotificationManager, param1String);
    }
    
    static void f(NotificationManager param1NotificationManager, String param1String) {
      e2.a(param1NotificationManager, param1String);
    }
    
    static String g(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getId();
    }
    
    static String h(NotificationChannelGroup param1NotificationChannelGroup) {
      return param1NotificationChannelGroup.getId();
    }
    
    static NotificationChannel i(NotificationManager param1NotificationManager, String param1String) {
      return f2.a(param1NotificationManager, param1String);
    }
    
    static List<NotificationChannelGroup> j(NotificationManager param1NotificationManager) {
      return d2.a(param1NotificationManager);
    }
    
    static List<NotificationChannel> k(NotificationManager param1NotificationManager) {
      return c2.a(param1NotificationManager);
    }
  }
  
  @RequiresApi(28)
  static class c {
    static NotificationChannelGroup a(NotificationManager param1NotificationManager, String param1String) {
      return k2.a(param1NotificationManager, param1String);
    }
  }
  
  @RequiresApi(30)
  static class d {
    static NotificationChannel a(NotificationManager param1NotificationManager, String param1String1, String param1String2) {
      return l2.a(param1NotificationManager, param1String1, param1String2);
    }
    
    static String b(NotificationChannel param1NotificationChannel) {
      return y.a(param1NotificationChannel);
    }
  }
  
  private static class e implements h {
    final String a;
    
    final int b;
    
    final String c;
    
    final Notification d;
    
    e(String param1String1, int param1Int, String param1String2, Notification param1Notification) {
      this.a = param1String1;
      this.b = param1Int;
      this.c = param1String2;
      this.d = param1Notification;
    }
    
    public void a(b.a param1a) throws RemoteException {
      param1a.G(this.a, this.b, this.c, this.d);
    }
    
    @NonNull
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder("NotifyTask[");
      stringBuilder.append("packageName:");
      stringBuilder.append(this.a);
      stringBuilder.append(", id:");
      stringBuilder.append(this.b);
      stringBuilder.append(", tag:");
      stringBuilder.append(this.c);
      stringBuilder.append("]");
      return stringBuilder.toString();
    }
  }
  
  private static class f {
    final ComponentName a;
    
    final IBinder b;
    
    f(ComponentName param1ComponentName, IBinder param1IBinder) {
      this.a = param1ComponentName;
      this.b = param1IBinder;
    }
  }
  
  private static class g implements Handler.Callback, ServiceConnection {
    private final Context b;
    
    private final HandlerThread c;
    
    private final Handler d;
    
    private final Map<ComponentName, a> e = new HashMap<ComponentName, a>();
    
    private Set<String> f = new HashSet<String>();
    
    g(Context param1Context) {
      this.b = param1Context;
      HandlerThread handlerThread = new HandlerThread("NotificationManagerCompat");
      this.c = handlerThread;
      handlerThread.start();
      this.d = new Handler(handlerThread.getLooper(), this);
    }
    
    private boolean a(a param1a) {
      if (param1a.b)
        return true; 
      Intent intent = (new Intent("android.support.BIND_NOTIFICATION_SIDE_CHANNEL")).setComponent(param1a.a);
      boolean bool = this.b.bindService(intent, this, 33);
      param1a.b = bool;
      if (bool) {
        param1a.e = 0;
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to bind to listener ");
        stringBuilder.append(param1a.a);
        Log.w("NotifManCompat", stringBuilder.toString());
        this.b.unbindService(this);
      } 
      return param1a.b;
    }
    
    private void b(a param1a) {
      if (param1a.b) {
        this.b.unbindService(this);
        param1a.b = false;
      } 
      param1a.c = null;
    }
    
    private void c(NotificationManagerCompat.h param1h) {
      j();
      for (a a : this.e.values()) {
        a.d.add(param1h);
        g(a);
      } 
    }
    
    private void d(ComponentName param1ComponentName) {
      a a = this.e.get(param1ComponentName);
      if (a != null)
        g(a); 
    }
    
    private void e(ComponentName param1ComponentName, IBinder param1IBinder) {
      a a = this.e.get(param1ComponentName);
      if (a != null) {
        a.c = b.a.a.L(param1IBinder);
        a.e = 0;
        g(a);
      } 
    }
    
    private void f(ComponentName param1ComponentName) {
      a a = this.e.get(param1ComponentName);
      if (a != null)
        b(a); 
    }
    
    private void g(a param1a) {
      if (Log.isLoggable("NotifManCompat", 3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Processing component ");
        stringBuilder.append(param1a.a);
        stringBuilder.append(", ");
        stringBuilder.append(param1a.d.size());
        stringBuilder.append(" queued tasks");
        Log.d("NotifManCompat", stringBuilder.toString());
      } 
      if (param1a.d.isEmpty())
        return; 
      if (!a(param1a) || param1a.c == null) {
        i(param1a);
        return;
      } 
      while (true) {
        NotificationManagerCompat.h h = param1a.d.peek();
        if (h != null)
          try {
            if (Log.isLoggable("NotifManCompat", 3)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Sending task ");
              stringBuilder.append(h);
              Log.d("NotifManCompat", stringBuilder.toString());
            } 
            h.a(param1a.c);
            param1a.d.remove();
            continue;
          } catch (DeadObjectException deadObjectException) {
            if (Log.isLoggable("NotifManCompat", 3)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Remote service has died: ");
              stringBuilder.append(param1a.a);
              Log.d("NotifManCompat", stringBuilder.toString());
            } 
          } catch (RemoteException remoteException) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("RemoteException communicating with ");
            stringBuilder.append(param1a.a);
            Log.w("NotifManCompat", stringBuilder.toString(), (Throwable)remoteException);
          }  
        if (!param1a.d.isEmpty())
          i(param1a); 
        return;
      } 
    }
    
    private void i(a param1a) {
      if (this.d.hasMessages(3, param1a.a))
        return; 
      int i = param1a.e + 1;
      param1a.e = i;
      if (i > 6) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Giving up on delivering ");
        stringBuilder.append(param1a.d.size());
        stringBuilder.append(" tasks to ");
        stringBuilder.append(param1a.a);
        stringBuilder.append(" after ");
        stringBuilder.append(param1a.e);
        stringBuilder.append(" retries");
        Log.w("NotifManCompat", stringBuilder.toString());
        param1a.d.clear();
        return;
      } 
      i = (1 << i - 1) * 1000;
      if (Log.isLoggable("NotifManCompat", 3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Scheduling retry for ");
        stringBuilder.append(i);
        stringBuilder.append(" ms");
        Log.d("NotifManCompat", stringBuilder.toString());
      } 
      Message message = this.d.obtainMessage(3, param1a.a);
      this.d.sendMessageDelayed(message, i);
    }
    
    private void j() {
      Set<String> set = NotificationManagerCompat.getEnabledListenerPackages(this.b);
      if (set.equals(this.f))
        return; 
      this.f = set;
      List list = this.b.getPackageManager().queryIntentServices((new Intent()).setAction("android.support.BIND_NOTIFICATION_SIDE_CHANNEL"), 0);
      HashSet<ComponentName> hashSet = new HashSet();
      for (ResolveInfo resolveInfo : list) {
        if (!set.contains(resolveInfo.serviceInfo.packageName))
          continue; 
        ServiceInfo serviceInfo = resolveInfo.serviceInfo;
        ComponentName componentName = new ComponentName(serviceInfo.packageName, serviceInfo.name);
        if (resolveInfo.serviceInfo.permission != null) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Permission present on component ");
          stringBuilder.append(componentName);
          stringBuilder.append(", not adding listener record.");
          Log.w("NotifManCompat", stringBuilder.toString());
          continue;
        } 
        hashSet.add(componentName);
      } 
      for (ComponentName componentName : hashSet) {
        if (!this.e.containsKey(componentName)) {
          if (Log.isLoggable("NotifManCompat", 3)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Adding listener record for ");
            stringBuilder.append(componentName);
            Log.d("NotifManCompat", stringBuilder.toString());
          } 
          this.e.put(componentName, new a(componentName));
        } 
      } 
      Iterator<Map.Entry> iterator = this.e.entrySet().iterator();
      while (iterator.hasNext()) {
        Map.Entry entry = iterator.next();
        if (!hashSet.contains(entry.getKey())) {
          if (Log.isLoggable("NotifManCompat", 3)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Removing listener record for ");
            stringBuilder.append(entry.getKey());
            Log.d("NotifManCompat", stringBuilder.toString());
          } 
          b((a)entry.getValue());
          iterator.remove();
        } 
      } 
    }
    
    public void h(NotificationManagerCompat.h param1h) {
      this.d.obtainMessage(0, param1h).sendToTarget();
    }
    
    public boolean handleMessage(Message param1Message) {
      NotificationManagerCompat.f f;
      int i = param1Message.what;
      if (i != 0) {
        if (i != 1) {
          if (i != 2) {
            if (i != 3)
              return false; 
            d((ComponentName)param1Message.obj);
            return true;
          } 
          f((ComponentName)param1Message.obj);
          return true;
        } 
        f = (NotificationManagerCompat.f)param1Message.obj;
        e(f.a, f.b);
        return true;
      } 
      c((NotificationManagerCompat.h)((Message)f).obj);
      return true;
    }
    
    public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
      if (Log.isLoggable("NotifManCompat", 3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Connected to service ");
        stringBuilder.append(param1ComponentName);
        Log.d("NotifManCompat", stringBuilder.toString());
      } 
      this.d.obtainMessage(1, new NotificationManagerCompat.f(param1ComponentName, param1IBinder)).sendToTarget();
    }
    
    public void onServiceDisconnected(ComponentName param1ComponentName) {
      if (Log.isLoggable("NotifManCompat", 3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Disconnected from service ");
        stringBuilder.append(param1ComponentName);
        Log.d("NotifManCompat", stringBuilder.toString());
      } 
      this.d.obtainMessage(2, param1ComponentName).sendToTarget();
    }
    
    private static class a {
      final ComponentName a;
      
      boolean b = false;
      
      b.a c;
      
      ArrayDeque<NotificationManagerCompat.h> d = new ArrayDeque<NotificationManagerCompat.h>();
      
      int e = 0;
      
      a(ComponentName param2ComponentName) {
        this.a = param2ComponentName;
      }
    }
  }
  
  private static class a {
    final ComponentName a;
    
    boolean b = false;
    
    b.a c;
    
    ArrayDeque<NotificationManagerCompat.h> d = new ArrayDeque<NotificationManagerCompat.h>();
    
    int e = 0;
    
    a(ComponentName param1ComponentName) {
      this.a = param1ComponentName;
    }
  }
  
  private static interface h {
    void a(b.a param1a) throws RemoteException;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\core\app\NotificationManagerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */