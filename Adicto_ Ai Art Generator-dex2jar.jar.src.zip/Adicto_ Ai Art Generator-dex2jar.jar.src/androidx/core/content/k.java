package androidx.core.content;

import android.content.LocusId;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.util.e;

public final class k {
  private final String a;
  
  private final LocusId b;
  
  public k(@NonNull String paramString) {
    this.a = (String)e.f(paramString, "id cannot be empty");
    if (Build.VERSION.SDK_INT >= 29) {
      this.b = a.a(paramString);
      return;
    } 
    this.b = null;
  }
  
  @NonNull
  private String a() {
    int i = this.a.length();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(i);
    stringBuilder.append("_chars");
    return stringBuilder.toString();
  }
  
  @NonNull
  @RequiresApi(29)
  public static k c(@NonNull LocusId paramLocusId) {
    e.e(paramLocusId, "locusId cannot be null");
    return new k((String)e.f(a.b(paramLocusId), "id cannot be empty"));
  }
  
  @NonNull
  @RequiresApi(29)
  public LocusId b() {
    return this.b;
  }
  
  public boolean equals(@Nullable Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject == null)
      return false; 
    if (k.class != paramObject.getClass())
      return false; 
    paramObject = paramObject;
    String str = this.a;
    return (str == null) ? ((((k)paramObject).a == null)) : str.equals(((k)paramObject).a);
  }
  
  public int hashCode() {
    int i;
    String str = this.a;
    if (str == null) {
      i = 0;
    } else {
      i = str.hashCode();
    } 
    return 31 + i;
  }
  
  @NonNull
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("LocusIdCompat[");
    stringBuilder.append(a());
    stringBuilder.append("]");
    return stringBuilder.toString();
  }
  
  @RequiresApi(29)
  private static class a {
    @NonNull
    static LocusId a(@NonNull String param1String) {
      return new LocusId(param1String);
    }
    
    @NonNull
    static String b(@NonNull LocusId param1LocusId) {
      return param1LocusId.getId();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\core\content\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */