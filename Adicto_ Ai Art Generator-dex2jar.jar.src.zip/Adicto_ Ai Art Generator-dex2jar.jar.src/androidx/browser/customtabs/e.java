package androidx.browser.customtabs;

import a.b;
import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.IBinder;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public abstract class e implements ServiceConnection {
  @Nullable
  private Context mApplicationContext;
  
  @Nullable
  Context getApplicationContext() {
    return this.mApplicationContext;
  }
  
  public abstract void onCustomTabsServiceConnected(@NonNull ComponentName paramComponentName, @NonNull c paramc);
  
  public final void onServiceConnected(@NonNull ComponentName paramComponentName, @NonNull IBinder paramIBinder) {
    if (this.mApplicationContext != null) {
      onCustomTabsServiceConnected(paramComponentName, new a(this, b.a.L(paramIBinder), paramComponentName, this.mApplicationContext));
      return;
    } 
    throw new IllegalStateException("Custom Tabs Service connected before an applicationcontext has been provided.");
  }
  
  void setApplicationContext(@NonNull Context paramContext) {
    this.mApplicationContext = paramContext;
  }
  
  class a extends c {
    a(e this$0, b param1b, ComponentName param1ComponentName, Context param1Context) {
      super(param1b, param1ComponentName, param1Context);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\browser\customtabs\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */