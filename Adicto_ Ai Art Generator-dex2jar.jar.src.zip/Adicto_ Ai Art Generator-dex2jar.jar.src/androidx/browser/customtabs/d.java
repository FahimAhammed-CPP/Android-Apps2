package androidx.browser.customtabs;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.LocaleList;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.SparseArray;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.p;
import java.util.ArrayList;

public final class d {
  @NonNull
  public final Intent a;
  
  @Nullable
  public final Bundle b;
  
  d(@NonNull Intent paramIntent, @Nullable Bundle paramBundle) {
    this.a = paramIntent;
    this.b = paramBundle;
  }
  
  public void a(@NonNull Context paramContext, @NonNull Uri paramUri) {
    this.a.setData(paramUri);
    androidx.core.content.a.startActivity(paramContext, this.a, this.b);
  }
  
  @RequiresApi(api = 24)
  private static class a {
    @Nullable
    static String a() {
      LocaleList localeList = LocaleList.getAdjustedDefault();
      return (localeList.size() > 0) ? localeList.get(0).toLanguageTag() : null;
    }
  }
  
  public static final class b {
    private final Intent a = new Intent("android.intent.action.VIEW");
    
    private final a.a b = new a.a();
    
    @Nullable
    private ArrayList<Bundle> c;
    
    @Nullable
    private Bundle d;
    
    @Nullable
    private ArrayList<Bundle> e;
    
    @Nullable
    private SparseArray<Bundle> f;
    
    @Nullable
    private Bundle g;
    
    private int h = 0;
    
    private boolean i = true;
    
    public b() {}
    
    public b(@Nullable f param1f) {
      if (param1f != null)
        c(param1f); 
    }
    
    @RequiresApi(api = 24)
    private void b() {
      String str = d.a.a();
      if (!TextUtils.isEmpty(str)) {
        Bundle bundle;
        if (this.a.hasExtra("com.android.browser.headers")) {
          bundle = this.a.getBundleExtra("com.android.browser.headers");
        } else {
          bundle = new Bundle();
        } 
        if (!bundle.containsKey("Accept-Language")) {
          bundle.putString("Accept-Language", str);
          this.a.putExtra("com.android.browser.headers", bundle);
        } 
      } 
    }
    
    private void d(@Nullable IBinder param1IBinder, @Nullable PendingIntent param1PendingIntent) {
      Bundle bundle = new Bundle();
      p.b(bundle, "android.support.customtabs.extra.SESSION", param1IBinder);
      if (param1PendingIntent != null)
        bundle.putParcelable("android.support.customtabs.extra.SESSION_ID", (Parcelable)param1PendingIntent); 
      this.a.putExtras(bundle);
    }
    
    @NonNull
    public d a() {
      if (!this.a.hasExtra("android.support.customtabs.extra.SESSION"))
        d(null, null); 
      ArrayList<Bundle> arrayList = this.c;
      if (arrayList != null)
        this.a.putParcelableArrayListExtra("android.support.customtabs.extra.MENU_ITEMS", arrayList); 
      arrayList = this.e;
      if (arrayList != null)
        this.a.putParcelableArrayListExtra("android.support.customtabs.extra.TOOLBAR_ITEMS", arrayList); 
      this.a.putExtra("android.support.customtabs.extra.EXTRA_ENABLE_INSTANT_APPS", this.i);
      this.a.putExtras(this.b.a().a());
      Bundle bundle = this.g;
      if (bundle != null)
        this.a.putExtras(bundle); 
      if (this.f != null) {
        bundle = new Bundle();
        bundle.putSparseParcelableArray("androidx.browser.customtabs.extra.COLOR_SCHEME_PARAMS", this.f);
        this.a.putExtras(bundle);
      } 
      this.a.putExtra("androidx.browser.customtabs.extra.SHARE_STATE", this.h);
      if (Build.VERSION.SDK_INT >= 24)
        b(); 
      return new d(this.a, this.d);
    }
    
    @NonNull
    public b c(@NonNull f param1f) {
      this.a.setPackage(param1f.d().getPackageName());
      d(param1f.c(), param1f.e());
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\browser\customtabs\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */