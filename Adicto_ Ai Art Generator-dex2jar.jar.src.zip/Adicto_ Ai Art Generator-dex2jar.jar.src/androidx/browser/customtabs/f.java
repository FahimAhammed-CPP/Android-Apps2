package androidx.browser.customtabs;

import a.a;
import a.b;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.os.RemoteException;
import androidx.annotation.Nullable;
import java.util.List;

public final class f {
  private final Object a = new Object();
  
  private final b b;
  
  private final a c;
  
  private final ComponentName d;
  
  @Nullable
  private final PendingIntent e;
  
  f(b paramb, a parama, ComponentName paramComponentName, @Nullable PendingIntent paramPendingIntent) {
    this.b = paramb;
    this.c = parama;
    this.d = paramComponentName;
    this.e = paramPendingIntent;
  }
  
  private void a(Bundle paramBundle) {
    PendingIntent pendingIntent = this.e;
    if (pendingIntent != null)
      paramBundle.putParcelable("android.support.customtabs.extra.SESSION_ID", (Parcelable)pendingIntent); 
  }
  
  private Bundle b(@Nullable Bundle paramBundle) {
    Bundle bundle = new Bundle();
    if (paramBundle != null)
      bundle.putAll(paramBundle); 
    a(bundle);
    return bundle;
  }
  
  IBinder c() {
    return this.c.asBinder();
  }
  
  ComponentName d() {
    return this.d;
  }
  
  @Nullable
  PendingIntent e() {
    return this.e;
  }
  
  public boolean f(@Nullable Uri paramUri, @Nullable Bundle paramBundle, @Nullable List<Bundle> paramList) {
    paramBundle = b(paramBundle);
    try {
      return this.b.C(this.c, paramUri, paramBundle, paramList);
    } catch (RemoteException remoteException) {
      return false;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\browser\customtabs\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */