package androidx.browser.customtabs;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public final class a {
  @Nullable
  public final Integer a;
  
  @Nullable
  public final Integer b;
  
  @Nullable
  public final Integer c;
  
  @Nullable
  public final Integer d;
  
  a(@Nullable Integer paramInteger1, @Nullable Integer paramInteger2, @Nullable Integer paramInteger3, @Nullable Integer paramInteger4) {
    this.a = paramInteger1;
    this.b = paramInteger2;
    this.c = paramInteger3;
    this.d = paramInteger4;
  }
  
  @NonNull
  Bundle a() {
    Bundle bundle = new Bundle();
    Integer integer = this.a;
    if (integer != null)
      bundle.putInt("android.support.customtabs.extra.TOOLBAR_COLOR", integer.intValue()); 
    integer = this.b;
    if (integer != null)
      bundle.putInt("android.support.customtabs.extra.SECONDARY_TOOLBAR_COLOR", integer.intValue()); 
    integer = this.c;
    if (integer != null)
      bundle.putInt("androidx.browser.customtabs.extra.NAVIGATION_BAR_COLOR", integer.intValue()); 
    integer = this.d;
    if (integer != null)
      bundle.putInt("androidx.browser.customtabs.extra.NAVIGATION_BAR_DIVIDER_COLOR", integer.intValue()); 
    return bundle;
  }
  
  public static final class a {
    @Nullable
    private Integer a;
    
    @Nullable
    private Integer b;
    
    @Nullable
    private Integer c;
    
    @Nullable
    private Integer d;
    
    @NonNull
    public a a() {
      return new a(this.a, this.b, this.c, this.d);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\browser\customtabs\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */