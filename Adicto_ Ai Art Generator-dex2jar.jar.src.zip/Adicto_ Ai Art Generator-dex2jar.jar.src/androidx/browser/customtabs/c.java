package androidx.browser.customtabs;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.os.RemoteException;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class c {
  private final a.b a;
  
  private final ComponentName b;
  
  private final Context c;
  
  c(a.b paramb, ComponentName paramComponentName, Context paramContext) {
    this.a = paramb;
    this.b = paramComponentName;
    this.c = paramContext;
  }
  
  public static boolean a(@NonNull Context paramContext, @Nullable String paramString, @NonNull e parame) {
    parame.setApplicationContext(paramContext.getApplicationContext());
    Intent intent = new Intent("android.support.customtabs.action.CustomTabsService");
    if (!TextUtils.isEmpty(paramString))
      intent.setPackage(paramString); 
    return paramContext.bindService(intent, parame, 33);
  }
  
  public static boolean b(@NonNull Context paramContext, @NonNull String paramString) {
    if (paramString == null)
      return false; 
    paramContext = paramContext.getApplicationContext();
    a a = new a(paramContext);
    try {
      return a(paramContext, paramString, a);
    } catch (SecurityException securityException) {
      return false;
    } 
  }
  
  private a.a.a c(@Nullable b paramb) {
    return new b(this, paramb);
  }
  
  @Nullable
  private f e(@Nullable b paramb, @Nullable PendingIntent paramPendingIntent) {
    a.a.a a = c(paramb);
    if (paramPendingIntent != null)
      try {
        Bundle bundle = new Bundle();
        bundle.putParcelable("android.support.customtabs.extra.SESSION_ID", (Parcelable)paramPendingIntent);
        boolean bool1 = this.a.x((a.a)a, bundle);
        return !bool1 ? null : new f(this.a, (a.a)a, this.b, paramPendingIntent);
      } catch (RemoteException remoteException) {
        return null;
      }  
    boolean bool = this.a.u((a.a)remoteException);
    return !bool ? null : new f(this.a, (a.a)remoteException, this.b, paramPendingIntent);
  }
  
  @Nullable
  public f d(@Nullable b paramb) {
    return e(paramb, null);
  }
  
  public boolean f(long paramLong) {
    try {
      return this.a.w(paramLong);
    } catch (RemoteException remoteException) {
      return false;
    } 
  }
  
  class a extends e {
    a(c this$0) {}
    
    public final void onCustomTabsServiceConnected(@NonNull ComponentName param1ComponentName, @NonNull c param1c) {
      param1c.f(0L);
      this.b.unbindService(this);
    }
    
    public void onServiceDisconnected(ComponentName param1ComponentName) {}
  }
  
  class b extends a.a.a {
    private Handler b = new Handler(Looper.getMainLooper());
    
    b(c this$0, b param1b) {}
    
    public void B(int param1Int1, int param1Int2, @Nullable Bundle param1Bundle) throws RemoteException {}
    
    public void D(int param1Int, Bundle param1Bundle) {}
    
    public void E(String param1String, Bundle param1Bundle) throws RemoteException {}
    
    public void F(Bundle param1Bundle) throws RemoteException {}
    
    public void I(int param1Int, Uri param1Uri, boolean param1Boolean, @Nullable Bundle param1Bundle) throws RemoteException {}
    
    public Bundle g(@NonNull String param1String, @Nullable Bundle param1Bundle) throws RemoteException {
      return null;
    }
    
    public void k(String param1String, Bundle param1Bundle) throws RemoteException {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\browser\customtabs\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */