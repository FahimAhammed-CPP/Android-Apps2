package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import g.i;

public class a extends i {
  final AlertController d = new AlertController(getContext(), this, getWindow());
  
  protected a(@NonNull Context paramContext, int paramInt) {
    super(paramContext, i(paramContext, paramInt));
  }
  
  static int i(@NonNull Context paramContext, int paramInt) {
    if ((paramInt >>> 24 & 0xFF) >= 1)
      return paramInt; 
    TypedValue typedValue = new TypedValue();
    paramContext.getTheme().resolveAttribute(f.a.o, typedValue, true);
    return typedValue.resourceId;
  }
  
  public ListView h() {
    return this.d.d();
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.d.e();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    return this.d.g(paramInt, paramKeyEvent) ? true : super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    return this.d.h(paramInt, paramKeyEvent) ? true : super.onKeyUp(paramInt, paramKeyEvent);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    super.setTitle(paramCharSequence);
    this.d.q(paramCharSequence);
  }
  
  public static class a {
    private final AlertController.f a;
    
    private final int b;
    
    public a(@NonNull Context param1Context) {
      this(param1Context, a.i(param1Context, 0));
    }
    
    public a(@NonNull Context param1Context, int param1Int) {
      this.a = new AlertController.f((Context)new ContextThemeWrapper(param1Context, a.i(param1Context, param1Int)));
      this.b = param1Int;
    }
    
    @NonNull
    public a a() {
      a a1 = new a(this.a.a, this.b);
      this.a.a(a1.d);
      a1.setCancelable(this.a.r);
      if (this.a.r)
        a1.setCanceledOnTouchOutside(true); 
      a1.setOnCancelListener(this.a.s);
      a1.setOnDismissListener(this.a.t);
      DialogInterface.OnKeyListener onKeyListener = this.a.u;
      if (onKeyListener != null)
        a1.setOnKeyListener(onKeyListener); 
      return a1;
    }
    
    @NonNull
    public Context b() {
      return this.a.a;
    }
    
    public a c(ListAdapter param1ListAdapter, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.f f1 = this.a;
      f1.w = param1ListAdapter;
      f1.x = param1OnClickListener;
      return this;
    }
    
    public a d(@Nullable View param1View) {
      this.a.g = param1View;
      return this;
    }
    
    public a e(@Nullable Drawable param1Drawable) {
      this.a.d = param1Drawable;
      return this;
    }
    
    public a f(DialogInterface.OnKeyListener param1OnKeyListener) {
      this.a.u = param1OnKeyListener;
      return this;
    }
    
    public a g(ListAdapter param1ListAdapter, int param1Int, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.f f1 = this.a;
      f1.w = param1ListAdapter;
      f1.x = param1OnClickListener;
      f1.I = param1Int;
      f1.H = true;
      return this;
    }
    
    public a h(@Nullable CharSequence param1CharSequence) {
      this.a.f = param1CharSequence;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\app\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */