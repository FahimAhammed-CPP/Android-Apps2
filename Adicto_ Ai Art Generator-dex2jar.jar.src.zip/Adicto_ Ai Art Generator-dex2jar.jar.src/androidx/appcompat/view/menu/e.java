package androidx.appcompat.view.menu;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import androidx.annotation.NonNull;
import androidx.core.view.ViewConfigurationCompat;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import y.a;

public class e implements a {
  private static final int[] A = new int[] { 1, 4, 5, 3, 2, 0 };
  
  private final Context a;
  
  private final Resources b;
  
  private boolean c;
  
  private boolean d;
  
  private a e;
  
  private ArrayList<g> f;
  
  private ArrayList<g> g;
  
  private boolean h;
  
  private ArrayList<g> i;
  
  private ArrayList<g> j;
  
  private boolean k;
  
  private int l = 0;
  
  private ContextMenu.ContextMenuInfo m;
  
  CharSequence n;
  
  Drawable o;
  
  View p;
  
  private boolean q = false;
  
  private boolean r = false;
  
  private boolean s = false;
  
  private boolean t = false;
  
  private boolean u = false;
  
  private ArrayList<g> v = new ArrayList<g>();
  
  private CopyOnWriteArrayList<WeakReference<j>> w = new CopyOnWriteArrayList<WeakReference<j>>();
  
  private g x;
  
  private boolean y = false;
  
  private boolean z;
  
  public e(Context paramContext) {
    this.a = paramContext;
    this.b = paramContext.getResources();
    this.f = new ArrayList<g>();
    this.g = new ArrayList<g>();
    this.h = true;
    this.i = new ArrayList<g>();
    this.j = new ArrayList<g>();
    this.k = true;
    b0(true);
  }
  
  private static int B(int paramInt) {
    int i = (0xFFFF0000 & paramInt) >> 16;
    if (i >= 0) {
      int[] arrayOfInt = A;
      if (i < arrayOfInt.length)
        return paramInt & 0xFFFF | arrayOfInt[i] << 16; 
    } 
    throw new IllegalArgumentException("order does not contain a valid category.");
  }
  
  private void N(int paramInt, boolean paramBoolean) {
    if (paramInt >= 0) {
      if (paramInt >= this.f.size())
        return; 
      this.f.remove(paramInt);
      if (paramBoolean)
        K(true); 
    } 
  }
  
  private void W(int paramInt1, CharSequence paramCharSequence, int paramInt2, Drawable paramDrawable, View paramView) {
    Resources resources = C();
    if (paramView != null) {
      this.p = paramView;
      this.n = null;
      this.o = null;
    } else {
      if (paramInt1 > 0) {
        this.n = resources.getText(paramInt1);
      } else if (paramCharSequence != null) {
        this.n = paramCharSequence;
      } 
      if (paramInt2 > 0) {
        this.o = androidx.core.content.a.getDrawable(u(), paramInt2);
      } else if (paramDrawable != null) {
        this.o = paramDrawable;
      } 
      this.p = null;
    } 
    K(false);
  }
  
  private void b0(boolean paramBoolean) {
    boolean bool = true;
    if (paramBoolean && (this.b.getConfiguration()).keyboard != 1 && ViewConfigurationCompat.shouldShowMenuShortcutsWhenKeyboardPresent(ViewConfiguration.get(this.a), this.a)) {
      paramBoolean = bool;
    } else {
      paramBoolean = false;
    } 
    this.d = paramBoolean;
  }
  
  private g g(int paramInt1, int paramInt2, int paramInt3, int paramInt4, CharSequence paramCharSequence, int paramInt5) {
    return new g(this, paramInt1, paramInt2, paramInt3, paramInt4, paramCharSequence, paramInt5);
  }
  
  private void i(boolean paramBoolean) {
    if (this.w.isEmpty())
      return; 
    d0();
    for (WeakReference<j> weakReference : this.w) {
      j j = weakReference.get();
      if (j == null) {
        this.w.remove(weakReference);
        continue;
      } 
      j.f(paramBoolean);
    } 
    c0();
  }
  
  private boolean j(m paramm, j paramj) {
    boolean bool2 = this.w.isEmpty();
    boolean bool1 = false;
    if (bool2)
      return false; 
    if (paramj != null)
      bool1 = paramj.e(paramm); 
    for (WeakReference<j> weakReference : this.w) {
      j j1 = weakReference.get();
      if (j1 == null) {
        this.w.remove(weakReference);
        continue;
      } 
      if (!bool1)
        bool1 = j1.e(paramm); 
    } 
    return bool1;
  }
  
  private static int n(ArrayList<g> paramArrayList, int paramInt) {
    for (int i = paramArrayList.size() - 1; i >= 0; i--) {
      if (((g)paramArrayList.get(i)).f() <= paramInt)
        return i + 1; 
    } 
    return 0;
  }
  
  boolean A() {
    return this.t;
  }
  
  Resources C() {
    return this.b;
  }
  
  public e D() {
    return this;
  }
  
  @NonNull
  public ArrayList<g> E() {
    if (!this.h)
      return this.g; 
    this.g.clear();
    int j = this.f.size();
    for (int i = 0; i < j; i++) {
      g g1 = this.f.get(i);
      if (g1.isVisible())
        this.g.add(g1); 
    } 
    this.h = false;
    this.k = true;
    return this.g;
  }
  
  public boolean F() {
    return this.y;
  }
  
  boolean G() {
    return this.c;
  }
  
  public boolean H() {
    return this.d;
  }
  
  void I(g paramg) {
    this.k = true;
    K(true);
  }
  
  void J(g paramg) {
    this.h = true;
    K(true);
  }
  
  public void K(boolean paramBoolean) {
    if (!this.q) {
      if (paramBoolean) {
        this.h = true;
        this.k = true;
      } 
      i(paramBoolean);
      return;
    } 
    this.r = true;
    if (paramBoolean)
      this.s = true; 
  }
  
  public boolean L(MenuItem paramMenuItem, int paramInt) {
    return M(paramMenuItem, null, paramInt);
  }
  
  public boolean M(MenuItem paramMenuItem, j paramj, int paramInt) {
    g g1 = (g)paramMenuItem;
    if (g1 != null) {
      boolean bool;
      boolean bool1;
      if (!g1.isEnabled())
        return false; 
      boolean bool2 = g1.k();
      androidx.core.view.b b = g1.a();
      if (b != null && b.a()) {
        bool = true;
      } else {
        bool = false;
      } 
      if (g1.j()) {
        bool2 |= g1.expandActionView();
        bool1 = bool2;
        if (bool2) {
          e(true);
          return bool2;
        } 
      } else {
        if (g1.hasSubMenu() || bool) {
          if ((paramInt & 0x4) == 0)
            e(false); 
          if (!g1.hasSubMenu())
            g1.x(new m(u(), this, g1)); 
          m m = (m)g1.getSubMenu();
          if (bool)
            b.f(m); 
          bool2 |= j(m, paramj);
          boolean bool3 = bool2;
          if (!bool2) {
            e(true);
            bool3 = bool2;
          } 
          return bool3;
        } 
        bool1 = bool2;
        if ((paramInt & 0x1) == 0) {
          e(true);
          return bool2;
        } 
      } 
      return bool1;
    } 
    return false;
  }
  
  public void O(j paramj) {
    for (WeakReference<j> weakReference : this.w) {
      j j1 = weakReference.get();
      if (j1 == null || j1 == paramj)
        this.w.remove(weakReference); 
    } 
  }
  
  public void P(Bundle paramBundle) {
    if (paramBundle == null)
      return; 
    SparseArray sparseArray = paramBundle.getSparseParcelableArray(t());
    int j = size();
    int i;
    for (i = 0; i < j; i++) {
      MenuItem menuItem = getItem(i);
      View view = menuItem.getActionView();
      if (view != null && view.getId() != -1)
        view.restoreHierarchyState(sparseArray); 
      if (menuItem.hasSubMenu())
        ((m)menuItem.getSubMenu()).P(paramBundle); 
    } 
    i = paramBundle.getInt("android:menu:expandedactionview");
    if (i > 0) {
      MenuItem menuItem = findItem(i);
      if (menuItem != null)
        menuItem.expandActionView(); 
    } 
  }
  
  public void Q(Bundle paramBundle) {
    int j = size();
    SparseArray sparseArray = null;
    int i = 0;
    while (i < j) {
      MenuItem menuItem = getItem(i);
      View view = menuItem.getActionView();
      SparseArray sparseArray1 = sparseArray;
      if (view != null) {
        sparseArray1 = sparseArray;
        if (view.getId() != -1) {
          SparseArray sparseArray2 = sparseArray;
          if (sparseArray == null)
            sparseArray2 = new SparseArray(); 
          view.saveHierarchyState(sparseArray2);
          sparseArray1 = sparseArray2;
          if (menuItem.isActionViewExpanded()) {
            paramBundle.putInt("android:menu:expandedactionview", menuItem.getItemId());
            sparseArray1 = sparseArray2;
          } 
        } 
      } 
      if (menuItem.hasSubMenu())
        ((m)menuItem.getSubMenu()).Q(paramBundle); 
      i++;
      sparseArray = sparseArray1;
    } 
    if (sparseArray != null)
      paramBundle.putSparseParcelableArray(t(), sparseArray); 
  }
  
  public void R(a parama) {
    this.e = parama;
  }
  
  public e S(int paramInt) {
    this.l = paramInt;
    return this;
  }
  
  void T(MenuItem paramMenuItem) {
    int j = paramMenuItem.getGroupId();
    int k = this.f.size();
    d0();
    for (int i = 0; i < k; i++) {
      g g1 = this.f.get(i);
      if (g1.getGroupId() == j && g1.m() && g1.isCheckable()) {
        boolean bool;
        if (g1 == paramMenuItem) {
          bool = true;
        } else {
          bool = false;
        } 
        g1.s(bool);
      } 
    } 
    c0();
  }
  
  protected e U(int paramInt) {
    W(0, null, paramInt, null, null);
    return this;
  }
  
  protected e V(Drawable paramDrawable) {
    W(0, null, 0, paramDrawable, null);
    return this;
  }
  
  protected e X(int paramInt) {
    W(paramInt, null, 0, null, null);
    return this;
  }
  
  protected e Y(CharSequence paramCharSequence) {
    W(0, paramCharSequence, 0, null, null);
    return this;
  }
  
  protected e Z(View paramView) {
    W(0, null, 0, null, paramView);
    return this;
  }
  
  protected MenuItem a(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    int i = B(paramInt3);
    g g1 = g(paramInt1, paramInt2, paramInt3, i, paramCharSequence, this.l);
    ContextMenu.ContextMenuInfo contextMenuInfo = this.m;
    if (contextMenuInfo != null)
      g1.v(contextMenuInfo); 
    ArrayList<g> arrayList = this.f;
    arrayList.add(n(arrayList, i), g1);
    K(true);
    return (MenuItem)g1;
  }
  
  public void a0(boolean paramBoolean) {
    this.z = paramBoolean;
  }
  
  public MenuItem add(int paramInt) {
    return a(0, 0, 0, this.b.getString(paramInt));
  }
  
  public MenuItem add(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return a(paramInt1, paramInt2, paramInt3, this.b.getString(paramInt4));
  }
  
  public MenuItem add(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    return a(paramInt1, paramInt2, paramInt3, paramCharSequence);
  }
  
  public MenuItem add(CharSequence paramCharSequence) {
    return a(0, 0, 0, paramCharSequence);
  }
  
  public int addIntentOptions(int paramInt1, int paramInt2, int paramInt3, ComponentName paramComponentName, Intent[] paramArrayOfIntent, Intent paramIntent, int paramInt4, MenuItem[] paramArrayOfMenuItem) {
    byte b1;
    PackageManager packageManager = this.a.getPackageManager();
    byte b2 = 0;
    List<ResolveInfo> list = packageManager.queryIntentActivityOptions(paramComponentName, paramArrayOfIntent, paramIntent, 0);
    if (list != null) {
      b1 = list.size();
    } else {
      b1 = 0;
    } 
    int i = b2;
    if ((paramInt4 & 0x1) == 0) {
      removeGroup(paramInt1);
      i = b2;
    } 
    while (i < b1) {
      ResolveInfo resolveInfo = list.get(i);
      paramInt4 = resolveInfo.specificIndex;
      if (paramInt4 < 0) {
        intent = paramIntent;
      } else {
        intent = paramArrayOfIntent[paramInt4];
      } 
      Intent intent = new Intent(intent);
      ActivityInfo activityInfo = resolveInfo.activityInfo;
      intent.setComponent(new ComponentName(activityInfo.applicationInfo.packageName, activityInfo.name));
      MenuItem menuItem = add(paramInt1, paramInt2, paramInt3, resolveInfo.loadLabel(packageManager)).setIcon(resolveInfo.loadIcon(packageManager)).setIntent(intent);
      if (paramArrayOfMenuItem != null) {
        paramInt4 = resolveInfo.specificIndex;
        if (paramInt4 >= 0)
          paramArrayOfMenuItem[paramInt4] = menuItem; 
      } 
      i++;
    } 
    return b1;
  }
  
  public SubMenu addSubMenu(int paramInt) {
    return addSubMenu(0, 0, 0, this.b.getString(paramInt));
  }
  
  public SubMenu addSubMenu(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return addSubMenu(paramInt1, paramInt2, paramInt3, this.b.getString(paramInt4));
  }
  
  public SubMenu addSubMenu(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    g g1 = (g)a(paramInt1, paramInt2, paramInt3, paramCharSequence);
    m m = new m(this.a, this, g1);
    g1.x(m);
    return m;
  }
  
  public SubMenu addSubMenu(CharSequence paramCharSequence) {
    return addSubMenu(0, 0, 0, paramCharSequence);
  }
  
  public void b(j paramj) {
    c(paramj, this.a);
  }
  
  public void c(j paramj, Context paramContext) {
    this.w.add(new WeakReference<j>(paramj));
    paramj.i(paramContext, this);
    this.k = true;
  }
  
  public void c0() {
    this.q = false;
    if (this.r) {
      this.r = false;
      K(this.s);
    } 
  }
  
  public void clear() {
    g g1 = this.x;
    if (g1 != null)
      f(g1); 
    this.f.clear();
    K(true);
  }
  
  public void clearHeader() {
    this.o = null;
    this.n = null;
    this.p = null;
    K(false);
  }
  
  public void close() {
    e(true);
  }
  
  public void d() {
    a a1 = this.e;
    if (a1 != null)
      a1.b(this); 
  }
  
  public void d0() {
    if (!this.q) {
      this.q = true;
      this.r = false;
      this.s = false;
    } 
  }
  
  public final void e(boolean paramBoolean) {
    if (this.u)
      return; 
    this.u = true;
    for (WeakReference<j> weakReference : this.w) {
      j j = weakReference.get();
      if (j == null) {
        this.w.remove(weakReference);
        continue;
      } 
      j.b(this, paramBoolean);
    } 
    this.u = false;
  }
  
  public boolean f(g paramg) {
    boolean bool3 = this.w.isEmpty();
    boolean bool1 = false;
    boolean bool2 = false;
    if (!bool3) {
      if (this.x != paramg)
        return false; 
      d0();
      Iterator<WeakReference<j>> iterator = this.w.iterator();
      bool1 = bool2;
      while (true) {
        bool2 = bool1;
        if (iterator.hasNext()) {
          WeakReference<j> weakReference = iterator.next();
          j j = weakReference.get();
          if (j == null) {
            this.w.remove(weakReference);
            continue;
          } 
          bool2 = j.h(this, paramg);
          bool1 = bool2;
          if (bool2)
            break; 
          continue;
        } 
        break;
      } 
      c0();
      bool1 = bool2;
      if (bool2) {
        this.x = null;
        bool1 = bool2;
      } 
    } 
    return bool1;
  }
  
  public MenuItem findItem(int paramInt) {
    int j = size();
    for (int i = 0; i < j; i++) {
      g g1 = this.f.get(i);
      if (g1.getItemId() == paramInt)
        return (MenuItem)g1; 
      if (g1.hasSubMenu()) {
        MenuItem menuItem = g1.getSubMenu().findItem(paramInt);
        if (menuItem != null)
          return menuItem; 
      } 
    } 
    return null;
  }
  
  public MenuItem getItem(int paramInt) {
    return (MenuItem)this.f.get(paramInt);
  }
  
  boolean h(@NonNull e parame, @NonNull MenuItem paramMenuItem) {
    a a1 = this.e;
    return (a1 != null && a1.a(parame, paramMenuItem));
  }
  
  public boolean hasVisibleItems() {
    if (this.z)
      return true; 
    int j = size();
    for (int i = 0; i < j; i++) {
      if (((g)this.f.get(i)).isVisible())
        return true; 
    } 
    return false;
  }
  
  public boolean isShortcutKey(int paramInt, KeyEvent paramKeyEvent) {
    return (p(paramInt, paramKeyEvent) != null);
  }
  
  public boolean k(g paramg) {
    boolean bool2 = this.w.isEmpty();
    boolean bool1 = false;
    if (bool2)
      return false; 
    d0();
    Iterator<WeakReference<j>> iterator = this.w.iterator();
    while (true) {
      bool2 = bool1;
      if (iterator.hasNext()) {
        WeakReference<j> weakReference = iterator.next();
        j j = weakReference.get();
        if (j == null) {
          this.w.remove(weakReference);
          continue;
        } 
        bool2 = j.c(this, paramg);
        bool1 = bool2;
        if (bool2)
          break; 
        continue;
      } 
      break;
    } 
    c0();
    if (bool2)
      this.x = paramg; 
    return bool2;
  }
  
  public int l(int paramInt) {
    return m(paramInt, 0);
  }
  
  public int m(int paramInt1, int paramInt2) {
    int j = size();
    int i = paramInt2;
    if (paramInt2 < 0)
      i = 0; 
    while (i < j) {
      if (((g)this.f.get(i)).getGroupId() == paramInt1)
        return i; 
      i++;
    } 
    return -1;
  }
  
  public int o(int paramInt) {
    int j = size();
    for (int i = 0; i < j; i++) {
      if (((g)this.f.get(i)).getItemId() == paramInt)
        return i; 
    } 
    return -1;
  }
  
  g p(int paramInt, KeyEvent paramKeyEvent) {
    ArrayList<g> arrayList = this.v;
    arrayList.clear();
    q(arrayList, paramInt, paramKeyEvent);
    if (arrayList.isEmpty())
      return null; 
    int j = paramKeyEvent.getMetaState();
    KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
    paramKeyEvent.getKeyData(keyData);
    int k = arrayList.size();
    if (k == 1)
      return arrayList.get(0); 
    boolean bool = G();
    for (int i = 0; i < k; i++) {
      char c;
      g g1 = arrayList.get(i);
      if (bool) {
        c = g1.getAlphabeticShortcut();
      } else {
        c = g1.getNumericShortcut();
      } 
      char[] arrayOfChar = keyData.meta;
      if ((c == arrayOfChar[0] && (j & 0x2) == 0) || (c == arrayOfChar[2] && (j & 0x2) != 0) || (bool && c == '\b' && paramInt == 67))
        return g1; 
    } 
    return null;
  }
  
  public boolean performIdentifierAction(int paramInt1, int paramInt2) {
    return L(findItem(paramInt1), paramInt2);
  }
  
  public boolean performShortcut(int paramInt1, KeyEvent paramKeyEvent, int paramInt2) {
    boolean bool;
    g g1 = p(paramInt1, paramKeyEvent);
    if (g1 != null) {
      bool = L((MenuItem)g1, paramInt2);
    } else {
      bool = false;
    } 
    if ((paramInt2 & 0x2) != 0)
      e(true); 
    return bool;
  }
  
  void q(List<g> paramList, int paramInt, KeyEvent paramKeyEvent) {
    boolean bool = G();
    int j = paramKeyEvent.getModifiers();
    KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
    if (!paramKeyEvent.getKeyData(keyData) && paramInt != 67)
      return; 
    int k = this.f.size();
    int i;
    for (i = 0; i < k; i++) {
      char c;
      int m;
      g g1 = this.f.get(i);
      if (g1.hasSubMenu())
        ((e)g1.getSubMenu()).q(paramList, paramInt, paramKeyEvent); 
      if (bool) {
        c = g1.getAlphabeticShortcut();
      } else {
        c = g1.getNumericShortcut();
      } 
      if (bool) {
        m = g1.getAlphabeticModifiers();
      } else {
        m = g1.getNumericModifiers();
      } 
      if ((j & 0x1100F) == (m & 0x1100F)) {
        m = 1;
      } else {
        m = 0;
      } 
      if (m != 0 && c != '\000') {
        char[] arrayOfChar = keyData.meta;
        if ((c == arrayOfChar[0] || c == arrayOfChar[2] || (bool && c == '\b' && paramInt == 67)) && g1.isEnabled())
          paramList.add(g1); 
      } 
    } 
  }
  
  public void r() {
    ArrayList<g> arrayList = E();
    if (!this.k)
      return; 
    Iterator<WeakReference<j>> iterator = this.w.iterator();
    boolean bool;
    for (bool = false; iterator.hasNext(); bool |= j.g()) {
      WeakReference<j> weakReference = iterator.next();
      j j = weakReference.get();
      if (j == null) {
        this.w.remove(weakReference);
        continue;
      } 
    } 
    if (bool) {
      this.i.clear();
      this.j.clear();
      int i = arrayList.size();
      bool = false;
      while (bool < i) {
        g g1 = arrayList.get(bool);
        if (g1.l()) {
          this.i.add(g1);
        } else {
          this.j.add(g1);
        } 
        int j = bool + 1;
      } 
    } else {
      this.i.clear();
      this.j.clear();
      this.j.addAll(E());
    } 
    this.k = false;
  }
  
  public void removeGroup(int paramInt) {
    int i = l(paramInt);
    if (i >= 0) {
      int k = this.f.size();
      for (int j = 0; j < k - i && ((g)this.f.get(i)).getGroupId() == paramInt; j++)
        N(i, false); 
      K(true);
    } 
  }
  
  public void removeItem(int paramInt) {
    N(o(paramInt), true);
  }
  
  public ArrayList<g> s() {
    r();
    return this.i;
  }
  
  public void setGroupCheckable(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
    int j = this.f.size();
    int i;
    for (i = 0; i < j; i++) {
      g g1 = this.f.get(i);
      if (g1.getGroupId() == paramInt) {
        g1.t(paramBoolean2);
        g1.setCheckable(paramBoolean1);
      } 
    } 
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    this.y = paramBoolean;
  }
  
  public void setGroupEnabled(int paramInt, boolean paramBoolean) {
    int j = this.f.size();
    for (int i = 0; i < j; i++) {
      g g1 = this.f.get(i);
      if (g1.getGroupId() == paramInt)
        g1.setEnabled(paramBoolean); 
    } 
  }
  
  public void setGroupVisible(int paramInt, boolean paramBoolean) {
    int j = this.f.size();
    int i = 0;
    boolean bool;
    for (bool = false; i < j; bool = bool1) {
      g g1 = this.f.get(i);
      boolean bool1 = bool;
      if (g1.getGroupId() == paramInt) {
        bool1 = bool;
        if (g1.y(paramBoolean))
          bool1 = true; 
      } 
      i++;
    } 
    if (bool)
      K(true); 
  }
  
  public void setQwertyMode(boolean paramBoolean) {
    this.c = paramBoolean;
    K(false);
  }
  
  public int size() {
    return this.f.size();
  }
  
  protected String t() {
    return "android:menu:actionviewstates";
  }
  
  public Context u() {
    return this.a;
  }
  
  public g v() {
    return this.x;
  }
  
  public Drawable w() {
    return this.o;
  }
  
  public CharSequence x() {
    return this.n;
  }
  
  public View y() {
    return this.p;
  }
  
  public ArrayList<g> z() {
    r();
    return this.j;
  }
  
  public static interface a {
    boolean a(@NonNull e param1e, @NonNull MenuItem param1MenuItem);
    
    void b(@NonNull e param1e);
  }
  
  public static interface b {
    boolean b(g param1g);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\view\menu\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */