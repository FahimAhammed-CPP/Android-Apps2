package androidx.appcompat.view.menu;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import androidx.appcompat.widget.j1;

public final class ExpandedMenuView extends ListView implements e.b, k, AdapterView.OnItemClickListener {
  private static final int[] d = new int[] { 16842964, 16843049 };
  
  private e b;
  
  private int c;
  
  public ExpandedMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16842868);
  }
  
  public ExpandedMenuView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet);
    setOnItemClickListener(this);
    j1 j1 = j1.u(paramContext, paramAttributeSet, d, paramInt, 0);
    if (j1.r(0))
      setBackgroundDrawable(j1.f(0)); 
    if (j1.r(1))
      setDivider(j1.f(1)); 
    j1.v();
  }
  
  public void a(e parame) {
    this.b = parame;
  }
  
  public boolean b(g paramg) {
    return this.b.L((MenuItem)paramg, 0);
  }
  
  public int getWindowAnimations() {
    return this.c;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    setChildrenDrawingCacheEnabled(false);
  }
  
  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong) {
    b((g)getAdapter().getItem(paramInt));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\view\menu\ExpandedMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */