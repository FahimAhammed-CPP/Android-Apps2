package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.Rect;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import l.e;

abstract class h implements e, j, AdapterView.OnItemClickListener {
  private Rect b;
  
  protected static int m(ListAdapter paramListAdapter, ViewGroup paramViewGroup, Context paramContext, int paramInt) {
    int i = 0;
    int n = View.MeasureSpec.makeMeasureSpec(0, 0);
    int i1 = View.MeasureSpec.makeMeasureSpec(0, 0);
    int i2 = paramListAdapter.getCount();
    ViewGroup viewGroup2 = null;
    int k = 0;
    int m = 0;
    ViewGroup viewGroup1 = paramViewGroup;
    paramViewGroup = viewGroup2;
    while (i < i2) {
      FrameLayout frameLayout2;
      int i4 = paramListAdapter.getItemViewType(i);
      int i3 = m;
      if (i4 != m) {
        paramViewGroup = null;
        i3 = i4;
      } 
      viewGroup2 = viewGroup1;
      if (viewGroup1 == null)
        frameLayout2 = new FrameLayout(paramContext); 
      View view = paramListAdapter.getView(i, (View)paramViewGroup, (ViewGroup)frameLayout2);
      view.measure(n, i1);
      i4 = view.getMeasuredWidth();
      if (i4 >= paramInt)
        return paramInt; 
      m = k;
      if (i4 > k)
        m = i4; 
      i++;
      k = m;
      m = i3;
      FrameLayout frameLayout1 = frameLayout2;
    } 
    return k;
  }
  
  protected static boolean w(e parame) {
    int k = parame.size();
    for (int i = 0; i < k; i++) {
      MenuItem menuItem = parame.getItem(i);
      if (menuItem.isVisible() && menuItem.getIcon() != null)
        return true; 
    } 
    return false;
  }
  
  protected static d x(ListAdapter paramListAdapter) {
    return (paramListAdapter instanceof HeaderViewListAdapter) ? (d)((HeaderViewListAdapter)paramListAdapter).getWrappedAdapter() : (d)paramListAdapter;
  }
  
  public boolean c(e parame, g paramg) {
    return false;
  }
  
  public boolean h(e parame, g paramg) {
    return false;
  }
  
  public void i(@NonNull Context paramContext, @Nullable e parame) {}
  
  public abstract void j(e parame);
  
  protected boolean k() {
    return true;
  }
  
  public Rect l() {
    return this.b;
  }
  
  public abstract void o(View paramView);
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    ListAdapter listAdapter = (ListAdapter)paramAdapterView.getAdapter();
    e e1 = (x(listAdapter)).b;
    MenuItem menuItem = (MenuItem)listAdapter.getItem(paramInt);
    if (k()) {
      paramInt = 0;
    } else {
      paramInt = 4;
    } 
    e1.M(menuItem, this, paramInt);
  }
  
  public void p(Rect paramRect) {
    this.b = paramRect;
  }
  
  public abstract void q(boolean paramBoolean);
  
  public abstract void r(int paramInt);
  
  public abstract void s(int paramInt);
  
  public abstract void t(PopupWindow.OnDismissListener paramOnDismissListener);
  
  public abstract void u(boolean paramBoolean);
  
  public abstract void v(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\view\menu\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */