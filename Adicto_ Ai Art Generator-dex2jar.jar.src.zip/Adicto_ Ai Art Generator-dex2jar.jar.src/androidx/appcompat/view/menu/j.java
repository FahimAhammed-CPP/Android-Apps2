package androidx.appcompat.view.menu;

import android.content.Context;
import androidx.annotation.NonNull;

public interface j {
  void b(e parame, boolean paramBoolean);
  
  boolean c(e parame, g paramg);
  
  void d(a parama);
  
  boolean e(m paramm);
  
  void f(boolean paramBoolean);
  
  boolean g();
  
  boolean h(e parame, g paramg);
  
  void i(Context paramContext, e parame);
  
  public static interface a {
    void b(@NonNull e param1e, boolean param1Boolean);
    
    boolean c(@NonNull e param1e);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\view\menu\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */