package androidx.appcompat.view.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;

public class d extends BaseAdapter {
  e b;
  
  private int c = -1;
  
  private boolean d;
  
  private final boolean e;
  
  private final LayoutInflater f;
  
  private final int g;
  
  public d(e parame, LayoutInflater paramLayoutInflater, boolean paramBoolean, int paramInt) {
    this.e = paramBoolean;
    this.f = paramLayoutInflater;
    this.b = parame;
    this.g = paramInt;
    a();
  }
  
  void a() {
    g g = this.b.v();
    if (g != null) {
      ArrayList<g> arrayList = this.b.z();
      int j = arrayList.size();
      for (int i = 0; i < j; i++) {
        if ((g)arrayList.get(i) == g) {
          this.c = i;
          return;
        } 
      } 
    } 
    this.c = -1;
  }
  
  public e b() {
    return this.b;
  }
  
  public g c(int paramInt) {
    ArrayList<g> arrayList;
    if (this.e) {
      arrayList = this.b.z();
    } else {
      arrayList = this.b.E();
    } 
    int j = this.c;
    int i = paramInt;
    if (j >= 0) {
      i = paramInt;
      if (paramInt >= j)
        i = paramInt + 1; 
    } 
    return arrayList.get(i);
  }
  
  public void d(boolean paramBoolean) {
    this.d = paramBoolean;
  }
  
  public int getCount() {
    ArrayList<g> arrayList;
    if (this.e) {
      arrayList = this.b.z();
    } else {
      arrayList = this.b.E();
    } 
    return (this.c < 0) ? arrayList.size() : (arrayList.size() - 1);
  }
  
  public long getItemId(int paramInt) {
    return paramInt;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = paramView;
    if (paramView == null)
      view = this.f.inflate(this.g, paramViewGroup, false); 
    int j = c(paramInt).getGroupId();
    int i = paramInt - 1;
    if (i >= 0) {
      i = c(i).getGroupId();
    } else {
      i = j;
    } 
    ListMenuItemView listMenuItemView = (ListMenuItemView)view;
    if (this.b.F() && j != i) {
      bool = true;
    } else {
      bool = false;
    } 
    listMenuItemView.setGroupDividerEnabled(bool);
    k.a a = (k.a)view;
    if (this.d)
      listMenuItemView.setForceShowIcon(true); 
    a.c(c(paramInt), 0);
    return view;
  }
  
  public void notifyDataSetChanged() {
    a();
    super.notifyDataSetChanged();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\view\menu\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */