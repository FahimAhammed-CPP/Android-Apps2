package androidx.appcompat.view.menu;

import android.content.DialogInterface;
import android.os.IBinder;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import androidx.annotation.NonNull;
import androidx.appcompat.app.a;
import f.g;

class f implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, j.a {
  private e b;
  
  private a c;
  
  c d;
  
  private j.a e;
  
  public f(e parame) {
    this.b = parame;
  }
  
  public void a() {
    a a1 = this.c;
    if (a1 != null)
      a1.dismiss(); 
  }
  
  public void b(@NonNull e parame, boolean paramBoolean) {
    if (paramBoolean || parame == this.b)
      a(); 
    j.a a1 = this.e;
    if (a1 != null)
      a1.b(parame, paramBoolean); 
  }
  
  public boolean c(@NonNull e parame) {
    j.a a1 = this.e;
    return (a1 != null) ? a1.c(parame) : false;
  }
  
  public void d(IBinder paramIBinder) {
    e e1 = this.b;
    a.a a2 = new a.a(e1.u());
    c c1 = new c(a2.b(), g.j);
    this.d = c1;
    c1.d(this);
    this.b.b(this.d);
    a2.c(this.d.a(), this);
    View view = e1.y();
    if (view != null) {
      a2.d(view);
    } else {
      a2.e(e1.w()).h(e1.x());
    } 
    a2.f(this);
    a a1 = a2.a();
    this.c = a1;
    a1.setOnDismissListener(this);
    WindowManager.LayoutParams layoutParams = this.c.getWindow().getAttributes();
    layoutParams.type = 1003;
    if (paramIBinder != null)
      layoutParams.token = paramIBinder; 
    layoutParams.flags |= 0x20000;
    this.c.show();
  }
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt) {
    this.b.L((MenuItem)this.d.a().getItem(paramInt), 0);
  }
  
  public void onDismiss(DialogInterface paramDialogInterface) {
    this.d.b(this.b, true);
  }
  
  public boolean onKey(DialogInterface paramDialogInterface, int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 82 || paramInt == 4) {
      KeyEvent.DispatcherState dispatcherState;
      if (paramKeyEvent.getAction() == 0 && paramKeyEvent.getRepeatCount() == 0) {
        Window window = this.c.getWindow();
        if (window != null) {
          View view = window.getDecorView();
          if (view != null) {
            dispatcherState = view.getKeyDispatcherState();
            if (dispatcherState != null) {
              dispatcherState.startTracking(paramKeyEvent, this);
              return true;
            } 
          } 
        } 
      } else if (paramKeyEvent.getAction() == 1 && !paramKeyEvent.isCanceled()) {
        Window window = this.c.getWindow();
        if (window != null) {
          View view = window.getDecorView();
          if (view != null) {
            KeyEvent.DispatcherState dispatcherState1 = view.getKeyDispatcherState();
            if (dispatcherState1 != null && dispatcherState1.isTracking(paramKeyEvent)) {
              this.b.e(true);
              dispatcherState.dismiss();
              return true;
            } 
          } 
        } 
      } 
    } 
    return this.b.performShortcut(paramInt, paramKeyEvent, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\view\menu\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */