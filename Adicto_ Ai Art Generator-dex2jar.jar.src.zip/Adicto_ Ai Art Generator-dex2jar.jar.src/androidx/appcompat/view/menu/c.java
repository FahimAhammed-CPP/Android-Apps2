package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import f.g;
import java.util.ArrayList;

public class c implements j, AdapterView.OnItemClickListener {
  Context b;
  
  LayoutInflater c;
  
  e d;
  
  ExpandedMenuView e;
  
  int f;
  
  int g;
  
  int h;
  
  private j.a i;
  
  a j;
  
  public c(int paramInt1, int paramInt2) {
    this.h = paramInt1;
    this.g = paramInt2;
  }
  
  public c(Context paramContext, int paramInt) {
    this(paramInt, 0);
    this.b = paramContext;
    this.c = LayoutInflater.from(paramContext);
  }
  
  public ListAdapter a() {
    if (this.j == null)
      this.j = new a(this); 
    return (ListAdapter)this.j;
  }
  
  public void b(e parame, boolean paramBoolean) {
    j.a a1 = this.i;
    if (a1 != null)
      a1.b(parame, paramBoolean); 
  }
  
  public boolean c(e parame, g paramg) {
    return false;
  }
  
  public void d(j.a parama) {
    this.i = parama;
  }
  
  public boolean e(m paramm) {
    if (!paramm.hasVisibleItems())
      return false; 
    (new f(paramm)).d(null);
    j.a a1 = this.i;
    if (a1 != null)
      a1.c(paramm); 
    return true;
  }
  
  public void f(boolean paramBoolean) {
    a a1 = this.j;
    if (a1 != null)
      a1.notifyDataSetChanged(); 
  }
  
  public boolean g() {
    return false;
  }
  
  public boolean h(e parame, g paramg) {
    return false;
  }
  
  public void i(Context paramContext, e parame) {
    ContextThemeWrapper contextThemeWrapper;
    if (this.g != 0) {
      contextThemeWrapper = new ContextThemeWrapper(paramContext, this.g);
      this.b = (Context)contextThemeWrapper;
      this.c = LayoutInflater.from((Context)contextThemeWrapper);
    } else if (this.b != null) {
      this.b = (Context)contextThemeWrapper;
      if (this.c == null)
        this.c = LayoutInflater.from((Context)contextThemeWrapper); 
    } 
    this.d = parame;
    a a1 = this.j;
    if (a1 != null)
      a1.notifyDataSetChanged(); 
  }
  
  public k j(ViewGroup paramViewGroup) {
    if (this.e == null) {
      this.e = (ExpandedMenuView)this.c.inflate(g.g, paramViewGroup, false);
      if (this.j == null)
        this.j = new a(this); 
      this.e.setAdapter((ListAdapter)this.j);
      this.e.setOnItemClickListener(this);
    } 
    return this.e;
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    this.d.M((MenuItem)this.j.b(paramInt), this, 0);
  }
  
  private class a extends BaseAdapter {
    private int b = -1;
    
    public a(c this$0) {
      a();
    }
    
    void a() {
      g g = this.c.d.v();
      if (g != null) {
        ArrayList<g> arrayList = this.c.d.z();
        int j = arrayList.size();
        for (int i = 0; i < j; i++) {
          if ((g)arrayList.get(i) == g) {
            this.b = i;
            return;
          } 
        } 
      } 
      this.b = -1;
    }
    
    public g b(int param1Int) {
      ArrayList<g> arrayList = this.c.d.z();
      int i = param1Int + this.c.f;
      int j = this.b;
      param1Int = i;
      if (j >= 0) {
        param1Int = i;
        if (i >= j)
          param1Int = i + 1; 
      } 
      return arrayList.get(param1Int);
    }
    
    public int getCount() {
      int i = this.c.d.z().size() - this.c.f;
      return (this.b < 0) ? i : (i - 1);
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      View view = param1View;
      if (param1View == null) {
        c c1 = this.c;
        view = c1.c.inflate(c1.h, param1ViewGroup, false);
      } 
      ((k.a)view).c(b(param1Int), 0);
      return view;
    }
    
    public void notifyDataSetChanged() {
      a();
      super.notifyDataSetChanged();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\view\menu\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */