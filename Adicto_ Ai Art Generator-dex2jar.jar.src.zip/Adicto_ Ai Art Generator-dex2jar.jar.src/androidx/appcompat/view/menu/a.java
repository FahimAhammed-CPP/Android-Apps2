package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

public abstract class a implements j {
  protected Context b;
  
  protected Context c;
  
  protected e d;
  
  protected LayoutInflater e;
  
  protected LayoutInflater f;
  
  private j.a g;
  
  private int h;
  
  private int i;
  
  protected k j;
  
  private int k;
  
  public a(Context paramContext, int paramInt1, int paramInt2) {
    this.b = paramContext;
    this.e = LayoutInflater.from(paramContext);
    this.h = paramInt1;
    this.i = paramInt2;
  }
  
  protected void a(View paramView, int paramInt) {
    ViewGroup viewGroup = (ViewGroup)paramView.getParent();
    if (viewGroup != null)
      viewGroup.removeView(paramView); 
    ((ViewGroup)this.j).addView(paramView, paramInt);
  }
  
  public void b(e parame, boolean paramBoolean) {
    j.a a1 = this.g;
    if (a1 != null)
      a1.b(parame, paramBoolean); 
  }
  
  public boolean c(e parame, g paramg) {
    return false;
  }
  
  public void d(j.a parama) {
    this.g = parama;
  }
  
  public boolean e(m paramm) {
    j.a a1 = this.g;
    if (a1 != null) {
      e e1;
      if (paramm == null)
        e1 = this.d; 
      return a1.c(e1);
    } 
    return false;
  }
  
  public void f(boolean paramBoolean) {
    ViewGroup viewGroup = (ViewGroup)this.j;
    if (viewGroup == null)
      return; 
    e e1 = this.d;
    int i = 0;
    if (e1 != null) {
      e1.r();
      ArrayList<g> arrayList = this.d.E();
      int n = arrayList.size();
      int m = 0;
      for (i = 0; m < n; i = i1) {
        g g = arrayList.get(m);
        int i1 = i;
        if (q(i, g)) {
          View view1 = viewGroup.getChildAt(i);
          if (view1 instanceof k.a) {
            g g1 = ((k.a)view1).getItemData();
          } else {
            e1 = null;
          } 
          View view2 = n(g, view1, viewGroup);
          if (g != e1) {
            view2.setPressed(false);
            view2.jumpDrawablesToCurrentState();
          } 
          if (view2 != view1)
            a(view2, i); 
          i1 = i + 1;
        } 
        m++;
      } 
    } 
    while (i < viewGroup.getChildCount()) {
      if (!l(viewGroup, i))
        i++; 
    } 
  }
  
  public boolean h(e parame, g paramg) {
    return false;
  }
  
  public void i(Context paramContext, e parame) {
    this.c = paramContext;
    this.f = LayoutInflater.from(paramContext);
    this.d = parame;
  }
  
  public abstract void j(g paramg, k.a parama);
  
  public k.a k(ViewGroup paramViewGroup) {
    return (k.a)this.e.inflate(this.i, paramViewGroup, false);
  }
  
  protected boolean l(ViewGroup paramViewGroup, int paramInt) {
    paramViewGroup.removeViewAt(paramInt);
    return true;
  }
  
  public j.a m() {
    return this.g;
  }
  
  public View n(g paramg, View paramView, ViewGroup paramViewGroup) {
    k.a a1;
    if (paramView instanceof k.a) {
      a1 = (k.a)paramView;
    } else {
      a1 = k(paramViewGroup);
    } 
    j(paramg, a1);
    return (View)a1;
  }
  
  public k o(ViewGroup paramViewGroup) {
    if (this.j == null) {
      k k1 = (k)this.e.inflate(this.h, paramViewGroup, false);
      this.j = k1;
      k1.a(this.d);
      f(true);
    } 
    return this.j;
  }
  
  public void p(int paramInt) {
    this.k = paramInt;
  }
  
  public abstract boolean q(int paramInt, g paramg);
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\view\menu\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */