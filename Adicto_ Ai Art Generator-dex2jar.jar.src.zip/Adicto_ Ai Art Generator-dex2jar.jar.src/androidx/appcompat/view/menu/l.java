package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.widget.y0;
import androidx.core.view.ViewCompat;
import f.d;
import f.g;

final class l extends h implements PopupWindow.OnDismissListener, View.OnKeyListener {
  private static final int w = g.m;
  
  private final Context c;
  
  private final e d;
  
  private final d e;
  
  private final boolean f;
  
  private final int g;
  
  private final int h;
  
  private final int i;
  
  final y0 j;
  
  final ViewTreeObserver.OnGlobalLayoutListener k = new a(this);
  
  private final View.OnAttachStateChangeListener l = new b(this);
  
  private PopupWindow.OnDismissListener m;
  
  private View n;
  
  View o;
  
  private j.a p;
  
  ViewTreeObserver q;
  
  private boolean r;
  
  private boolean s;
  
  private int t;
  
  private int u = 0;
  
  private boolean v;
  
  public l(Context paramContext, e parame, View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    this.c = paramContext;
    this.d = parame;
    this.f = paramBoolean;
    this.e = new d(parame, LayoutInflater.from(paramContext), paramBoolean, w);
    this.h = paramInt1;
    this.i = paramInt2;
    Resources resources = paramContext.getResources();
    this.g = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(d.d));
    this.n = paramView;
    this.j = new y0(paramContext, null, paramInt1, paramInt2);
    parame.c(this, paramContext);
  }
  
  private boolean y() {
    if (a())
      return true; 
    if (!this.r) {
      boolean bool;
      View view = this.n;
      if (view == null)
        return false; 
      this.o = view;
      this.j.F(this);
      this.j.G(this);
      this.j.E(true);
      view = this.o;
      if (this.q == null) {
        bool = true;
      } else {
        bool = false;
      } 
      ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
      this.q = viewTreeObserver;
      if (bool)
        viewTreeObserver.addOnGlobalLayoutListener(this.k); 
      view.addOnAttachStateChangeListener(this.l);
      this.j.y(view);
      this.j.B(this.u);
      if (!this.s) {
        this.t = h.m((ListAdapter)this.e, null, this.c, this.g);
        this.s = true;
      } 
      this.j.A(this.t);
      this.j.D(2);
      this.j.C(l());
      this.j.show();
      ListView listView = this.j.n();
      listView.setOnKeyListener(this);
      if (this.v && this.d.x() != null) {
        FrameLayout frameLayout = (FrameLayout)LayoutInflater.from(this.c).inflate(g.l, (ViewGroup)listView, false);
        TextView textView = (TextView)frameLayout.findViewById(16908310);
        if (textView != null)
          textView.setText(this.d.x()); 
        frameLayout.setEnabled(false);
        listView.addHeaderView((View)frameLayout, null, false);
      } 
      this.j.l((ListAdapter)this.e);
      this.j.show();
      return true;
    } 
    return false;
  }
  
  public boolean a() {
    return (!this.r && this.j.a());
  }
  
  public void b(e parame, boolean paramBoolean) {
    if (parame != this.d)
      return; 
    dismiss();
    j.a a1 = this.p;
    if (a1 != null)
      a1.b(parame, paramBoolean); 
  }
  
  public void d(j.a parama) {
    this.p = parama;
  }
  
  public void dismiss() {
    if (a())
      this.j.dismiss(); 
  }
  
  public boolean e(m paramm) {
    if (paramm.hasVisibleItems()) {
      i i1 = new i(this.c, paramm, this.o, this.f, this.h, this.i);
      i1.j(this.p);
      i1.g(h.w(paramm));
      i1.i(this.m);
      this.m = null;
      this.d.e(false);
      int j = this.j.b();
      int k = this.j.k();
      int i = j;
      if ((Gravity.getAbsoluteGravity(this.u, ViewCompat.getLayoutDirection(this.n)) & 0x7) == 5)
        i = j + this.n.getWidth(); 
      if (i1.n(i, k)) {
        j.a a1 = this.p;
        if (a1 != null)
          a1.c(paramm); 
        return true;
      } 
    } 
    return false;
  }
  
  public void f(boolean paramBoolean) {
    this.s = false;
    d d1 = this.e;
    if (d1 != null)
      d1.notifyDataSetChanged(); 
  }
  
  public boolean g() {
    return false;
  }
  
  public void j(e parame) {}
  
  public ListView n() {
    return this.j.n();
  }
  
  public void o(View paramView) {
    this.n = paramView;
  }
  
  public void onDismiss() {
    this.r = true;
    this.d.close();
    ViewTreeObserver viewTreeObserver = this.q;
    if (viewTreeObserver != null) {
      if (!viewTreeObserver.isAlive())
        this.q = this.o.getViewTreeObserver(); 
      this.q.removeGlobalOnLayoutListener(this.k);
      this.q = null;
    } 
    this.o.removeOnAttachStateChangeListener(this.l);
    PopupWindow.OnDismissListener onDismissListener = this.m;
    if (onDismissListener != null)
      onDismissListener.onDismiss(); 
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1 && paramInt == 82) {
      dismiss();
      return true;
    } 
    return false;
  }
  
  public void q(boolean paramBoolean) {
    this.e.d(paramBoolean);
  }
  
  public void r(int paramInt) {
    this.u = paramInt;
  }
  
  public void s(int paramInt) {
    this.j.d(paramInt);
  }
  
  public void show() {
    if (y())
      return; 
    throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
  }
  
  public void t(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.m = paramOnDismissListener;
  }
  
  public void u(boolean paramBoolean) {
    this.v = paramBoolean;
  }
  
  public void v(int paramInt) {
    this.j.h(paramInt);
  }
  
  class a implements ViewTreeObserver.OnGlobalLayoutListener {
    a(l this$0) {}
    
    public void onGlobalLayout() {
      if (this.b.a() && !this.b.j.w()) {
        View view = this.b.o;
        if (view == null || !view.isShown()) {
          this.b.dismiss();
          return;
        } 
        this.b.j.show();
        return;
      } 
    }
  }
  
  class b implements View.OnAttachStateChangeListener {
    b(l this$0) {}
    
    public void onViewAttachedToWindow(View param1View) {}
    
    public void onViewDetachedFromWindow(View param1View) {
      ViewTreeObserver viewTreeObserver = this.b.q;
      if (viewTreeObserver != null) {
        if (!viewTreeObserver.isAlive())
          this.b.q = param1View.getViewTreeObserver(); 
        l l1 = this.b;
        l1.q.removeGlobalOnLayoutListener(l1.k);
      } 
      param1View.removeOnAttachStateChangeListener(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\view\menu\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */