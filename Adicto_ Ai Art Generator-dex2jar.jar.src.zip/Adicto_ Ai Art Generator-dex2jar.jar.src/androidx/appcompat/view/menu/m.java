package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import androidx.annotation.NonNull;

public class m extends e implements SubMenu {
  private e B;
  
  private g C;
  
  public m(Context paramContext, e parame, g paramg) {
    super(paramContext);
    this.B = parame;
    this.C = paramg;
  }
  
  public e D() {
    return this.B.D();
  }
  
  public boolean F() {
    return this.B.F();
  }
  
  public boolean G() {
    return this.B.G();
  }
  
  public boolean H() {
    return this.B.H();
  }
  
  public void R(e.a parama) {
    this.B.R(parama);
  }
  
  public Menu e0() {
    return (Menu)this.B;
  }
  
  public boolean f(g paramg) {
    return this.B.f(paramg);
  }
  
  public MenuItem getItem() {
    return (MenuItem)this.C;
  }
  
  boolean h(@NonNull e parame, @NonNull MenuItem paramMenuItem) {
    return (super.h(parame, paramMenuItem) || this.B.h(parame, paramMenuItem));
  }
  
  public boolean k(g paramg) {
    return this.B.k(paramg);
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    this.B.setGroupDividerEnabled(paramBoolean);
  }
  
  public SubMenu setHeaderIcon(int paramInt) {
    return (SubMenu)U(paramInt);
  }
  
  public SubMenu setHeaderIcon(Drawable paramDrawable) {
    return (SubMenu)V(paramDrawable);
  }
  
  public SubMenu setHeaderTitle(int paramInt) {
    return (SubMenu)X(paramInt);
  }
  
  public SubMenu setHeaderTitle(CharSequence paramCharSequence) {
    return (SubMenu)Y(paramCharSequence);
  }
  
  public SubMenu setHeaderView(View paramView) {
    return (SubMenu)Z(paramView);
  }
  
  public SubMenu setIcon(int paramInt) {
    this.C.setIcon(paramInt);
    return this;
  }
  
  public SubMenu setIcon(Drawable paramDrawable) {
    this.C.setIcon(paramDrawable);
    return this;
  }
  
  public void setQwertyMode(boolean paramBoolean) {
    this.B.setQwertyMode(paramBoolean);
  }
  
  public String t() {
    boolean bool;
    g g1 = this.C;
    if (g1 != null) {
      bool = g1.getItemId();
    } else {
      bool = false;
    } 
    if (!bool)
      return null; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(super.t());
    stringBuilder.append(":");
    stringBuilder.append(bool);
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\view\menu\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */