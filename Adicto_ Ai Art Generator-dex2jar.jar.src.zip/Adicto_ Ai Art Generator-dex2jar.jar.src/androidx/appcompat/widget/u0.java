package androidx.appcompat.widget;

import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.view.menu.e;

public interface u0 {
  void c(@NonNull e parame, @NonNull MenuItem paramMenuItem);
  
  void m(@NonNull e parame, @NonNull MenuItem paramMenuItem);
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widge\\u0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */