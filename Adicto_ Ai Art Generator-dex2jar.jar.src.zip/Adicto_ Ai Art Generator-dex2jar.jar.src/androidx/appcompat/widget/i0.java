package androidx.appcompat.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;
import android.widget.ToggleButton;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class i0 extends ToggleButton {
  private final c0 b;
  
  public i0(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16842827);
  }
  
  public i0(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    e1.a((View)this, getContext());
    c0 c01 = new c0((TextView)this);
    this.b = c01;
    c01.m(paramAttributeSet, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\i0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */