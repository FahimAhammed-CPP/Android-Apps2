package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class AppCompatImageView extends ImageView {
  private final e mBackgroundTintHelper;
  
  private final m mImageHelper;
  
  public AppCompatImageView(@NonNull Context paramContext) {
    this(paramContext, null);
  }
  
  public AppCompatImageView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public AppCompatImageView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt) {
    super(g1.b(paramContext), paramAttributeSet, paramInt);
    e1.a((View)this, getContext());
    e e1 = new e((View)this);
    this.mBackgroundTintHelper = e1;
    e1.e(paramAttributeSet, paramInt);
    m m1 = new m(this);
    this.mImageHelper = m1;
    m1.f(paramAttributeSet, paramInt);
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.mBackgroundTintHelper;
    if (e1 != null)
      e1.b(); 
    m m1 = this.mImageHelper;
    if (m1 != null)
      m1.b(); 
  }
  
  @Nullable
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.mBackgroundTintHelper;
    return (e1 != null) ? e1.c() : null;
  }
  
  @Nullable
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.mBackgroundTintHelper;
    return (e1 != null) ? e1.d() : null;
  }
  
  @Nullable
  public ColorStateList getSupportImageTintList() {
    m m1 = this.mImageHelper;
    return (m1 != null) ? m1.c() : null;
  }
  
  @Nullable
  public PorterDuff.Mode getSupportImageTintMode() {
    m m1 = this.mImageHelper;
    return (m1 != null) ? m1.d() : null;
  }
  
  public boolean hasOverlappingRendering() {
    return (this.mImageHelper.e() && super.hasOverlappingRendering());
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.mBackgroundTintHelper;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.mBackgroundTintHelper;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setImageBitmap(Bitmap paramBitmap) {
    super.setImageBitmap(paramBitmap);
    m m1 = this.mImageHelper;
    if (m1 != null)
      m1.b(); 
  }
  
  public void setImageDrawable(@Nullable Drawable paramDrawable) {
    super.setImageDrawable(paramDrawable);
    m m1 = this.mImageHelper;
    if (m1 != null)
      m1.b(); 
  }
  
  public void setImageResource(int paramInt) {
    m m1 = this.mImageHelper;
    if (m1 != null)
      m1.g(paramInt); 
  }
  
  public void setImageURI(@Nullable Uri paramUri) {
    super.setImageURI(paramUri);
    m m1 = this.mImageHelper;
    if (m1 != null)
      m1.b(); 
  }
  
  public void setSupportBackgroundTintList(@Nullable ColorStateList paramColorStateList) {
    e e1 = this.mBackgroundTintHelper;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(@Nullable PorterDuff.Mode paramMode) {
    e e1 = this.mBackgroundTintHelper;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  public void setSupportImageTintList(@Nullable ColorStateList paramColorStateList) {
    m m1 = this.mImageHelper;
    if (m1 != null)
      m1.h(paramColorStateList); 
  }
  
  public void setSupportImageTintMode(@Nullable PorterDuff.Mode paramMode) {
    m m1 = this.mImageHelper;
    if (m1 != null)
      m1.i(paramMode); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\AppCompatImageView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */