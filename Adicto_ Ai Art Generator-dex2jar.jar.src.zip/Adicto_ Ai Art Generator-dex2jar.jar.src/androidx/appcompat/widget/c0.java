package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.res.h;
import androidx.core.widget.b;
import f.j;
import java.lang.ref.WeakReference;

class c0 {
  @NonNull
  private final TextView a;
  
  private h1 b;
  
  private h1 c;
  
  private h1 d;
  
  private h1 e;
  
  private h1 f;
  
  private h1 g;
  
  private h1 h;
  
  @NonNull
  private final f0 i;
  
  private int j = 0;
  
  private int k = -1;
  
  private Typeface l;
  
  private boolean m;
  
  c0(@NonNull TextView paramTextView) {
    this.a = paramTextView;
    this.i = new f0(paramTextView);
  }
  
  private void A(int paramInt, float paramFloat) {
    this.i.v(paramInt, paramFloat);
  }
  
  private void B(Context paramContext, j1 paramj1) {
    this.j = paramj1.j(j.M2, this.j);
    int j = Build.VERSION.SDK_INT;
    boolean bool = false;
    if (j >= 28) {
      int k = paramj1.j(j.R2, -1);
      this.k = k;
      if (k != -1)
        this.j = this.j & 0x2 | 0x0; 
    } 
    int i = j.Q2;
    if (paramj1.r(i) || paramj1.r(j.S2)) {
      this.l = null;
      int k = j.S2;
      if (paramj1.r(k))
        i = k; 
      k = this.k;
      int m = this.j;
      if (!paramContext.isRestricted()) {
        a a = new a(this, k, m, new WeakReference<TextView>(this.a));
        try {
          boolean bool1;
          Typeface typeface = paramj1.i(i, this.j, a);
          if (typeface != null)
            if (j >= 28 && this.k != -1) {
              typeface = Typeface.create(typeface, 0);
              k = this.k;
              if ((this.j & 0x2) != 0) {
                bool1 = true;
              } else {
                bool1 = false;
              } 
              this.l = b0.a(typeface, k, bool1);
            } else {
              this.l = typeface;
            }  
          if (this.l == null) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          this.m = bool1;
        } catch (UnsupportedOperationException|android.content.res.Resources.NotFoundException unsupportedOperationException) {}
      } 
      if (this.l == null) {
        String str = paramj1.n(i);
        if (str != null) {
          Typeface typeface;
          if (Build.VERSION.SDK_INT >= 28 && this.k != -1) {
            typeface = Typeface.create(str, 0);
            i = this.k;
            boolean bool1 = bool;
            if ((this.j & 0x2) != 0)
              bool1 = true; 
            this.l = b0.a(typeface, i, bool1);
            return;
          } 
          this.l = Typeface.create((String)typeface, this.j);
        } 
      } 
      return;
    } 
    i = j.L2;
    if (paramj1.r(i)) {
      this.m = false;
      i = paramj1.j(i, 1);
      if (i != 1) {
        if (i != 2) {
          if (i != 3)
            return; 
          this.l = Typeface.MONOSPACE;
          return;
        } 
        this.l = Typeface.SERIF;
        return;
      } 
      this.l = Typeface.SANS_SERIF;
    } 
  }
  
  private void a(Drawable paramDrawable, h1 paramh1) {
    if (paramDrawable != null && paramh1 != null)
      i.i(paramDrawable, paramh1, this.a.getDrawableState()); 
  }
  
  private static h1 d(Context paramContext, i parami, int paramInt) {
    ColorStateList colorStateList = parami.f(paramContext, paramInt);
    if (colorStateList != null) {
      h1 h11 = new h1();
      h11.d = true;
      h11.a = colorStateList;
      return h11;
    } 
    return null;
  }
  
  private void x(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4, Drawable paramDrawable5, Drawable paramDrawable6) {
    TextView textView;
    Drawable[] arrayOfDrawable;
    if (paramDrawable5 != null || paramDrawable6 != null) {
      arrayOfDrawable = this.a.getCompoundDrawablesRelative();
      textView = this.a;
      if (paramDrawable5 == null)
        paramDrawable5 = arrayOfDrawable[0]; 
      if (paramDrawable2 == null)
        paramDrawable2 = arrayOfDrawable[1]; 
      if (paramDrawable6 == null)
        paramDrawable6 = arrayOfDrawable[2]; 
      if (paramDrawable4 == null)
        paramDrawable4 = arrayOfDrawable[3]; 
      textView.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable5, paramDrawable2, paramDrawable6, paramDrawable4);
      return;
    } 
    if (textView != null || paramDrawable2 != null || arrayOfDrawable != null || paramDrawable4 != null) {
      Drawable drawable1;
      Drawable drawable2;
      Drawable[] arrayOfDrawable1 = this.a.getCompoundDrawablesRelative();
      paramDrawable5 = arrayOfDrawable1[0];
      if (paramDrawable5 != null || arrayOfDrawable1[2] != null) {
        textView = this.a;
        if (paramDrawable2 == null)
          paramDrawable2 = arrayOfDrawable1[1]; 
        drawable2 = arrayOfDrawable1[2];
        if (paramDrawable4 == null)
          paramDrawable4 = arrayOfDrawable1[3]; 
        textView.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable5, paramDrawable2, drawable2, paramDrawable4);
        return;
      } 
      arrayOfDrawable1 = this.a.getCompoundDrawables();
      TextView textView1 = this.a;
      if (textView == null)
        drawable1 = arrayOfDrawable1[0]; 
      if (paramDrawable2 == null)
        paramDrawable2 = arrayOfDrawable1[1]; 
      if (drawable2 == null)
        drawable2 = arrayOfDrawable1[2]; 
      if (paramDrawable4 == null)
        paramDrawable4 = arrayOfDrawable1[3]; 
      textView1.setCompoundDrawablesWithIntrinsicBounds(drawable1, paramDrawable2, drawable2, paramDrawable4);
      return;
    } 
  }
  
  private void y() {
    h1 h11 = this.h;
    this.b = h11;
    this.c = h11;
    this.d = h11;
    this.e = h11;
    this.f = h11;
    this.g = h11;
  }
  
  void b() {
    if (this.b != null || this.c != null || this.d != null || this.e != null) {
      Drawable[] arrayOfDrawable = this.a.getCompoundDrawables();
      a(arrayOfDrawable[0], this.b);
      a(arrayOfDrawable[1], this.c);
      a(arrayOfDrawable[2], this.d);
      a(arrayOfDrawable[3], this.e);
    } 
    if (this.f != null || this.g != null) {
      Drawable[] arrayOfDrawable = this.a.getCompoundDrawablesRelative();
      a(arrayOfDrawable[0], this.f);
      a(arrayOfDrawable[2], this.g);
    } 
  }
  
  void c() {
    this.i.a();
  }
  
  int e() {
    return this.i.h();
  }
  
  int f() {
    return this.i.i();
  }
  
  int g() {
    return this.i.j();
  }
  
  int[] h() {
    return this.i.k();
  }
  
  int i() {
    return this.i.l();
  }
  
  @Nullable
  ColorStateList j() {
    h1 h11 = this.h;
    return (h11 != null) ? h11.a : null;
  }
  
  @Nullable
  PorterDuff.Mode k() {
    h1 h11 = this.h;
    return (h11 != null) ? h11.b : null;
  }
  
  boolean l() {
    return this.i.p();
  }
  
  void m(@Nullable AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroid/widget/TextView;
    //   4: invokevirtual getContext : ()Landroid/content/Context;
    //   7: astore #17
    //   9: invokestatic b : ()Landroidx/appcompat/widget/i;
    //   12: astore #16
    //   14: getstatic f/j.a0 : [I
    //   17: astore #8
    //   19: aload #17
    //   21: aload_1
    //   22: aload #8
    //   24: iload_2
    //   25: iconst_0
    //   26: invokestatic u : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/j1;
    //   29: astore #9
    //   31: aload_0
    //   32: getfield a : Landroid/widget/TextView;
    //   35: astore #10
    //   37: aload #10
    //   39: aload #10
    //   41: invokevirtual getContext : ()Landroid/content/Context;
    //   44: aload #8
    //   46: aload_1
    //   47: aload #9
    //   49: invokevirtual q : ()Landroid/content/res/TypedArray;
    //   52: iload_2
    //   53: iconst_0
    //   54: invokestatic saveAttributeDataForStyleable : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   57: aload #9
    //   59: getstatic f/j.b0 : I
    //   62: iconst_m1
    //   63: invokevirtual m : (II)I
    //   66: istore_3
    //   67: getstatic f/j.e0 : I
    //   70: istore #4
    //   72: aload #9
    //   74: iload #4
    //   76: invokevirtual r : (I)Z
    //   79: ifeq -> 101
    //   82: aload_0
    //   83: aload #17
    //   85: aload #16
    //   87: aload #9
    //   89: iload #4
    //   91: iconst_0
    //   92: invokevirtual m : (II)I
    //   95: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/i;I)Landroidx/appcompat/widget/h1;
    //   98: putfield b : Landroidx/appcompat/widget/h1;
    //   101: getstatic f/j.c0 : I
    //   104: istore #4
    //   106: aload #9
    //   108: iload #4
    //   110: invokevirtual r : (I)Z
    //   113: ifeq -> 135
    //   116: aload_0
    //   117: aload #17
    //   119: aload #16
    //   121: aload #9
    //   123: iload #4
    //   125: iconst_0
    //   126: invokevirtual m : (II)I
    //   129: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/i;I)Landroidx/appcompat/widget/h1;
    //   132: putfield c : Landroidx/appcompat/widget/h1;
    //   135: getstatic f/j.f0 : I
    //   138: istore #4
    //   140: aload #9
    //   142: iload #4
    //   144: invokevirtual r : (I)Z
    //   147: ifeq -> 169
    //   150: aload_0
    //   151: aload #17
    //   153: aload #16
    //   155: aload #9
    //   157: iload #4
    //   159: iconst_0
    //   160: invokevirtual m : (II)I
    //   163: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/i;I)Landroidx/appcompat/widget/h1;
    //   166: putfield d : Landroidx/appcompat/widget/h1;
    //   169: getstatic f/j.d0 : I
    //   172: istore #4
    //   174: aload #9
    //   176: iload #4
    //   178: invokevirtual r : (I)Z
    //   181: ifeq -> 203
    //   184: aload_0
    //   185: aload #17
    //   187: aload #16
    //   189: aload #9
    //   191: iload #4
    //   193: iconst_0
    //   194: invokevirtual m : (II)I
    //   197: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/i;I)Landroidx/appcompat/widget/h1;
    //   200: putfield e : Landroidx/appcompat/widget/h1;
    //   203: getstatic android/os/Build$VERSION.SDK_INT : I
    //   206: istore #4
    //   208: getstatic f/j.g0 : I
    //   211: istore #5
    //   213: aload #9
    //   215: iload #5
    //   217: invokevirtual r : (I)Z
    //   220: ifeq -> 242
    //   223: aload_0
    //   224: aload #17
    //   226: aload #16
    //   228: aload #9
    //   230: iload #5
    //   232: iconst_0
    //   233: invokevirtual m : (II)I
    //   236: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/i;I)Landroidx/appcompat/widget/h1;
    //   239: putfield f : Landroidx/appcompat/widget/h1;
    //   242: getstatic f/j.h0 : I
    //   245: istore #5
    //   247: aload #9
    //   249: iload #5
    //   251: invokevirtual r : (I)Z
    //   254: ifeq -> 276
    //   257: aload_0
    //   258: aload #17
    //   260: aload #16
    //   262: aload #9
    //   264: iload #5
    //   266: iconst_0
    //   267: invokevirtual m : (II)I
    //   270: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/i;I)Landroidx/appcompat/widget/h1;
    //   273: putfield g : Landroidx/appcompat/widget/h1;
    //   276: aload #9
    //   278: invokevirtual v : ()V
    //   281: aload_0
    //   282: getfield a : Landroid/widget/TextView;
    //   285: invokevirtual getTransformationMethod : ()Landroid/text/method/TransformationMethod;
    //   288: instanceof android/text/method/PasswordTransformationMethod
    //   291: istore #7
    //   293: iload_3
    //   294: iconst_m1
    //   295: if_icmpeq -> 560
    //   298: aload #17
    //   300: iload_3
    //   301: getstatic f/j.J2 : [I
    //   304: invokestatic s : (Landroid/content/Context;I[I)Landroidx/appcompat/widget/j1;
    //   307: astore #14
    //   309: iload #7
    //   311: ifne -> 341
    //   314: getstatic f/j.U2 : I
    //   317: istore_3
    //   318: aload #14
    //   320: iload_3
    //   321: invokevirtual r : (I)Z
    //   324: ifeq -> 341
    //   327: aload #14
    //   329: iload_3
    //   330: iconst_0
    //   331: invokevirtual a : (IZ)Z
    //   334: istore #6
    //   336: iconst_1
    //   337: istore_3
    //   338: goto -> 346
    //   341: iconst_0
    //   342: istore #6
    //   344: iconst_0
    //   345: istore_3
    //   346: aload_0
    //   347: aload #17
    //   349: aload #14
    //   351: invokespecial B : (Landroid/content/Context;Landroidx/appcompat/widget/j1;)V
    //   354: iload #4
    //   356: bipush #23
    //   358: if_icmpge -> 464
    //   361: getstatic f/j.N2 : I
    //   364: istore #5
    //   366: aload #14
    //   368: iload #5
    //   370: invokevirtual r : (I)Z
    //   373: ifeq -> 388
    //   376: aload #14
    //   378: iload #5
    //   380: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   383: astore #8
    //   385: goto -> 391
    //   388: aconst_null
    //   389: astore #8
    //   391: getstatic f/j.O2 : I
    //   394: istore #5
    //   396: aload #14
    //   398: iload #5
    //   400: invokevirtual r : (I)Z
    //   403: ifeq -> 418
    //   406: aload #14
    //   408: iload #5
    //   410: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   413: astore #9
    //   415: goto -> 421
    //   418: aconst_null
    //   419: astore #9
    //   421: getstatic f/j.P2 : I
    //   424: istore #5
    //   426: aload #8
    //   428: astore #11
    //   430: aload #9
    //   432: astore #10
    //   434: aload #14
    //   436: iload #5
    //   438: invokevirtual r : (I)Z
    //   441: ifeq -> 470
    //   444: aload #14
    //   446: iload #5
    //   448: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   451: astore #12
    //   453: aload #8
    //   455: astore #11
    //   457: aload #9
    //   459: astore #8
    //   461: goto -> 477
    //   464: aconst_null
    //   465: astore #11
    //   467: aconst_null
    //   468: astore #10
    //   470: aconst_null
    //   471: astore #12
    //   473: aload #10
    //   475: astore #8
    //   477: getstatic f/j.V2 : I
    //   480: istore #5
    //   482: aload #14
    //   484: iload #5
    //   486: invokevirtual r : (I)Z
    //   489: ifeq -> 504
    //   492: aload #14
    //   494: iload #5
    //   496: invokevirtual n : (I)Ljava/lang/String;
    //   499: astore #13
    //   501: goto -> 507
    //   504: aconst_null
    //   505: astore #13
    //   507: iload #4
    //   509: bipush #26
    //   511: if_icmplt -> 541
    //   514: getstatic f/j.T2 : I
    //   517: istore #5
    //   519: aload #14
    //   521: iload #5
    //   523: invokevirtual r : (I)Z
    //   526: ifeq -> 541
    //   529: aload #14
    //   531: iload #5
    //   533: invokevirtual n : (I)Ljava/lang/String;
    //   536: astore #10
    //   538: goto -> 544
    //   541: aconst_null
    //   542: astore #10
    //   544: aload #14
    //   546: invokevirtual v : ()V
    //   549: aload #11
    //   551: astore #9
    //   553: aload #13
    //   555: astore #11
    //   557: goto -> 580
    //   560: aconst_null
    //   561: astore #10
    //   563: aconst_null
    //   564: astore #9
    //   566: aconst_null
    //   567: astore #11
    //   569: iconst_0
    //   570: istore #6
    //   572: aconst_null
    //   573: astore #8
    //   575: aconst_null
    //   576: astore #12
    //   578: iconst_0
    //   579: istore_3
    //   580: aload #17
    //   582: aload_1
    //   583: getstatic f/j.J2 : [I
    //   586: iload_2
    //   587: iconst_0
    //   588: invokestatic u : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/j1;
    //   591: astore #18
    //   593: iload #7
    //   595: ifne -> 628
    //   598: getstatic f/j.U2 : I
    //   601: istore #5
    //   603: aload #18
    //   605: iload #5
    //   607: invokevirtual r : (I)Z
    //   610: ifeq -> 628
    //   613: aload #18
    //   615: iload #5
    //   617: iconst_0
    //   618: invokevirtual a : (IZ)Z
    //   621: istore #6
    //   623: iconst_1
    //   624: istore_3
    //   625: goto -> 628
    //   628: aload #9
    //   630: astore #13
    //   632: aload #8
    //   634: astore #14
    //   636: aload #12
    //   638: astore #15
    //   640: iload #4
    //   642: bipush #23
    //   644: if_icmpge -> 739
    //   647: getstatic f/j.N2 : I
    //   650: istore #5
    //   652: aload #18
    //   654: iload #5
    //   656: invokevirtual r : (I)Z
    //   659: ifeq -> 671
    //   662: aload #18
    //   664: iload #5
    //   666: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   669: astore #9
    //   671: getstatic f/j.O2 : I
    //   674: istore #5
    //   676: aload #18
    //   678: iload #5
    //   680: invokevirtual r : (I)Z
    //   683: ifeq -> 695
    //   686: aload #18
    //   688: iload #5
    //   690: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   693: astore #8
    //   695: getstatic f/j.P2 : I
    //   698: istore #5
    //   700: aload #9
    //   702: astore #13
    //   704: aload #8
    //   706: astore #14
    //   708: aload #12
    //   710: astore #15
    //   712: aload #18
    //   714: iload #5
    //   716: invokevirtual r : (I)Z
    //   719: ifeq -> 739
    //   722: aload #18
    //   724: iload #5
    //   726: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   729: astore #15
    //   731: aload #8
    //   733: astore #14
    //   735: aload #9
    //   737: astore #13
    //   739: getstatic f/j.V2 : I
    //   742: istore #5
    //   744: aload #18
    //   746: iload #5
    //   748: invokevirtual r : (I)Z
    //   751: ifeq -> 763
    //   754: aload #18
    //   756: iload #5
    //   758: invokevirtual n : (I)Ljava/lang/String;
    //   761: astore #11
    //   763: iload #4
    //   765: bipush #26
    //   767: if_icmplt -> 797
    //   770: getstatic f/j.T2 : I
    //   773: istore #5
    //   775: aload #18
    //   777: iload #5
    //   779: invokevirtual r : (I)Z
    //   782: ifeq -> 797
    //   785: aload #18
    //   787: iload #5
    //   789: invokevirtual n : (I)Ljava/lang/String;
    //   792: astore #8
    //   794: goto -> 801
    //   797: aload #10
    //   799: astore #8
    //   801: iload #4
    //   803: bipush #28
    //   805: if_icmplt -> 846
    //   808: getstatic f/j.K2 : I
    //   811: istore #5
    //   813: aload #18
    //   815: iload #5
    //   817: invokevirtual r : (I)Z
    //   820: ifeq -> 846
    //   823: aload #18
    //   825: iload #5
    //   827: iconst_m1
    //   828: invokevirtual e : (II)I
    //   831: ifne -> 846
    //   834: aload_0
    //   835: getfield a : Landroid/widget/TextView;
    //   838: iconst_0
    //   839: fconst_0
    //   840: invokevirtual setTextSize : (IF)V
    //   843: goto -> 846
    //   846: aload_0
    //   847: aload #17
    //   849: aload #18
    //   851: invokespecial B : (Landroid/content/Context;Landroidx/appcompat/widget/j1;)V
    //   854: aload #18
    //   856: invokevirtual v : ()V
    //   859: aload #13
    //   861: ifnull -> 873
    //   864: aload_0
    //   865: getfield a : Landroid/widget/TextView;
    //   868: aload #13
    //   870: invokevirtual setTextColor : (Landroid/content/res/ColorStateList;)V
    //   873: aload #14
    //   875: ifnull -> 887
    //   878: aload_0
    //   879: getfield a : Landroid/widget/TextView;
    //   882: aload #14
    //   884: invokevirtual setHintTextColor : (Landroid/content/res/ColorStateList;)V
    //   887: aload #15
    //   889: ifnull -> 901
    //   892: aload_0
    //   893: getfield a : Landroid/widget/TextView;
    //   896: aload #15
    //   898: invokevirtual setLinkTextColor : (Landroid/content/res/ColorStateList;)V
    //   901: iload #7
    //   903: ifne -> 916
    //   906: iload_3
    //   907: ifeq -> 916
    //   910: aload_0
    //   911: iload #6
    //   913: invokevirtual r : (Z)V
    //   916: aload_0
    //   917: getfield l : Landroid/graphics/Typeface;
    //   920: astore #9
    //   922: aload #9
    //   924: ifnull -> 960
    //   927: aload_0
    //   928: getfield k : I
    //   931: iconst_m1
    //   932: if_icmpne -> 951
    //   935: aload_0
    //   936: getfield a : Landroid/widget/TextView;
    //   939: aload #9
    //   941: aload_0
    //   942: getfield j : I
    //   945: invokevirtual setTypeface : (Landroid/graphics/Typeface;I)V
    //   948: goto -> 960
    //   951: aload_0
    //   952: getfield a : Landroid/widget/TextView;
    //   955: aload #9
    //   957: invokevirtual setTypeface : (Landroid/graphics/Typeface;)V
    //   960: aload #8
    //   962: ifnull -> 975
    //   965: aload_0
    //   966: getfield a : Landroid/widget/TextView;
    //   969: aload #8
    //   971: invokestatic a : (Landroid/widget/TextView;Ljava/lang/String;)Z
    //   974: pop
    //   975: aload #11
    //   977: ifnull -> 1029
    //   980: iload #4
    //   982: bipush #24
    //   984: if_icmplt -> 1002
    //   987: aload_0
    //   988: getfield a : Landroid/widget/TextView;
    //   991: aload #11
    //   993: invokestatic forLanguageTags : (Ljava/lang/String;)Landroid/os/LocaleList;
    //   996: invokestatic a : (Landroid/widget/TextView;Landroid/os/LocaleList;)V
    //   999: goto -> 1029
    //   1002: aload #11
    //   1004: iconst_0
    //   1005: aload #11
    //   1007: bipush #44
    //   1009: invokevirtual indexOf : (I)I
    //   1012: invokevirtual substring : (II)Ljava/lang/String;
    //   1015: astore #8
    //   1017: aload_0
    //   1018: getfield a : Landroid/widget/TextView;
    //   1021: aload #8
    //   1023: invokestatic forLanguageTag : (Ljava/lang/String;)Ljava/util/Locale;
    //   1026: invokevirtual setTextLocale : (Ljava/util/Locale;)V
    //   1029: aload_0
    //   1030: getfield i : Landroidx/appcompat/widget/f0;
    //   1033: aload_1
    //   1034: iload_2
    //   1035: invokevirtual q : (Landroid/util/AttributeSet;I)V
    //   1038: getstatic androidx/core/widget/b.a0 : Z
    //   1041: ifeq -> 1126
    //   1044: aload_0
    //   1045: getfield i : Landroidx/appcompat/widget/f0;
    //   1048: invokevirtual l : ()I
    //   1051: ifeq -> 1126
    //   1054: aload_0
    //   1055: getfield i : Landroidx/appcompat/widget/f0;
    //   1058: invokevirtual k : ()[I
    //   1061: astore #8
    //   1063: aload #8
    //   1065: arraylength
    //   1066: ifle -> 1126
    //   1069: aload_0
    //   1070: getfield a : Landroid/widget/TextView;
    //   1073: invokestatic a : (Landroid/widget/TextView;)I
    //   1076: i2f
    //   1077: ldc_w -1.0
    //   1080: fcmpl
    //   1081: ifeq -> 1116
    //   1084: aload_0
    //   1085: getfield a : Landroid/widget/TextView;
    //   1088: aload_0
    //   1089: getfield i : Landroidx/appcompat/widget/f0;
    //   1092: invokevirtual i : ()I
    //   1095: aload_0
    //   1096: getfield i : Landroidx/appcompat/widget/f0;
    //   1099: invokevirtual h : ()I
    //   1102: aload_0
    //   1103: getfield i : Landroidx/appcompat/widget/f0;
    //   1106: invokevirtual j : ()I
    //   1109: iconst_0
    //   1110: invokestatic a : (Landroid/widget/TextView;IIII)V
    //   1113: goto -> 1126
    //   1116: aload_0
    //   1117: getfield a : Landroid/widget/TextView;
    //   1120: aload #8
    //   1122: iconst_0
    //   1123: invokestatic a : (Landroid/widget/TextView;[II)V
    //   1126: aload #17
    //   1128: aload_1
    //   1129: getstatic f/j.i0 : [I
    //   1132: invokestatic t : (Landroid/content/Context;Landroid/util/AttributeSet;[I)Landroidx/appcompat/widget/j1;
    //   1135: astore #13
    //   1137: aload #13
    //   1139: getstatic f/j.q0 : I
    //   1142: iconst_m1
    //   1143: invokevirtual m : (II)I
    //   1146: istore_2
    //   1147: iload_2
    //   1148: iconst_m1
    //   1149: if_icmpeq -> 1164
    //   1152: aload #16
    //   1154: aload #17
    //   1156: iload_2
    //   1157: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1160: astore_1
    //   1161: goto -> 1166
    //   1164: aconst_null
    //   1165: astore_1
    //   1166: aload #13
    //   1168: getstatic f/j.v0 : I
    //   1171: iconst_m1
    //   1172: invokevirtual m : (II)I
    //   1175: istore_2
    //   1176: iload_2
    //   1177: iconst_m1
    //   1178: if_icmpeq -> 1194
    //   1181: aload #16
    //   1183: aload #17
    //   1185: iload_2
    //   1186: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1189: astore #8
    //   1191: goto -> 1197
    //   1194: aconst_null
    //   1195: astore #8
    //   1197: aload #13
    //   1199: getstatic f/j.r0 : I
    //   1202: iconst_m1
    //   1203: invokevirtual m : (II)I
    //   1206: istore_2
    //   1207: iload_2
    //   1208: iconst_m1
    //   1209: if_icmpeq -> 1225
    //   1212: aload #16
    //   1214: aload #17
    //   1216: iload_2
    //   1217: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1220: astore #9
    //   1222: goto -> 1228
    //   1225: aconst_null
    //   1226: astore #9
    //   1228: aload #13
    //   1230: getstatic f/j.o0 : I
    //   1233: iconst_m1
    //   1234: invokevirtual m : (II)I
    //   1237: istore_2
    //   1238: iload_2
    //   1239: iconst_m1
    //   1240: if_icmpeq -> 1256
    //   1243: aload #16
    //   1245: aload #17
    //   1247: iload_2
    //   1248: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1251: astore #10
    //   1253: goto -> 1259
    //   1256: aconst_null
    //   1257: astore #10
    //   1259: aload #13
    //   1261: getstatic f/j.s0 : I
    //   1264: iconst_m1
    //   1265: invokevirtual m : (II)I
    //   1268: istore_2
    //   1269: iload_2
    //   1270: iconst_m1
    //   1271: if_icmpeq -> 1287
    //   1274: aload #16
    //   1276: aload #17
    //   1278: iload_2
    //   1279: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1282: astore #11
    //   1284: goto -> 1290
    //   1287: aconst_null
    //   1288: astore #11
    //   1290: aload #13
    //   1292: getstatic f/j.p0 : I
    //   1295: iconst_m1
    //   1296: invokevirtual m : (II)I
    //   1299: istore_2
    //   1300: iload_2
    //   1301: iconst_m1
    //   1302: if_icmpeq -> 1318
    //   1305: aload #16
    //   1307: aload #17
    //   1309: iload_2
    //   1310: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1313: astore #12
    //   1315: goto -> 1321
    //   1318: aconst_null
    //   1319: astore #12
    //   1321: aload_0
    //   1322: aload_1
    //   1323: aload #8
    //   1325: aload #9
    //   1327: aload #10
    //   1329: aload #11
    //   1331: aload #12
    //   1333: invokespecial x : (Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   1336: getstatic f/j.t0 : I
    //   1339: istore_2
    //   1340: aload #13
    //   1342: iload_2
    //   1343: invokevirtual r : (I)Z
    //   1346: ifeq -> 1364
    //   1349: aload #13
    //   1351: iload_2
    //   1352: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   1355: astore_1
    //   1356: aload_0
    //   1357: getfield a : Landroid/widget/TextView;
    //   1360: aload_1
    //   1361: invokestatic f : (Landroid/widget/TextView;Landroid/content/res/ColorStateList;)V
    //   1364: getstatic f/j.u0 : I
    //   1367: istore_2
    //   1368: aload #13
    //   1370: iload_2
    //   1371: invokevirtual r : (I)Z
    //   1374: ifeq -> 1400
    //   1377: aload #13
    //   1379: iload_2
    //   1380: iconst_m1
    //   1381: invokevirtual j : (II)I
    //   1384: aconst_null
    //   1385: invokestatic d : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;
    //   1388: astore_1
    //   1389: aload_0
    //   1390: getfield a : Landroid/widget/TextView;
    //   1393: aload_1
    //   1394: invokestatic g : (Landroid/widget/TextView;Landroid/graphics/PorterDuff$Mode;)V
    //   1397: goto -> 1400
    //   1400: aload #13
    //   1402: getstatic f/j.w0 : I
    //   1405: iconst_m1
    //   1406: invokevirtual e : (II)I
    //   1409: istore_2
    //   1410: aload #13
    //   1412: getstatic f/j.x0 : I
    //   1415: iconst_m1
    //   1416: invokevirtual e : (II)I
    //   1419: istore_3
    //   1420: aload #13
    //   1422: getstatic f/j.y0 : I
    //   1425: iconst_m1
    //   1426: invokevirtual e : (II)I
    //   1429: istore #4
    //   1431: aload #13
    //   1433: invokevirtual v : ()V
    //   1436: iload_2
    //   1437: iconst_m1
    //   1438: if_icmpeq -> 1449
    //   1441: aload_0
    //   1442: getfield a : Landroid/widget/TextView;
    //   1445: iload_2
    //   1446: invokestatic h : (Landroid/widget/TextView;I)V
    //   1449: iload_3
    //   1450: iconst_m1
    //   1451: if_icmpeq -> 1462
    //   1454: aload_0
    //   1455: getfield a : Landroid/widget/TextView;
    //   1458: iload_3
    //   1459: invokestatic i : (Landroid/widget/TextView;I)V
    //   1462: iload #4
    //   1464: iconst_m1
    //   1465: if_icmpeq -> 1477
    //   1468: aload_0
    //   1469: getfield a : Landroid/widget/TextView;
    //   1472: iload #4
    //   1474: invokestatic j : (Landroid/widget/TextView;I)V
    //   1477: return
  }
  
  void n(WeakReference<TextView> paramWeakReference, Typeface paramTypeface) {
    if (this.m) {
      this.l = paramTypeface;
      TextView textView = paramWeakReference.get();
      if (textView != null)
        textView.setTypeface(paramTypeface, this.j); 
    } 
  }
  
  void o(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!b.a0)
      c(); 
  }
  
  void p() {
    b();
  }
  
  void q(Context paramContext, int paramInt) {
    j1 j1 = j1.s(paramContext, paramInt, j.J2);
    paramInt = j.U2;
    if (j1.r(paramInt))
      r(j1.a(paramInt, false)); 
    paramInt = Build.VERSION.SDK_INT;
    if (paramInt < 23) {
      int j = j.N2;
      if (j1.r(j)) {
        ColorStateList colorStateList = j1.c(j);
        if (colorStateList != null)
          this.a.setTextColor(colorStateList); 
      } 
    } 
    int i = j.K2;
    if (j1.r(i) && j1.e(i, -1) == 0)
      this.a.setTextSize(0, 0.0F); 
    B(paramContext, j1);
    if (paramInt >= 26) {
      paramInt = j.T2;
      if (j1.r(paramInt)) {
        String str = j1.n(paramInt);
        if (str != null)
          w.a(this.a, str); 
      } 
    } 
    j1.v();
    Typeface typeface = this.l;
    if (typeface != null)
      this.a.setTypeface(typeface, this.j); 
  }
  
  void r(boolean paramBoolean) {
    this.a.setAllCaps(paramBoolean);
  }
  
  void s(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws IllegalArgumentException {
    this.i.r(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  void t(@NonNull int[] paramArrayOfint, int paramInt) throws IllegalArgumentException {
    this.i.s(paramArrayOfint, paramInt);
  }
  
  void u(int paramInt) {
    this.i.t(paramInt);
  }
  
  void v(@Nullable ColorStateList paramColorStateList) {
    boolean bool;
    if (this.h == null)
      this.h = new h1(); 
    h1 h11 = this.h;
    h11.a = paramColorStateList;
    if (paramColorStateList != null) {
      bool = true;
    } else {
      bool = false;
    } 
    h11.d = bool;
    y();
  }
  
  void w(@Nullable PorterDuff.Mode paramMode) {
    boolean bool;
    if (this.h == null)
      this.h = new h1(); 
    h1 h11 = this.h;
    h11.b = paramMode;
    if (paramMode != null) {
      bool = true;
    } else {
      bool = false;
    } 
    h11.c = bool;
    y();
  }
  
  void z(int paramInt, float paramFloat) {
    if (!b.a0 && !l())
      A(paramInt, paramFloat); 
  }
  
  class a extends h.e {
    a(c0 this$0, int param1Int1, int param1Int2, WeakReference param1WeakReference) {}
    
    public void h(int param1Int) {}
    
    public void i(@NonNull Typeface param1Typeface) {
      Typeface typeface = param1Typeface;
      if (Build.VERSION.SDK_INT >= 28) {
        int i = this.a;
        typeface = param1Typeface;
        if (i != -1) {
          boolean bool;
          if ((this.b & 0x2) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          typeface = b0.a(param1Typeface, i, bool);
        } 
      } 
      this.d.n(this.c, typeface);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */