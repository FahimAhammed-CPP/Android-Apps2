package androidx.appcompat.widget;

import android.view.Menu;
import android.view.Window;
import androidx.appcompat.view.menu.j;

public interface j0 {
  boolean a();
  
  boolean b();
  
  boolean c();
  
  void d(Menu paramMenu, j.a parama);
  
  boolean e();
  
  void f();
  
  boolean g();
  
  void h(int paramInt);
  
  void l();
  
  void setWindowCallback(Window.Callback paramCallback);
  
  void setWindowTitle(CharSequence paramCharSequence);
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */