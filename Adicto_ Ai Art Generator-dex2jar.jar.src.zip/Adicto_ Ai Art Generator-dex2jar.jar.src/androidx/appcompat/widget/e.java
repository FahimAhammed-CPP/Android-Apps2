package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.ViewCompat;
import f.j;

class e {
  @NonNull
  private final View a;
  
  private final i b;
  
  private int c = -1;
  
  private h1 d;
  
  private h1 e;
  
  private h1 f;
  
  e(@NonNull View paramView) {
    this.a = paramView;
    this.b = i.b();
  }
  
  private boolean a(@NonNull Drawable paramDrawable) {
    if (this.f == null)
      this.f = new h1(); 
    h1 h11 = this.f;
    h11.a();
    ColorStateList colorStateList = ViewCompat.getBackgroundTintList(this.a);
    if (colorStateList != null) {
      h11.d = true;
      h11.a = colorStateList;
    } 
    PorterDuff.Mode mode = ViewCompat.getBackgroundTintMode(this.a);
    if (mode != null) {
      h11.c = true;
      h11.b = mode;
    } 
    if (h11.d || h11.c) {
      i.i(paramDrawable, h11, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  private boolean k() {
    int j = Build.VERSION.SDK_INT;
    return (j > 21) ? ((this.d != null)) : ((j == 21));
  }
  
  void b() {
    Drawable drawable = this.a.getBackground();
    if (drawable != null) {
      if (k() && a(drawable))
        return; 
      h1 h11 = this.e;
      if (h11 != null) {
        i.i(drawable, h11, this.a.getDrawableState());
        return;
      } 
      h11 = this.d;
      if (h11 != null)
        i.i(drawable, h11, this.a.getDrawableState()); 
    } 
  }
  
  ColorStateList c() {
    h1 h11 = this.e;
    return (h11 != null) ? h11.a : null;
  }
  
  PorterDuff.Mode d() {
    h1 h11 = this.e;
    return (h11 != null) ? h11.b : null;
  }
  
  void e(@Nullable AttributeSet paramAttributeSet, int paramInt) {
    Context context = this.a.getContext();
    int[] arrayOfInt = j.D3;
    j1 j1 = j1.u(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    View view = this.a;
    ViewCompat.saveAttributeDataForStyleable(view, view.getContext(), arrayOfInt, paramAttributeSet, j1.q(), paramInt, 0);
    try {
      paramInt = j.E3;
      if (j1.r(paramInt)) {
        this.c = j1.m(paramInt, -1);
        ColorStateList colorStateList = this.b.f(this.a.getContext(), this.c);
        if (colorStateList != null)
          h(colorStateList); 
      } 
      paramInt = j.F3;
      if (j1.r(paramInt))
        ViewCompat.setBackgroundTintList(this.a, j1.c(paramInt)); 
      paramInt = j.G3;
      if (j1.r(paramInt))
        ViewCompat.setBackgroundTintMode(this.a, l0.d(j1.j(paramInt, -1), null)); 
      return;
    } finally {
      j1.v();
    } 
  }
  
  void f(Drawable paramDrawable) {
    this.c = -1;
    h(null);
    b();
  }
  
  void g(int paramInt) {
    this.c = paramInt;
    i i1 = this.b;
    if (i1 != null) {
      ColorStateList colorStateList = i1.f(this.a.getContext(), paramInt);
    } else {
      i1 = null;
    } 
    h((ColorStateList)i1);
    b();
  }
  
  void h(ColorStateList paramColorStateList) {
    if (paramColorStateList != null) {
      if (this.d == null)
        this.d = new h1(); 
      h1 h11 = this.d;
      h11.a = paramColorStateList;
      h11.d = true;
    } else {
      this.d = null;
    } 
    b();
  }
  
  void i(ColorStateList paramColorStateList) {
    if (this.e == null)
      this.e = new h1(); 
    h1 h11 = this.e;
    h11.a = paramColorStateList;
    h11.d = true;
    b();
  }
  
  void j(PorterDuff.Mode paramMode) {
    if (this.e == null)
      this.e = new h1(); 
    h1 h11 = this.e;
    h11.b = paramMode;
    h11.c = true;
    b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */