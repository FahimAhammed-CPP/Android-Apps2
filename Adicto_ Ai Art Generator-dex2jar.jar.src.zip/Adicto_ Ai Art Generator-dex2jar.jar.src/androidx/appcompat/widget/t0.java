package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.ViewCompat;
import androidx.core.widget.k;
import f.j;
import java.lang.reflect.Method;
import l.e;

public class t0 implements e {
  private static Method H;
  
  private static Method I;
  
  private static Method J;
  
  private final c A = new c(this);
  
  private Runnable B;
  
  final Handler C;
  
  private final Rect D = new Rect();
  
  private Rect E;
  
  private boolean F;
  
  PopupWindow G;
  
  private Context b;
  
  private ListAdapter c;
  
  m0 d;
  
  private int e = -2;
  
  private int f = -2;
  
  private int g;
  
  private int h;
  
  private int i = 1002;
  
  private boolean j;
  
  private boolean k;
  
  private boolean l;
  
  private int m = 0;
  
  private boolean n = false;
  
  private boolean o = false;
  
  int p = Integer.MAX_VALUE;
  
  private View q;
  
  private int r = 0;
  
  private DataSetObserver s;
  
  private View t;
  
  private Drawable u;
  
  private AdapterView.OnItemClickListener v;
  
  private AdapterView.OnItemSelectedListener w;
  
  final g x = new g(this);
  
  private final f y = new f(this);
  
  private final e z = new e(this);
  
  static {
    if (Build.VERSION.SDK_INT <= 28) {
      try {
        H = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", new Class[] { boolean.class });
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
      } 
      try {
        J = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", new Class[] { Rect.class });
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
      } 
    } 
    if (Build.VERSION.SDK_INT <= 23)
      try {
        I = PopupWindow.class.getDeclaredMethod("getMaxAvailableHeight", new Class[] { View.class, int.class, boolean.class });
        return;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
      }  
  }
  
  public t0(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public t0(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this.b = paramContext;
    this.C = new Handler(paramContext.getMainLooper());
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, j.o1, paramInt1, paramInt2);
    this.g = typedArray.getDimensionPixelOffset(j.p1, 0);
    int i = typedArray.getDimensionPixelOffset(j.q1, 0);
    this.h = i;
    if (i != 0)
      this.j = true; 
    typedArray.recycle();
    o o = new o(paramContext, paramAttributeSet, paramInt1, paramInt2);
    this.G = o;
    o.setInputMethodMode(1);
  }
  
  private void I(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = H;
      if (method != null)
        try {
          method.invoke(this.G, new Object[] { Boolean.valueOf(paramBoolean) });
          return;
        } catch (Exception exception) {
          Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
          return;
        }  
    } else {
      s0.a(this.G, paramBoolean);
    } 
  }
  
  private int p() {
    byte b1;
    byte b2;
    m0 m01 = this.d;
    boolean bool = true;
    if (m01 == null) {
      LinearLayout.LayoutParams layoutParams1;
      LinearLayout.LayoutParams layoutParams2;
      Context context = this.b;
      this.B = new a(this);
      m0 m03 = r(context, this.F ^ true);
      this.d = m03;
      Drawable drawable1 = this.u;
      if (drawable1 != null)
        m03.setSelector(drawable1); 
      this.d.setAdapter(this.c);
      this.d.setOnItemClickListener(this.v);
      this.d.setFocusable(true);
      this.d.setFocusableInTouchMode(true);
      this.d.setOnItemSelectedListener(new b(this));
      this.d.setOnScrollListener(this.z);
      AdapterView.OnItemSelectedListener onItemSelectedListener = this.w;
      if (onItemSelectedListener != null)
        this.d.setOnItemSelectedListener(onItemSelectedListener); 
      m0 m02 = this.d;
      View view = this.q;
      if (view != null) {
        boolean bool1;
        StringBuilder stringBuilder;
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(1);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 0, 1.0F);
        b1 = this.r;
        if (b1 != 0) {
          if (b1 != 1) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid hint position ");
            stringBuilder.append(this.r);
            Log.e("ListPopupWindow", stringBuilder.toString());
          } else {
            linearLayout.addView((View)stringBuilder, (ViewGroup.LayoutParams)layoutParams);
            linearLayout.addView(view);
          } 
        } else {
          linearLayout.addView(view);
          linearLayout.addView((View)stringBuilder, (ViewGroup.LayoutParams)layoutParams);
        } 
        b1 = this.f;
        if (b1 >= 0) {
          bool1 = true;
        } else {
          b1 = 0;
          bool1 = false;
        } 
        view.measure(View.MeasureSpec.makeMeasureSpec(b1, bool1), 0);
        layoutParams2 = (LinearLayout.LayoutParams)view.getLayoutParams();
        b1 = view.getMeasuredHeight() + layoutParams2.topMargin + layoutParams2.bottomMargin;
      } else {
        b1 = 0;
        layoutParams1 = layoutParams2;
      } 
      this.G.setContentView((View)layoutParams1);
    } else {
      ViewGroup viewGroup = (ViewGroup)this.G.getContentView();
      View view = this.q;
      if (view != null) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)view.getLayoutParams();
        b1 = view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
      } else {
        b1 = 0;
      } 
    } 
    Drawable drawable = this.G.getBackground();
    if (drawable != null) {
      drawable.getPadding(this.D);
      Rect rect = this.D;
      int m = rect.top;
      int k = rect.bottom + m;
      b2 = k;
      if (!this.j) {
        this.h = -m;
        b2 = k;
      } 
    } else {
      this.D.setEmpty();
      b2 = 0;
    } 
    if (this.G.getInputMethodMode() != 2)
      bool = false; 
    int j = t(s(), this.h, bool);
    if (this.n || this.e == -1)
      return j + b2; 
    int i = this.f;
    if (i != -2) {
      if (i != -1) {
        i = View.MeasureSpec.makeMeasureSpec(i, 1073741824);
      } else {
        i = (this.b.getResources().getDisplayMetrics()).widthPixels;
        Rect rect = this.D;
        i = View.MeasureSpec.makeMeasureSpec(i - rect.left + rect.right, 1073741824);
      } 
    } else {
      i = (this.b.getResources().getDisplayMetrics()).widthPixels;
      Rect rect = this.D;
      i = View.MeasureSpec.makeMeasureSpec(i - rect.left + rect.right, -2147483648);
    } 
    j = this.d.d(i, 0, -1, j - b1, -1);
    i = b1;
    if (j > 0)
      i = b1 + b2 + this.d.getPaddingTop() + this.d.getPaddingBottom(); 
    return j + i;
  }
  
  private int t(View paramView, int paramInt, boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 23) {
      Method method = I;
      if (method != null)
        try {
          return ((Integer)method.invoke(this.G, new Object[] { paramView, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) })).intValue();
        } catch (Exception exception) {
          Log.i("ListPopupWindow", "Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.");
        }  
      return this.G.getMaxAvailableHeight(paramView, paramInt);
    } 
    return r0.a(this.G, paramView, paramInt, paramBoolean);
  }
  
  private void x() {
    View view = this.q;
    if (view != null) {
      ViewParent viewParent = view.getParent();
      if (viewParent instanceof ViewGroup)
        ((ViewGroup)viewParent).removeView(this.q); 
    } 
  }
  
  public void A(int paramInt) {
    Drawable drawable = this.G.getBackground();
    if (drawable != null) {
      drawable.getPadding(this.D);
      Rect rect = this.D;
      this.f = rect.left + rect.right + paramInt;
      return;
    } 
    L(paramInt);
  }
  
  public void B(int paramInt) {
    this.m = paramInt;
  }
  
  public void C(@Nullable Rect paramRect) {
    if (paramRect != null) {
      paramRect = new Rect(paramRect);
    } else {
      paramRect = null;
    } 
    this.E = paramRect;
  }
  
  public void D(int paramInt) {
    this.G.setInputMethodMode(paramInt);
  }
  
  public void E(boolean paramBoolean) {
    this.F = paramBoolean;
    this.G.setFocusable(paramBoolean);
  }
  
  public void F(@Nullable PopupWindow.OnDismissListener paramOnDismissListener) {
    this.G.setOnDismissListener(paramOnDismissListener);
  }
  
  public void G(@Nullable AdapterView.OnItemClickListener paramOnItemClickListener) {
    this.v = paramOnItemClickListener;
  }
  
  public void H(boolean paramBoolean) {
    this.l = true;
    this.k = paramBoolean;
  }
  
  public void J(int paramInt) {
    this.r = paramInt;
  }
  
  public void K(int paramInt) {
    m0 m01 = this.d;
    if (a() && m01 != null) {
      m01.setListSelectionHidden(false);
      m01.setSelection(paramInt);
      if (m01.getChoiceMode() != 0)
        m01.setItemChecked(paramInt, true); 
    } 
  }
  
  public void L(int paramInt) {
    this.f = paramInt;
  }
  
  public boolean a() {
    return this.G.isShowing();
  }
  
  public int b() {
    return this.g;
  }
  
  public void d(int paramInt) {
    this.g = paramInt;
  }
  
  public void dismiss() {
    this.G.dismiss();
    x();
    this.G.setContentView(null);
    this.d = null;
    this.C.removeCallbacks(this.x);
  }
  
  @Nullable
  public Drawable f() {
    return this.G.getBackground();
  }
  
  public void h(int paramInt) {
    this.h = paramInt;
    this.j = true;
  }
  
  public int k() {
    return !this.j ? 0 : this.h;
  }
  
  public void l(@Nullable ListAdapter paramListAdapter) {
    DataSetObserver dataSetObserver = this.s;
    if (dataSetObserver == null) {
      this.s = new d(this);
    } else {
      ListAdapter listAdapter = this.c;
      if (listAdapter != null)
        listAdapter.unregisterDataSetObserver(dataSetObserver); 
    } 
    this.c = paramListAdapter;
    if (paramListAdapter != null)
      paramListAdapter.registerDataSetObserver(this.s); 
    m0 m01 = this.d;
    if (m01 != null)
      m01.setAdapter(this.c); 
  }
  
  @Nullable
  public ListView n() {
    return this.d;
  }
  
  public void o(@Nullable Drawable paramDrawable) {
    this.G.setBackgroundDrawable(paramDrawable);
  }
  
  public void q() {
    m0 m01 = this.d;
    if (m01 != null) {
      m01.setListSelectionHidden(true);
      m01.requestLayout();
    } 
  }
  
  @NonNull
  m0 r(Context paramContext, boolean paramBoolean) {
    return new m0(paramContext, paramBoolean);
  }
  
  @Nullable
  public View s() {
    return this.t;
  }
  
  public void show() {
    int i;
    int j = p();
    boolean bool1 = v();
    k.b(this.G, this.i);
    boolean bool2 = this.G.isShowing();
    boolean bool = true;
    if (bool2) {
      if (!ViewCompat.isAttachedToWindow(s()))
        return; 
      int m = this.f;
      if (m == -1) {
        i = -1;
      } else {
        i = m;
        if (m == -2)
          i = s().getWidth(); 
      } 
      m = this.e;
      if (m == -1) {
        if (!bool1)
          j = -1; 
        if (bool1) {
          PopupWindow popupWindow2 = this.G;
          if (this.f == -1) {
            m = -1;
          } else {
            m = 0;
          } 
          popupWindow2.setWidth(m);
          this.G.setHeight(0);
        } else {
          PopupWindow popupWindow2 = this.G;
          if (this.f == -1) {
            m = -1;
          } else {
            m = 0;
          } 
          popupWindow2.setWidth(m);
          this.G.setHeight(-1);
        } 
      } else if (m != -2) {
        j = m;
      } 
      PopupWindow popupWindow1 = this.G;
      if (this.o || this.n)
        bool = false; 
      popupWindow1.setOutsideTouchable(bool);
      popupWindow1 = this.G;
      View view = s();
      m = this.g;
      int n = this.h;
      if (i < 0)
        i = -1; 
      if (j < 0)
        j = -1; 
      popupWindow1.update(view, m, n, i, j);
      return;
    } 
    int k = this.f;
    if (k == -1) {
      i = -1;
    } else {
      i = k;
      if (k == -2)
        i = s().getWidth(); 
    } 
    k = this.e;
    if (k == -1) {
      j = -1;
    } else if (k != -2) {
      j = k;
    } 
    this.G.setWidth(i);
    this.G.setHeight(j);
    I(true);
    PopupWindow popupWindow = this.G;
    if (!this.o && !this.n) {
      bool = true;
    } else {
      bool = false;
    } 
    popupWindow.setOutsideTouchable(bool);
    this.G.setTouchInterceptor(this.y);
    if (this.l)
      k.a(this.G, this.k); 
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = J;
      if (method != null)
        try {
          method.invoke(this.G, new Object[] { this.E });
        } catch (Exception exception) {
          Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", exception);
        }  
    } else {
      q0.a(this.G, this.E);
    } 
    k.c(this.G, s(), this.g, this.h, this.m);
    this.d.setSelection(-1);
    if (!this.F || this.d.isInTouchMode())
      q(); 
    if (!this.F)
      this.C.post(this.A); 
  }
  
  public int u() {
    return this.f;
  }
  
  public boolean v() {
    return (this.G.getInputMethodMode() == 2);
  }
  
  public boolean w() {
    return this.F;
  }
  
  public void y(@Nullable View paramView) {
    this.t = paramView;
  }
  
  public void z(int paramInt) {
    this.G.setAnimationStyle(paramInt);
  }
  
  class a implements Runnable {
    a(t0 this$0) {}
    
    public void run() {
      View view = this.b.s();
      if (view != null && view.getWindowToken() != null)
        this.b.show(); 
    }
  }
  
  class b implements AdapterView.OnItemSelectedListener {
    b(t0 this$0) {}
    
    public void onItemSelected(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      if (param1Int != -1) {
        m0 m0 = this.b.d;
        if (m0 != null)
          m0.setListSelectionHidden(false); 
      } 
    }
    
    public void onNothingSelected(AdapterView<?> param1AdapterView) {}
  }
  
  private class c implements Runnable {
    c(t0 this$0) {}
    
    public void run() {
      this.b.q();
    }
  }
  
  private class d extends DataSetObserver {
    d(t0 this$0) {}
    
    public void onChanged() {
      if (this.a.a())
        this.a.show(); 
    }
    
    public void onInvalidated() {
      this.a.dismiss();
    }
  }
  
  private class e implements AbsListView.OnScrollListener {
    e(t0 this$0) {}
    
    public void onScroll(AbsListView param1AbsListView, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void onScrollStateChanged(AbsListView param1AbsListView, int param1Int) {
      if (param1Int == 1 && !this.a.v() && this.a.G.getContentView() != null) {
        t0 t01 = this.a;
        t01.C.removeCallbacks(t01.x);
        this.a.x.run();
      } 
    }
  }
  
  private class f implements View.OnTouchListener {
    f(t0 this$0) {}
    
    public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
      int i = param1MotionEvent.getAction();
      int j = (int)param1MotionEvent.getX();
      int k = (int)param1MotionEvent.getY();
      if (i == 0) {
        PopupWindow popupWindow = this.b.G;
        if (popupWindow != null && popupWindow.isShowing() && j >= 0 && j < this.b.G.getWidth() && k >= 0 && k < this.b.G.getHeight()) {
          t0 t01 = this.b;
          t01.C.postDelayed(t01.x, 250L);
          return false;
        } 
      } 
      if (i == 1) {
        t0 t01 = this.b;
        t01.C.removeCallbacks(t01.x);
      } 
      return false;
    }
  }
  
  private class g implements Runnable {
    g(t0 this$0) {}
    
    public void run() {
      m0 m0 = this.b.d;
      if (m0 != null && ViewCompat.isAttachedToWindow((View)m0) && this.b.d.getCount() > this.b.d.getChildCount()) {
        int i = this.b.d.getChildCount();
        t0 t01 = this.b;
        if (i <= t01.p) {
          t01.G.setInputMethodMode(2);
          this.b.show();
        } 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\t0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */