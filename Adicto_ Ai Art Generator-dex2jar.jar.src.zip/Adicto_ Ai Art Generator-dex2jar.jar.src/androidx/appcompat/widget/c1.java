package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

public class c1 extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
  private static final Interpolator k = (Interpolator)new DecelerateInterpolator();
  
  Runnable b;
  
  private c c;
  
  p0 d;
  
  private Spinner e;
  
  private boolean f;
  
  int g;
  
  int h;
  
  private int i;
  
  private int j;
  
  private Spinner b() {
    u u = new u(getContext(), null, f.a.h);
    u.setLayoutParams((ViewGroup.LayoutParams)new p0.a(-2, -1));
    u.setOnItemSelectedListener(this);
    return u;
  }
  
  private boolean d() {
    Spinner spinner = this.e;
    return (spinner != null && spinner.getParent() == this);
  }
  
  private void e() {
    if (d())
      return; 
    if (this.e == null)
      this.e = b(); 
    removeView((View)this.d);
    addView((View)this.e, new ViewGroup.LayoutParams(-2, -1));
    if (this.e.getAdapter() == null)
      this.e.setAdapter((SpinnerAdapter)new b(this)); 
    Runnable runnable = this.b;
    if (runnable != null) {
      removeCallbacks(runnable);
      this.b = null;
    } 
    this.e.setSelection(this.j);
  }
  
  private boolean f() {
    if (!d())
      return false; 
    removeView((View)this.e);
    addView((View)this.d, new ViewGroup.LayoutParams(-2, -1));
    setTabSelected(this.e.getSelectedItemPosition());
    return false;
  }
  
  public void a(int paramInt) {
    View view = this.d.getChildAt(paramInt);
    Runnable runnable = this.b;
    if (runnable != null)
      removeCallbacks(runnable); 
    a a = new a(this, view);
    this.b = a;
    post(a);
  }
  
  d c(g.a.c paramc, boolean paramBoolean) {
    d d = new d(this, getContext(), paramc, paramBoolean);
    if (paramBoolean) {
      d.setBackgroundDrawable(null);
      d.setLayoutParams((ViewGroup.LayoutParams)new AbsListView.LayoutParams(-1, this.i));
      return d;
    } 
    d.setFocusable(true);
    if (this.c == null)
      this.c = new c(this); 
    d.setOnClickListener(this.c);
    return d;
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    Runnable runnable = this.b;
    if (runnable != null)
      post(runnable); 
  }
  
  protected void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    k.a a = k.a.b(getContext());
    setContentHeight(a.f());
    this.h = a.e();
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    Runnable runnable = this.b;
    if (runnable != null)
      removeCallbacks(runnable); 
  }
  
  public void onItemSelected(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    ((d)paramView).b().e();
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    boolean bool;
    int i = View.MeasureSpec.getMode(paramInt1);
    paramInt2 = 1;
    if (i == 1073741824) {
      bool = true;
    } else {
      bool = false;
    } 
    setFillViewport(bool);
    int j = this.d.getChildCount();
    if (j > 1 && (i == 1073741824 || i == Integer.MIN_VALUE)) {
      if (j > 2) {
        this.g = (int)(View.MeasureSpec.getSize(paramInt1) * 0.4F);
      } else {
        this.g = View.MeasureSpec.getSize(paramInt1) / 2;
      } 
      this.g = Math.min(this.g, this.h);
    } else {
      this.g = -1;
    } 
    i = View.MeasureSpec.makeMeasureSpec(this.i, 1073741824);
    if (bool || !this.f)
      paramInt2 = 0; 
    if (paramInt2 != 0) {
      this.d.measure(0, i);
      if (this.d.getMeasuredWidth() > View.MeasureSpec.getSize(paramInt1)) {
        e();
      } else {
        f();
      } 
    } else {
      f();
    } 
    paramInt2 = getMeasuredWidth();
    super.onMeasure(paramInt1, i);
    paramInt1 = getMeasuredWidth();
    if (bool && paramInt2 != paramInt1)
      setTabSelected(this.j); 
  }
  
  public void onNothingSelected(AdapterView<?> paramAdapterView) {}
  
  public void setAllowCollapse(boolean paramBoolean) {
    this.f = paramBoolean;
  }
  
  public void setContentHeight(int paramInt) {
    this.i = paramInt;
    requestLayout();
  }
  
  public void setTabSelected(int paramInt) {
    this.j = paramInt;
    int j = this.d.getChildCount();
    for (int i = 0; i < j; i++) {
      boolean bool;
      View view = this.d.getChildAt(i);
      if (i == paramInt) {
        bool = true;
      } else {
        bool = false;
      } 
      view.setSelected(bool);
      if (bool)
        a(paramInt); 
    } 
    Spinner spinner = this.e;
    if (spinner != null && paramInt >= 0)
      spinner.setSelection(paramInt); 
  }
  
  class a implements Runnable {
    a(c1 this$0, View param1View) {}
    
    public void run() {
      int i = this.b.getLeft();
      int j = (this.c.getWidth() - this.b.getWidth()) / 2;
      this.c.smoothScrollTo(i - j, 0);
      this.c.b = null;
    }
  }
  
  private class b extends BaseAdapter {
    b(c1 this$0) {}
    
    public int getCount() {
      return this.b.d.getChildCount();
    }
    
    public Object getItem(int param1Int) {
      return ((c1.d)this.b.d.getChildAt(param1Int)).b();
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      if (param1View == null)
        return (View)this.b.c((g.a.c)getItem(param1Int), true); 
      ((c1.d)param1View).a((g.a.c)getItem(param1Int));
      return param1View;
    }
  }
  
  private class c implements View.OnClickListener {
    c(c1 this$0) {}
    
    public void onClick(View param1View) {
      ((c1.d)param1View).b().e();
      int j = this.b.d.getChildCount();
      for (int i = 0; i < j; i++) {
        boolean bool;
        View view = this.b.d.getChildAt(i);
        if (view == param1View) {
          bool = true;
        } else {
          bool = false;
        } 
        view.setSelected(bool);
      } 
    }
  }
  
  private class d extends LinearLayout {
    private final int[] b;
    
    private g.a.c c;
    
    private TextView d;
    
    private ImageView e;
    
    private View f;
    
    public d(c1 this$0, Context param1Context, g.a.c param1c, boolean param1Boolean) {
      super(param1Context, null, i);
      int[] arrayOfInt = new int[1];
      arrayOfInt[0] = 16842964;
      this.b = arrayOfInt;
      this.c = param1c;
      j1 j1 = j1.u(param1Context, null, arrayOfInt, i, 0);
      if (j1.r(0))
        setBackgroundDrawable(j1.f(0)); 
      j1.v();
      if (param1Boolean)
        setGravity(8388627); 
      c();
    }
    
    public void a(g.a.c param1c) {
      this.c = param1c;
      c();
    }
    
    public g.a.c b() {
      return this.c;
    }
    
    public void c() {
      g.a.c c2 = this.c;
      View view = c2.b();
      ViewParent viewParent = null;
      if (view != null) {
        viewParent = view.getParent();
        if (viewParent != this) {
          if (viewParent != null)
            ((ViewGroup)viewParent).removeView(view); 
          addView(view);
        } 
        this.f = view;
        TextView textView = this.d;
        if (textView != null)
          textView.setVisibility(8); 
        ImageView imageView = this.e;
        if (imageView != null) {
          imageView.setVisibility(8);
          this.e.setImageDrawable(null);
          return;
        } 
      } else {
        CharSequence charSequence1;
        view = this.f;
        if (view != null) {
          removeView(view);
          this.f = null;
        } 
        Drawable drawable = c2.c();
        CharSequence charSequence2 = c2.d();
        if (drawable != null) {
          if (this.e == null) {
            AppCompatImageView appCompatImageView = new AppCompatImageView(getContext());
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.gravity = 16;
            appCompatImageView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            addView((View)appCompatImageView, 0);
            this.e = appCompatImageView;
          } 
          this.e.setImageDrawable(drawable);
          this.e.setVisibility(0);
        } else {
          ImageView imageView1 = this.e;
          if (imageView1 != null) {
            imageView1.setVisibility(8);
            this.e.setImageDrawable(null);
          } 
        } 
        int i = TextUtils.isEmpty(charSequence2) ^ true;
        if (i != 0) {
          if (this.d == null) {
            AppCompatTextView appCompatTextView = new AppCompatTextView(getContext(), null, f.a.e);
            appCompatTextView.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.gravity = 16;
            appCompatTextView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            addView((View)appCompatTextView);
            this.d = appCompatTextView;
          } 
          this.d.setText(charSequence2);
          this.d.setVisibility(0);
        } else {
          TextView textView = this.d;
          if (textView != null) {
            textView.setVisibility(8);
            this.d.setText(null);
          } 
        } 
        ImageView imageView = this.e;
        if (imageView != null)
          imageView.setContentDescription(c2.a()); 
        if (i == 0)
          charSequence1 = c2.a(); 
        m1.a((View)this, charSequence1);
      } 
    }
    
    public void onInitializeAccessibilityEvent(AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName("androidx.appcompat.app.ActionBar$Tab");
    }
    
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo param1AccessibilityNodeInfo) {
      super.onInitializeAccessibilityNodeInfo(param1AccessibilityNodeInfo);
      param1AccessibilityNodeInfo.setClassName("androidx.appcompat.app.ActionBar$Tab");
    }
    
    public void onMeasure(int param1Int1, int param1Int2) {
      super.onMeasure(param1Int1, param1Int2);
      if (this.g.g > 0) {
        param1Int1 = getMeasuredWidth();
        int i = this.g.g;
        if (param1Int1 > i)
          super.onMeasure(View.MeasureSpec.makeMeasureSpec(i, 1073741824), param1Int2); 
      } 
    }
    
    public void setSelected(boolean param1Boolean) {
      boolean bool;
      if (isSelected() != param1Boolean) {
        bool = true;
      } else {
        bool = false;
      } 
      super.setSelected(param1Boolean);
      if (bool && param1Boolean)
        sendAccessibilityEvent(4); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\c1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */