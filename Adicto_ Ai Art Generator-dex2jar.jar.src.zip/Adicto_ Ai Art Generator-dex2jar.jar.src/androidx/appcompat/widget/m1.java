package androidx.appcompat.widget;

import android.os.Build;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class m1 {
  public static void a(@NonNull View paramView, @Nullable CharSequence paramCharSequence) {
    if (Build.VERSION.SDK_INT >= 26) {
      l1.a(paramView, paramCharSequence);
      return;
    } 
    n1.f(paramView, paramCharSequence);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\m1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */