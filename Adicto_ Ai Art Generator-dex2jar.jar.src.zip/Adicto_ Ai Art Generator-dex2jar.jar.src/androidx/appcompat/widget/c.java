package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.view.menu.a;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.i;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.view.menu.k;
import androidx.appcompat.view.menu.m;
import androidx.core.view.b;
import f.g;
import java.util.ArrayList;

class c extends a implements b.a {
  a A;
  
  c B;
  
  private b C;
  
  final f D = new f(this);
  
  int E;
  
  d l;
  
  private Drawable m;
  
  private boolean n;
  
  private boolean o;
  
  private boolean p;
  
  private int q;
  
  private int r;
  
  private int s;
  
  private boolean t;
  
  private boolean u;
  
  private boolean v;
  
  private boolean w;
  
  private int x;
  
  private final SparseBooleanArray y = new SparseBooleanArray();
  
  e z;
  
  public c(Context paramContext) {
    super(paramContext, g.c, g.b);
  }
  
  private View z(MenuItem paramMenuItem) {
    ViewGroup viewGroup = (ViewGroup)this.j;
    if (viewGroup == null)
      return null; 
    int j = viewGroup.getChildCount();
    for (int i = 0; i < j; i++) {
      View view = viewGroup.getChildAt(i);
      if (view instanceof k.a && ((k.a)view).getItemData() == paramMenuItem)
        return view; 
    } 
    return null;
  }
  
  public Drawable A() {
    d d1 = this.l;
    return (d1 != null) ? d1.getDrawable() : (this.n ? this.m : null);
  }
  
  public boolean B() {
    c c1 = this.B;
    if (c1 != null) {
      k k = this.j;
      if (k != null) {
        ((View)k).removeCallbacks(c1);
        this.B = null;
        return true;
      } 
    } 
    e e1 = this.z;
    if (e1 != null) {
      e1.b();
      return true;
    } 
    return false;
  }
  
  public boolean C() {
    a a1 = this.A;
    if (a1 != null) {
      a1.b();
      return true;
    } 
    return false;
  }
  
  public boolean D() {
    return (this.B != null || E());
  }
  
  public boolean E() {
    e e1 = this.z;
    return (e1 != null && e1.d());
  }
  
  public void F(Configuration paramConfiguration) {
    if (!this.t)
      this.s = k.a.b(this.c).d(); 
    androidx.appcompat.view.menu.e e1 = this.d;
    if (e1 != null)
      e1.K(true); 
  }
  
  public void G(boolean paramBoolean) {
    this.w = paramBoolean;
  }
  
  public void H(ActionMenuView paramActionMenuView) {
    this.j = paramActionMenuView;
    paramActionMenuView.a(this.d);
  }
  
  public void I(Drawable paramDrawable) {
    d d1 = this.l;
    if (d1 != null) {
      d1.setImageDrawable(paramDrawable);
      return;
    } 
    this.n = true;
    this.m = paramDrawable;
  }
  
  public void J(boolean paramBoolean) {
    this.o = paramBoolean;
    this.p = true;
  }
  
  public boolean K() {
    if (this.o && !E()) {
      androidx.appcompat.view.menu.e e1 = this.d;
      if (e1 != null && this.j != null && this.B == null && !e1.z().isEmpty()) {
        c c1 = new c(this, new e(this, this.c, this.d, (View)this.l, true));
        this.B = c1;
        ((View)this.j).post(c1);
        return true;
      } 
    } 
    return false;
  }
  
  public void b(androidx.appcompat.view.menu.e parame, boolean paramBoolean) {
    y();
    super.b(parame, paramBoolean);
  }
  
  public boolean e(m paramm) {
    boolean bool = paramm.hasVisibleItems();
    boolean bool1 = false;
    if (!bool)
      return false; 
    m m1;
    for (m1 = paramm; m1.e0() != this.d; m1 = (m)m1.e0());
    View view = z(m1.getItem());
    if (view == null)
      return false; 
    this.E = paramm.getItem().getItemId();
    int j = paramm.size();
    int i = 0;
    while (true) {
      bool = bool1;
      if (i < j) {
        MenuItem menuItem = paramm.getItem(i);
        if (menuItem.isVisible() && menuItem.getIcon() != null) {
          bool = true;
          break;
        } 
        i++;
        continue;
      } 
      break;
    } 
    a a1 = new a(this, this.c, paramm, view);
    this.A = a1;
    a1.g(bool);
    this.A.k();
    super.e(paramm);
    return true;
  }
  
  public void f(boolean paramBoolean) {
    super.f(paramBoolean);
    ((View)this.j).requestLayout();
    androidx.appcompat.view.menu.e<g> e1 = this.d;
    byte b1 = 0;
    if (e1 != null) {
      ArrayList<g> arrayList = e1.s();
      int k = arrayList.size();
      for (int j = 0; j < k; j++) {
        b b2 = ((g)arrayList.get(j)).a();
        if (b2 != null)
          b2.i(this); 
      } 
    } 
    e1 = this.d;
    if (e1 != null) {
      ArrayList arrayList = e1.z();
    } else {
      e1 = null;
    } 
    int i = b1;
    if (this.o) {
      i = b1;
      if (e1 != null) {
        int j = e1.size();
        if (j == 1) {
          i = ((g)e1.get(0)).isActionViewExpanded() ^ true;
        } else {
          i = b1;
          if (j > 0)
            i = 1; 
        } 
      } 
    } 
    if (i != 0) {
      if (this.l == null)
        this.l = new d(this, this.b); 
      ViewGroup viewGroup = (ViewGroup)this.l.getParent();
      if (viewGroup != this.j) {
        if (viewGroup != null)
          viewGroup.removeView((View)this.l); 
        viewGroup = (ActionMenuView)this.j;
        viewGroup.addView((View)this.l, (ViewGroup.LayoutParams)viewGroup.B());
      } 
    } else {
      d d1 = this.l;
      if (d1 != null) {
        ViewParent viewParent = d1.getParent();
        k k = this.j;
        if (viewParent == k)
          ((ViewGroup)k).removeView((View)this.l); 
      } 
    } 
    ((ActionMenuView)this.j).setOverflowReserved(this.o);
  }
  
  public boolean g() {
    // Byte code:
    //   0: aload_0
    //   1: astore #18
    //   3: aload #18
    //   5: getfield d : Landroidx/appcompat/view/menu/e;
    //   8: astore #17
    //   10: aload #17
    //   12: ifnull -> 32
    //   15: aload #17
    //   17: invokevirtual E : ()Ljava/util/ArrayList;
    //   20: astore #17
    //   22: aload #17
    //   24: invokevirtual size : ()I
    //   27: istore #4
    //   29: goto -> 38
    //   32: aconst_null
    //   33: astore #17
    //   35: iconst_0
    //   36: istore #4
    //   38: aload #18
    //   40: getfield s : I
    //   43: istore_1
    //   44: aload #18
    //   46: getfield r : I
    //   49: istore #10
    //   51: iconst_0
    //   52: iconst_0
    //   53: invokestatic makeMeasureSpec : (II)I
    //   56: istore #11
    //   58: aload #18
    //   60: getfield j : Landroidx/appcompat/view/menu/k;
    //   63: checkcast android/view/ViewGroup
    //   66: astore #19
    //   68: iconst_0
    //   69: istore_2
    //   70: iconst_0
    //   71: istore #6
    //   73: iconst_0
    //   74: istore_3
    //   75: iconst_0
    //   76: istore #5
    //   78: iload_2
    //   79: iload #4
    //   81: if_icmpge -> 165
    //   84: aload #17
    //   86: iload_2
    //   87: invokevirtual get : (I)Ljava/lang/Object;
    //   90: checkcast androidx/appcompat/view/menu/g
    //   93: astore #20
    //   95: aload #20
    //   97: invokevirtual o : ()Z
    //   100: ifeq -> 110
    //   103: iload_3
    //   104: iconst_1
    //   105: iadd
    //   106: istore_3
    //   107: goto -> 130
    //   110: aload #20
    //   112: invokevirtual n : ()Z
    //   115: ifeq -> 127
    //   118: iload #5
    //   120: iconst_1
    //   121: iadd
    //   122: istore #5
    //   124: goto -> 130
    //   127: iconst_1
    //   128: istore #6
    //   130: iload_1
    //   131: istore #7
    //   133: aload #18
    //   135: getfield w : Z
    //   138: ifeq -> 155
    //   141: iload_1
    //   142: istore #7
    //   144: aload #20
    //   146: invokevirtual isActionViewExpanded : ()Z
    //   149: ifeq -> 155
    //   152: iconst_0
    //   153: istore #7
    //   155: iload_2
    //   156: iconst_1
    //   157: iadd
    //   158: istore_2
    //   159: iload #7
    //   161: istore_1
    //   162: goto -> 78
    //   165: iload_1
    //   166: istore_2
    //   167: aload #18
    //   169: getfield o : Z
    //   172: ifeq -> 194
    //   175: iload #6
    //   177: ifne -> 190
    //   180: iload_1
    //   181: istore_2
    //   182: iload #5
    //   184: iload_3
    //   185: iadd
    //   186: iload_1
    //   187: if_icmple -> 194
    //   190: iload_1
    //   191: iconst_1
    //   192: isub
    //   193: istore_2
    //   194: iload_2
    //   195: iload_3
    //   196: isub
    //   197: istore_1
    //   198: aload #18
    //   200: getfield y : Landroid/util/SparseBooleanArray;
    //   203: astore #20
    //   205: aload #20
    //   207: invokevirtual clear : ()V
    //   210: aload #18
    //   212: getfield u : Z
    //   215: ifeq -> 242
    //   218: aload #18
    //   220: getfield x : I
    //   223: istore_2
    //   224: iload #10
    //   226: iload_2
    //   227: idiv
    //   228: istore_3
    //   229: iload_2
    //   230: iload #10
    //   232: iload_2
    //   233: irem
    //   234: iload_3
    //   235: idiv
    //   236: iadd
    //   237: istore #8
    //   239: goto -> 247
    //   242: iconst_0
    //   243: istore #8
    //   245: iconst_0
    //   246: istore_3
    //   247: iconst_0
    //   248: istore #9
    //   250: iconst_0
    //   251: istore_2
    //   252: iload #10
    //   254: istore #6
    //   256: iload #4
    //   258: istore #10
    //   260: aload_0
    //   261: astore #18
    //   263: iload #9
    //   265: iload #10
    //   267: if_icmpge -> 745
    //   270: aload #17
    //   272: iload #9
    //   274: invokevirtual get : (I)Ljava/lang/Object;
    //   277: checkcast androidx/appcompat/view/menu/g
    //   280: astore #21
    //   282: aload #21
    //   284: invokevirtual o : ()Z
    //   287: ifeq -> 394
    //   290: aload #18
    //   292: aload #21
    //   294: aconst_null
    //   295: aload #19
    //   297: invokevirtual n : (Landroidx/appcompat/view/menu/g;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   300: astore #22
    //   302: aload #18
    //   304: getfield u : Z
    //   307: ifeq -> 327
    //   310: iload_3
    //   311: aload #22
    //   313: iload #8
    //   315: iload_3
    //   316: iload #11
    //   318: iconst_0
    //   319: invokestatic H : (Landroid/view/View;IIII)I
    //   322: isub
    //   323: istore_3
    //   324: goto -> 336
    //   327: aload #22
    //   329: iload #11
    //   331: iload #11
    //   333: invokevirtual measure : (II)V
    //   336: aload #22
    //   338: invokevirtual getMeasuredWidth : ()I
    //   341: istore #5
    //   343: iload #6
    //   345: iload #5
    //   347: isub
    //   348: istore #7
    //   350: iload_2
    //   351: istore #4
    //   353: iload_2
    //   354: ifne -> 361
    //   357: iload #5
    //   359: istore #4
    //   361: aload #21
    //   363: invokevirtual getGroupId : ()I
    //   366: istore_2
    //   367: iload_2
    //   368: ifeq -> 378
    //   371: aload #20
    //   373: iload_2
    //   374: iconst_1
    //   375: invokevirtual put : (IZ)V
    //   378: aload #21
    //   380: iconst_1
    //   381: invokevirtual u : (Z)V
    //   384: iload #7
    //   386: istore #6
    //   388: iload #4
    //   390: istore_2
    //   391: goto -> 736
    //   394: aload #21
    //   396: invokevirtual n : ()Z
    //   399: ifeq -> 730
    //   402: aload #21
    //   404: invokevirtual getGroupId : ()I
    //   407: istore #12
    //   409: aload #20
    //   411: iload #12
    //   413: invokevirtual get : (I)Z
    //   416: istore #16
    //   418: iload_1
    //   419: ifgt -> 427
    //   422: iload #16
    //   424: ifeq -> 450
    //   427: iload #6
    //   429: ifle -> 450
    //   432: aload #18
    //   434: getfield u : Z
    //   437: ifeq -> 444
    //   440: iload_3
    //   441: ifle -> 450
    //   444: iconst_1
    //   445: istore #13
    //   447: goto -> 453
    //   450: iconst_0
    //   451: istore #13
    //   453: iload #13
    //   455: istore #14
    //   457: iload #13
    //   459: istore #15
    //   461: iload #6
    //   463: istore #7
    //   465: iload_3
    //   466: istore #5
    //   468: iload_2
    //   469: istore #4
    //   471: iload #13
    //   473: ifeq -> 606
    //   476: aload #18
    //   478: aload #21
    //   480: aconst_null
    //   481: aload #19
    //   483: invokevirtual n : (Landroidx/appcompat/view/menu/g;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   486: astore #22
    //   488: aload #18
    //   490: getfield u : Z
    //   493: ifeq -> 532
    //   496: aload #22
    //   498: iload #8
    //   500: iload_3
    //   501: iload #11
    //   503: iconst_0
    //   504: invokestatic H : (Landroid/view/View;IIII)I
    //   507: istore #5
    //   509: iload_3
    //   510: iload #5
    //   512: isub
    //   513: istore #4
    //   515: iload #4
    //   517: istore_3
    //   518: iload #5
    //   520: ifne -> 541
    //   523: iconst_0
    //   524: istore #14
    //   526: iload #4
    //   528: istore_3
    //   529: goto -> 541
    //   532: aload #22
    //   534: iload #11
    //   536: iload #11
    //   538: invokevirtual measure : (II)V
    //   541: aload #22
    //   543: invokevirtual getMeasuredWidth : ()I
    //   546: istore #5
    //   548: iload #6
    //   550: iload #5
    //   552: isub
    //   553: istore #7
    //   555: iload_2
    //   556: istore #4
    //   558: iload_2
    //   559: ifne -> 566
    //   562: iload #5
    //   564: istore #4
    //   566: aload #18
    //   568: getfield u : Z
    //   571: ifeq -> 582
    //   574: iload #7
    //   576: iflt -> 595
    //   579: goto -> 590
    //   582: iload #7
    //   584: iload #4
    //   586: iadd
    //   587: ifle -> 595
    //   590: iconst_1
    //   591: istore_2
    //   592: goto -> 597
    //   595: iconst_0
    //   596: istore_2
    //   597: iload #14
    //   599: iload_2
    //   600: iand
    //   601: istore #15
    //   603: iload_3
    //   604: istore #5
    //   606: iload #15
    //   608: ifeq -> 629
    //   611: iload #12
    //   613: ifeq -> 629
    //   616: aload #20
    //   618: iload #12
    //   620: iconst_1
    //   621: invokevirtual put : (IZ)V
    //   624: iload_1
    //   625: istore_2
    //   626: goto -> 706
    //   629: iload_1
    //   630: istore_2
    //   631: iload #16
    //   633: ifeq -> 706
    //   636: aload #20
    //   638: iload #12
    //   640: iconst_0
    //   641: invokevirtual put : (IZ)V
    //   644: iconst_0
    //   645: istore_3
    //   646: iload_1
    //   647: istore_2
    //   648: iload_3
    //   649: iload #9
    //   651: if_icmpge -> 706
    //   654: aload #17
    //   656: iload_3
    //   657: invokevirtual get : (I)Ljava/lang/Object;
    //   660: checkcast androidx/appcompat/view/menu/g
    //   663: astore #18
    //   665: iload_1
    //   666: istore_2
    //   667: aload #18
    //   669: invokevirtual getGroupId : ()I
    //   672: iload #12
    //   674: if_icmpne -> 697
    //   677: iload_1
    //   678: istore_2
    //   679: aload #18
    //   681: invokevirtual l : ()Z
    //   684: ifeq -> 691
    //   687: iload_1
    //   688: iconst_1
    //   689: iadd
    //   690: istore_2
    //   691: aload #18
    //   693: iconst_0
    //   694: invokevirtual u : (Z)V
    //   697: iload_3
    //   698: iconst_1
    //   699: iadd
    //   700: istore_3
    //   701: iload_2
    //   702: istore_1
    //   703: goto -> 646
    //   706: iload_2
    //   707: istore_1
    //   708: iload #15
    //   710: ifeq -> 717
    //   713: iload_2
    //   714: iconst_1
    //   715: isub
    //   716: istore_1
    //   717: aload #21
    //   719: iload #15
    //   721: invokevirtual u : (Z)V
    //   724: iload #5
    //   726: istore_3
    //   727: goto -> 384
    //   730: aload #21
    //   732: iconst_0
    //   733: invokevirtual u : (Z)V
    //   736: iload #9
    //   738: iconst_1
    //   739: iadd
    //   740: istore #9
    //   742: goto -> 260
    //   745: iconst_1
    //   746: ireturn
  }
  
  public void i(@NonNull Context paramContext, @Nullable androidx.appcompat.view.menu.e parame) {
    super.i(paramContext, parame);
    Resources resources = paramContext.getResources();
    k.a a1 = k.a.b(paramContext);
    if (!this.p)
      this.o = a1.h(); 
    if (!this.v)
      this.q = a1.c(); 
    if (!this.t)
      this.s = a1.d(); 
    int i = this.q;
    if (this.o) {
      if (this.l == null) {
        d d1 = new d(this, this.b);
        this.l = d1;
        if (this.n) {
          d1.setImageDrawable(this.m);
          this.m = null;
          this.n = false;
        } 
        int j = View.MeasureSpec.makeMeasureSpec(0, 0);
        this.l.measure(j, j);
      } 
      i -= this.l.getMeasuredWidth();
    } else {
      this.l = null;
    } 
    this.r = i;
    this.x = (int)((resources.getDisplayMetrics()).density * 56.0F);
  }
  
  public void j(g paramg, k.a parama) {
    parama.c(paramg, 0);
    ActionMenuView actionMenuView = (ActionMenuView)this.j;
    ActionMenuItemView actionMenuItemView = (ActionMenuItemView)parama;
    actionMenuItemView.setItemInvoker(actionMenuView);
    if (this.C == null)
      this.C = new b(this); 
    actionMenuItemView.setPopupCallback(this.C);
  }
  
  public boolean l(ViewGroup paramViewGroup, int paramInt) {
    return (paramViewGroup.getChildAt(paramInt) == this.l) ? false : super.l(paramViewGroup, paramInt);
  }
  
  public View n(g paramg, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = paramg.getActionView();
    if (view == null || paramg.j())
      view = super.n(paramg, paramView, paramViewGroup); 
    if (paramg.isActionViewExpanded()) {
      bool = true;
    } else {
      bool = false;
    } 
    view.setVisibility(bool);
    ActionMenuView actionMenuView = (ActionMenuView)paramViewGroup;
    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
    if (!actionMenuView.checkLayoutParams(layoutParams))
      view.setLayoutParams((ViewGroup.LayoutParams)actionMenuView.A(layoutParams)); 
    return view;
  }
  
  public k o(ViewGroup paramViewGroup) {
    k k2 = this.j;
    k k1 = super.o(paramViewGroup);
    if (k2 != k1)
      ((ActionMenuView)k1).setPresenter(this); 
    return k1;
  }
  
  public boolean q(int paramInt, g paramg) {
    return paramg.l();
  }
  
  public boolean y() {
    return B() | C();
  }
  
  private class a extends i {
    public a(c this$0, Context param1Context, m param1m, View param1View) {
      super(param1Context, (androidx.appcompat.view.menu.e)param1m, param1View, false, f.a.l);
      if (!((g)param1m.getItem()).l()) {
        View view;
        c.d d2 = this$0.l;
        c.d d1 = d2;
        if (d2 == null)
          view = (View)c.t(this$0); 
        f(view);
      } 
      j(this$0.D);
    }
    
    protected void e() {
      c c1 = this.m;
      c1.A = null;
      c1.E = 0;
      super.e();
    }
  }
  
  private class b extends ActionMenuItemView.b {
    b(c this$0) {}
    
    public l.e a() {
      c.a a = this.a.A;
      return (l.e)((a != null) ? a.c() : null);
    }
  }
  
  private class c implements Runnable {
    private c.e b;
    
    public c(c this$0, c.e param1e) {
      this.b = param1e;
    }
    
    public void run() {
      if (c.v(this.c) != null)
        c.w(this.c).d(); 
      View view = (View)c.x(this.c);
      if (view != null && view.getWindowToken() != null && this.b.m())
        this.c.z = this.b; 
      this.c.B = null;
    }
  }
  
  private class d extends AppCompatImageView implements ActionMenuView.a {
    public d(c this$0, Context param1Context) {
      super(param1Context, null, f.a.k);
      setClickable(true);
      setFocusable(true);
      setVisibility(0);
      setEnabled(true);
      m1.a((View)this, getContentDescription());
      setOnTouchListener(new a(this, (View)this, this$0));
    }
    
    public boolean a() {
      return false;
    }
    
    public boolean b() {
      return false;
    }
    
    public boolean performClick() {
      if (super.performClick())
        return true; 
      playSoundEffect(0);
      this.b.K();
      return true;
    }
    
    protected boolean setFrame(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      boolean bool = super.setFrame(param1Int1, param1Int2, param1Int3, param1Int4);
      Drawable drawable1 = getDrawable();
      Drawable drawable2 = getBackground();
      if (drawable1 != null && drawable2 != null) {
        int i = getWidth();
        param1Int2 = getHeight();
        param1Int1 = Math.max(i, param1Int2) / 2;
        int j = getPaddingLeft();
        int k = getPaddingRight();
        param1Int3 = getPaddingTop();
        param1Int4 = getPaddingBottom();
        i = (i + j - k) / 2;
        param1Int2 = (param1Int2 + param1Int3 - param1Int4) / 2;
        androidx.core.graphics.drawable.a.k(drawable2, i - param1Int1, param1Int2 - param1Int1, i + param1Int1, param1Int2 + param1Int1);
      } 
      return bool;
    }
    
    class a extends o0 {
      a(c.d this$0, View param2View, c param2c) {
        super(param2View);
      }
      
      public l.e b() {
        c.e e = this.l.b.z;
        return (l.e)((e == null) ? null : e.c());
      }
      
      public boolean c() {
        this.l.b.K();
        return true;
      }
      
      public boolean d() {
        c c1 = this.l.b;
        if (c1.B != null)
          return false; 
        c1.B();
        return true;
      }
    }
  }
  
  class a extends o0 {
    a(c this$0, View param1View, c param1c) {
      super(param1View);
    }
    
    public l.e b() {
      c.e e = this.l.b.z;
      return (l.e)((e == null) ? null : e.c());
    }
    
    public boolean c() {
      this.l.b.K();
      return true;
    }
    
    public boolean d() {
      c c1 = this.l.b;
      if (c1.B != null)
        return false; 
      c1.B();
      return true;
    }
  }
  
  private class e extends i {
    public e(c this$0, Context param1Context, androidx.appcompat.view.menu.e param1e, View param1View, boolean param1Boolean) {
      super(param1Context, param1e, param1View, param1Boolean, f.a.l);
      h(8388613);
      j(this$0.D);
    }
    
    protected void e() {
      if (c.r(this.m) != null)
        c.s(this.m).close(); 
      this.m.z = null;
      super.e();
    }
  }
  
  private class f implements j.a {
    f(c this$0) {}
    
    public void b(@NonNull androidx.appcompat.view.menu.e param1e, boolean param1Boolean) {
      if (param1e instanceof m)
        param1e.D().e(false); 
      j.a a1 = this.b.m();
      if (a1 != null)
        a1.b(param1e, param1Boolean); 
    }
    
    public boolean c(@NonNull androidx.appcompat.view.menu.e param1e) {
      androidx.appcompat.view.menu.e e1 = c.u(this.b);
      boolean bool = false;
      if (param1e == e1)
        return false; 
      this.b.E = ((m)param1e).getItem().getItemId();
      j.a a1 = this.b.m();
      if (a1 != null)
        bool = a1.c(param1e); 
      return bool;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */