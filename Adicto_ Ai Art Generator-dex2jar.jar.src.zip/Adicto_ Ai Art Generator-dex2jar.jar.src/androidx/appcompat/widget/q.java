package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.annotation.Nullable;
import f.a;
import h.b;

public class q extends RadioButton {
  private final h b;
  
  private final e c;
  
  private final c0 d;
  
  public q(Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.E);
  }
  
  public q(Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt) {
    super(g1.b(paramContext), paramAttributeSet, paramInt);
    e1.a((View)this, getContext());
    h h1 = new h((CompoundButton)this);
    this.b = h1;
    h1.e(paramAttributeSet, paramInt);
    e e1 = new e((View)this);
    this.c = e1;
    e1.e(paramAttributeSet, paramInt);
    c0 c01 = new c0((TextView)this);
    this.d = c01;
    c01.m(paramAttributeSet, paramInt);
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.c;
    if (e1 != null)
      e1.b(); 
    c0 c01 = this.d;
    if (c01 != null)
      c01.b(); 
  }
  
  public int getCompoundPaddingLeft() {
    int j = super.getCompoundPaddingLeft();
    h h1 = this.b;
    int i = j;
    if (h1 != null)
      i = h1.b(j); 
    return i;
  }
  
  @Nullable
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.c;
    return (e1 != null) ? e1.c() : null;
  }
  
  @Nullable
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.c;
    return (e1 != null) ? e1.d() : null;
  }
  
  @Nullable
  public ColorStateList getSupportButtonTintList() {
    h h1 = this.b;
    return (h1 != null) ? h1.c() : null;
  }
  
  @Nullable
  public PorterDuff.Mode getSupportButtonTintMode() {
    h h1 = this.b;
    return (h1 != null) ? h1.d() : null;
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.c;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.c;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setButtonDrawable(int paramInt) {
    setButtonDrawable(b.d(getContext(), paramInt));
  }
  
  public void setButtonDrawable(Drawable paramDrawable) {
    super.setButtonDrawable(paramDrawable);
    h h1 = this.b;
    if (h1 != null)
      h1.f(); 
  }
  
  public void setSupportBackgroundTintList(@Nullable ColorStateList paramColorStateList) {
    e e1 = this.c;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(@Nullable PorterDuff.Mode paramMode) {
    e e1 = this.c;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  public void setSupportButtonTintList(@Nullable ColorStateList paramColorStateList) {
    h h1 = this.b;
    if (h1 != null)
      h1.g(paramColorStateList); 
  }
  
  public void setSupportButtonTintMode(@Nullable PorterDuff.Mode paramMode) {
    h h1 = this.b;
    if (h1 != null)
      h1.h(paramMode); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */