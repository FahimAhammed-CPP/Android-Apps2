package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.transition.Transition;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.view.menu.ListMenuItemView;
import androidx.appcompat.view.menu.d;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.g;
import java.lang.reflect.Method;

public class y0 extends t0 implements u0 {
  private static Method L;
  
  private u0 K;
  
  static {
    try {
      if (Build.VERSION.SDK_INT <= 28) {
        L = PopupWindow.class.getDeclaredMethod("setTouchModal", new Class[] { boolean.class });
        return;
      } 
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
    } 
  }
  
  public y0(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
  }
  
  public void M(Object paramObject) {
    if (Build.VERSION.SDK_INT >= 23)
      x0.a(this.G, (Transition)paramObject); 
  }
  
  public void N(Object paramObject) {
    if (Build.VERSION.SDK_INT >= 23)
      w0.a(this.G, (Transition)paramObject); 
  }
  
  public void O(u0 paramu0) {
    this.K = paramu0;
  }
  
  public void P(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = L;
      if (method != null)
        try {
          method.invoke(this.G, new Object[] { Boolean.valueOf(paramBoolean) });
          return;
        } catch (Exception exception) {
          Log.i("MenuPopupWindow", "Could not invoke setTouchModal() on PopupWindow. Oh well.");
          return;
        }  
    } else {
      v0.a(this.G, paramBoolean);
    } 
  }
  
  public void c(@NonNull e parame, @NonNull MenuItem paramMenuItem) {
    u0 u01 = this.K;
    if (u01 != null)
      u01.c(parame, paramMenuItem); 
  }
  
  public void m(@NonNull e parame, @NonNull MenuItem paramMenuItem) {
    u0 u01 = this.K;
    if (u01 != null)
      u01.m(parame, paramMenuItem); 
  }
  
  @NonNull
  m0 r(Context paramContext, boolean paramBoolean) {
    a a = new a(paramContext, paramBoolean);
    a.setHoverListener(this);
    return a;
  }
  
  public static class a extends m0 {
    final int p;
    
    final int q;
    
    private u0 r;
    
    private MenuItem s;
    
    public a(Context param1Context, boolean param1Boolean) {
      super(param1Context, param1Boolean);
      if (1 == param1Context.getResources().getConfiguration().getLayoutDirection()) {
        this.p = 21;
        this.q = 22;
        return;
      } 
      this.p = 22;
      this.q = 21;
    }
    
    public boolean onHoverEvent(MotionEvent param1MotionEvent) {
      if (this.r != null) {
        int i;
        d d;
        ListAdapter listAdapter = getAdapter();
        if (listAdapter instanceof HeaderViewListAdapter) {
          HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter)listAdapter;
          i = headerViewListAdapter.getHeadersCount();
          d = (d)headerViewListAdapter.getWrappedAdapter();
        } else {
          i = 0;
          d = d;
        } 
        g g2 = null;
        g g1 = g2;
        if (param1MotionEvent.getAction() != 10) {
          int j = pointToPosition((int)param1MotionEvent.getX(), (int)param1MotionEvent.getY());
          g1 = g2;
          if (j != -1) {
            i = j - i;
            g1 = g2;
            if (i >= 0) {
              g1 = g2;
              if (i < d.getCount())
                g1 = d.c(i); 
            } 
          } 
        } 
        MenuItem menuItem = this.s;
        if (menuItem != g1) {
          e e = d.b();
          if (menuItem != null)
            this.r.m(e, menuItem); 
          this.s = (MenuItem)g1;
          if (g1 != null)
            this.r.c(e, (MenuItem)g1); 
        } 
      } 
      return super.onHoverEvent(param1MotionEvent);
    }
    
    public boolean onKeyDown(int param1Int, KeyEvent param1KeyEvent) {
      ListMenuItemView listMenuItemView = (ListMenuItemView)getSelectedView();
      if (listMenuItemView != null && param1Int == this.p) {
        if (listMenuItemView.isEnabled() && listMenuItemView.getItemData().hasSubMenu())
          performItemClick((View)listMenuItemView, getSelectedItemPosition(), getSelectedItemId()); 
        return true;
      } 
      if (listMenuItemView != null && param1Int == this.q) {
        setSelection(-1);
        ((d)getAdapter()).b().e(false);
        return true;
      } 
      return super.onKeyDown(param1Int, param1KeyEvent);
    }
    
    public void setHoverListener(u0 param1u0) {
      this.r = param1u0;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\y0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */