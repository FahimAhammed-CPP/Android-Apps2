package androidx.appcompat.widget;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Resources;
import androidx.annotation.NonNull;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class g1 extends ContextWrapper {
  private static final Object c = new Object();
  
  private static ArrayList<WeakReference<g1>> d;
  
  private final Resources a;
  
  private final Resources.Theme b;
  
  private g1(@NonNull Context paramContext) {
    super(paramContext);
    if (p1.b()) {
      p1 p1 = new p1((Context)this, paramContext.getResources());
      this.a = p1;
      Resources.Theme theme = p1.newTheme();
      this.b = theme;
      theme.setTo(paramContext.getTheme());
      return;
    } 
    this.a = new i1((Context)this, paramContext.getResources());
    this.b = null;
  }
  
  private static boolean a(@NonNull Context paramContext) {
    boolean bool = paramContext instanceof g1;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (!bool) {
      bool1 = bool2;
      if (!(paramContext.getResources() instanceof i1)) {
        if (paramContext.getResources() instanceof p1)
          return false; 
        bool1 = bool2;
        if (p1.b())
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public static Context b(@NonNull Context paramContext) {
    if (a(paramContext))
      synchronized (c) {
        ArrayList<WeakReference<g1>> arrayList = d;
        if (arrayList == null) {
          d = new ArrayList<WeakReference<g1>>();
        } else {
          for (int i = arrayList.size() - 1;; i--) {
            if (i >= 0) {
              WeakReference weakReference = d.get(i);
              if (weakReference == null || weakReference.get() == null)
                d.remove(i); 
            } else {
              for (i = d.size() - 1;; i--) {
                if (i >= 0) {
                  WeakReference<g1> weakReference = d.get(i);
                  if (weakReference != null) {
                    g1 g12 = weakReference.get();
                  } else {
                    weakReference = null;
                  } 
                  if (weakReference != null && weakReference.getBaseContext() == paramContext)
                    return (Context)weakReference; 
                } else {
                  g11 = new g1(paramContext);
                  d.add(new WeakReference<g1>(g11));
                  return (Context)g11;
                } 
              } 
            } 
          } 
          i--;
        } 
        g1 g11 = new g1((Context)g11);
        d.add(new WeakReference<g1>(g11));
        return (Context)g11;
      }  
    return paramContext;
  }
  
  public AssetManager getAssets() {
    return this.a.getAssets();
  }
  
  public Resources getResources() {
    return this.a;
  }
  
  public Resources.Theme getTheme() {
    Resources.Theme theme2 = this.b;
    Resources.Theme theme1 = theme2;
    if (theme2 == null)
      theme1 = super.getTheme(); 
    return theme1;
  }
  
  public void setTheme(int paramInt) {
    Resources.Theme theme = this.b;
    if (theme == null) {
      super.setTheme(paramInt);
      return;
    } 
    theme.applyStyle(paramInt, true);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\g1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */