package androidx.appcompat.widget;

import android.view.textclassifier.TextClassificationManager;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.util.e;
import g.e;

final class v {
  @NonNull
  private TextView a;
  
  @Nullable
  private TextClassifier b;
  
  v(@NonNull TextView paramTextView) {
    this.a = (TextView)e.d(paramTextView);
  }
  
  @NonNull
  @RequiresApi(api = 26)
  public TextClassifier a() {
    TextClassifier textClassifier2 = this.b;
    TextClassifier textClassifier1 = textClassifier2;
    if (textClassifier2 == null) {
      TextClassificationManager textClassificationManager = (TextClassificationManager)e.a(this.a.getContext(), TextClassificationManager.class);
      if (textClassificationManager != null)
        return textClassificationManager.getTextClassifier(); 
      textClassifier1 = TextClassifier.NO_OP;
    } 
    return textClassifier1;
  }
  
  @RequiresApi(api = 26)
  public void b(@Nullable TextClassifier paramTextClassifier) {
    this.b = paramTextClassifier;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */