package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.graphics.d;
import androidx.core.text.d;
import androidx.core.widget.a0;
import androidx.core.widget.b;
import androidx.core.widget.p;
import h.b;
import java.util.concurrent.Future;

public class AppCompatTextView extends TextView implements a0, b {
  private final e mBackgroundTintHelper;
  
  @Nullable
  private Future<d> mPrecomputedTextFuture;
  
  private final v mTextClassifierHelper;
  
  private final c0 mTextHelper;
  
  public AppCompatTextView(@NonNull Context paramContext) {
    this(paramContext, null);
  }
  
  public AppCompatTextView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16842884);
  }
  
  public AppCompatTextView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt) {
    super(g1.b(paramContext), paramAttributeSet, paramInt);
    e1.a((View)this, getContext());
    e e1 = new e((View)this);
    this.mBackgroundTintHelper = e1;
    e1.e(paramAttributeSet, paramInt);
    c0 c01 = new c0(this);
    this.mTextHelper = c01;
    c01.m(paramAttributeSet, paramInt);
    c01.b();
    this.mTextClassifierHelper = new v(this);
  }
  
  private void consumeTextFutureAndSetBlocking() {
    Future<d> future = this.mPrecomputedTextFuture;
    if (future != null)
      try {
        this.mPrecomputedTextFuture = null;
        p.k(this, future.get());
        return;
      } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {
        return;
      }  
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.mBackgroundTintHelper;
    if (e1 != null)
      e1.b(); 
    c0 c01 = this.mTextHelper;
    if (c01 != null)
      c01.b(); 
  }
  
  public int getAutoSizeMaxTextSize() {
    if (b.a0)
      return super.getAutoSizeMaxTextSize(); 
    c0 c01 = this.mTextHelper;
    return (c01 != null) ? c01.e() : -1;
  }
  
  public int getAutoSizeMinTextSize() {
    if (b.a0)
      return super.getAutoSizeMinTextSize(); 
    c0 c01 = this.mTextHelper;
    return (c01 != null) ? c01.f() : -1;
  }
  
  public int getAutoSizeStepGranularity() {
    if (b.a0)
      return super.getAutoSizeStepGranularity(); 
    c0 c01 = this.mTextHelper;
    return (c01 != null) ? c01.g() : -1;
  }
  
  public int[] getAutoSizeTextAvailableSizes() {
    if (b.a0)
      return super.getAutoSizeTextAvailableSizes(); 
    c0 c01 = this.mTextHelper;
    return (c01 != null) ? c01.h() : new int[0];
  }
  
  public int getAutoSizeTextType() {
    boolean bool1 = b.a0;
    boolean bool = false;
    if (bool1) {
      if (super.getAutoSizeTextType() == 1)
        bool = true; 
      return bool;
    } 
    c0 c01 = this.mTextHelper;
    return (c01 != null) ? c01.i() : 0;
  }
  
  public int getFirstBaselineToTopHeight() {
    return p.a(this);
  }
  
  public int getLastBaselineToBottomHeight() {
    return p.b(this);
  }
  
  @Nullable
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.mBackgroundTintHelper;
    return (e1 != null) ? e1.c() : null;
  }
  
  @Nullable
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.mBackgroundTintHelper;
    return (e1 != null) ? e1.d() : null;
  }
  
  @Nullable
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.mTextHelper.j();
  }
  
  @Nullable
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.mTextHelper.k();
  }
  
  public CharSequence getText() {
    consumeTextFutureAndSetBlocking();
    return super.getText();
  }
  
  @NonNull
  @RequiresApi(api = 26)
  public TextClassifier getTextClassifier() {
    if (Build.VERSION.SDK_INT < 28) {
      v v1 = this.mTextClassifierHelper;
      if (v1 != null)
        return v1.a(); 
    } 
    return super.getTextClassifier();
  }
  
  @NonNull
  public d.a getTextMetricsParamsCompat() {
    return p.e(this);
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    return k.a(super.onCreateInputConnection(paramEditorInfo), paramEditorInfo, (View)this);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    c0 c01 = this.mTextHelper;
    if (c01 != null)
      c01.o(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    consumeTextFutureAndSetBlocking();
    super.onMeasure(paramInt1, paramInt2);
  }
  
  protected void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    c0 c01 = this.mTextHelper;
    if (c01 != null && !b.a0 && c01.l())
      this.mTextHelper.c(); 
  }
  
  public void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws IllegalArgumentException {
    if (b.a0) {
      super.setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    c0 c01 = this.mTextHelper;
    if (c01 != null)
      c01.s(paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void setAutoSizeTextTypeUniformWithPresetSizes(@NonNull int[] paramArrayOfint, int paramInt) throws IllegalArgumentException {
    if (b.a0) {
      super.setAutoSizeTextTypeUniformWithPresetSizes(paramArrayOfint, paramInt);
      return;
    } 
    c0 c01 = this.mTextHelper;
    if (c01 != null)
      c01.t(paramArrayOfint, paramInt); 
  }
  
  public void setAutoSizeTextTypeWithDefaults(int paramInt) {
    if (b.a0) {
      super.setAutoSizeTextTypeWithDefaults(paramInt);
      return;
    } 
    c0 c01 = this.mTextHelper;
    if (c01 != null)
      c01.u(paramInt); 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.mBackgroundTintHelper;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.mBackgroundTintHelper;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setCompoundDrawables(@Nullable Drawable paramDrawable1, @Nullable Drawable paramDrawable2, @Nullable Drawable paramDrawable3, @Nullable Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    c0 c01 = this.mTextHelper;
    if (c01 != null)
      c01.p(); 
  }
  
  @RequiresApi(17)
  public void setCompoundDrawablesRelative(@Nullable Drawable paramDrawable1, @Nullable Drawable paramDrawable2, @Nullable Drawable paramDrawable3, @Nullable Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    c0 c01 = this.mTextHelper;
    if (c01 != null)
      c01.p(); 
  }
  
  @RequiresApi(17)
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Drawable drawable1;
    Drawable drawable2;
    Drawable drawable3;
    Context context = getContext();
    Drawable drawable4 = null;
    if (paramInt1 != 0) {
      drawable1 = b.d(context, paramInt1);
    } else {
      drawable1 = null;
    } 
    if (paramInt2 != 0) {
      drawable2 = b.d(context, paramInt2);
    } else {
      drawable2 = null;
    } 
    if (paramInt3 != 0) {
      drawable3 = b.d(context, paramInt3);
    } else {
      drawable3 = null;
    } 
    if (paramInt4 != 0)
      drawable4 = b.d(context, paramInt4); 
    setCompoundDrawablesRelativeWithIntrinsicBounds(drawable1, drawable2, drawable3, drawable4);
    c0 c01 = this.mTextHelper;
    if (c01 != null)
      c01.p(); 
  }
  
  @RequiresApi(17)
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(@Nullable Drawable paramDrawable1, @Nullable Drawable paramDrawable2, @Nullable Drawable paramDrawable3, @Nullable Drawable paramDrawable4) {
    super.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    c0 c01 = this.mTextHelper;
    if (c01 != null)
      c01.p(); 
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Drawable drawable1;
    Drawable drawable2;
    Drawable drawable3;
    Context context = getContext();
    Drawable drawable4 = null;
    if (paramInt1 != 0) {
      drawable1 = b.d(context, paramInt1);
    } else {
      drawable1 = null;
    } 
    if (paramInt2 != 0) {
      drawable2 = b.d(context, paramInt2);
    } else {
      drawable2 = null;
    } 
    if (paramInt3 != 0) {
      drawable3 = b.d(context, paramInt3);
    } else {
      drawable3 = null;
    } 
    if (paramInt4 != 0)
      drawable4 = b.d(context, paramInt4); 
    setCompoundDrawablesWithIntrinsicBounds(drawable1, drawable2, drawable3, drawable4);
    c0 c01 = this.mTextHelper;
    if (c01 != null)
      c01.p(); 
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(@Nullable Drawable paramDrawable1, @Nullable Drawable paramDrawable2, @Nullable Drawable paramDrawable3, @Nullable Drawable paramDrawable4) {
    super.setCompoundDrawablesWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    c0 c01 = this.mTextHelper;
    if (c01 != null)
      c01.p(); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(p.m(this, paramCallback));
  }
  
  public void setFirstBaselineToTopHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      super.setFirstBaselineToTopHeight(paramInt);
      return;
    } 
    p.h(this, paramInt);
  }
  
  public void setLastBaselineToBottomHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      super.setLastBaselineToBottomHeight(paramInt);
      return;
    } 
    p.i(this, paramInt);
  }
  
  public void setLineHeight(int paramInt) {
    p.j(this, paramInt);
  }
  
  public void setPrecomputedText(@NonNull d paramd) {
    p.k(this, paramd);
  }
  
  public void setSupportBackgroundTintList(@Nullable ColorStateList paramColorStateList) {
    e e1 = this.mBackgroundTintHelper;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(@Nullable PorterDuff.Mode paramMode) {
    e e1 = this.mBackgroundTintHelper;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(@Nullable ColorStateList paramColorStateList) {
    this.mTextHelper.v(paramColorStateList);
    this.mTextHelper.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(@Nullable PorterDuff.Mode paramMode) {
    this.mTextHelper.w(paramMode);
    this.mTextHelper.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    c0 c01 = this.mTextHelper;
    if (c01 != null)
      c01.q(paramContext, paramInt); 
  }
  
  @RequiresApi(api = 26)
  public void setTextClassifier(@Nullable TextClassifier paramTextClassifier) {
    if (Build.VERSION.SDK_INT < 28) {
      v v1 = this.mTextClassifierHelper;
      if (v1 != null) {
        v1.b(paramTextClassifier);
        return;
      } 
    } 
    super.setTextClassifier(paramTextClassifier);
  }
  
  public void setTextFuture(@Nullable Future<d> paramFuture) {
    this.mPrecomputedTextFuture = paramFuture;
    if (paramFuture != null)
      requestLayout(); 
  }
  
  public void setTextMetricsParamsCompat(@NonNull d.a parama) {
    p.l(this, parama);
  }
  
  public void setTextSize(int paramInt, float paramFloat) {
    if (b.a0) {
      super.setTextSize(paramInt, paramFloat);
      return;
    } 
    c0 c01 = this.mTextHelper;
    if (c01 != null)
      c01.z(paramInt, paramFloat); 
  }
  
  public void setTypeface(@Nullable Typeface paramTypeface, int paramInt) {
    Typeface typeface;
    if (paramTypeface != null && paramInt > 0) {
      typeface = d.a(getContext(), paramTypeface, paramInt);
    } else {
      typeface = null;
    } 
    if (typeface != null)
      paramTypeface = typeface; 
    super.setTypeface(paramTypeface, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\AppCompatTextView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */