package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.j;
import androidx.core.view.ViewCompat;
import androidx.core.view.l2;
import androidx.core.view.m2;
import androidx.core.view.n2;
import f.e;
import f.f;
import f.h;
import f.j;

public class k1 implements k0 {
  Toolbar a;
  
  private int b;
  
  private View c;
  
  private View d;
  
  private Drawable e;
  
  private Drawable f;
  
  private Drawable g;
  
  private boolean h;
  
  CharSequence i;
  
  private CharSequence j;
  
  private CharSequence k;
  
  Window.Callback l;
  
  boolean m;
  
  private c n;
  
  private int o;
  
  private int p;
  
  private Drawable q;
  
  public k1(Toolbar paramToolbar, boolean paramBoolean) {
    this(paramToolbar, paramBoolean, h.a, e.n);
  }
  
  public k1(Toolbar paramToolbar, boolean paramBoolean, int paramInt1, int paramInt2) {
    boolean bool;
    this.o = 0;
    this.p = 0;
    this.a = paramToolbar;
    this.i = paramToolbar.getTitle();
    this.j = paramToolbar.getSubtitle();
    if (this.i != null) {
      bool = true;
    } else {
      bool = false;
    } 
    this.h = bool;
    this.g = paramToolbar.getNavigationIcon();
    j1 j1 = j1.u(paramToolbar.getContext(), null, j.a, f.a.c, 0);
    this.q = j1.f(j.l);
    if (paramBoolean) {
      CharSequence charSequence = j1.o(j.r);
      if (!TextUtils.isEmpty(charSequence))
        D(charSequence); 
      charSequence = j1.o(j.p);
      if (!TextUtils.isEmpty(charSequence))
        C(charSequence); 
      Drawable drawable = j1.f(j.n);
      if (drawable != null)
        y(drawable); 
      drawable = j1.f(j.m);
      if (drawable != null)
        setIcon(drawable); 
      if (this.g == null) {
        drawable = this.q;
        if (drawable != null)
          B(drawable); 
      } 
      i(j1.j(j.h, 0));
      paramInt2 = j1.m(j.g, 0);
      if (paramInt2 != 0) {
        w(LayoutInflater.from(this.a.getContext()).inflate(paramInt2, this.a, false));
        i(this.b | 0x10);
      } 
      paramInt2 = j1.l(j.j, 0);
      if (paramInt2 > 0) {
        ViewGroup.LayoutParams layoutParams = this.a.getLayoutParams();
        layoutParams.height = paramInt2;
        this.a.setLayoutParams(layoutParams);
      } 
      paramInt2 = j1.d(j.f, -1);
      int i = j1.d(j.e, -1);
      if (paramInt2 >= 0 || i >= 0)
        this.a.H(Math.max(paramInt2, 0), Math.max(i, 0)); 
      paramInt2 = j1.m(j.s, 0);
      if (paramInt2 != 0) {
        Toolbar toolbar = this.a;
        toolbar.K(toolbar.getContext(), paramInt2);
      } 
      paramInt2 = j1.m(j.q, 0);
      if (paramInt2 != 0) {
        Toolbar toolbar = this.a;
        toolbar.J(toolbar.getContext(), paramInt2);
      } 
      paramInt2 = j1.m(j.o, 0);
      if (paramInt2 != 0)
        this.a.setPopupTheme(paramInt2); 
    } else {
      this.b = v();
    } 
    j1.v();
    x(paramInt1);
    this.k = this.a.getNavigationContentDescription();
    this.a.setNavigationOnClickListener(new a(this));
  }
  
  private void E(CharSequence paramCharSequence) {
    this.i = paramCharSequence;
    if ((this.b & 0x8) != 0)
      this.a.setTitle(paramCharSequence); 
  }
  
  private void F() {
    if ((this.b & 0x4) != 0) {
      if (TextUtils.isEmpty(this.k)) {
        this.a.setNavigationContentDescription(this.p);
        return;
      } 
      this.a.setNavigationContentDescription(this.k);
    } 
  }
  
  private void G() {
    if ((this.b & 0x4) != 0) {
      Toolbar toolbar = this.a;
      Drawable drawable = this.g;
      if (drawable == null)
        drawable = this.q; 
      toolbar.setNavigationIcon(drawable);
      return;
    } 
    this.a.setNavigationIcon((Drawable)null);
  }
  
  private void H() {
    Drawable drawable;
    int i = this.b;
    if ((i & 0x2) != 0) {
      if ((i & 0x1) != 0) {
        drawable = this.f;
        if (drawable == null)
          drawable = this.e; 
      } else {
        drawable = this.e;
      } 
    } else {
      drawable = null;
    } 
    this.a.setLogo(drawable);
  }
  
  private int v() {
    if (this.a.getNavigationIcon() != null) {
      this.q = this.a.getNavigationIcon();
      return 15;
    } 
    return 11;
  }
  
  public void A(CharSequence paramCharSequence) {
    this.k = paramCharSequence;
    F();
  }
  
  public void B(Drawable paramDrawable) {
    this.g = paramDrawable;
    G();
  }
  
  public void C(CharSequence paramCharSequence) {
    this.j = paramCharSequence;
    if ((this.b & 0x8) != 0)
      this.a.setSubtitle(paramCharSequence); 
  }
  
  public void D(CharSequence paramCharSequence) {
    this.h = true;
    E(paramCharSequence);
  }
  
  public boolean a() {
    return this.a.d();
  }
  
  public boolean b() {
    return this.a.w();
  }
  
  public boolean c() {
    return this.a.N();
  }
  
  public void collapseActionView() {
    this.a.e();
  }
  
  public void d(Menu paramMenu, j.a parama) {
    if (this.n == null) {
      c c1 = new c(this.a.getContext());
      this.n = c1;
      c1.p(f.g);
    } 
    this.n.d(parama);
    this.a.I((e)paramMenu, this.n);
  }
  
  public boolean e() {
    return this.a.A();
  }
  
  public void f() {
    this.m = true;
  }
  
  public boolean g() {
    return this.a.z();
  }
  
  public Context getContext() {
    return this.a.getContext();
  }
  
  public CharSequence getTitle() {
    return this.a.getTitle();
  }
  
  public boolean h() {
    return this.a.v();
  }
  
  public void i(int paramInt) {
    int i = this.b ^ paramInt;
    this.b = paramInt;
    if (i != 0) {
      if ((i & 0x4) != 0) {
        if ((paramInt & 0x4) != 0)
          F(); 
        G();
      } 
      if ((i & 0x3) != 0)
        H(); 
      if ((i & 0x8) != 0)
        if ((paramInt & 0x8) != 0) {
          this.a.setTitle(this.i);
          this.a.setSubtitle(this.j);
        } else {
          this.a.setTitle((CharSequence)null);
          this.a.setSubtitle((CharSequence)null);
        }  
      if ((i & 0x10) != 0) {
        View view = this.d;
        if (view != null) {
          if ((paramInt & 0x10) != 0) {
            this.a.addView(view);
            return;
          } 
          this.a.removeView(view);
        } 
      } 
    } 
  }
  
  public int j() {
    return this.o;
  }
  
  public l2 k(int paramInt, long paramLong) {
    float f;
    l2 l2 = ViewCompat.animate((View)this.a);
    if (paramInt == 0) {
      f = 1.0F;
    } else {
      f = 0.0F;
    } 
    return l2.b(f).f(paramLong).h((m2)new b(this, paramInt));
  }
  
  public ViewGroup l() {
    return this.a;
  }
  
  public void m(boolean paramBoolean) {}
  
  public void n() {
    Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
  }
  
  public void o(boolean paramBoolean) {
    this.a.setCollapsible(paramBoolean);
  }
  
  public void p() {
    this.a.f();
  }
  
  public void q(c1 paramc1) {
    View view = this.c;
    if (view != null) {
      ViewParent viewParent = view.getParent();
      Toolbar toolbar = this.a;
      if (viewParent == toolbar)
        toolbar.removeView(this.c); 
    } 
    this.c = (View)paramc1;
    if (paramc1 != null && this.o == 2) {
      this.a.addView((View)paramc1, 0);
      Toolbar.e e = (Toolbar.e)this.c.getLayoutParams();
      ((ViewGroup.MarginLayoutParams)e).width = -2;
      ((ViewGroup.MarginLayoutParams)e).height = -2;
      e.a = 8388691;
      paramc1.setAllowCollapse(true);
    } 
  }
  
  public void r(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = h.b.d(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    y(drawable);
  }
  
  public void s(int paramInt) {
    this.a.setVisibility(paramInt);
  }
  
  public void setIcon(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = h.b.d(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setIcon(drawable);
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.e = paramDrawable;
    H();
  }
  
  public void setWindowCallback(Window.Callback paramCallback) {
    this.l = paramCallback;
  }
  
  public void setWindowTitle(CharSequence paramCharSequence) {
    if (!this.h)
      E(paramCharSequence); 
  }
  
  public int t() {
    return this.b;
  }
  
  public void u() {
    Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
  }
  
  public void w(View paramView) {
    View view = this.d;
    if (view != null && (this.b & 0x10) != 0)
      this.a.removeView(view); 
    this.d = paramView;
    if (paramView != null && (this.b & 0x10) != 0)
      this.a.addView(paramView); 
  }
  
  public void x(int paramInt) {
    if (paramInt == this.p)
      return; 
    this.p = paramInt;
    if (TextUtils.isEmpty(this.a.getNavigationContentDescription()))
      z(this.p); 
  }
  
  public void y(Drawable paramDrawable) {
    this.f = paramDrawable;
    H();
  }
  
  public void z(int paramInt) {
    String str;
    if (paramInt == 0) {
      str = null;
    } else {
      str = getContext().getString(paramInt);
    } 
    A(str);
  }
  
  class a implements View.OnClickListener {
    final l.a b;
    
    a(k1 this$0) {
      this.b = new l.a(this$0.a.getContext(), 0, 16908332, 0, 0, this$0.i);
    }
    
    public void onClick(View param1View) {
      k1 k11 = this.c;
      Window.Callback callback = k11.l;
      if (callback != null && k11.m)
        callback.onMenuItemSelected(0, (MenuItem)this.b); 
    }
  }
  
  class b extends n2 {
    private boolean a = false;
    
    b(k1 this$0, int param1Int) {}
    
    public void a(View param1View) {
      this.a = true;
    }
    
    public void b(View param1View) {
      if (!this.a)
        this.c.a.setVisibility(this.b); 
    }
    
    public void c(View param1View) {
      this.c.a.setVisibility(0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\k1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */