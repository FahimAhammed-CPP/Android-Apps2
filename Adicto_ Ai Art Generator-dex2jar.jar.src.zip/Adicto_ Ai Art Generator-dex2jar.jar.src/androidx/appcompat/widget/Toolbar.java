package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.view.menu.m;
import androidx.core.view.ViewCompat;
import androidx.core.view.h;
import f.j;
import java.util.ArrayList;
import java.util.List;

public class Toolbar extends ViewGroup {
  private ColorStateList A;
  
  private ColorStateList B;
  
  private boolean C;
  
  private boolean D;
  
  private final ArrayList<View> E = new ArrayList<View>();
  
  private final ArrayList<View> F = new ArrayList<View>();
  
  private final int[] G = new int[2];
  
  f H;
  
  private final ActionMenuView.e I = new a(this);
  
  private k1 J;
  
  private c K;
  
  private d L;
  
  private j.a M;
  
  private androidx.appcompat.view.menu.e.a N;
  
  private boolean O;
  
  private final Runnable P = new b(this);
  
  private ActionMenuView b;
  
  private TextView c;
  
  private TextView d;
  
  private ImageButton e;
  
  private ImageView f;
  
  private Drawable g;
  
  private CharSequence h;
  
  ImageButton i;
  
  View j;
  
  private Context k;
  
  private int l;
  
  private int m;
  
  private int n;
  
  int o;
  
  private int p;
  
  private int q;
  
  private int r;
  
  private int s;
  
  private int t;
  
  private b1 u;
  
  private int v;
  
  private int w;
  
  private int x = 8388627;
  
  private CharSequence y;
  
  private CharSequence z;
  
  public Toolbar(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, f.a.L);
  }
  
  public Toolbar(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    Context context = getContext();
    int[] arrayOfInt = j.W2;
    j1 j1 = j1.u(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    ViewCompat.saveAttributeDataForStyleable((View)this, paramContext, arrayOfInt, paramAttributeSet, j1.q(), paramInt, 0);
    this.m = j1.m(j.y3, 0);
    this.n = j1.m(j.p3, 0);
    this.x = j1.k(j.X2, this.x);
    this.o = j1.k(j.Y2, 48);
    int i = j1.d(j.s3, 0);
    int j = j.x3;
    paramInt = i;
    if (j1.r(j))
      paramInt = j1.d(j, i); 
    this.t = paramInt;
    this.s = paramInt;
    this.r = paramInt;
    this.q = paramInt;
    paramInt = j1.d(j.v3, -1);
    if (paramInt >= 0)
      this.q = paramInt; 
    paramInt = j1.d(j.u3, -1);
    if (paramInt >= 0)
      this.r = paramInt; 
    paramInt = j1.d(j.w3, -1);
    if (paramInt >= 0)
      this.s = paramInt; 
    paramInt = j1.d(j.t3, -1);
    if (paramInt >= 0)
      this.t = paramInt; 
    this.p = j1.e(j.j3, -1);
    paramInt = j1.d(j.f3, -2147483648);
    i = j1.d(j.b3, -2147483648);
    j = j1.e(j.d3, 0);
    int k = j1.e(j.e3, 0);
    h();
    this.u.e(j, k);
    if (paramInt != Integer.MIN_VALUE || i != Integer.MIN_VALUE)
      this.u.g(paramInt, i); 
    this.v = j1.d(j.g3, -2147483648);
    this.w = j1.d(j.c3, -2147483648);
    this.g = j1.f(j.a3);
    this.h = j1.o(j.Z2);
    CharSequence charSequence3 = j1.o(j.r3);
    if (!TextUtils.isEmpty(charSequence3))
      setTitle(charSequence3); 
    charSequence3 = j1.o(j.o3);
    if (!TextUtils.isEmpty(charSequence3))
      setSubtitle(charSequence3); 
    this.k = getContext();
    setPopupTheme(j1.m(j.n3, 0));
    Drawable drawable2 = j1.f(j.m3);
    if (drawable2 != null)
      setNavigationIcon(drawable2); 
    CharSequence charSequence2 = j1.o(j.l3);
    if (!TextUtils.isEmpty(charSequence2))
      setNavigationContentDescription(charSequence2); 
    Drawable drawable1 = j1.f(j.h3);
    if (drawable1 != null)
      setLogo(drawable1); 
    CharSequence charSequence1 = j1.o(j.i3);
    if (!TextUtils.isEmpty(charSequence1))
      setLogoDescription(charSequence1); 
    paramInt = j.z3;
    if (j1.r(paramInt))
      setTitleTextColor(j1.c(paramInt)); 
    paramInt = j.q3;
    if (j1.r(paramInt))
      setSubtitleTextColor(j1.c(paramInt)); 
    paramInt = j.k3;
    if (j1.r(paramInt))
      x(j1.m(paramInt, 0)); 
    j1.v();
  }
  
  private int B(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)e1).leftMargin - paramArrayOfint[0];
    paramInt1 += Math.max(0, i);
    paramArrayOfint[0] = Math.max(0, -i);
    paramInt2 = q(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1, paramInt2, paramInt1 + i, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 + i + ((ViewGroup.MarginLayoutParams)e1).rightMargin;
  }
  
  private int C(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)e1).rightMargin - paramArrayOfint[1];
    paramInt1 -= Math.max(0, i);
    paramArrayOfint[1] = Math.max(0, -i);
    paramInt2 = q(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1 - i, paramInt2, paramInt1, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 - i + ((ViewGroup.MarginLayoutParams)e1).leftMargin;
  }
  
  private int D(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = marginLayoutParams.leftMargin - paramArrayOfint[0];
    int j = marginLayoutParams.rightMargin - paramArrayOfint[1];
    int k = Math.max(0, i) + Math.max(0, j);
    paramArrayOfint[0] = Math.max(0, -i);
    paramArrayOfint[1] = Math.max(0, -j);
    paramView.measure(ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + k + paramInt2, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height));
    return paramView.getMeasuredWidth() + k;
  }
  
  private void E(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width);
    paramInt2 = ViewGroup.getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height);
    paramInt3 = View.MeasureSpec.getMode(paramInt2);
    paramInt1 = paramInt2;
    if (paramInt3 != 1073741824) {
      paramInt1 = paramInt2;
      if (paramInt5 >= 0) {
        paramInt1 = paramInt5;
        if (paramInt3 != 0)
          paramInt1 = Math.min(View.MeasureSpec.getSize(paramInt2), paramInt5); 
        paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
      } 
    } 
    paramView.measure(i, paramInt1);
  }
  
  private void F() {
    removeCallbacks(this.P);
    post(this.P);
  }
  
  private boolean L() {
    if (!this.O)
      return false; 
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if (M(view) && view.getMeasuredWidth() > 0 && view.getMeasuredHeight() > 0)
        return false; 
    } 
    return true;
  }
  
  private boolean M(View paramView) {
    return (paramView != null && paramView.getParent() == this && paramView.getVisibility() != 8);
  }
  
  private void b(List<View> paramList, int paramInt) {
    int i = ViewCompat.getLayoutDirection((View)this);
    boolean bool = false;
    if (i == 1) {
      i = 1;
    } else {
      i = 0;
    } 
    int k = getChildCount();
    int j = androidx.core.view.e.a(paramInt, ViewCompat.getLayoutDirection((View)this));
    paramList.clear();
    paramInt = bool;
    if (i != 0) {
      for (paramInt = k - 1; paramInt >= 0; paramInt--) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && M(view) && p(e1.a) == j)
          paramList.add(view); 
      } 
    } else {
      while (paramInt < k) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && M(view) && p(e1.a) == j)
          paramList.add(view); 
        paramInt++;
      } 
    } 
  }
  
  private void c(View paramView, boolean paramBoolean) {
    e e1;
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams == null) {
      e1 = m();
    } else if (!checkLayoutParams((ViewGroup.LayoutParams)e1)) {
      e1 = o((ViewGroup.LayoutParams)e1);
    } else {
      e1 = e1;
    } 
    e1.b = 1;
    if (paramBoolean && this.j != null) {
      paramView.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.F.add(paramView);
      return;
    } 
    addView(paramView, (ViewGroup.LayoutParams)e1);
  }
  
  private MenuInflater getMenuInflater() {
    return (MenuInflater)new k.g(getContext());
  }
  
  private void h() {
    if (this.u == null)
      this.u = new b1(); 
  }
  
  private void i() {
    if (this.f == null)
      this.f = new AppCompatImageView(getContext()); 
  }
  
  private void j() {
    k();
    if (this.b.J() == null) {
      androidx.appcompat.view.menu.e e1 = (androidx.appcompat.view.menu.e)this.b.getMenu();
      if (this.L == null)
        this.L = new d(this); 
      this.b.setExpandedActionViewsExclusive(true);
      e1.c(this.L, this.k);
    } 
  }
  
  private void k() {
    if (this.b == null) {
      ActionMenuView actionMenuView = new ActionMenuView(getContext());
      this.b = actionMenuView;
      actionMenuView.setPopupTheme(this.l);
      this.b.setOnMenuItemClickListener(this.I);
      this.b.K(this.M, this.N);
      e e1 = m();
      e1.a = 0x800005 | this.o & 0x70;
      this.b.setLayoutParams((ViewGroup.LayoutParams)e1);
      c((View)this.b, false);
    } 
  }
  
  private void l() {
    if (this.e == null) {
      this.e = new l(getContext(), null, f.a.K);
      e e1 = m();
      e1.a = 0x800003 | this.o & 0x70;
      this.e.setLayoutParams((ViewGroup.LayoutParams)e1);
    } 
  }
  
  private int p(int paramInt) {
    int i = ViewCompat.getLayoutDirection((View)this);
    int j = androidx.core.view.e.a(paramInt, i) & 0x7;
    if (j != 1) {
      paramInt = 3;
      if (j != 3 && j != 5) {
        if (i == 1)
          paramInt = 5; 
        return paramInt;
      } 
    } 
    return j;
  }
  
  private int q(View paramView, int paramInt) {
    e e1 = (e)paramView.getLayoutParams();
    int j = paramView.getMeasuredHeight();
    if (paramInt > 0) {
      paramInt = (j - paramInt) / 2;
    } else {
      paramInt = 0;
    } 
    int i = r(e1.a);
    if (i != 48) {
      if (i != 80) {
        int k = getPaddingTop();
        int m = getPaddingBottom();
        int n = getHeight();
        i = (n - k - m - j) / 2;
        paramInt = ((ViewGroup.MarginLayoutParams)e1).topMargin;
        if (i >= paramInt) {
          j = n - m - j - i - k;
          m = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
          paramInt = i;
          if (j < m)
            paramInt = Math.max(0, i - m - j); 
        } 
        return k + paramInt;
      } 
      return getHeight() - getPaddingBottom() - j - ((ViewGroup.MarginLayoutParams)e1).bottomMargin - paramInt;
    } 
    return getPaddingTop() - paramInt;
  }
  
  private int r(int paramInt) {
    int i = paramInt & 0x70;
    paramInt = i;
    if (i != 16) {
      paramInt = i;
      if (i != 48) {
        paramInt = i;
        if (i != 80)
          paramInt = this.x & 0x70; 
      } 
    } 
    return paramInt;
  }
  
  private int s(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return h.b(marginLayoutParams) + h.a(marginLayoutParams);
  }
  
  private int t(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
  }
  
  private int u(List<View> paramList, int[] paramArrayOfint) {
    int m = paramArrayOfint[0];
    int k = paramArrayOfint[1];
    int n = paramList.size();
    int i = 0;
    int j = 0;
    while (i < n) {
      View view = paramList.get(i);
      e e1 = (e)view.getLayoutParams();
      m = ((ViewGroup.MarginLayoutParams)e1).leftMargin - m;
      k = ((ViewGroup.MarginLayoutParams)e1).rightMargin - k;
      int i1 = Math.max(0, m);
      int i2 = Math.max(0, k);
      m = Math.max(0, -m);
      k = Math.max(0, -k);
      j += i1 + view.getMeasuredWidth() + i2;
      i++;
    } 
    return j;
  }
  
  private boolean y(View paramView) {
    return (paramView.getParent() == this || this.F.contains(paramView));
  }
  
  public boolean A() {
    ActionMenuView actionMenuView = this.b;
    return (actionMenuView != null && actionMenuView.F());
  }
  
  void G() {
    for (int i = getChildCount() - 1; i >= 0; i--) {
      View view = getChildAt(i);
      if (((e)view.getLayoutParams()).b != 2 && view != this.b) {
        removeViewAt(i);
        this.F.add(view);
      } 
    } 
  }
  
  public void H(int paramInt1, int paramInt2) {
    h();
    this.u.g(paramInt1, paramInt2);
  }
  
  public void I(androidx.appcompat.view.menu.e parame, c paramc) {
    if (parame == null && this.b == null)
      return; 
    k();
    androidx.appcompat.view.menu.e e1 = this.b.J();
    if (e1 == parame)
      return; 
    if (e1 != null) {
      e1.O((j)this.K);
      e1.O(this.L);
    } 
    if (this.L == null)
      this.L = new d(this); 
    paramc.G(true);
    if (parame != null) {
      parame.c((j)paramc, this.k);
      parame.c(this.L, this.k);
    } else {
      paramc.i(this.k, null);
      this.L.i(this.k, null);
      paramc.f(true);
      this.L.f(true);
    } 
    this.b.setPopupTheme(this.l);
    this.b.setPresenter(paramc);
    this.K = paramc;
  }
  
  public void J(Context paramContext, int paramInt) {
    this.n = paramInt;
    TextView textView = this.d;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public void K(Context paramContext, int paramInt) {
    this.m = paramInt;
    TextView textView = this.c;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public boolean N() {
    ActionMenuView actionMenuView = this.b;
    return (actionMenuView != null && actionMenuView.L());
  }
  
  void a() {
    for (int i = this.F.size() - 1; i >= 0; i--)
      addView(this.F.get(i)); 
    this.F.clear();
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (super.checkLayoutParams(paramLayoutParams) && paramLayoutParams instanceof e);
  }
  
  public boolean d() {
    if (getVisibility() == 0) {
      ActionMenuView actionMenuView = this.b;
      if (actionMenuView != null && actionMenuView.G())
        return true; 
    } 
    return false;
  }
  
  public void e() {
    androidx.appcompat.view.menu.g g;
    d d1 = this.L;
    if (d1 == null) {
      d1 = null;
    } else {
      g = d1.c;
    } 
    if (g != null)
      g.collapseActionView(); 
  }
  
  public void f() {
    ActionMenuView actionMenuView = this.b;
    if (actionMenuView != null)
      actionMenuView.x(); 
  }
  
  void g() {
    if (this.i == null) {
      l l = new l(getContext(), null, f.a.K);
      this.i = l;
      l.setImageDrawable(this.g);
      this.i.setContentDescription(this.h);
      e e1 = m();
      e1.a = 0x800003 | this.o & 0x70;
      e1.b = 2;
      this.i.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.i.setOnClickListener(new c(this));
    } 
  }
  
  @Nullable
  public CharSequence getCollapseContentDescription() {
    ImageButton imageButton = this.i;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  @Nullable
  public Drawable getCollapseIcon() {
    ImageButton imageButton = this.i;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  public int getContentInsetEnd() {
    b1 b11 = this.u;
    return (b11 != null) ? b11.a() : 0;
  }
  
  public int getContentInsetEndWithActions() {
    int i = this.w;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetEnd();
  }
  
  public int getContentInsetLeft() {
    b1 b11 = this.u;
    return (b11 != null) ? b11.b() : 0;
  }
  
  public int getContentInsetRight() {
    b1 b11 = this.u;
    return (b11 != null) ? b11.c() : 0;
  }
  
  public int getContentInsetStart() {
    b1 b11 = this.u;
    return (b11 != null) ? b11.d() : 0;
  }
  
  public int getContentInsetStartWithNavigation() {
    int i = this.v;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetStart();
  }
  
  public int getCurrentContentInsetEnd() {
    // Byte code:
    //   0: aload_0
    //   1: getfield b : Landroidx/appcompat/widget/ActionMenuView;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 30
    //   9: aload_2
    //   10: invokevirtual J : ()Landroidx/appcompat/view/menu/e;
    //   13: astore_2
    //   14: aload_2
    //   15: ifnull -> 30
    //   18: aload_2
    //   19: invokevirtual hasVisibleItems : ()Z
    //   22: ifeq -> 30
    //   25: iconst_1
    //   26: istore_1
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: ifeq -> 52
    //   36: aload_0
    //   37: invokevirtual getContentInsetEnd : ()I
    //   40: aload_0
    //   41: getfield w : I
    //   44: iconst_0
    //   45: invokestatic max : (II)I
    //   48: invokestatic max : (II)I
    //   51: ireturn
    //   52: aload_0
    //   53: invokevirtual getContentInsetEnd : ()I
    //   56: ireturn
  }
  
  public int getCurrentContentInsetLeft() {
    return (ViewCompat.getLayoutDirection((View)this) == 1) ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
  }
  
  public int getCurrentContentInsetRight() {
    return (ViewCompat.getLayoutDirection((View)this) == 1) ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
  }
  
  public int getCurrentContentInsetStart() {
    return (getNavigationIcon() != null) ? Math.max(getContentInsetStart(), Math.max(this.v, 0)) : getContentInsetStart();
  }
  
  public Drawable getLogo() {
    ImageView imageView = this.f;
    return (imageView != null) ? imageView.getDrawable() : null;
  }
  
  public CharSequence getLogoDescription() {
    ImageView imageView = this.f;
    return (imageView != null) ? imageView.getContentDescription() : null;
  }
  
  public Menu getMenu() {
    j();
    return this.b.getMenu();
  }
  
  @Nullable
  public CharSequence getNavigationContentDescription() {
    ImageButton imageButton = this.e;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  @Nullable
  public Drawable getNavigationIcon() {
    ImageButton imageButton = this.e;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  c getOuterActionMenuPresenter() {
    return this.K;
  }
  
  @Nullable
  public Drawable getOverflowIcon() {
    j();
    return this.b.getOverflowIcon();
  }
  
  Context getPopupContext() {
    return this.k;
  }
  
  public int getPopupTheme() {
    return this.l;
  }
  
  public CharSequence getSubtitle() {
    return this.z;
  }
  
  @Nullable
  final TextView getSubtitleTextView() {
    return this.d;
  }
  
  public CharSequence getTitle() {
    return this.y;
  }
  
  public int getTitleMarginBottom() {
    return this.t;
  }
  
  public int getTitleMarginEnd() {
    return this.r;
  }
  
  public int getTitleMarginStart() {
    return this.q;
  }
  
  public int getTitleMarginTop() {
    return this.s;
  }
  
  @Nullable
  final TextView getTitleTextView() {
    return this.c;
  }
  
  public k0 getWrapper() {
    if (this.J == null)
      this.J = new k1(this, true); 
    return this.J;
  }
  
  protected e m() {
    return new e(-2, -2);
  }
  
  public e n(AttributeSet paramAttributeSet) {
    return new e(getContext(), paramAttributeSet);
  }
  
  protected e o(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof e) ? new e((e)paramLayoutParams) : ((paramLayoutParams instanceof g.a.a) ? new e((g.a.a)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new e((ViewGroup.MarginLayoutParams)paramLayoutParams) : new e(paramLayoutParams)));
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    removeCallbacks(this.P);
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.D = false; 
    if (!this.D) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.D = true; 
    } 
    if (i == 10 || i == 3)
      this.D = false; 
    return true;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (ViewCompat.getLayoutDirection((View)this) == 1) {
      k = 1;
    } else {
      k = 0;
    } 
    int n = getWidth();
    int i3 = getHeight();
    int i = getPaddingLeft();
    int i1 = getPaddingRight();
    int i2 = getPaddingTop();
    int i4 = getPaddingBottom();
    int m = n - i1;
    int[] arrayOfInt = this.G;
    arrayOfInt[1] = 0;
    arrayOfInt[0] = 0;
    paramInt1 = ViewCompat.getMinimumHeight((View)this);
    if (paramInt1 >= 0) {
      paramInt4 = Math.min(paramInt1, paramInt4 - paramInt2);
    } else {
      paramInt4 = 0;
    } 
    if (M((View)this.e)) {
      if (k) {
        j = C((View)this.e, m, arrayOfInt, paramInt4);
        paramInt3 = i;
      } else {
        paramInt3 = B((View)this.e, i, arrayOfInt, paramInt4);
        j = m;
      } 
    } else {
      paramInt3 = i;
      j = m;
    } 
    paramInt1 = paramInt3;
    paramInt2 = j;
    if (M((View)this.i))
      if (k) {
        paramInt2 = C((View)this.i, j, arrayOfInt, paramInt4);
        paramInt1 = paramInt3;
      } else {
        paramInt1 = B((View)this.i, paramInt3, arrayOfInt, paramInt4);
        paramInt2 = j;
      }  
    int j = paramInt1;
    paramInt3 = paramInt2;
    if (M((View)this.b))
      if (k) {
        j = B((View)this.b, paramInt1, arrayOfInt, paramInt4);
        paramInt3 = paramInt2;
      } else {
        paramInt3 = C((View)this.b, paramInt2, arrayOfInt, paramInt4);
        j = paramInt1;
      }  
    paramInt2 = getCurrentContentInsetLeft();
    paramInt1 = getCurrentContentInsetRight();
    arrayOfInt[0] = Math.max(0, paramInt2 - j);
    arrayOfInt[1] = Math.max(0, paramInt1 - m - paramInt3);
    paramInt2 = Math.max(j, paramInt2);
    paramInt3 = Math.min(paramInt3, m - paramInt1);
    paramInt1 = paramInt2;
    j = paramInt3;
    if (M(this.j))
      if (k) {
        j = C(this.j, paramInt3, arrayOfInt, paramInt4);
        paramInt1 = paramInt2;
      } else {
        paramInt1 = B(this.j, paramInt2, arrayOfInt, paramInt4);
        j = paramInt3;
      }  
    paramInt3 = paramInt1;
    paramInt2 = j;
    if (M((View)this.f))
      if (k) {
        paramInt2 = C((View)this.f, j, arrayOfInt, paramInt4);
        paramInt3 = paramInt1;
      } else {
        paramInt3 = B((View)this.f, paramInt1, arrayOfInt, paramInt4);
        paramInt2 = j;
      }  
    paramBoolean = M((View)this.c);
    boolean bool = M((View)this.d);
    if (paramBoolean) {
      e e1 = (e)this.c.getLayoutParams();
      paramInt1 = ((ViewGroup.MarginLayoutParams)e1).topMargin + this.c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)e1).bottomMargin + 0;
    } else {
      paramInt1 = 0;
    } 
    if (bool) {
      e e1 = (e)this.d.getLayoutParams();
      paramInt1 += ((ViewGroup.MarginLayoutParams)e1).topMargin + this.d.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
    } 
    if (paramBoolean || bool) {
      TextView textView1;
      TextView textView2;
      if (paramBoolean) {
        textView1 = this.c;
      } else {
        textView1 = this.d;
      } 
      if (bool) {
        textView2 = this.d;
      } else {
        textView2 = this.c;
      } 
      e e1 = (e)textView1.getLayoutParams();
      e e2 = (e)textView2.getLayoutParams();
      if ((paramBoolean && this.c.getMeasuredWidth() > 0) || (bool && this.d.getMeasuredWidth() > 0)) {
        j = 1;
      } else {
        j = 0;
      } 
      m = this.x & 0x70;
      if (m != 48) {
        if (m != 80) {
          m = (i3 - i2 - i4 - paramInt1) / 2;
          int i5 = ((ViewGroup.MarginLayoutParams)e1).topMargin;
          int i6 = this.s;
          if (m < i5 + i6) {
            paramInt1 = i5 + i6;
          } else {
            i3 = i3 - i4 - paramInt1 - m - i2;
            i4 = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
            i5 = this.t;
            paramInt1 = m;
            if (i3 < i4 + i5)
              paramInt1 = Math.max(0, m - ((ViewGroup.MarginLayoutParams)e2).bottomMargin + i5 - i3); 
          } 
          paramInt1 = i2 + paramInt1;
        } else {
          paramInt1 = i3 - i4 - ((ViewGroup.MarginLayoutParams)e2).bottomMargin - this.t - paramInt1;
        } 
      } else {
        paramInt1 = getPaddingTop() + ((ViewGroup.MarginLayoutParams)e1).topMargin + this.s;
      } 
      if (k) {
        if (j != 0) {
          k = this.q;
        } else {
          k = 0;
        } 
        k -= arrayOfInt[1];
        paramInt2 -= Math.max(0, k);
        arrayOfInt[1] = Math.max(0, -k);
        if (paramBoolean) {
          e1 = (e)this.c.getLayoutParams();
          m = paramInt2 - this.c.getMeasuredWidth();
          k = this.c.getMeasuredHeight() + paramInt1;
          this.c.layout(m, paramInt1, paramInt2, k);
          paramInt1 = m - this.r;
          m = k + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          k = paramInt2;
          m = paramInt1;
          paramInt1 = k;
        } 
        if (bool) {
          k = m + ((ViewGroup.MarginLayoutParams)this.d.getLayoutParams()).topMargin;
          m = this.d.getMeasuredWidth();
          i2 = this.d.getMeasuredHeight();
          this.d.layout(paramInt2 - m, k, paramInt2, i2 + k);
          k = paramInt2 - this.r;
        } else {
          k = paramInt2;
        } 
        if (j != 0)
          paramInt2 = Math.min(paramInt1, k); 
        paramInt1 = paramInt3;
      } else {
        if (j != 0) {
          k = this.q;
        } else {
          k = 0;
        } 
        k -= arrayOfInt[0];
        paramInt3 += Math.max(0, k);
        arrayOfInt[0] = Math.max(0, -k);
        if (paramBoolean) {
          e1 = (e)this.c.getLayoutParams();
          k = this.c.getMeasuredWidth() + paramInt3;
          m = this.c.getMeasuredHeight() + paramInt1;
          this.c.layout(paramInt3, paramInt1, k, m);
          k += this.r;
          paramInt1 = m + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          k = paramInt3;
        } 
        if (bool) {
          paramInt1 += ((ViewGroup.MarginLayoutParams)this.d.getLayoutParams()).topMargin;
          m = this.d.getMeasuredWidth() + paramInt3;
          i2 = this.d.getMeasuredHeight();
          this.d.layout(paramInt3, paramInt1, m, i2 + paramInt1);
          m += this.r;
        } else {
          m = paramInt3;
        } 
        paramInt1 = paramInt3;
        paramInt3 = paramInt2;
        if (j != 0) {
          paramInt1 = Math.max(k, m);
          paramInt3 = paramInt2;
        } 
        j = i;
        i = 0;
        b(this.E, 3);
        k = this.E.size();
        paramInt2 = 0;
      } 
    } else {
      paramInt1 = paramInt3;
    } 
    paramInt3 = paramInt2;
    j = i;
    i = 0;
    b(this.E, 3);
    int k = this.E.size();
    paramInt2 = 0;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof g)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    g g = (g)paramParcelable;
    super.onRestoreInstanceState(g.c());
    ActionMenuView actionMenuView = this.b;
    if (actionMenuView != null) {
      androidx.appcompat.view.menu.e e1 = actionMenuView.J();
    } else {
      actionMenuView = null;
    } 
    int i = g.d;
    if (i != 0 && this.L != null && actionMenuView != null) {
      MenuItem menuItem = actionMenuView.findItem(i);
      if (menuItem != null)
        menuItem.expandActionView(); 
    } 
    if (g.e)
      F(); 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    super.onRtlPropertiesChanged(paramInt);
    h();
    b1 b11 = this.u;
    boolean bool = true;
    if (paramInt != 1)
      bool = false; 
    b11.f(bool);
  }
  
  protected Parcelable onSaveInstanceState() {
    g g = new g(super.onSaveInstanceState());
    d d1 = this.L;
    if (d1 != null) {
      androidx.appcompat.view.menu.g g1 = d1.c;
      if (g1 != null)
        g.d = g1.getItemId(); 
    } 
    g.e = A();
    return (Parcelable)g;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.C = false; 
    if (!this.C) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.C = true; 
    } 
    if (i == 1 || i == 3)
      this.C = false; 
    return true;
  }
  
  public void setCollapseContentDescription(@StringRes int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setCollapseContentDescription(charSequence);
  }
  
  public void setCollapseContentDescription(@Nullable CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      g(); 
    ImageButton imageButton = this.i;
    if (imageButton != null)
      imageButton.setContentDescription(paramCharSequence); 
  }
  
  public void setCollapseIcon(int paramInt) {
    setCollapseIcon(h.b.d(getContext(), paramInt));
  }
  
  public void setCollapseIcon(@Nullable Drawable paramDrawable) {
    if (paramDrawable != null) {
      g();
      this.i.setImageDrawable(paramDrawable);
      return;
    } 
    ImageButton imageButton = this.i;
    if (imageButton != null)
      imageButton.setImageDrawable(this.g); 
  }
  
  public void setCollapsible(boolean paramBoolean) {
    this.O = paramBoolean;
    requestLayout();
  }
  
  public void setContentInsetEndWithActions(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.w) {
      this.w = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setContentInsetStartWithNavigation(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.v) {
      this.v = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setLogo(int paramInt) {
    setLogo(h.b.d(getContext(), paramInt));
  }
  
  public void setLogo(Drawable paramDrawable) {
    if (paramDrawable != null) {
      i();
      if (!y((View)this.f))
        c((View)this.f, true); 
    } else {
      ImageView imageView1 = this.f;
      if (imageView1 != null && y((View)imageView1)) {
        removeView((View)this.f);
        this.F.remove(this.f);
      } 
    } 
    ImageView imageView = this.f;
    if (imageView != null)
      imageView.setImageDrawable(paramDrawable); 
  }
  
  public void setLogoDescription(@StringRes int paramInt) {
    setLogoDescription(getContext().getText(paramInt));
  }
  
  public void setLogoDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      i(); 
    ImageView imageView = this.f;
    if (imageView != null)
      imageView.setContentDescription(paramCharSequence); 
  }
  
  public void setNavigationContentDescription(@StringRes int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setNavigationContentDescription(charSequence);
  }
  
  public void setNavigationContentDescription(@Nullable CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      l(); 
    ImageButton imageButton = this.e;
    if (imageButton != null)
      imageButton.setContentDescription(paramCharSequence); 
  }
  
  public void setNavigationIcon(int paramInt) {
    setNavigationIcon(h.b.d(getContext(), paramInt));
  }
  
  public void setNavigationIcon(@Nullable Drawable paramDrawable) {
    if (paramDrawable != null) {
      l();
      if (!y((View)this.e))
        c((View)this.e, true); 
    } else {
      ImageButton imageButton1 = this.e;
      if (imageButton1 != null && y((View)imageButton1)) {
        removeView((View)this.e);
        this.F.remove(this.e);
      } 
    } 
    ImageButton imageButton = this.e;
    if (imageButton != null)
      imageButton.setImageDrawable(paramDrawable); 
  }
  
  public void setNavigationOnClickListener(View.OnClickListener paramOnClickListener) {
    l();
    this.e.setOnClickListener(paramOnClickListener);
  }
  
  public void setOnMenuItemClickListener(f paramf) {
    this.H = paramf;
  }
  
  public void setOverflowIcon(@Nullable Drawable paramDrawable) {
    j();
    this.b.setOverflowIcon(paramDrawable);
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.l != paramInt) {
      this.l = paramInt;
      if (paramInt == 0) {
        this.k = getContext();
        return;
      } 
      this.k = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  public void setSubtitle(@StringRes int paramInt) {
    setSubtitle(getContext().getText(paramInt));
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.d == null) {
        Context context = getContext();
        AppCompatTextView appCompatTextView = new AppCompatTextView(context);
        this.d = appCompatTextView;
        appCompatTextView.setSingleLine();
        this.d.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.n;
        if (i != 0)
          this.d.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.B;
        if (colorStateList != null)
          this.d.setTextColor(colorStateList); 
      } 
      if (!y((View)this.d))
        c((View)this.d, true); 
    } else {
      TextView textView1 = this.d;
      if (textView1 != null && y((View)textView1)) {
        removeView((View)this.d);
        this.F.remove(this.d);
      } 
    } 
    TextView textView = this.d;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.z = paramCharSequence;
  }
  
  public void setSubtitleTextColor(int paramInt) {
    setSubtitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setSubtitleTextColor(@NonNull ColorStateList paramColorStateList) {
    this.B = paramColorStateList;
    TextView textView = this.d;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public void setTitle(@StringRes int paramInt) {
    setTitle(getContext().getText(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.c == null) {
        Context context = getContext();
        AppCompatTextView appCompatTextView = new AppCompatTextView(context);
        this.c = appCompatTextView;
        appCompatTextView.setSingleLine();
        this.c.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.m;
        if (i != 0)
          this.c.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.A;
        if (colorStateList != null)
          this.c.setTextColor(colorStateList); 
      } 
      if (!y((View)this.c))
        c((View)this.c, true); 
    } else {
      TextView textView1 = this.c;
      if (textView1 != null && y((View)textView1)) {
        removeView((View)this.c);
        this.F.remove(this.c);
      } 
    } 
    TextView textView = this.c;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.y = paramCharSequence;
  }
  
  public void setTitleMarginBottom(int paramInt) {
    this.t = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginEnd(int paramInt) {
    this.r = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginStart(int paramInt) {
    this.q = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginTop(int paramInt) {
    this.s = paramInt;
    requestLayout();
  }
  
  public void setTitleTextColor(int paramInt) {
    setTitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setTitleTextColor(@NonNull ColorStateList paramColorStateList) {
    this.A = paramColorStateList;
    TextView textView = this.c;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public boolean v() {
    d d1 = this.L;
    return (d1 != null && d1.c != null);
  }
  
  public boolean w() {
    ActionMenuView actionMenuView = this.b;
    return (actionMenuView != null && actionMenuView.D());
  }
  
  public void x(int paramInt) {
    getMenuInflater().inflate(paramInt, getMenu());
  }
  
  public boolean z() {
    ActionMenuView actionMenuView = this.b;
    return (actionMenuView != null && actionMenuView.E());
  }
  
  class a implements ActionMenuView.e {
    a(Toolbar this$0) {}
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      Toolbar.f f = this.a.H;
      return (f != null) ? f.onMenuItemClick(param1MenuItem) : false;
    }
  }
  
  class b implements Runnable {
    b(Toolbar this$0) {}
    
    public void run() {
      this.b.N();
    }
  }
  
  class c implements View.OnClickListener {
    c(Toolbar this$0) {}
    
    public void onClick(View param1View) {
      this.b.e();
    }
  }
  
  private class d implements j {
    androidx.appcompat.view.menu.e b;
    
    androidx.appcompat.view.menu.g c;
    
    d(Toolbar this$0) {}
    
    public void b(androidx.appcompat.view.menu.e param1e, boolean param1Boolean) {}
    
    public boolean c(androidx.appcompat.view.menu.e param1e, androidx.appcompat.view.menu.g param1g) {
      this.d.g();
      ViewParent viewParent = this.d.i.getParent();
      Toolbar toolbar = this.d;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView((View)toolbar.i); 
        Toolbar toolbar1 = this.d;
        toolbar1.addView((View)toolbar1.i);
      } 
      this.d.j = param1g.getActionView();
      this.c = param1g;
      viewParent = this.d.j.getParent();
      toolbar = this.d;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView(toolbar.j); 
        Toolbar.e e1 = this.d.m();
        toolbar = this.d;
        e1.a = 0x800003 | toolbar.o & 0x70;
        e1.b = 2;
        toolbar.j.setLayoutParams((ViewGroup.LayoutParams)e1);
        Toolbar toolbar1 = this.d;
        toolbar1.addView(toolbar1.j);
      } 
      this.d.G();
      this.d.requestLayout();
      param1g.r(true);
      View view = this.d.j;
      if (view instanceof k.c)
        ((k.c)view).onActionViewExpanded(); 
      return true;
    }
    
    public boolean e(m param1m) {
      return false;
    }
    
    public void f(boolean param1Boolean) {
      if (this.c != null) {
        androidx.appcompat.view.menu.e e1 = this.b;
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (e1 != null) {
          int k = e1.size();
          int i = 0;
          while (true) {
            bool1 = bool2;
            if (i < k) {
              if (this.b.getItem(i) == this.c) {
                bool1 = true;
                break;
              } 
              i++;
              continue;
            } 
            break;
          } 
        } 
        if (!bool1)
          h(this.b, this.c); 
      } 
    }
    
    public boolean g() {
      return false;
    }
    
    public boolean h(androidx.appcompat.view.menu.e param1e, androidx.appcompat.view.menu.g param1g) {
      View view = this.d.j;
      if (view instanceof k.c)
        ((k.c)view).onActionViewCollapsed(); 
      Toolbar toolbar = this.d;
      toolbar.removeView(toolbar.j);
      toolbar = this.d;
      toolbar.removeView((View)toolbar.i);
      toolbar = this.d;
      toolbar.j = null;
      toolbar.a();
      this.c = null;
      this.d.requestLayout();
      param1g.r(false);
      return true;
    }
    
    public void i(Context param1Context, androidx.appcompat.view.menu.e param1e) {
      androidx.appcompat.view.menu.e e1 = this.b;
      if (e1 != null) {
        androidx.appcompat.view.menu.g g1 = this.c;
        if (g1 != null)
          e1.f(g1); 
      } 
      this.b = param1e;
    }
  }
  
  public static class e extends g.a.a {
    int b = 0;
    
    public e(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = 8388627;
    }
    
    public e(@NonNull Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public e(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public e(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super((ViewGroup.LayoutParams)param1MarginLayoutParams);
      a(param1MarginLayoutParams);
    }
    
    public e(e param1e) {
      super(param1e);
      this.b = param1e.b;
    }
    
    public e(g.a.a param1a) {
      super(param1a);
    }
    
    void a(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      ((ViewGroup.MarginLayoutParams)this).leftMargin = param1MarginLayoutParams.leftMargin;
      ((ViewGroup.MarginLayoutParams)this).topMargin = param1MarginLayoutParams.topMargin;
      ((ViewGroup.MarginLayoutParams)this).rightMargin = param1MarginLayoutParams.rightMargin;
      ((ViewGroup.MarginLayoutParams)this).bottomMargin = param1MarginLayoutParams.bottomMargin;
    }
  }
  
  public static interface f {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
  
  public static class g extends c0.a {
    public static final Parcelable.Creator<g> CREATOR = (Parcelable.Creator<g>)new a();
    
    int d;
    
    boolean e;
    
    public g(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      boolean bool;
      this.d = param1Parcel.readInt();
      if (param1Parcel.readInt() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.e = bool;
    }
    
    public g(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    class a implements Parcelable.ClassLoaderCreator<g> {
      public Toolbar.g a(Parcel param2Parcel) {
        return new Toolbar.g(param2Parcel, null);
      }
      
      public Toolbar.g b(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new Toolbar.g(param2Parcel, param2ClassLoader);
      }
      
      public Toolbar.g[] c(int param2Int) {
        return new Toolbar.g[param2Int];
      }
    }
  }
  
  class a implements Parcelable.ClassLoaderCreator<g> {
    public Toolbar.g a(Parcel param1Parcel) {
      return new Toolbar.g(param1Parcel, null);
    }
    
    public Toolbar.g b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new Toolbar.g(param1Parcel, param1ClassLoader);
    }
    
    public Toolbar.g[] c(int param1Int) {
      return new Toolbar.g[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\Toolbar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */