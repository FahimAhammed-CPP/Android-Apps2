package androidx.appcompat.widget;

import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityManager;
import androidx.core.view.ViewCompat;
import androidx.core.view.ViewConfigurationCompat;

class n1 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {
  private static n1 k;
  
  private static n1 l;
  
  private final View b;
  
  private final CharSequence c;
  
  private final int d;
  
  private final Runnable e = new a(this);
  
  private final Runnable f = new b(this);
  
  private int g;
  
  private int h;
  
  private o1 i;
  
  private boolean j;
  
  private n1(View paramView, CharSequence paramCharSequence) {
    this.b = paramView;
    this.c = paramCharSequence;
    this.d = ViewConfigurationCompat.getScaledHoverSlop(ViewConfiguration.get(paramView.getContext()));
    b();
    paramView.setOnLongClickListener(this);
    paramView.setOnHoverListener(this);
  }
  
  private void a() {
    this.b.removeCallbacks(this.e);
  }
  
  private void b() {
    this.g = Integer.MAX_VALUE;
    this.h = Integer.MAX_VALUE;
  }
  
  private void d() {
    this.b.postDelayed(this.e, ViewConfiguration.getLongPressTimeout());
  }
  
  private static void e(n1 paramn1) {
    n1 n11 = k;
    if (n11 != null)
      n11.a(); 
    k = paramn1;
    if (paramn1 != null)
      paramn1.d(); 
  }
  
  public static void f(View paramView, CharSequence paramCharSequence) {
    n1 n11;
    n1 n12 = k;
    if (n12 != null && n12.b == paramView)
      e(null); 
    if (TextUtils.isEmpty(paramCharSequence)) {
      n11 = l;
      if (n11 != null && n11.b == paramView)
        n11.c(); 
      paramView.setOnLongClickListener(null);
      paramView.setLongClickable(false);
      paramView.setOnHoverListener(null);
      return;
    } 
    new n1(paramView, (CharSequence)n11);
  }
  
  private boolean h(MotionEvent paramMotionEvent) {
    int i = (int)paramMotionEvent.getX();
    int j = (int)paramMotionEvent.getY();
    if (Math.abs(i - this.g) <= this.d && Math.abs(j - this.h) <= this.d)
      return false; 
    this.g = i;
    this.h = j;
    return true;
  }
  
  void c() {
    if (l == this) {
      l = null;
      o1 o11 = this.i;
      if (o11 != null) {
        o11.c();
        this.i = null;
        b();
        this.b.removeOnAttachStateChangeListener(this);
      } else {
        Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
      } 
    } 
    if (k == this)
      e(null); 
    this.b.removeCallbacks(this.f);
  }
  
  void g(boolean paramBoolean) {
    long l;
    if (!ViewCompat.isAttachedToWindow(this.b))
      return; 
    e(null);
    n1 n11 = l;
    if (n11 != null)
      n11.c(); 
    l = this;
    this.j = paramBoolean;
    o1 o11 = new o1(this.b.getContext());
    this.i = o11;
    o11.e(this.b, this.g, this.h, this.j, this.c);
    this.b.addOnAttachStateChangeListener(this);
    if (this.j) {
      l = 2500L;
    } else {
      int i;
      if ((ViewCompat.getWindowSystemUiVisibility(this.b) & 0x1) == 1) {
        l = 3000L;
        i = ViewConfiguration.getLongPressTimeout();
      } else {
        l = 15000L;
        i = ViewConfiguration.getLongPressTimeout();
      } 
      l -= i;
    } 
    this.b.removeCallbacks(this.f);
    this.b.postDelayed(this.f, l);
  }
  
  public boolean onHover(View paramView, MotionEvent paramMotionEvent) {
    if (this.i != null && this.j)
      return false; 
    AccessibilityManager accessibilityManager = (AccessibilityManager)this.b.getContext().getSystemService("accessibility");
    if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled())
      return false; 
    int i = paramMotionEvent.getAction();
    if (i != 7) {
      if (i != 10)
        return false; 
      b();
      c();
      return false;
    } 
    if (this.b.isEnabled() && this.i == null && h(paramMotionEvent))
      e(this); 
    return false;
  }
  
  public boolean onLongClick(View paramView) {
    this.g = paramView.getWidth() / 2;
    this.h = paramView.getHeight() / 2;
    g(true);
    return true;
  }
  
  public void onViewAttachedToWindow(View paramView) {}
  
  public void onViewDetachedFromWindow(View paramView) {
    c();
  }
  
  class a implements Runnable {
    a(n1 this$0) {}
    
    public void run() {
      this.b.g(false);
    }
  }
  
  class b implements Runnable {
    b(n1 this$0) {}
    
    public void run() {
      this.b.c();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\n1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */