package androidx.appcompat.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.widget.p;
import h.b;

public class g extends CheckedTextView {
  private static final int[] c = new int[] { 16843016 };
  
  private final c0 b;
  
  public g(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16843720);
  }
  
  public g(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt) {
    super(g1.b(paramContext), paramAttributeSet, paramInt);
    e1.a((View)this, getContext());
    c0 c01 = new c0((TextView)this);
    this.b = c01;
    c01.m(paramAttributeSet, paramInt);
    c01.b();
    j1 j1 = j1.u(getContext(), paramAttributeSet, c, paramInt, 0);
    setCheckMarkDrawable(j1.f(0));
    j1.v();
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    c0 c01 = this.b;
    if (c01 != null)
      c01.b(); 
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    return k.a(super.onCreateInputConnection(paramEditorInfo), paramEditorInfo, (View)this);
  }
  
  public void setCheckMarkDrawable(int paramInt) {
    setCheckMarkDrawable(b.d(getContext(), paramInt));
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(p.m((TextView)this, paramCallback));
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    c0 c01 = this.b;
    if (c01 != null)
      c01.q(paramContext, paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */