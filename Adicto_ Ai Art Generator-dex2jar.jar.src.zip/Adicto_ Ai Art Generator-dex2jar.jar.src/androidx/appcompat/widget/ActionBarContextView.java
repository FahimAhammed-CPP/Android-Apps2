package androidx.appcompat.widget;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.j;
import androidx.core.view.ViewCompat;
import androidx.core.view.l2;
import f.f;
import f.g;
import f.j;
import k.b;

public class ActionBarContextView extends a {
  private CharSequence j;
  
  private CharSequence k;
  
  private View l;
  
  private View m;
  
  private LinearLayout n;
  
  private TextView o;
  
  private TextView p;
  
  private int q;
  
  private int r;
  
  private boolean s;
  
  private int t;
  
  public ActionBarContextView(@NonNull Context paramContext) {
    this(paramContext, null);
  }
  
  public ActionBarContextView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, f.a.j);
  }
  
  public ActionBarContextView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    j1 j1 = j1.u(paramContext, paramAttributeSet, j.y, paramInt, 0);
    ViewCompat.setBackground((View)this, j1.f(j.z));
    this.q = j1.m(j.D, 0);
    this.r = j1.m(j.C, 0);
    this.f = j1.l(j.B, 0);
    this.t = j1.m(j.A, g.d);
    j1.v();
  }
  
  private void i() {
    if (this.n == null) {
      LayoutInflater.from(getContext()).inflate(g.a, this);
      LinearLayout linearLayout1 = (LinearLayout)getChildAt(getChildCount() - 1);
      this.n = linearLayout1;
      this.o = (TextView)linearLayout1.findViewById(f.e);
      this.p = (TextView)this.n.findViewById(f.d);
      if (this.q != 0)
        this.o.setTextAppearance(getContext(), this.q); 
      if (this.r != 0)
        this.p.setTextAppearance(getContext(), this.r); 
    } 
    this.o.setText(this.j);
    this.p.setText(this.k);
    boolean bool1 = TextUtils.isEmpty(this.j);
    int i = TextUtils.isEmpty(this.k) ^ true;
    TextView textView = this.p;
    boolean bool = false;
    if (i != 0) {
      b = 0;
    } else {
      b = 8;
    } 
    textView.setVisibility(b);
    LinearLayout linearLayout = this.n;
    byte b = bool;
    if ((bool1 ^ true) == 0)
      if (i != 0) {
        b = bool;
      } else {
        b = 8;
      }  
    linearLayout.setVisibility(b);
    if (this.n.getParent() == null)
      addView((View)this.n); 
  }
  
  public void g() {
    if (this.l == null)
      k(); 
  }
  
  protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new ViewGroup.MarginLayoutParams(-1, -2);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new ViewGroup.MarginLayoutParams(getContext(), paramAttributeSet);
  }
  
  public CharSequence getSubtitle() {
    return this.k;
  }
  
  public CharSequence getTitle() {
    return this.j;
  }
  
  public void h(b paramb) {
    View view = this.l;
    if (view == null) {
      view = LayoutInflater.from(getContext()).inflate(this.t, this, false);
      this.l = view;
      addView(view);
    } else if (view.getParent() == null) {
      addView(this.l);
    } 
    this.l.findViewById(f.i).setOnClickListener(new a(this, paramb));
    e e = (e)paramb.e();
    c c = this.e;
    if (c != null)
      c.y(); 
    c = new c(getContext());
    this.e = c;
    c.J(true);
    ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
    e.c((j)this.e, this.c);
    ActionMenuView actionMenuView = (ActionMenuView)this.e.o(this);
    this.d = actionMenuView;
    ViewCompat.setBackground((View)actionMenuView, null);
    addView((View)this.d, layoutParams);
  }
  
  public boolean j() {
    return this.s;
  }
  
  public void k() {
    removeAllViews();
    this.m = null;
    this.d = null;
  }
  
  public boolean l() {
    c c = this.e;
    return (c != null) ? c.K() : false;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    c c = this.e;
    if (c != null) {
      c.B();
      this.e.C();
    } 
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    if (paramAccessibilityEvent.getEventType() == 32) {
      paramAccessibilityEvent.setSource((View)this);
      paramAccessibilityEvent.setClassName(getClass().getName());
      paramAccessibilityEvent.setPackageName(getContext().getPackageName());
      paramAccessibilityEvent.setContentDescription(this.j);
      return;
    } 
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i;
    paramBoolean = q1.b((View)this);
    if (paramBoolean) {
      i = paramInt3 - paramInt1 - getPaddingRight();
    } else {
      i = getPaddingLeft();
    } 
    int j = getPaddingTop();
    int k = paramInt4 - paramInt2 - getPaddingTop() - getPaddingBottom();
    View view2 = this.l;
    paramInt2 = i;
    if (view2 != null) {
      paramInt2 = i;
      if (view2.getVisibility() != 8) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.l.getLayoutParams();
        if (paramBoolean) {
          paramInt2 = marginLayoutParams.rightMargin;
        } else {
          paramInt2 = marginLayoutParams.leftMargin;
        } 
        if (paramBoolean) {
          paramInt4 = marginLayoutParams.leftMargin;
        } else {
          paramInt4 = marginLayoutParams.rightMargin;
        } 
        paramInt2 = a.d(i, paramInt2, paramBoolean);
        paramInt2 = a.d(paramInt2 + e(this.l, paramInt2, j, k, paramBoolean), paramInt4, paramBoolean);
      } 
    } 
    LinearLayout linearLayout = this.n;
    paramInt4 = paramInt2;
    if (linearLayout != null) {
      paramInt4 = paramInt2;
      if (this.m == null) {
        paramInt4 = paramInt2;
        if (linearLayout.getVisibility() != 8)
          paramInt4 = paramInt2 + e((View)this.n, paramInt2, j, k, paramBoolean); 
      } 
    } 
    View view1 = this.m;
    if (view1 != null)
      e(view1, paramInt4, j, k, paramBoolean); 
    if (paramBoolean) {
      paramInt1 = getPaddingLeft();
    } else {
      paramInt1 = paramInt3 - paramInt1 - getPaddingRight();
    } 
    ActionMenuView actionMenuView = this.d;
    if (actionMenuView != null)
      e((View)actionMenuView, paramInt1, j, k, paramBoolean ^ true); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.getMode(paramInt1);
    int j = 1073741824;
    if (i == 1073741824) {
      if (View.MeasureSpec.getMode(paramInt2) != 0) {
        int n = View.MeasureSpec.getSize(paramInt1);
        i = this.f;
        if (i <= 0)
          i = View.MeasureSpec.getSize(paramInt2); 
        int i1 = getPaddingTop() + getPaddingBottom();
        paramInt1 = n - getPaddingLeft() - getPaddingRight();
        int m = i - i1;
        int k = View.MeasureSpec.makeMeasureSpec(m, -2147483648);
        View view2 = this.l;
        boolean bool = false;
        paramInt2 = paramInt1;
        if (view2 != null) {
          paramInt1 = c(view2, paramInt1, k, 0);
          ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.l.getLayoutParams();
          paramInt2 = paramInt1 - marginLayoutParams.leftMargin + marginLayoutParams.rightMargin;
        } 
        ActionMenuView actionMenuView = this.d;
        paramInt1 = paramInt2;
        if (actionMenuView != null) {
          paramInt1 = paramInt2;
          if (actionMenuView.getParent() == this)
            paramInt1 = c((View)this.d, paramInt2, k, 0); 
        } 
        LinearLayout linearLayout = this.n;
        paramInt2 = paramInt1;
        if (linearLayout != null) {
          paramInt2 = paramInt1;
          if (this.m == null)
            if (this.s) {
              paramInt2 = View.MeasureSpec.makeMeasureSpec(0, 0);
              this.n.measure(paramInt2, k);
              int i2 = this.n.getMeasuredWidth();
              if (i2 <= paramInt1) {
                k = 1;
              } else {
                k = 0;
              } 
              paramInt2 = paramInt1;
              if (k != 0)
                paramInt2 = paramInt1 - i2; 
              linearLayout = this.n;
              if (k != 0) {
                paramInt1 = 0;
              } else {
                paramInt1 = 8;
              } 
              linearLayout.setVisibility(paramInt1);
            } else {
              paramInt2 = c((View)linearLayout, paramInt1, k, 0);
            }  
        } 
        View view1 = this.m;
        if (view1 != null) {
          ViewGroup.LayoutParams layoutParams = view1.getLayoutParams();
          int i2 = layoutParams.width;
          if (i2 != -2) {
            paramInt1 = 1073741824;
          } else {
            paramInt1 = Integer.MIN_VALUE;
          } 
          k = paramInt2;
          if (i2 >= 0)
            k = Math.min(i2, paramInt2); 
          i2 = layoutParams.height;
          if (i2 != -2) {
            paramInt2 = j;
          } else {
            paramInt2 = Integer.MIN_VALUE;
          } 
          j = m;
          if (i2 >= 0)
            j = Math.min(i2, m); 
          this.m.measure(View.MeasureSpec.makeMeasureSpec(k, paramInt1), View.MeasureSpec.makeMeasureSpec(j, paramInt2));
        } 
        if (this.f <= 0) {
          j = getChildCount();
          paramInt2 = 0;
          paramInt1 = bool;
          while (paramInt1 < j) {
            k = getChildAt(paramInt1).getMeasuredHeight() + i1;
            i = paramInt2;
            if (k > paramInt2)
              i = k; 
            paramInt1++;
            paramInt2 = i;
          } 
          setMeasuredDimension(n, paramInt2);
          return;
        } 
        setMeasuredDimension(n, i);
        return;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(getClass().getSimpleName());
      stringBuilder1.append(" can only be used with android:layout_height=\"wrap_content\"");
      throw new IllegalStateException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void setContentHeight(int paramInt) {
    this.f = paramInt;
  }
  
  public void setCustomView(View paramView) {
    View view = this.m;
    if (view != null)
      removeView(view); 
    this.m = paramView;
    if (paramView != null) {
      LinearLayout linearLayout = this.n;
      if (linearLayout != null) {
        removeView((View)linearLayout);
        this.n = null;
      } 
    } 
    if (paramView != null)
      addView(paramView); 
    requestLayout();
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    this.k = paramCharSequence;
    i();
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.j = paramCharSequence;
    i();
  }
  
  public void setTitleOptional(boolean paramBoolean) {
    if (paramBoolean != this.s)
      requestLayout(); 
    this.s = paramBoolean;
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  class a implements View.OnClickListener {
    a(ActionBarContextView this$0, b param1b) {}
    
    public void onClick(View param1View) {
      this.b.c();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\ActionBarContextView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */