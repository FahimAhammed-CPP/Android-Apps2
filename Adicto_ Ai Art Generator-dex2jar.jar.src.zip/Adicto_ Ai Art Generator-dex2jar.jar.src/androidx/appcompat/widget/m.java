package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.core.view.ViewCompat;
import androidx.core.widget.h;
import f.j;
import h.b;

public class m {
  @NonNull
  private final ImageView a;
  
  private h1 b;
  
  private h1 c;
  
  private h1 d;
  
  public m(@NonNull ImageView paramImageView) {
    this.a = paramImageView;
  }
  
  private boolean a(@NonNull Drawable paramDrawable) {
    if (this.d == null)
      this.d = new h1(); 
    h1 h11 = this.d;
    h11.a();
    ColorStateList colorStateList = h.a(this.a);
    if (colorStateList != null) {
      h11.d = true;
      h11.a = colorStateList;
    } 
    PorterDuff.Mode mode = h.b(this.a);
    if (mode != null) {
      h11.c = true;
      h11.b = mode;
    } 
    if (h11.d || h11.c) {
      i.i(paramDrawable, h11, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  private boolean j() {
    int i = Build.VERSION.SDK_INT;
    return (i > 21) ? ((this.b != null)) : ((i == 21));
  }
  
  void b() {
    Drawable drawable = this.a.getDrawable();
    if (drawable != null)
      l0.b(drawable); 
    if (drawable != null) {
      if (j() && a(drawable))
        return; 
      h1 h11 = this.c;
      if (h11 != null) {
        i.i(drawable, h11, this.a.getDrawableState());
        return;
      } 
      h11 = this.b;
      if (h11 != null)
        i.i(drawable, h11, this.a.getDrawableState()); 
    } 
  }
  
  ColorStateList c() {
    h1 h11 = this.c;
    return (h11 != null) ? h11.a : null;
  }
  
  PorterDuff.Mode d() {
    h1 h11 = this.c;
    return (h11 != null) ? h11.b : null;
  }
  
  boolean e() {
    return !(this.a.getBackground() instanceof android.graphics.drawable.RippleDrawable);
  }
  
  public void f(AttributeSet paramAttributeSet, int paramInt) {
    Context context = this.a.getContext();
    int[] arrayOfInt = j.R;
    j1 j1 = j1.u(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    ImageView imageView = this.a;
    ViewCompat.saveAttributeDataForStyleable((View)imageView, imageView.getContext(), arrayOfInt, paramAttributeSet, j1.q(), paramInt, 0);
    try {
      Drawable drawable2 = this.a.getDrawable();
      Drawable drawable1 = drawable2;
      if (drawable2 == null) {
        paramInt = j1.m(j.S, -1);
        drawable1 = drawable2;
        if (paramInt != -1) {
          drawable2 = b.d(this.a.getContext(), paramInt);
          drawable1 = drawable2;
          if (drawable2 != null) {
            this.a.setImageDrawable(drawable2);
            drawable1 = drawable2;
          } 
        } 
      } 
      if (drawable1 != null)
        l0.b(drawable1); 
      paramInt = j.T;
      if (j1.r(paramInt))
        h.c(this.a, j1.c(paramInt)); 
      paramInt = j.U;
      if (j1.r(paramInt))
        h.d(this.a, l0.d(j1.j(paramInt, -1), null)); 
      return;
    } finally {
      j1.v();
    } 
  }
  
  public void g(int paramInt) {
    if (paramInt != 0) {
      Drawable drawable = b.d(this.a.getContext(), paramInt);
      if (drawable != null)
        l0.b(drawable); 
      this.a.setImageDrawable(drawable);
    } else {
      this.a.setImageDrawable(null);
    } 
    b();
  }
  
  void h(ColorStateList paramColorStateList) {
    if (this.c == null)
      this.c = new h1(); 
    h1 h11 = this.c;
    h11.a = paramColorStateList;
    h11.d = true;
    b();
  }
  
  void i(PorterDuff.Mode paramMode) {
    if (this.c == null)
      this.c = new h1(); 
    h1 h11 = this.c;
    h11.b = paramMode;
    h11.c = true;
    b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */