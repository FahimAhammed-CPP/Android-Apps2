package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.view.menu.j;
import androidx.core.view.l2;

public interface k0 {
  boolean a();
  
  boolean b();
  
  boolean c();
  
  void collapseActionView();
  
  void d(Menu paramMenu, j.a parama);
  
  boolean e();
  
  void f();
  
  boolean g();
  
  Context getContext();
  
  CharSequence getTitle();
  
  boolean h();
  
  void i(int paramInt);
  
  int j();
  
  l2 k(int paramInt, long paramLong);
  
  ViewGroup l();
  
  void m(boolean paramBoolean);
  
  void n();
  
  void o(boolean paramBoolean);
  
  void p();
  
  void q(c1 paramc1);
  
  void r(int paramInt);
  
  void s(int paramInt);
  
  void setIcon(int paramInt);
  
  void setIcon(Drawable paramDrawable);
  
  void setWindowCallback(Window.Callback paramCallback);
  
  void setWindowTitle(CharSequence paramCharSequence);
  
  int t();
  
  void u();
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\k0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */