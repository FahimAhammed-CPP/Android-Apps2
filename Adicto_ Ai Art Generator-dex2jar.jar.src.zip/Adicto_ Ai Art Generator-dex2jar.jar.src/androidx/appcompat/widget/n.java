package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.MultiAutoCompleteTextView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import f.a;
import h.b;

public class n extends MultiAutoCompleteTextView {
  private static final int[] d = new int[] { 16843126 };
  
  private final e b;
  
  private final c0 c;
  
  public n(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.p);
  }
  
  public n(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt) {
    super(g1.b(paramContext), paramAttributeSet, paramInt);
    e1.a((View)this, getContext());
    j1 j1 = j1.u(getContext(), paramAttributeSet, d, paramInt, 0);
    if (j1.r(0))
      setDropDownBackgroundDrawable(j1.f(0)); 
    j1.v();
    e e1 = new e((View)this);
    this.b = e1;
    e1.e(paramAttributeSet, paramInt);
    c0 c01 = new c0((TextView)this);
    this.c = c01;
    c01.m(paramAttributeSet, paramInt);
    c01.b();
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.b;
    if (e1 != null)
      e1.b(); 
    c0 c01 = this.c;
    if (c01 != null)
      c01.b(); 
  }
  
  @Nullable
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.b;
    return (e1 != null) ? e1.c() : null;
  }
  
  @Nullable
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.b;
    return (e1 != null) ? e1.d() : null;
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    return k.a(super.onCreateInputConnection(paramEditorInfo), paramEditorInfo, (View)this);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.b;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.b;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setDropDownBackgroundResource(int paramInt) {
    setDropDownBackgroundDrawable(b.d(getContext(), paramInt));
  }
  
  public void setSupportBackgroundTintList(@Nullable ColorStateList paramColorStateList) {
    e e1 = this.b;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(@Nullable PorterDuff.Mode paramMode) {
    e e1 = this.b;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    c0 c01 = this.c;
    if (c01 != null)
      c01.q(paramContext, paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */