package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.collection.g;
import androidx.collection.h;
import androidx.vectordrawable.graphics.drawable.g;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public final class z0 {
  private static final PorterDuff.Mode h = PorterDuff.Mode.SRC_IN;
  
  private static z0 i;
  
  private static final c j = new c(6);
  
  private WeakHashMap<Context, h<ColorStateList>> a;
  
  private g<String, d> b;
  
  private h<String> c;
  
  private final WeakHashMap<Context, androidx.collection.d<WeakReference<Drawable.ConstantState>>> d = new WeakHashMap<Context, androidx.collection.d<WeakReference<Drawable.ConstantState>>>(0);
  
  private TypedValue e;
  
  private boolean f;
  
  private e g;
  
  private void a(@NonNull String paramString, @NonNull d paramd) {
    if (this.b == null)
      this.b = new g(); 
    this.b.put(paramString, paramd);
  }
  
  private boolean b(@NonNull Context paramContext, long paramLong, @NonNull Drawable paramDrawable) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload #4
    //   4: invokevirtual getConstantState : ()Landroid/graphics/drawable/Drawable$ConstantState;
    //   7: astore #6
    //   9: aload #6
    //   11: ifnull -> 75
    //   14: aload_0
    //   15: getfield d : Ljava/util/WeakHashMap;
    //   18: aload_1
    //   19: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   22: checkcast androidx/collection/d
    //   25: astore #5
    //   27: aload #5
    //   29: astore #4
    //   31: aload #5
    //   33: ifnonnull -> 56
    //   36: new androidx/collection/d
    //   39: dup
    //   40: invokespecial <init> : ()V
    //   43: astore #4
    //   45: aload_0
    //   46: getfield d : Ljava/util/WeakHashMap;
    //   49: aload_1
    //   50: aload #4
    //   52: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   55: pop
    //   56: aload #4
    //   58: lload_2
    //   59: new java/lang/ref/WeakReference
    //   62: dup
    //   63: aload #6
    //   65: invokespecial <init> : (Ljava/lang/Object;)V
    //   68: invokevirtual i : (JLjava/lang/Object;)V
    //   71: aload_0
    //   72: monitorexit
    //   73: iconst_1
    //   74: ireturn
    //   75: aload_0
    //   76: monitorexit
    //   77: iconst_0
    //   78: ireturn
    //   79: astore_1
    //   80: aload_0
    //   81: monitorexit
    //   82: aload_1
    //   83: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	79	finally
    //   14	27	79	finally
    //   36	56	79	finally
    //   56	71	79	finally
  }
  
  private void c(@NonNull Context paramContext, int paramInt, @NonNull ColorStateList paramColorStateList) {
    if (this.a == null)
      this.a = new WeakHashMap<Context, h<ColorStateList>>(); 
    h<ColorStateList> h2 = this.a.get(paramContext);
    h<ColorStateList> h1 = h2;
    if (h2 == null) {
      h1 = new h();
      this.a.put(paramContext, h1);
    } 
    h1.a(paramInt, paramColorStateList);
  }
  
  private void d(@NonNull Context paramContext) {
    if (this.f)
      return; 
    this.f = true;
    Drawable drawable = j(paramContext, j.a.a);
    if (drawable != null && q(drawable))
      return; 
    this.f = false;
    throw new IllegalStateException("This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.");
  }
  
  private static long e(TypedValue paramTypedValue) {
    return paramTypedValue.assetCookie << 32L | paramTypedValue.data;
  }
  
  private Drawable f(@NonNull Context paramContext, int paramInt) {
    Drawable drawable1;
    if (this.e == null)
      this.e = new TypedValue(); 
    TypedValue typedValue = this.e;
    paramContext.getResources().getValue(paramInt, typedValue, true);
    long l = e(typedValue);
    Drawable drawable2 = i(paramContext, l);
    if (drawable2 != null)
      return drawable2; 
    e e1 = this.g;
    if (e1 == null) {
      e1 = null;
    } else {
      drawable1 = e1.a(this, paramContext, paramInt);
    } 
    if (drawable1 != null) {
      drawable1.setChangingConfigurations(typedValue.changingConfigurations);
      b(paramContext, l, drawable1);
    } 
    return drawable1;
  }
  
  private static PorterDuffColorFilter g(ColorStateList paramColorStateList, PorterDuff.Mode paramMode, int[] paramArrayOfint) {
    return (paramColorStateList == null || paramMode == null) ? null : l(paramColorStateList.getColorForState(paramArrayOfint, 0), paramMode);
  }
  
  public static z0 h() {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/z0
    //   2: monitorenter
    //   3: getstatic androidx/appcompat/widget/z0.i : Landroidx/appcompat/widget/z0;
    //   6: ifnonnull -> 25
    //   9: new androidx/appcompat/widget/z0
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: astore_0
    //   17: aload_0
    //   18: putstatic androidx/appcompat/widget/z0.i : Landroidx/appcompat/widget/z0;
    //   21: aload_0
    //   22: invokestatic p : (Landroidx/appcompat/widget/z0;)V
    //   25: getstatic androidx/appcompat/widget/z0.i : Landroidx/appcompat/widget/z0;
    //   28: astore_0
    //   29: ldc androidx/appcompat/widget/z0
    //   31: monitorexit
    //   32: aload_0
    //   33: areturn
    //   34: astore_0
    //   35: ldc androidx/appcompat/widget/z0
    //   37: monitorexit
    //   38: aload_0
    //   39: athrow
    // Exception table:
    //   from	to	target	type
    //   3	25	34	finally
    //   25	29	34	finally
  }
  
  private Drawable i(@NonNull Context paramContext, long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : Ljava/util/WeakHashMap;
    //   6: aload_1
    //   7: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   10: checkcast androidx/collection/d
    //   13: astore #4
    //   15: aload #4
    //   17: ifnonnull -> 24
    //   20: aload_0
    //   21: monitorexit
    //   22: aconst_null
    //   23: areturn
    //   24: aload #4
    //   26: lload_2
    //   27: invokevirtual f : (J)Ljava/lang/Object;
    //   30: checkcast java/lang/ref/WeakReference
    //   33: astore #5
    //   35: aload #5
    //   37: ifnull -> 75
    //   40: aload #5
    //   42: invokevirtual get : ()Ljava/lang/Object;
    //   45: checkcast android/graphics/drawable/Drawable$ConstantState
    //   48: astore #5
    //   50: aload #5
    //   52: ifnull -> 69
    //   55: aload #5
    //   57: aload_1
    //   58: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   61: invokevirtual newDrawable : (Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    //   64: astore_1
    //   65: aload_0
    //   66: monitorexit
    //   67: aload_1
    //   68: areturn
    //   69: aload #4
    //   71: lload_2
    //   72: invokevirtual j : (J)V
    //   75: aload_0
    //   76: monitorexit
    //   77: aconst_null
    //   78: areturn
    //   79: astore_1
    //   80: aload_0
    //   81: monitorexit
    //   82: aload_1
    //   83: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	79	finally
    //   24	35	79	finally
    //   40	50	79	finally
    //   55	65	79	finally
    //   69	75	79	finally
  }
  
  public static PorterDuffColorFilter l(int paramInt, PorterDuff.Mode paramMode) {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/z0
    //   2: monitorenter
    //   3: getstatic androidx/appcompat/widget/z0.j : Landroidx/appcompat/widget/z0$c;
    //   6: astore #4
    //   8: aload #4
    //   10: iload_0
    //   11: aload_1
    //   12: invokevirtual b : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
    //   15: astore_3
    //   16: aload_3
    //   17: astore_2
    //   18: aload_3
    //   19: ifnonnull -> 41
    //   22: new android/graphics/PorterDuffColorFilter
    //   25: dup
    //   26: iload_0
    //   27: aload_1
    //   28: invokespecial <init> : (ILandroid/graphics/PorterDuff$Mode;)V
    //   31: astore_2
    //   32: aload #4
    //   34: iload_0
    //   35: aload_1
    //   36: aload_2
    //   37: invokevirtual c : (ILandroid/graphics/PorterDuff$Mode;Landroid/graphics/PorterDuffColorFilter;)Landroid/graphics/PorterDuffColorFilter;
    //   40: pop
    //   41: ldc androidx/appcompat/widget/z0
    //   43: monitorexit
    //   44: aload_2
    //   45: areturn
    //   46: astore_1
    //   47: ldc androidx/appcompat/widget/z0
    //   49: monitorexit
    //   50: aload_1
    //   51: athrow
    // Exception table:
    //   from	to	target	type
    //   3	16	46	finally
    //   22	41	46	finally
  }
  
  private ColorStateList n(@NonNull Context paramContext, int paramInt) {
    WeakHashMap<Context, h<ColorStateList>> weakHashMap = this.a;
    ColorStateList colorStateList2 = null;
    ColorStateList colorStateList1 = colorStateList2;
    if (weakHashMap != null) {
      h h1 = weakHashMap.get(paramContext);
      colorStateList1 = colorStateList2;
      if (h1 != null)
        colorStateList1 = (ColorStateList)h1.f(paramInt); 
    } 
    return colorStateList1;
  }
  
  private static void p(@NonNull z0 paramz0) {
    if (Build.VERSION.SDK_INT < 24) {
      paramz0.a("vector", new f());
      paramz0.a("animated-vector", new b());
      paramz0.a("animated-selector", new a());
    } 
  }
  
  private static boolean q(@NonNull Drawable paramDrawable) {
    return (paramDrawable instanceof g || "android.graphics.drawable.VectorDrawable".equals(paramDrawable.getClass().getName()));
  }
  
  private Drawable r(@NonNull Context paramContext, int paramInt) {
    g<String, d> g1 = this.b;
    if (g1 != null && !g1.isEmpty()) {
      h<String> h1 = this.c;
      if (h1 != null) {
        String str = (String)h1.f(paramInt);
        if ("appcompat_skip_skip".equals(str) || (str != null && this.b.get(str) == null))
          return null; 
      } else {
        this.c = new h();
      } 
      if (this.e == null)
        this.e = new TypedValue(); 
      TypedValue typedValue = this.e;
      Resources resources = paramContext.getResources();
      resources.getValue(paramInt, typedValue, true);
      long l = e(typedValue);
      Drawable drawable1 = i(paramContext, l);
      if (drawable1 != null)
        return drawable1; 
      CharSequence charSequence = typedValue.string;
      Drawable drawable2 = drawable1;
      if (charSequence != null) {
        drawable2 = drawable1;
        if (charSequence.toString().endsWith(".xml")) {
          drawable2 = drawable1;
          try {
            int i;
            XmlResourceParser xmlResourceParser = resources.getXml(paramInt);
            drawable2 = drawable1;
            AttributeSet attributeSet = Xml.asAttributeSet((XmlPullParser)xmlResourceParser);
            while (true) {
              drawable2 = drawable1;
              i = xmlResourceParser.next();
              if (i != 2 && i != 1)
                continue; 
              break;
            } 
            if (i == 2) {
              drawable2 = drawable1;
              String str = xmlResourceParser.getName();
              drawable2 = drawable1;
              this.c.a(paramInt, str);
              drawable2 = drawable1;
              d d = (d)this.b.get(str);
              Drawable drawable = drawable1;
              if (d != null) {
                drawable2 = drawable1;
                drawable = d.a(paramContext, (XmlPullParser)xmlResourceParser, attributeSet, paramContext.getTheme());
              } 
              drawable2 = drawable;
              if (drawable != null) {
                drawable2 = drawable;
                drawable.setChangingConfigurations(typedValue.changingConfigurations);
                drawable2 = drawable;
                b(paramContext, l, drawable);
                drawable2 = drawable;
              } 
            } else {
              drawable2 = drawable1;
              throw new XmlPullParserException("No start tag found");
            } 
          } catch (Exception exception) {
            Log.e("ResourceManagerInternal", "Exception while inflating drawable", exception);
          } 
        } 
      } 
      if (drawable2 == null)
        this.c.a(paramInt, "appcompat_skip_skip"); 
      return drawable2;
    } 
    return null;
  }
  
  private Drawable v(@NonNull Context paramContext, int paramInt, boolean paramBoolean, @NonNull Drawable paramDrawable) {
    Drawable drawable;
    PorterDuff.Mode mode1;
    PorterDuff.Mode mode2;
    ColorStateList colorStateList = m(paramContext, paramInt);
    if (colorStateList != null) {
      drawable = paramDrawable;
      if (l0.a(paramDrawable))
        drawable = paramDrawable.mutate(); 
      drawable = androidx.core.graphics.drawable.a.p(drawable);
      androidx.core.graphics.drawable.a.n(drawable, colorStateList);
      mode1 = o(paramInt);
      Drawable drawable1 = drawable;
      if (mode1 != null) {
        androidx.core.graphics.drawable.a.o(drawable, mode1);
        return drawable;
      } 
    } else {
      e e1 = this.g;
      if (e1 != null && e1.e((Context)drawable, paramInt, (Drawable)mode1))
        return (Drawable)mode1; 
      mode2 = mode1;
      if (!x((Context)drawable, paramInt, (Drawable)mode1)) {
        mode2 = mode1;
        if (paramBoolean)
          mode2 = null; 
      } 
    } 
    return (Drawable)mode2;
  }
  
  static void w(Drawable paramDrawable, h1 paramh1, int[] paramArrayOfint) {
    if (l0.a(paramDrawable) && paramDrawable.mutate() != paramDrawable) {
      Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
      return;
    } 
    boolean bool = paramh1.d;
    if (bool || paramh1.c) {
      PorterDuff.Mode mode;
      ColorStateList colorStateList;
      if (bool) {
        colorStateList = paramh1.a;
      } else {
        colorStateList = null;
      } 
      if (paramh1.c) {
        mode = paramh1.b;
      } else {
        mode = h;
      } 
      paramDrawable.setColorFilter((ColorFilter)g(colorStateList, mode, paramArrayOfint));
    } else {
      paramDrawable.clearColorFilter();
    } 
    if (Build.VERSION.SDK_INT <= 23)
      paramDrawable.invalidateSelf(); 
  }
  
  public Drawable j(@NonNull Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: iload_2
    //   5: iconst_0
    //   6: invokevirtual k : (Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;
    //   9: astore_1
    //   10: aload_0
    //   11: monitorexit
    //   12: aload_1
    //   13: areturn
    //   14: astore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_1
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	14	finally
  }
  
  Drawable k(@NonNull Context paramContext, int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: invokespecial d : (Landroid/content/Context;)V
    //   7: aload_0
    //   8: aload_1
    //   9: iload_2
    //   10: invokespecial r : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   13: astore #5
    //   15: aload #5
    //   17: astore #4
    //   19: aload #5
    //   21: ifnonnull -> 32
    //   24: aload_0
    //   25: aload_1
    //   26: iload_2
    //   27: invokespecial f : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   30: astore #4
    //   32: aload #4
    //   34: astore #5
    //   36: aload #4
    //   38: ifnonnull -> 48
    //   41: aload_1
    //   42: iload_2
    //   43: invokestatic getDrawable : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   46: astore #5
    //   48: aload #5
    //   50: astore #4
    //   52: aload #5
    //   54: ifnull -> 68
    //   57: aload_0
    //   58: aload_1
    //   59: iload_2
    //   60: iload_3
    //   61: aload #5
    //   63: invokespecial v : (Landroid/content/Context;IZLandroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    //   66: astore #4
    //   68: aload #4
    //   70: ifnull -> 78
    //   73: aload #4
    //   75: invokestatic b : (Landroid/graphics/drawable/Drawable;)V
    //   78: aload_0
    //   79: monitorexit
    //   80: aload #4
    //   82: areturn
    //   83: astore_1
    //   84: aload_0
    //   85: monitorexit
    //   86: aload_1
    //   87: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	83	finally
    //   24	32	83	finally
    //   41	48	83	finally
    //   57	68	83	finally
    //   73	78	83	finally
  }
  
  ColorStateList m(@NonNull Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: iload_2
    //   5: invokespecial n : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   8: astore_3
    //   9: aload_3
    //   10: astore #4
    //   12: aload_3
    //   13: ifnonnull -> 56
    //   16: aload_0
    //   17: getfield g : Landroidx/appcompat/widget/z0$e;
    //   20: astore_3
    //   21: aload_3
    //   22: ifnonnull -> 30
    //   25: aconst_null
    //   26: astore_3
    //   27: goto -> 39
    //   30: aload_3
    //   31: aload_1
    //   32: iload_2
    //   33: invokeinterface b : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   38: astore_3
    //   39: aload_3
    //   40: astore #4
    //   42: aload_3
    //   43: ifnull -> 56
    //   46: aload_0
    //   47: aload_1
    //   48: iload_2
    //   49: aload_3
    //   50: invokespecial c : (Landroid/content/Context;ILandroid/content/res/ColorStateList;)V
    //   53: aload_3
    //   54: astore #4
    //   56: aload_0
    //   57: monitorexit
    //   58: aload #4
    //   60: areturn
    //   61: astore_1
    //   62: aload_0
    //   63: monitorexit
    //   64: aload_1
    //   65: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	61	finally
    //   16	21	61	finally
    //   30	39	61	finally
    //   46	53	61	finally
  }
  
  PorterDuff.Mode o(int paramInt) {
    e e1 = this.g;
    return (e1 == null) ? null : e1.d(paramInt);
  }
  
  public void s(@NonNull Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : Ljava/util/WeakHashMap;
    //   6: aload_1
    //   7: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   10: checkcast androidx/collection/d
    //   13: astore_1
    //   14: aload_1
    //   15: ifnull -> 22
    //   18: aload_1
    //   19: invokevirtual b : ()V
    //   22: aload_0
    //   23: monitorexit
    //   24: return
    //   25: astore_1
    //   26: aload_0
    //   27: monitorexit
    //   28: aload_1
    //   29: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	25	finally
    //   18	22	25	finally
  }
  
  Drawable t(@NonNull Context paramContext, @NonNull p1 paramp1, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: iload_3
    //   5: invokespecial r : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   8: astore #5
    //   10: aload #5
    //   12: astore #4
    //   14: aload #5
    //   16: ifnonnull -> 26
    //   19: aload_2
    //   20: iload_3
    //   21: invokevirtual c : (I)Landroid/graphics/drawable/Drawable;
    //   24: astore #4
    //   26: aload #4
    //   28: ifnull -> 45
    //   31: aload_0
    //   32: aload_1
    //   33: iload_3
    //   34: iconst_0
    //   35: aload #4
    //   37: invokespecial v : (Landroid/content/Context;IZLandroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    //   40: astore_1
    //   41: aload_0
    //   42: monitorexit
    //   43: aload_1
    //   44: areturn
    //   45: aload_0
    //   46: monitorexit
    //   47: aconst_null
    //   48: areturn
    //   49: astore_1
    //   50: aload_0
    //   51: monitorexit
    //   52: aload_1
    //   53: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	49	finally
    //   19	26	49	finally
    //   31	41	49	finally
  }
  
  public void u(e parame) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: putfield g : Landroidx/appcompat/widget/z0$e;
    //   7: aload_0
    //   8: monitorexit
    //   9: return
    //   10: astore_1
    //   11: aload_0
    //   12: monitorexit
    //   13: aload_1
    //   14: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	10	finally
  }
  
  boolean x(@NonNull Context paramContext, int paramInt, @NonNull Drawable paramDrawable) {
    e e1 = this.g;
    return (e1 != null && e1.c(paramContext, paramInt, paramDrawable));
  }
  
  @RequiresApi(11)
  static class a implements d {
    public Drawable a(@NonNull Context param1Context, @NonNull XmlPullParser param1XmlPullParser, @NonNull AttributeSet param1AttributeSet, @Nullable Resources.Theme param1Theme) {
      try {
        return (Drawable)i.a.m(param1Context, param1Context.getResources(), param1XmlPullParser, param1AttributeSet, param1Theme);
      } catch (Exception exception) {
        Log.e("AsldcInflateDelegate", "Exception while inflating <animated-selector>", exception);
        return null;
      } 
    }
  }
  
  private static class b implements d {
    public Drawable a(@NonNull Context param1Context, @NonNull XmlPullParser param1XmlPullParser, @NonNull AttributeSet param1AttributeSet, @Nullable Resources.Theme param1Theme) {
      try {
        return (Drawable)androidx.vectordrawable.graphics.drawable.b.a(param1Context, param1Context.getResources(), param1XmlPullParser, param1AttributeSet, param1Theme);
      } catch (Exception exception) {
        Log.e("AvdcInflateDelegate", "Exception while inflating <animated-vector>", exception);
        return null;
      } 
    }
  }
  
  private static class c extends androidx.collection.e<Integer, PorterDuffColorFilter> {
    public c(int param1Int) {
      super(param1Int);
    }
    
    private static int a(int param1Int, PorterDuff.Mode param1Mode) {
      return (param1Int + 31) * 31 + param1Mode.hashCode();
    }
    
    PorterDuffColorFilter b(int param1Int, PorterDuff.Mode param1Mode) {
      return (PorterDuffColorFilter)get(Integer.valueOf(a(param1Int, param1Mode)));
    }
    
    PorterDuffColorFilter c(int param1Int, PorterDuff.Mode param1Mode, PorterDuffColorFilter param1PorterDuffColorFilter) {
      return (PorterDuffColorFilter)put(Integer.valueOf(a(param1Int, param1Mode)), param1PorterDuffColorFilter);
    }
  }
  
  private static interface d {
    Drawable a(@NonNull Context param1Context, @NonNull XmlPullParser param1XmlPullParser, @NonNull AttributeSet param1AttributeSet, @Nullable Resources.Theme param1Theme);
  }
  
  static interface e {
    Drawable a(@NonNull z0 param1z0, @NonNull Context param1Context, int param1Int);
    
    ColorStateList b(@NonNull Context param1Context, int param1Int);
    
    boolean c(@NonNull Context param1Context, int param1Int, @NonNull Drawable param1Drawable);
    
    PorterDuff.Mode d(int param1Int);
    
    boolean e(@NonNull Context param1Context, int param1Int, @NonNull Drawable param1Drawable);
  }
  
  private static class f implements d {
    public Drawable a(@NonNull Context param1Context, @NonNull XmlPullParser param1XmlPullParser, @NonNull AttributeSet param1AttributeSet, @Nullable Resources.Theme param1Theme) {
      try {
        return (Drawable)g.c(param1Context.getResources(), param1XmlPullParser, param1AttributeSet, param1Theme);
      } catch (Exception exception) {
        Log.e("VdcInflateDelegate", "Exception while inflating <vector>", exception);
        return null;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\z0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */