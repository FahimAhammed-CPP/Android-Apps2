package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.ViewCompat;
import androidx.core.view.l2;
import androidx.core.view.m2;
import f.j;

abstract class a extends ViewGroup {
  protected final a b = new a(this);
  
  protected final Context c;
  
  protected ActionMenuView d;
  
  protected c e;
  
  protected int f;
  
  protected l2 g;
  
  private boolean h;
  
  private boolean i;
  
  a(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  a(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TypedValue typedValue = new TypedValue();
    if (paramContext.getTheme().resolveAttribute(f.a.a, typedValue, true) && typedValue.resourceId != 0) {
      this.c = (Context)new ContextThemeWrapper(paramContext, typedValue.resourceId);
      return;
    } 
    this.c = paramContext;
  }
  
  protected static int d(int paramInt1, int paramInt2, boolean paramBoolean) {
    return paramBoolean ? (paramInt1 - paramInt2) : (paramInt1 + paramInt2);
  }
  
  protected int c(View paramView, int paramInt1, int paramInt2, int paramInt3) {
    paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1, -2147483648), paramInt2);
    return Math.max(0, paramInt1 - paramView.getMeasuredWidth() - paramInt3);
  }
  
  protected int e(View paramView, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    int i = paramView.getMeasuredWidth();
    int j = paramView.getMeasuredHeight();
    paramInt2 += (paramInt3 - j) / 2;
    if (paramBoolean) {
      paramView.layout(paramInt1 - i, paramInt2, paramInt1, j + paramInt2);
    } else {
      paramView.layout(paramInt1, paramInt2, paramInt1 + i, j + paramInt2);
    } 
    paramInt1 = i;
    if (paramBoolean)
      paramInt1 = -i; 
    return paramInt1;
  }
  
  public l2 f(int paramInt, long paramLong) {
    l2 l21 = this.g;
    if (l21 != null)
      l21.c(); 
    if (paramInt == 0) {
      if (getVisibility() != 0)
        setAlpha(0.0F); 
      l21 = ViewCompat.animate((View)this).b(1.0F);
      l21.f(paramLong);
      l21.h(this.b.d(l21, paramInt));
      return l21;
    } 
    l21 = ViewCompat.animate((View)this).b(0.0F);
    l21.f(paramLong);
    l21.h(this.b.d(l21, paramInt));
    return l21;
  }
  
  public int getAnimatedVisibility() {
    return (this.g != null) ? this.b.b : getVisibility();
  }
  
  public int getContentHeight() {
    return this.f;
  }
  
  protected void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    TypedArray typedArray = getContext().obtainStyledAttributes(null, j.a, f.a.c, 0);
    setContentHeight(typedArray.getLayoutDimension(j.j, 0));
    typedArray.recycle();
    c c1 = this.e;
    if (c1 != null)
      c1.F(paramConfiguration); 
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.i = false; 
    if (!this.i) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.i = true; 
    } 
    if (i == 10 || i == 3)
      this.i = false; 
    return true;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.h = false; 
    if (!this.h) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.h = true; 
    } 
    if (i == 1 || i == 3)
      this.h = false; 
    return true;
  }
  
  public void setContentHeight(int paramInt) {
    this.f = paramInt;
    requestLayout();
  }
  
  public void setVisibility(int paramInt) {
    if (paramInt != getVisibility()) {
      l2 l21 = this.g;
      if (l21 != null)
        l21.c(); 
      super.setVisibility(paramInt);
    } 
  }
  
  protected class a implements m2 {
    private boolean a = false;
    
    int b;
    
    protected a(a this$0) {}
    
    public void a(View param1View) {
      this.a = true;
    }
    
    public void b(View param1View) {
      if (this.a)
        return; 
      a a1 = this.c;
      a1.g = null;
      a.b(a1, this.b);
    }
    
    public void c(View param1View) {
      a.a(this.c, 0);
      this.a = false;
    }
    
    public a d(l2 param1l2, int param1Int) {
      this.c.g = param1l2;
      this.b = param1Int;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */