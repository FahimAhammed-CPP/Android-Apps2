package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import androidx.annotation.NonNull;
import java.lang.ref.WeakReference;

class i1 extends a1 {
  private final WeakReference<Context> b;
  
  public i1(@NonNull Context paramContext, @NonNull Resources paramResources) {
    super(paramResources);
    this.b = new WeakReference<Context>(paramContext);
  }
  
  public Drawable getDrawable(int paramInt) throws Resources.NotFoundException {
    Drawable drawable = super.getDrawable(paramInt);
    Context context = this.b.get();
    if (drawable != null && context != null)
      z0.h().x(context, paramInt, drawable); 
    return drawable;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\appcompat\widget\i1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */