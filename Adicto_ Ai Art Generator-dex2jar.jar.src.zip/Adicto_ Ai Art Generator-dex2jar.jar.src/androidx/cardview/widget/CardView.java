package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import q.b;
import q.c;
import q.d;

public class CardView extends FrameLayout {
  private static final int[] i = new int[] { 16842801 };
  
  private static final c j;
  
  private boolean b;
  
  private boolean c;
  
  int d;
  
  int e;
  
  final Rect f;
  
  final Rect g;
  
  private final b h;
  
  static {
    a a = new a();
    j = a;
    a.k();
  }
  
  public CardView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, q.a.a);
  }
  
  public CardView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    ColorStateList colorStateList;
    Rect rect = new Rect();
    this.f = rect;
    this.g = new Rect();
    a a = new a(this);
    this.h = a;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, d.a, paramInt, c.a);
    paramInt = d.d;
    if (typedArray.hasValue(paramInt)) {
      colorStateList = typedArray.getColorStateList(paramInt);
    } else {
      TypedArray typedArray1 = getContext().obtainStyledAttributes(i);
      paramInt = typedArray1.getColor(0, 0);
      typedArray1.recycle();
      float[] arrayOfFloat = new float[3];
      Color.colorToHSV(paramInt, arrayOfFloat);
      if (arrayOfFloat[2] > 0.5F) {
        paramInt = getResources().getColor(b.b);
      } else {
        paramInt = getResources().getColor(b.a);
      } 
      colorStateList = ColorStateList.valueOf(paramInt);
    } 
    float f3 = typedArray.getDimension(d.e, 0.0F);
    float f2 = typedArray.getDimension(d.f, 0.0F);
    float f1 = typedArray.getDimension(d.g, 0.0F);
    this.b = typedArray.getBoolean(d.i, false);
    this.c = typedArray.getBoolean(d.h, true);
    paramInt = typedArray.getDimensionPixelSize(d.j, 0);
    rect.left = typedArray.getDimensionPixelSize(d.l, paramInt);
    rect.top = typedArray.getDimensionPixelSize(d.n, paramInt);
    rect.right = typedArray.getDimensionPixelSize(d.m, paramInt);
    rect.bottom = typedArray.getDimensionPixelSize(d.k, paramInt);
    if (f2 > f1)
      f1 = f2; 
    this.d = typedArray.getDimensionPixelSize(d.b, 0);
    this.e = typedArray.getDimensionPixelSize(d.c, 0);
    typedArray.recycle();
    j.h(a, paramContext, colorStateList, f3, f2, f1);
  }
  
  @NonNull
  public ColorStateList getCardBackgroundColor() {
    return j.e(this.h);
  }
  
  public float getCardElevation() {
    return j.i(this.h);
  }
  
  public int getContentPaddingBottom() {
    return this.f.bottom;
  }
  
  public int getContentPaddingLeft() {
    return this.f.left;
  }
  
  public int getContentPaddingRight() {
    return this.f.right;
  }
  
  public int getContentPaddingTop() {
    return this.f.top;
  }
  
  public float getMaxCardElevation() {
    return j.d(this.h);
  }
  
  public boolean getPreventCornerOverlap() {
    return this.c;
  }
  
  public float getRadius() {
    return j.b(this.h);
  }
  
  public boolean getUseCompatPadding() {
    return this.b;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    c c1 = j;
    if (!(c1 instanceof a)) {
      int i = View.MeasureSpec.getMode(paramInt1);
      if (i == Integer.MIN_VALUE || i == 1073741824)
        paramInt1 = View.MeasureSpec.makeMeasureSpec(Math.max((int)Math.ceil(c1.l(this.h)), View.MeasureSpec.getSize(paramInt1)), i); 
      i = View.MeasureSpec.getMode(paramInt2);
      if (i == Integer.MIN_VALUE || i == 1073741824)
        paramInt2 = View.MeasureSpec.makeMeasureSpec(Math.max((int)Math.ceil(c1.f(this.h)), View.MeasureSpec.getSize(paramInt2)), i); 
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setCardBackgroundColor(int paramInt) {
    j.m(this.h, ColorStateList.valueOf(paramInt));
  }
  
  public void setCardBackgroundColor(@Nullable ColorStateList paramColorStateList) {
    j.m(this.h, paramColorStateList);
  }
  
  public void setCardElevation(float paramFloat) {
    j.c(this.h, paramFloat);
  }
  
  public void setMaxCardElevation(float paramFloat) {
    j.n(this.h, paramFloat);
  }
  
  public void setMinimumHeight(int paramInt) {
    this.e = paramInt;
    super.setMinimumHeight(paramInt);
  }
  
  public void setMinimumWidth(int paramInt) {
    this.d = paramInt;
    super.setMinimumWidth(paramInt);
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public void setPaddingRelative(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public void setPreventCornerOverlap(boolean paramBoolean) {
    if (paramBoolean != this.c) {
      this.c = paramBoolean;
      j.g(this.h);
    } 
  }
  
  public void setRadius(float paramFloat) {
    j.a(this.h, paramFloat);
  }
  
  public void setUseCompatPadding(boolean paramBoolean) {
    if (this.b != paramBoolean) {
      this.b = paramBoolean;
      j.j(this.h);
    } 
  }
  
  class a implements b {
    private Drawable a;
    
    a(CardView this$0) {}
    
    public void a(Drawable param1Drawable) {
      this.a = param1Drawable;
      this.b.setBackgroundDrawable(param1Drawable);
    }
    
    public boolean b() {
      return this.b.getUseCompatPadding();
    }
    
    public Drawable c() {
      return this.a;
    }
    
    public void d(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.b.g.set(param1Int1, param1Int2, param1Int3, param1Int4);
      CardView cardView = this.b;
      Rect rect = cardView.f;
      CardView.a(cardView, param1Int1 + rect.left, param1Int2 + rect.top, param1Int3 + rect.right, param1Int4 + rect.bottom);
    }
    
    public boolean e() {
      return this.b.getPreventCornerOverlap();
    }
    
    public View f() {
      return (View)this.b;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\cardview\widget\CardView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */