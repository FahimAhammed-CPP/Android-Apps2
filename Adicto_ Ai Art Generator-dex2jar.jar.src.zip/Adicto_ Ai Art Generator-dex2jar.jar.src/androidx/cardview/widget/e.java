package androidx.cardview.widget;

import android.graphics.drawable.Drawable;

class e extends Drawable {
  private static final double a = Math.cos(Math.toRadians(45.0D));
  
  static float a(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    float f = paramFloat1;
    if (paramBoolean)
      f = (float)(paramFloat1 + (1.0D - a) * paramFloat2); 
    return f;
  }
  
  static float b(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return paramBoolean ? (float)((paramFloat1 * 1.5F) + (1.0D - a) * paramFloat2) : (paramFloat1 * 1.5F);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\cardview\widget\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */