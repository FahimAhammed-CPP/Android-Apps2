package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.View;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

@RequiresApi(21)
class a implements c {
  private d o(b paramb) {
    return (d)paramb.c();
  }
  
  public void a(b paramb, float paramFloat) {
    o(paramb).h(paramFloat);
  }
  
  public float b(b paramb) {
    return o(paramb).d();
  }
  
  public void c(b paramb, float paramFloat) {
    paramb.f().setElevation(paramFloat);
  }
  
  public float d(b paramb) {
    return o(paramb).c();
  }
  
  public ColorStateList e(b paramb) {
    return o(paramb).b();
  }
  
  public float f(b paramb) {
    return b(paramb) * 2.0F;
  }
  
  public void g(b paramb) {
    n(paramb, d(paramb));
  }
  
  public void h(b paramb, Context paramContext, ColorStateList paramColorStateList, float paramFloat1, float paramFloat2, float paramFloat3) {
    paramb.a(new d(paramColorStateList, paramFloat1));
    View view = paramb.f();
    view.setClipToOutline(true);
    view.setElevation(paramFloat2);
    n(paramb, paramFloat3);
  }
  
  public float i(b paramb) {
    return paramb.f().getElevation();
  }
  
  public void j(b paramb) {
    n(paramb, d(paramb));
  }
  
  public void k() {}
  
  public float l(b paramb) {
    return b(paramb) * 2.0F;
  }
  
  public void m(b paramb, @Nullable ColorStateList paramColorStateList) {
    o(paramb).f(paramColorStateList);
  }
  
  public void n(b paramb, float paramFloat) {
    o(paramb).g(paramFloat, paramb.b(), paramb.e());
    p(paramb);
  }
  
  public void p(b paramb) {
    if (!paramb.b()) {
      paramb.d(0, 0, 0, 0);
      return;
    } 
    float f1 = d(paramb);
    float f2 = b(paramb);
    int i = (int)Math.ceil(e.a(f1, f2, paramb.e()));
    int j = (int)Math.ceil(e.b(f1, f2, paramb.e()));
    paramb.d(i, j, i, j);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\cardview\widget\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */