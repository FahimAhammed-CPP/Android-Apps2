package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import androidx.annotation.Nullable;

interface c {
  void a(b paramb, float paramFloat);
  
  float b(b paramb);
  
  void c(b paramb, float paramFloat);
  
  float d(b paramb);
  
  ColorStateList e(b paramb);
  
  float f(b paramb);
  
  void g(b paramb);
  
  void h(b paramb, Context paramContext, ColorStateList paramColorStateList, float paramFloat1, float paramFloat2, float paramFloat3);
  
  float i(b paramb);
  
  void j(b paramb);
  
  void k();
  
  float l(b paramb);
  
  void m(b paramb, @Nullable ColorStateList paramColorStateList);
  
  void n(b paramb, float paramFloat);
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\cardview\widget\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */