package androidx.activity;

import id.w;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import kotlin.jvm.internal.l;
import ud.a;

public abstract class j {
  private boolean a;
  
  private final CopyOnWriteArrayList<a> b;
  
  private a<w> c;
  
  public j(boolean paramBoolean) {
    this.a = paramBoolean;
    this.b = new CopyOnWriteArrayList<a>();
  }
  
  public final void a(a parama) {
    l.e(parama, "cancellable");
    this.b.add(parama);
  }
  
  public abstract void b();
  
  public final boolean c() {
    return this.a;
  }
  
  public final void d() {
    Iterator<a> iterator = this.b.iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).cancel(); 
  }
  
  public final void e(a parama) {
    l.e(parama, "cancellable");
    this.b.remove(parama);
  }
  
  public final void f(boolean paramBoolean) {
    this.a = paramBoolean;
    a<w> a1 = this.c;
    if (a1 != null)
      a1.invoke(); 
  }
  
  public final void g(a<w> parama) {
    this.c = parama;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\activity\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */