package androidx.activity.result;

import e.d;
import kotlin.jvm.internal.l;

public final class f {
  private d.f a = (d.f)d.b.a;
  
  public final d.f a() {
    return this.a;
  }
  
  public final void b(d.f paramf) {
    l.e(paramf, "<set-?>");
    this.a = paramf;
  }
  
  public static final class a {
    private d.f a = (d.f)d.b.a;
    
    public final f a() {
      f f1 = new f();
      f1.b(this.a);
      return f1;
    }
    
    public final a b(d.f param1f) {
      l.e(param1f, "mediaType");
      this.a = param1f;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\activity\result\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */