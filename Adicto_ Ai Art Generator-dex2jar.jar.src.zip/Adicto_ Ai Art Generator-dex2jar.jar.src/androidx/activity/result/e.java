package androidx.activity.result;

import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.l;

public final class e implements Parcelable {
  public static final Parcelable.Creator<e> CREATOR;
  
  public static final c f = new c(null);
  
  private final IntentSender b;
  
  private final Intent c;
  
  private final int d;
  
  private final int e;
  
  static {
    CREATOR = new b();
  }
  
  public e(IntentSender paramIntentSender, Intent paramIntent, int paramInt1, int paramInt2) {
    this.b = paramIntentSender;
    this.c = paramIntent;
    this.d = paramInt1;
    this.e = paramInt2;
  }
  
  public e(Parcel paramParcel) {
    this((IntentSender)parcelable, (Intent)paramParcel.readParcelable(Intent.class.getClassLoader()), paramParcel.readInt(), paramParcel.readInt());
  }
  
  public final Intent c() {
    return this.c;
  }
  
  public final int d() {
    return this.d;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public final int e() {
    return this.e;
  }
  
  public final IntentSender f() {
    return this.b;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    l.e(paramParcel, "dest");
    paramParcel.writeParcelable((Parcelable)this.b, paramInt);
    paramParcel.writeParcelable((Parcelable)this.c, paramInt);
    paramParcel.writeInt(this.d);
    paramParcel.writeInt(this.e);
  }
  
  public static final class a {
    private final IntentSender a;
    
    private Intent b;
    
    private int c;
    
    private int d;
    
    public a(IntentSender param1IntentSender) {
      this.a = param1IntentSender;
    }
    
    public final e a() {
      return new e(this.a, this.b, this.c, this.d);
    }
    
    public final a b(Intent param1Intent) {
      this.b = param1Intent;
      return this;
    }
    
    public final a c(int param1Int1, int param1Int2) {
      this.d = param1Int1;
      this.c = param1Int2;
      return this;
    }
  }
  
  public static final class b implements Parcelable.Creator<e> {
    public e a(Parcel param1Parcel) {
      l.e(param1Parcel, "inParcel");
      return new e(param1Parcel);
    }
    
    public e[] b(int param1Int) {
      return new e[param1Int];
    }
  }
  
  public static final class c {
    private c() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\activity\result\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */