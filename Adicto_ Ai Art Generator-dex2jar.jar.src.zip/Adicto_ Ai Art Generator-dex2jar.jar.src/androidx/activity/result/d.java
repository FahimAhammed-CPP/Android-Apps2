package androidx.activity.result;

public interface d {
  ActivityResultRegistry getActivityResultRegistry();
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\activity\result\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */