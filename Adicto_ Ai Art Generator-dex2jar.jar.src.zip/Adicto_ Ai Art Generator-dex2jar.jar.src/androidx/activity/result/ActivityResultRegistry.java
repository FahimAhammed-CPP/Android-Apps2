package androidx.activity.result;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.f;
import androidx.lifecycle.g;
import androidx.lifecycle.j;
import androidx.lifecycle.k;
import androidx.lifecycle.l;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public abstract class ActivityResultRegistry {
  private Random a = new Random();
  
  private final Map<Integer, String> b = new HashMap<Integer, String>();
  
  final Map<String, Integer> c = new HashMap<String, Integer>();
  
  private final Map<String, d> d = new HashMap<String, d>();
  
  ArrayList<String> e = new ArrayList<String>();
  
  final transient Map<String, c<?>> f = new HashMap<String, c<?>>();
  
  final Map<String, Object> g = new HashMap<String, Object>();
  
  final Bundle h = new Bundle();
  
  private void a(int paramInt, String paramString) {
    this.b.put(Integer.valueOf(paramInt), paramString);
    this.c.put(paramString, Integer.valueOf(paramInt));
  }
  
  private <O> void d(String paramString, int paramInt, @Nullable Intent paramIntent, @Nullable c<O> paramc) {
    if (paramc != null && paramc.a != null && this.e.contains(paramString)) {
      paramc.a.a((O)paramc.b.c(paramInt, paramIntent));
      this.e.remove(paramString);
      return;
    } 
    this.g.remove(paramString);
    this.h.putParcelable(paramString, new a(paramInt, paramIntent));
  }
  
  private int e() {
    int i = this.a.nextInt(2147418112);
    while (true) {
      i += 65536;
      if (this.b.containsKey(Integer.valueOf(i))) {
        i = this.a.nextInt(2147418112);
        continue;
      } 
      return i;
    } 
  }
  
  private void k(String paramString) {
    if ((Integer)this.c.get(paramString) != null)
      return; 
    a(e(), paramString);
  }
  
  public final boolean b(int paramInt1, int paramInt2, @Nullable Intent paramIntent) {
    String str = this.b.get(Integer.valueOf(paramInt1));
    if (str == null)
      return false; 
    d(str, paramInt2, paramIntent, this.f.get(str));
    return true;
  }
  
  public final <O> boolean c(int paramInt, O paramO) {
    String str = this.b.get(Integer.valueOf(paramInt));
    if (str == null)
      return false; 
    c c = this.f.get(str);
    if (c != null) {
      b<O> b = c.a;
      if (b == null) {
        this.h.remove(str);
        this.g.put(str, paramO);
        return true;
      } 
      if (this.e.remove(str))
        b.a(paramO); 
      return true;
    } 
    this.h.remove(str);
    this.g.put(str, paramO);
    return true;
  }
  
  public abstract <I, O> void f(int paramInt, @NonNull e.a<I, O> parama, I paramI, @Nullable f paramf);
  
  public final void g(@Nullable Bundle paramBundle) {
    if (paramBundle == null)
      return; 
    ArrayList<Integer> arrayList = paramBundle.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
    ArrayList<String> arrayList1 = paramBundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
    if (arrayList1 != null) {
      if (arrayList == null)
        return; 
      this.e = paramBundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
      this.a = (Random)paramBundle.getSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT");
      this.h.putAll(paramBundle.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT"));
      for (int i = 0; i < arrayList1.size(); i++) {
        String str = arrayList1.get(i);
        if (this.c.containsKey(str)) {
          Integer integer = this.c.remove(str);
          if (!this.h.containsKey(str))
            this.b.remove(integer); 
        } 
        a(((Integer)arrayList.get(i)).intValue(), arrayList1.get(i));
      } 
    } 
  }
  
  public final void h(@NonNull Bundle paramBundle) {
    paramBundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList(this.c.values()));
    paramBundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList(this.c.keySet()));
    paramBundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList<String>(this.e));
    paramBundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle)this.h.clone());
    paramBundle.putSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT", this.a);
  }
  
  @NonNull
  public final <I, O> c<I> i(@NonNull String paramString, @NonNull l paraml, @NonNull e.a<I, O> parama, @NonNull b<O> paramb) {
    d d;
    g g = paraml.getLifecycle();
    if (!g.b().b(g.b.e)) {
      k(paramString);
      d d1 = this.d.get(paramString);
      d = d1;
      if (d1 == null)
        d = new d(g); 
      d.a(new j(this, paramString, paramb, parama) {
            public void onStateChanged(@NonNull l param1l, @NonNull g.a param1a) {
              if (g.a.ON_START.equals(param1a)) {
                this.e.f.put(this.b, new ActivityResultRegistry.c(this.c, this.d));
                if (this.e.g.containsKey(this.b)) {
                  param1l = (l)this.e.g.get(this.b);
                  this.e.g.remove(this.b);
                  this.c.a(param1l);
                } 
                a a1 = (a)this.e.h.getParcelable(this.b);
                if (a1 != null) {
                  this.e.h.remove(this.b);
                  this.c.a(this.d.c(a1.d(), a1.c()));
                  return;
                } 
              } else {
                if (g.a.ON_STOP.equals(param1a)) {
                  this.e.f.remove(this.b);
                  return;
                } 
                if (g.a.ON_DESTROY.equals(param1a))
                  this.e.l(this.b); 
              } 
            }
          });
      this.d.put(paramString, d);
      return new a(this, paramString, parama);
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("LifecycleOwner ");
    stringBuilder.append(d);
    stringBuilder.append(" is attempting to register while current state is ");
    stringBuilder.append(g.b());
    stringBuilder.append(". LifecycleOwners must call register before they are STARTED.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  @NonNull
  public final <I, O> c<I> j(@NonNull String paramString, @NonNull e.a<I, O> parama, @NonNull b<O> paramb) {
    k(paramString);
    this.f.put(paramString, new c(paramb, parama));
    if (this.g.containsKey(paramString)) {
      Object object = this.g.get(paramString);
      this.g.remove(paramString);
      paramb.a((O)object);
    } 
    a a1 = (a)this.h.getParcelable(paramString);
    if (a1 != null) {
      this.h.remove(paramString);
      paramb.a((O)parama.c(a1.d(), a1.c()));
    } 
    return new b(this, paramString, parama);
  }
  
  final void l(@NonNull String paramString) {
    if (!this.e.contains(paramString)) {
      Integer integer = this.c.remove(paramString);
      if (integer != null)
        this.b.remove(integer); 
    } 
    this.f.remove(paramString);
    if (this.g.containsKey(paramString)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Dropping pending result for request ");
      stringBuilder.append(paramString);
      stringBuilder.append(": ");
      stringBuilder.append(this.g.get(paramString));
      Log.w("ActivityResultRegistry", stringBuilder.toString());
      this.g.remove(paramString);
    } 
    if (this.h.containsKey(paramString)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Dropping pending result for request ");
      stringBuilder.append(paramString);
      stringBuilder.append(": ");
      stringBuilder.append(this.h.getParcelable(paramString));
      Log.w("ActivityResultRegistry", stringBuilder.toString());
      this.h.remove(paramString);
    } 
    d d = this.d.get(paramString);
    if (d != null) {
      d.b();
      this.d.remove(paramString);
    } 
  }
  
  class a extends c<I> {
    a(ActivityResultRegistry this$0, String param1String, e.a param1a) {}
    
    public void b(I param1I, @Nullable f param1f) {
      Integer integer = this.c.c.get(this.a);
      if (integer != null) {
        this.c.e.add(this.a);
        try {
          this.c.f(integer.intValue(), this.b, param1I, param1f);
          return;
        } catch (Exception exception) {
          this.c.e.remove(this.a);
          throw exception;
        } 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Attempting to launch an unregistered ActivityResultLauncher with contract ");
      stringBuilder.append(this.b);
      stringBuilder.append(" and input ");
      stringBuilder.append(exception);
      stringBuilder.append(". You must ensure the ActivityResultLauncher is registered before calling launch().");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void c() {
      this.c.l(this.a);
    }
  }
  
  class b extends c<I> {
    b(ActivityResultRegistry this$0, String param1String, e.a param1a) {}
    
    public void b(I param1I, @Nullable f param1f) {
      Integer integer = this.c.c.get(this.a);
      if (integer != null) {
        this.c.e.add(this.a);
        try {
          this.c.f(integer.intValue(), this.b, param1I, param1f);
          return;
        } catch (Exception exception) {
          this.c.e.remove(this.a);
          throw exception;
        } 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Attempting to launch an unregistered ActivityResultLauncher with contract ");
      stringBuilder.append(this.b);
      stringBuilder.append(" and input ");
      stringBuilder.append(exception);
      stringBuilder.append(". You must ensure the ActivityResultLauncher is registered before calling launch().");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void c() {
      this.c.l(this.a);
    }
  }
  
  private static class c<O> {
    final b<O> a;
    
    final e.a<?, O> b;
    
    c(b<O> param1b, e.a<?, O> param1a) {
      this.a = param1b;
      this.b = param1a;
    }
  }
  
  private static class d {
    final g a;
    
    private final ArrayList<j> b;
    
    d(@NonNull g param1g) {
      this.a = param1g;
      this.b = new ArrayList<j>();
    }
    
    void a(@NonNull j param1j) {
      this.a.a((k)param1j);
      this.b.add(param1j);
    }
    
    void b() {
      for (j j : this.b)
        this.a.c((k)j); 
      this.b.clear();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\activity\result\ActivityResultRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */