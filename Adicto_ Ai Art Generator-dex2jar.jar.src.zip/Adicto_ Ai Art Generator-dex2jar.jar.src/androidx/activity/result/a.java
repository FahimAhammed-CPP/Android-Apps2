package androidx.activity.result;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public final class a implements Parcelable {
  @NonNull
  public static final Parcelable.Creator<a> CREATOR = new a();
  
  private final int b;
  
  @Nullable
  private final Intent c;
  
  public a(int paramInt, @Nullable Intent paramIntent) {
    this.b = paramInt;
    this.c = paramIntent;
  }
  
  a(Parcel paramParcel) {
    Intent intent;
    this.b = paramParcel.readInt();
    if (paramParcel.readInt() == 0) {
      paramParcel = null;
    } else {
      intent = (Intent)Intent.CREATOR.createFromParcel(paramParcel);
    } 
    this.c = intent;
  }
  
  @NonNull
  public static String e(int paramInt) {
    return (paramInt != -1) ? ((paramInt != 0) ? String.valueOf(paramInt) : "RESULT_CANCELED") : "RESULT_OK";
  }
  
  @Nullable
  public Intent c() {
    return this.c;
  }
  
  public int d() {
    return this.b;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ActivityResult{resultCode=");
    stringBuilder.append(e(this.b));
    stringBuilder.append(", data=");
    stringBuilder.append(this.c);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public void writeToParcel(@NonNull Parcel paramParcel, int paramInt) {
    boolean bool;
    paramParcel.writeInt(this.b);
    if (this.c == null) {
      bool = false;
    } else {
      bool = true;
    } 
    paramParcel.writeInt(bool);
    Intent intent = this.c;
    if (intent != null)
      intent.writeToParcel(paramParcel, paramInt); 
  }
  
  class a implements Parcelable.Creator<a> {
    public a a(@NonNull Parcel param1Parcel) {
      return new a(param1Parcel);
    }
    
    public a[] b(int param1Int) {
      return new a[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\activity\result\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */