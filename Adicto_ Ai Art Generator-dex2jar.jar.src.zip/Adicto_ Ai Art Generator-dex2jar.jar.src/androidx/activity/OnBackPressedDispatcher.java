package androidx.activity;

import android.os.Build;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.annotation.RequiresApi;
import androidx.lifecycle.g;
import androidx.lifecycle.j;
import androidx.lifecycle.k;
import androidx.lifecycle.l;
import id.w;
import java.util.Iterator;
import jd.h;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.m;

public final class OnBackPressedDispatcher {
  private final Runnable a;
  
  private final h<j> b;
  
  private ud.a<w> c;
  
  private OnBackInvokedCallback d;
  
  private OnBackInvokedDispatcher e;
  
  private boolean f;
  
  public OnBackPressedDispatcher(Runnable paramRunnable) {
    this.a = paramRunnable;
    this.b = new h();
    if (Build.VERSION.SDK_INT >= 33) {
      this.c = new a(this);
      this.d = c.a.b(new b(this));
    } 
  }
  
  public final void b(l paraml, j paramj) {
    l.e(paraml, "owner");
    l.e(paramj, "onBackPressedCallback");
    g g = paraml.getLifecycle();
    if (g.b() == g.b.b)
      return; 
    paramj.a(new LifecycleOnBackPressedCancellable(this, g, paramj));
    if (Build.VERSION.SDK_INT >= 33) {
      g();
      paramj.g(this.c);
    } 
  }
  
  public final a c(j paramj) {
    l.e(paramj, "onBackPressedCallback");
    this.b.add(paramj);
    d d = new d(this, paramj);
    paramj.a(d);
    if (Build.VERSION.SDK_INT >= 33) {
      g();
      paramj.g(this.c);
    } 
    return d;
  }
  
  public final boolean d() {
    h<j> h1 = this.b;
    boolean bool = h1 instanceof java.util.Collection;
    boolean bool1 = false;
    if (bool && h1.isEmpty())
      return false; 
    Iterator<j> iterator = h1.iterator();
    while (true) {
      bool = bool1;
      if (iterator.hasNext()) {
        if (((j)iterator.next()).c()) {
          bool = true;
          break;
        } 
        continue;
      } 
      break;
    } 
    return bool;
  }
  
  public final void e() {
    // Byte code:
    //   0: aload_0
    //   1: getfield b : Ljd/h;
    //   4: astore_1
    //   5: aload_1
    //   6: aload_1
    //   7: invokeinterface size : ()I
    //   12: invokeinterface listIterator : (I)Ljava/util/ListIterator;
    //   17: astore_2
    //   18: aload_2
    //   19: invokeinterface hasPrevious : ()Z
    //   24: ifeq -> 47
    //   27: aload_2
    //   28: invokeinterface previous : ()Ljava/lang/Object;
    //   33: astore_1
    //   34: aload_1
    //   35: checkcast androidx/activity/j
    //   38: invokevirtual c : ()Z
    //   41: ifeq -> 18
    //   44: goto -> 49
    //   47: aconst_null
    //   48: astore_1
    //   49: aload_1
    //   50: checkcast androidx/activity/j
    //   53: astore_1
    //   54: aload_1
    //   55: ifnull -> 63
    //   58: aload_1
    //   59: invokevirtual b : ()V
    //   62: return
    //   63: aload_0
    //   64: getfield a : Ljava/lang/Runnable;
    //   67: astore_1
    //   68: aload_1
    //   69: ifnull -> 78
    //   72: aload_1
    //   73: invokeinterface run : ()V
    //   78: return
  }
  
  @RequiresApi(33)
  public final void f(OnBackInvokedDispatcher paramOnBackInvokedDispatcher) {
    l.e(paramOnBackInvokedDispatcher, "invoker");
    this.e = paramOnBackInvokedDispatcher;
    g();
  }
  
  @RequiresApi(33)
  public final void g() {
    boolean bool = d();
    OnBackInvokedDispatcher onBackInvokedDispatcher = this.e;
    OnBackInvokedCallback onBackInvokedCallback = this.d;
    if (onBackInvokedDispatcher != null && onBackInvokedCallback != null) {
      if (bool && !this.f) {
        c.a.d(onBackInvokedDispatcher, 0, onBackInvokedCallback);
        this.f = true;
        return;
      } 
      if (!bool && this.f) {
        c.a.e(onBackInvokedDispatcher, onBackInvokedCallback);
        this.f = false;
      } 
    } 
  }
  
  private final class LifecycleOnBackPressedCancellable implements j, a {
    private final g b;
    
    private final j c;
    
    private a d;
    
    public LifecycleOnBackPressedCancellable(OnBackPressedDispatcher this$0, g param1g, j param1j) {
      this.b = param1g;
      this.c = param1j;
      param1g.a((k)this);
    }
    
    public void cancel() {
      this.b.c((k)this);
      this.c.e(this);
      a a1 = this.d;
      if (a1 != null)
        a1.cancel(); 
      this.d = null;
    }
    
    public void onStateChanged(l param1l, g.a param1a) {
      l.e(param1l, "source");
      l.e(param1a, "event");
      if (param1a == g.a.ON_START) {
        this.d = this.e.c(this.c);
        return;
      } 
      if (param1a == g.a.ON_STOP) {
        a a1 = this.d;
        if (a1 != null) {
          a1.cancel();
          return;
        } 
      } else if (param1a == g.a.ON_DESTROY) {
        cancel();
      } 
    }
  }
  
  static final class a extends m implements ud.a<w> {
    a(OnBackPressedDispatcher param1OnBackPressedDispatcher) {
      super(0);
    }
    
    public final void a() {
      this.b.g();
    }
  }
  
  static final class b extends m implements ud.a<w> {
    b(OnBackPressedDispatcher param1OnBackPressedDispatcher) {
      super(0);
    }
    
    public final void a() {
      this.b.e();
    }
  }
  
  @RequiresApi(33)
  public static final class c {
    public static final c a = new c();
    
    private static final void c(ud.a param1a) {
      l.e(param1a, "$onBackInvoked");
      param1a.invoke();
    }
    
    public final OnBackInvokedCallback b(ud.a<w> param1a) {
      l.e(param1a, "onBackInvoked");
      return new k(param1a);
    }
    
    public final void d(Object param1Object1, int param1Int, Object param1Object2) {
      l.e(param1Object1, "dispatcher");
      l.e(param1Object2, "callback");
      ((OnBackInvokedDispatcher)param1Object1).registerOnBackInvokedCallback(param1Int, (OnBackInvokedCallback)param1Object2);
    }
    
    public final void e(Object param1Object1, Object param1Object2) {
      l.e(param1Object1, "dispatcher");
      l.e(param1Object2, "callback");
      ((OnBackInvokedDispatcher)param1Object1).unregisterOnBackInvokedCallback((OnBackInvokedCallback)param1Object2);
    }
  }
  
  private final class d implements a {
    private final j b;
    
    public d(OnBackPressedDispatcher this$0, j param1j) {
      this.b = param1j;
    }
    
    public void cancel() {
      OnBackPressedDispatcher.a(this.c).remove(this.b);
      this.b.e(this);
      if (Build.VERSION.SDK_INT >= 33) {
        this.b.g(null);
        this.c.g();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\activity\OnBackPressedDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */