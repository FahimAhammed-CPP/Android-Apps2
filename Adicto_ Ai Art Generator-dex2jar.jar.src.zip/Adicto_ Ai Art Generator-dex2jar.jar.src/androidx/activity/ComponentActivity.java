package androidx.activity;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.activity.result.ActivityResultRegistry;
import androidx.activity.result.b;
import androidx.activity.result.c;
import androidx.activity.result.d;
import androidx.activity.result.e;
import androidx.annotation.CallSuper;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.n2;
import androidx.core.app.q;
import androidx.core.app.r;
import androidx.core.view.k;
import androidx.core.view.z;
import androidx.lifecycle.a0;
import androidx.lifecycle.d0;
import androidx.lifecycle.f;
import androidx.lifecycle.h0;
import androidx.lifecycle.j;
import androidx.lifecycle.k;
import androidx.lifecycle.k0;
import androidx.lifecycle.l;
import androidx.lifecycle.l0;
import androidx.lifecycle.m;
import androidx.lifecycle.m0;
import androidx.lifecycle.n0;
import androidx.lifecycle.x;
import id.w;
import java.io.Serializable;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;
import t0.d;

public class ComponentActivity extends q implements l0, f, d, l, d, i {
  private static final String ACTIVITY_RESULT_TAG = "android:support:activity-result";
  
  private final ActivityResultRegistry mActivityResultRegistry;
  
  private int mContentLayoutId;
  
  final d.a mContextAwareHelper = new d.a();
  
  private h0.b mDefaultFactory;
  
  private boolean mDispatchingOnMultiWindowModeChanged;
  
  private boolean mDispatchingOnPictureInPictureModeChanged;
  
  @NonNull
  final h mFullyDrawnReporter;
  
  private final m mLifecycleRegistry = new m(this);
  
  private final k mMenuHostHelper = new k(new b(this));
  
  private final AtomicInteger mNextLocalRequestCode;
  
  private final OnBackPressedDispatcher mOnBackPressedDispatcher;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<Configuration>> mOnConfigurationChangedListeners;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<r>> mOnMultiWindowModeChangedListeners;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<Intent>> mOnNewIntentListeners;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<n2>> mOnPictureInPictureModeChangedListeners;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<Integer>> mOnTrimMemoryListeners;
  
  final f mReportFullyDrawnExecutor;
  
  final t0.c mSavedStateRegistryController;
  
  private k0 mViewModelStore;
  
  public ComponentActivity() {
    t0.c c1 = t0.c.a(this);
    this.mSavedStateRegistryController = c1;
    this.mOnBackPressedDispatcher = new OnBackPressedDispatcher(new a(this));
    f f1 = createFullyDrawnExecutor();
    this.mReportFullyDrawnExecutor = f1;
    this.mFullyDrawnReporter = new h(f1, new c(this));
    this.mNextLocalRequestCode = new AtomicInteger();
    this.mActivityResultRegistry = new b(this);
    this.mOnConfigurationChangedListeners = new CopyOnWriteArrayList<androidx.core.util.a<Configuration>>();
    this.mOnTrimMemoryListeners = new CopyOnWriteArrayList<androidx.core.util.a<Integer>>();
    this.mOnNewIntentListeners = new CopyOnWriteArrayList<androidx.core.util.a<Intent>>();
    this.mOnMultiWindowModeChangedListeners = new CopyOnWriteArrayList<androidx.core.util.a<r>>();
    this.mOnPictureInPictureModeChangedListeners = new CopyOnWriteArrayList<androidx.core.util.a<n2>>();
    this.mDispatchingOnMultiWindowModeChanged = false;
    this.mDispatchingOnPictureInPictureModeChanged = false;
    if (getLifecycle() != null) {
      int j = Build.VERSION.SDK_INT;
      getLifecycle().a((k)new j(this) {
            public void onStateChanged(@NonNull l param1l, @NonNull androidx.lifecycle.g.a param1a) {
              if (param1a == androidx.lifecycle.g.a.ON_STOP) {
                Window window = this.b.getWindow();
                if (window != null) {
                  View view = window.peekDecorView();
                } else {
                  window = null;
                } 
                if (window != null)
                  ComponentActivity.c.a((View)window); 
              } 
            }
          });
      getLifecycle().a((k)new j(this) {
            public void onStateChanged(@NonNull l param1l, @NonNull androidx.lifecycle.g.a param1a) {
              if (param1a == androidx.lifecycle.g.a.ON_DESTROY) {
                this.b.mContextAwareHelper.b();
                if (!this.b.isChangingConfigurations())
                  this.b.getViewModelStore().a(); 
                this.b.mReportFullyDrawnExecutor.b();
              } 
            }
          });
      getLifecycle().a((k)new j(this) {
            public void onStateChanged(@NonNull l param1l, @NonNull androidx.lifecycle.g.a param1a) {
              this.b.ensureViewModelStore();
              this.b.getLifecycle().c((k)this);
            }
          });
      c1.c();
      a0.c(this);
      if (j <= 23)
        getLifecycle().a((k)new ImmLeaksCleaner((Activity)this)); 
      getSavedStateRegistry().h("android:support:activity-result", new d(this));
      addOnContextAvailableListener(new e(this));
      return;
    } 
    throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
  }
  
  public ComponentActivity(int paramInt) {
    this();
    this.mContentLayoutId = paramInt;
  }
  
  private f createFullyDrawnExecutor() {
    return new g(this);
  }
  
  private void initViewTreeOwners() {
    m0.a(getWindow().getDecorView(), this);
    n0.a(getWindow().getDecorView(), this);
    t0.e.a(getWindow().getDecorView(), this);
    o.a(getWindow().getDecorView(), this);
    n.a(getWindow().getDecorView(), this);
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    initViewTreeOwners();
    this.mReportFullyDrawnExecutor.o(getWindow().getDecorView());
    super.addContentView(paramView, paramLayoutParams);
  }
  
  public void addMenuProvider(@NonNull z paramz) {
    this.mMenuHostHelper.c(paramz);
  }
  
  public void addMenuProvider(@NonNull z paramz, @NonNull l paraml) {
    this.mMenuHostHelper.d(paramz, paraml);
  }
  
  public void addMenuProvider(@NonNull z paramz, @NonNull l paraml, @NonNull androidx.lifecycle.g.b paramb) {
    this.mMenuHostHelper.e(paramz, paraml, paramb);
  }
  
  public final void addOnConfigurationChangedListener(@NonNull androidx.core.util.a<Configuration> parama) {
    this.mOnConfigurationChangedListeners.add(parama);
  }
  
  public final void addOnContextAvailableListener(@NonNull d.b paramb) {
    this.mContextAwareHelper.a(paramb);
  }
  
  public final void addOnMultiWindowModeChangedListener(@NonNull androidx.core.util.a<r> parama) {
    this.mOnMultiWindowModeChangedListeners.add(parama);
  }
  
  public final void addOnNewIntentListener(@NonNull androidx.core.util.a<Intent> parama) {
    this.mOnNewIntentListeners.add(parama);
  }
  
  public final void addOnPictureInPictureModeChangedListener(@NonNull androidx.core.util.a<n2> parama) {
    this.mOnPictureInPictureModeChangedListeners.add(parama);
  }
  
  public final void addOnTrimMemoryListener(@NonNull androidx.core.util.a<Integer> parama) {
    this.mOnTrimMemoryListeners.add(parama);
  }
  
  void ensureViewModelStore() {
    if (this.mViewModelStore == null) {
      e e = (e)getLastNonConfigurationInstance();
      if (e != null)
        this.mViewModelStore = e.b; 
      if (this.mViewModelStore == null)
        this.mViewModelStore = new k0(); 
    } 
  }
  
  @NonNull
  public final ActivityResultRegistry getActivityResultRegistry() {
    return this.mActivityResultRegistry;
  }
  
  @CallSuper
  @NonNull
  public n0.a getDefaultViewModelCreationExtras() {
    n0.d d1 = new n0.d();
    if (getApplication() != null)
      d1.c(h0.a.g, getApplication()); 
    d1.c(a0.a, this);
    d1.c(a0.b, this);
    if (getIntent() != null && getIntent().getExtras() != null)
      d1.c(a0.c, getIntent().getExtras()); 
    return (n0.a)d1;
  }
  
  @NonNull
  public h0.b getDefaultViewModelProviderFactory() {
    if (this.mDefaultFactory == null) {
      Bundle bundle;
      Application application = getApplication();
      if (getIntent() != null) {
        bundle = getIntent().getExtras();
      } else {
        bundle = null;
      } 
      this.mDefaultFactory = (h0.b)new d0(application, this, bundle);
    } 
    return this.mDefaultFactory;
  }
  
  @NonNull
  public h getFullyDrawnReporter() {
    return this.mFullyDrawnReporter;
  }
  
  @Deprecated
  @Nullable
  public Object getLastCustomNonConfigurationInstance() {
    e e = (e)getLastNonConfigurationInstance();
    return (e != null) ? e.a : null;
  }
  
  @NonNull
  public androidx.lifecycle.g getLifecycle() {
    return (androidx.lifecycle.g)this.mLifecycleRegistry;
  }
  
  @NonNull
  public final OnBackPressedDispatcher getOnBackPressedDispatcher() {
    return this.mOnBackPressedDispatcher;
  }
  
  @NonNull
  public final androidx.savedstate.a getSavedStateRegistry() {
    return this.mSavedStateRegistryController.b();
  }
  
  @NonNull
  public k0 getViewModelStore() {
    if (getApplication() != null) {
      ensureViewModelStore();
      return this.mViewModelStore;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  public void invalidateMenu() {
    invalidateOptionsMenu();
  }
  
  @Deprecated
  @CallSuper
  protected void onActivityResult(int paramInt1, int paramInt2, @Nullable Intent paramIntent) {
    if (!this.mActivityResultRegistry.b(paramInt1, paramInt2, paramIntent))
      super.onActivityResult(paramInt1, paramInt2, paramIntent); 
  }
  
  public void onBackPressed() {
    this.mOnBackPressedDispatcher.e();
  }
  
  @CallSuper
  public void onConfigurationChanged(@NonNull Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    Iterator<androidx.core.util.a<Configuration>> iterator = this.mOnConfigurationChangedListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(paramConfiguration); 
  }
  
  protected void onCreate(@Nullable Bundle paramBundle) {
    this.mSavedStateRegistryController.d(paramBundle);
    this.mContextAwareHelper.c((Context)this);
    super.onCreate(paramBundle);
    x.e((Activity)this);
    if (androidx.core.os.a.d())
      this.mOnBackPressedDispatcher.f(d.a((Activity)this)); 
    int j = this.mContentLayoutId;
    if (j != 0)
      setContentView(j); 
  }
  
  public boolean onCreatePanelMenu(int paramInt, @NonNull Menu paramMenu) {
    if (paramInt == 0) {
      super.onCreatePanelMenu(paramInt, paramMenu);
      this.mMenuHostHelper.h(paramMenu, getMenuInflater());
    } 
    return true;
  }
  
  public boolean onMenuItemSelected(int paramInt, @NonNull MenuItem paramMenuItem) {
    return super.onMenuItemSelected(paramInt, paramMenuItem) ? true : ((paramInt == 0) ? this.mMenuHostHelper.j(paramMenuItem) : false);
  }
  
  @CallSuper
  public void onMultiWindowModeChanged(boolean paramBoolean) {
    if (this.mDispatchingOnMultiWindowModeChanged)
      return; 
    Iterator<androidx.core.util.a<r>> iterator = this.mOnMultiWindowModeChangedListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(new r(paramBoolean)); 
  }
  
  @CallSuper
  @RequiresApi(api = 26)
  public void onMultiWindowModeChanged(boolean paramBoolean, @NonNull Configuration paramConfiguration) {
    this.mDispatchingOnMultiWindowModeChanged = true;
    try {
      super.onMultiWindowModeChanged(paramBoolean, paramConfiguration);
      this.mDispatchingOnMultiWindowModeChanged = false;
      Iterator<androidx.core.util.a<r>> iterator = this.mOnMultiWindowModeChangedListeners.iterator();
      return;
    } finally {
      this.mDispatchingOnMultiWindowModeChanged = false;
    } 
  }
  
  @CallSuper
  protected void onNewIntent(Intent paramIntent) {
    super.onNewIntent(paramIntent);
    Iterator<androidx.core.util.a<Intent>> iterator = this.mOnNewIntentListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(paramIntent); 
  }
  
  public void onPanelClosed(int paramInt, @NonNull Menu paramMenu) {
    this.mMenuHostHelper.i(paramMenu);
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  @CallSuper
  public void onPictureInPictureModeChanged(boolean paramBoolean) {
    if (this.mDispatchingOnPictureInPictureModeChanged)
      return; 
    Iterator<androidx.core.util.a<n2>> iterator = this.mOnPictureInPictureModeChangedListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(new n2(paramBoolean)); 
  }
  
  @CallSuper
  @RequiresApi(api = 26)
  public void onPictureInPictureModeChanged(boolean paramBoolean, @NonNull Configuration paramConfiguration) {
    this.mDispatchingOnPictureInPictureModeChanged = true;
    try {
      super.onPictureInPictureModeChanged(paramBoolean, paramConfiguration);
      this.mDispatchingOnPictureInPictureModeChanged = false;
      Iterator<androidx.core.util.a<n2>> iterator = this.mOnPictureInPictureModeChangedListeners.iterator();
      return;
    } finally {
      this.mDispatchingOnPictureInPictureModeChanged = false;
    } 
  }
  
  public boolean onPreparePanel(int paramInt, @Nullable View paramView, @NonNull Menu paramMenu) {
    if (paramInt == 0) {
      super.onPreparePanel(paramInt, paramView, paramMenu);
      this.mMenuHostHelper.k(paramMenu);
    } 
    return true;
  }
  
  @Deprecated
  @CallSuper
  public void onRequestPermissionsResult(int paramInt, @NonNull String[] paramArrayOfString, @NonNull int[] paramArrayOfint) {
    if (!this.mActivityResultRegistry.b(paramInt, -1, (new Intent()).putExtra("androidx.activity.result.contract.extra.PERMISSIONS", paramArrayOfString).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", paramArrayOfint)) && Build.VERSION.SDK_INT >= 23)
      super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint); 
  }
  
  @Deprecated
  @Nullable
  public Object onRetainCustomNonConfigurationInstance() {
    return null;
  }
  
  @Nullable
  public final Object onRetainNonConfigurationInstance() {
    Object object = onRetainCustomNonConfigurationInstance();
    k0 k02 = this.mViewModelStore;
    k0 k01 = k02;
    if (k02 == null) {
      e e1 = (e)getLastNonConfigurationInstance();
      k01 = k02;
      if (e1 != null)
        k01 = e1.b; 
    } 
    if (k01 == null && object == null)
      return null; 
    e e = new e();
    e.a = object;
    e.b = k01;
    return e;
  }
  
  @CallSuper
  protected void onSaveInstanceState(@NonNull Bundle paramBundle) {
    androidx.lifecycle.g g = getLifecycle();
    if (g instanceof m)
      ((m)g).n(androidx.lifecycle.g.b.d); 
    super.onSaveInstanceState(paramBundle);
    this.mSavedStateRegistryController.e(paramBundle);
  }
  
  @CallSuper
  public void onTrimMemory(int paramInt) {
    super.onTrimMemory(paramInt);
    Iterator<androidx.core.util.a<Integer>> iterator = this.mOnTrimMemoryListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(Integer.valueOf(paramInt)); 
  }
  
  @Nullable
  public Context peekAvailableContext() {
    return this.mContextAwareHelper.d();
  }
  
  @NonNull
  public final <I, O> c<I> registerForActivityResult(@NonNull e.a<I, O> parama, @NonNull ActivityResultRegistry paramActivityResultRegistry, @NonNull b<O> paramb) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("activity_rq#");
    stringBuilder.append(this.mNextLocalRequestCode.getAndIncrement());
    return paramActivityResultRegistry.i(stringBuilder.toString(), this, parama, paramb);
  }
  
  @NonNull
  public final <I, O> c<I> registerForActivityResult(@NonNull e.a<I, O> parama, @NonNull b<O> paramb) {
    return registerForActivityResult(parama, this.mActivityResultRegistry, paramb);
  }
  
  public void removeMenuProvider(@NonNull z paramz) {
    this.mMenuHostHelper.l(paramz);
  }
  
  public final void removeOnConfigurationChangedListener(@NonNull androidx.core.util.a<Configuration> parama) {
    this.mOnConfigurationChangedListeners.remove(parama);
  }
  
  public final void removeOnContextAvailableListener(@NonNull d.b paramb) {
    this.mContextAwareHelper.e(paramb);
  }
  
  public final void removeOnMultiWindowModeChangedListener(@NonNull androidx.core.util.a<r> parama) {
    this.mOnMultiWindowModeChangedListeners.remove(parama);
  }
  
  public final void removeOnNewIntentListener(@NonNull androidx.core.util.a<Intent> parama) {
    this.mOnNewIntentListeners.remove(parama);
  }
  
  public final void removeOnPictureInPictureModeChangedListener(@NonNull androidx.core.util.a<n2> parama) {
    this.mOnPictureInPictureModeChangedListeners.remove(parama);
  }
  
  public final void removeOnTrimMemoryListener(@NonNull androidx.core.util.a<Integer> parama) {
    this.mOnTrimMemoryListeners.remove(parama);
  }
  
  public void reportFullyDrawn() {
    try {
      if (x0.b.h())
        x0.b.c("reportFullyDrawn() for ComponentActivity"); 
      super.reportFullyDrawn();
      this.mFullyDrawnReporter.b();
      return;
    } finally {
      x0.b.f();
    } 
  }
  
  public void setContentView(int paramInt) {
    initViewTreeOwners();
    this.mReportFullyDrawnExecutor.o(getWindow().getDecorView());
    super.setContentView(paramInt);
  }
  
  public void setContentView(View paramView) {
    initViewTreeOwners();
    this.mReportFullyDrawnExecutor.o(getWindow().getDecorView());
    super.setContentView(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    initViewTreeOwners();
    this.mReportFullyDrawnExecutor.o(getWindow().getDecorView());
    super.setContentView(paramView, paramLayoutParams);
  }
  
  @Deprecated
  public void startActivityForResult(@NonNull Intent paramIntent, int paramInt) {
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  @Deprecated
  public void startActivityForResult(@NonNull Intent paramIntent, int paramInt, @Nullable Bundle paramBundle) {
    super.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  @Deprecated
  public void startIntentSenderForResult(@NonNull IntentSender paramIntentSender, int paramInt1, @Nullable Intent paramIntent, int paramInt2, int paramInt3, int paramInt4) throws IntentSender.SendIntentException {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  @Deprecated
  public void startIntentSenderForResult(@NonNull IntentSender paramIntentSender, int paramInt1, @Nullable Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, @Nullable Bundle paramBundle) throws IntentSender.SendIntentException {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  class a implements Runnable {
    a(ComponentActivity this$0) {}
    
    public void run() {
      try {
        this.b.onBackPressed();
        return;
      } catch (IllegalStateException illegalStateException) {
        if (TextUtils.equals(illegalStateException.getMessage(), "Can not perform this action after onSaveInstanceState"))
          return; 
        throw illegalStateException;
      } 
    }
  }
  
  class b extends ActivityResultRegistry {
    b(ComponentActivity this$0) {}
    
    public <I, O> void f(int param1Int, @NonNull e.a<I, O> param1a, I param1I, @Nullable androidx.core.app.f param1f) {
      String[] arrayOfString1;
      String[] arrayOfString2;
      e e;
      ComponentActivity componentActivity = this.i;
      e.a.a a1 = param1a.b((Context)componentActivity, param1I);
      if (a1 != null) {
        (new Handler(Looper.getMainLooper())).post(new a(this, param1Int, a1));
        return;
      } 
      Intent intent = param1a.a((Context)componentActivity, param1I);
      param1a = null;
      if (intent.getExtras() != null && intent.getExtras().getClassLoader() == null)
        intent.setExtrasClassLoader(componentActivity.getClassLoader()); 
      if (intent.hasExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) {
        Bundle bundle = intent.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
        intent.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
      } 
      if ("androidx.activity.result.contract.action.REQUEST_PERMISSIONS".equals(intent.getAction())) {
        arrayOfString2 = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
        arrayOfString1 = arrayOfString2;
        if (arrayOfString2 == null)
          arrayOfString1 = new String[0]; 
        androidx.core.app.b.g((Activity)componentActivity, arrayOfString1, param1Int);
        return;
      } 
      if ("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST".equals(arrayOfString2.getAction())) {
        e = (e)arrayOfString2.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST");
        try {
          androidx.core.app.b.l((Activity)componentActivity, e.f(), param1Int, e.c(), e.d(), e.e(), 0, (Bundle)arrayOfString1);
          return;
        } catch (android.content.IntentSender.SendIntentException sendIntentException) {
          (new Handler(Looper.getMainLooper())).post(new b(this, param1Int, sendIntentException));
          return;
        } 
      } 
      androidx.core.app.b.k((Activity)componentActivity, (Intent)e, param1Int, (Bundle)sendIntentException);
    }
    
    class a implements Runnable {
      a(ComponentActivity.b this$0, int param2Int, e.a.a param2a) {}
      
      public void run() {
        this.d.c(this.b, this.c.a());
      }
    }
    
    class b implements Runnable {
      b(ComponentActivity.b this$0, int param2Int, IntentSender.SendIntentException param2SendIntentException) {}
      
      public void run() {
        this.d.b(this.b, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.c));
      }
    }
  }
  
  class a implements Runnable {
    a(ComponentActivity this$0, int param1Int, e.a.a param1a) {}
    
    public void run() {
      this.d.c(this.b, this.c.a());
    }
  }
  
  class b implements Runnable {
    b(ComponentActivity this$0, int param1Int, IntentSender.SendIntentException param1SendIntentException) {}
    
    public void run() {
      this.d.b(this.b, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.c));
    }
  }
  
  @RequiresApi(19)
  static class c {
    static void a(View param1View) {
      param1View.cancelPendingInputEvents();
    }
  }
  
  @RequiresApi(33)
  static class d {
    static OnBackInvokedDispatcher a(Activity param1Activity) {
      return param1Activity.getOnBackInvokedDispatcher();
    }
  }
  
  static final class e {
    Object a;
    
    k0 b;
  }
  
  private static interface f extends Executor {
    void b();
    
    void o(@NonNull View param1View);
  }
  
  @RequiresApi(16)
  class g implements f, ViewTreeObserver.OnDrawListener, Runnable {
    final long b = SystemClock.uptimeMillis() + 10000L;
    
    Runnable c;
    
    boolean d = false;
    
    g(ComponentActivity this$0) {}
    
    public void b() {
      this.e.getWindow().getDecorView().removeCallbacks(this);
      this.e.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
    }
    
    public void execute(Runnable param1Runnable) {
      this.c = param1Runnable;
      View view = this.e.getWindow().getDecorView();
      if (this.d) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
          view.invalidate();
          return;
        } 
        view.postInvalidate();
        return;
      } 
      view.postOnAnimation(new f(this));
    }
    
    public void o(@NonNull View param1View) {
      if (!this.d) {
        this.d = true;
        param1View.getViewTreeObserver().addOnDrawListener(this);
      } 
    }
    
    public void onDraw() {
      Runnable runnable = this.c;
      if (runnable != null) {
        runnable.run();
        this.c = null;
        if (this.e.mFullyDrawnReporter.c()) {
          this.d = false;
          this.e.getWindow().getDecorView().post(this);
          return;
        } 
      } else if (SystemClock.uptimeMillis() > this.b) {
        this.d = false;
        this.e.getWindow().getDecorView().post(this);
      } 
    }
    
    public void run() {
      this.e.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\androidx\activity\ComponentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */