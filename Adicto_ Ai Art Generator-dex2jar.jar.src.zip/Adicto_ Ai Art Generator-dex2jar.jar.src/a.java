import de.d;
import de.g;
import java.math.BigInteger;
import java.security.MessageDigest;
import kotlin.jvm.internal.l;

public final class a {
  public static final String a(String paramString) {
    l.e(paramString, "<this>");
    MessageDigest messageDigest = MessageDigest.getInstance("MD5");
    byte[] arrayOfByte = paramString.getBytes(d.b);
    l.d(arrayOfByte, "this as java.lang.String).getBytes(charset)");
    String str = (new BigInteger(1, messageDigest.digest(arrayOfByte))).toString(16);
    l.d(str, "toString(...)");
    return g.U(str, 32, '0');
  }
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */