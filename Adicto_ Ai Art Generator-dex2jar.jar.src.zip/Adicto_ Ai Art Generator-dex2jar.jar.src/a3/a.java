package a3;

import android.content.Context;
import java.io.OutputStream;

public interface a {
  void a(Context paramContext, byte[] paramArrayOfbyte, OutputStream paramOutputStream, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean, int paramInt5);
  
  void b(Context paramContext, String paramString, OutputStream paramOutputStream, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean, int paramInt5, int paramInt6);
  
  int getType();
}


/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\a3\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */