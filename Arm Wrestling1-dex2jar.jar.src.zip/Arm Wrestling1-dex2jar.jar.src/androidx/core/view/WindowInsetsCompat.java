package androidx.core.view;

import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.DisplayCutout;
import android.view.WindowInsets;
import androidx.annotation.IntRange;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.core.graphics.Insets;
import androidx.core.util.ObjectsCompat;
import androidx.core.util.Preconditions;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.Objects;

public class WindowInsetsCompat {
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public static final WindowInsetsCompat CONSUMED = (new Builder()).build().consumeDisplayCutout().consumeStableInsets().consumeSystemWindowInsets();
  
  private static final String TAG = "WindowInsetsCompat";
  
  private final Impl mImpl;
  
  @RequiresApi(20)
  private WindowInsetsCompat(@NonNull WindowInsets paramWindowInsets) {
    if (Build.VERSION.SDK_INT >= 29) {
      this.mImpl = new Impl29(this, paramWindowInsets);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 28) {
      this.mImpl = new Impl28(this, paramWindowInsets);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 21) {
      this.mImpl = new Impl21(this, paramWindowInsets);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 20) {
      this.mImpl = new Impl20(this, paramWindowInsets);
      return;
    } 
    this.mImpl = new Impl(this);
  }
  
  public WindowInsetsCompat(@Nullable WindowInsetsCompat paramWindowInsetsCompat) {
    if (paramWindowInsetsCompat != null) {
      Impl impl = paramWindowInsetsCompat.mImpl;
      if (Build.VERSION.SDK_INT >= 29 && impl instanceof Impl29) {
        this.mImpl = new Impl29(this, (Impl29)impl);
        return;
      } 
      if (Build.VERSION.SDK_INT >= 28 && impl instanceof Impl28) {
        this.mImpl = new Impl28(this, (Impl28)impl);
        return;
      } 
      if (Build.VERSION.SDK_INT >= 21 && impl instanceof Impl21) {
        this.mImpl = new Impl21(this, (Impl21)impl);
        return;
      } 
      if (Build.VERSION.SDK_INT >= 20 && impl instanceof Impl20) {
        this.mImpl = new Impl20(this, (Impl20)impl);
        return;
      } 
      this.mImpl = new Impl(this);
      return;
    } 
    this.mImpl = new Impl(this);
  }
  
  static Insets insetInsets(Insets paramInsets, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = Math.max(0, paramInsets.left - paramInt1);
    int j = Math.max(0, paramInsets.top - paramInt2);
    int k = Math.max(0, paramInsets.right - paramInt3);
    int m = Math.max(0, paramInsets.bottom - paramInt4);
    return (i == paramInt1 && j == paramInt2 && k == paramInt3 && m == paramInt4) ? paramInsets : Insets.of(i, j, k, m);
  }
  
  @NonNull
  @RequiresApi(20)
  public static WindowInsetsCompat toWindowInsetsCompat(@NonNull WindowInsets paramWindowInsets) {
    return new WindowInsetsCompat((WindowInsets)Preconditions.checkNotNull(paramWindowInsets));
  }
  
  @NonNull
  public WindowInsetsCompat consumeDisplayCutout() {
    return this.mImpl.consumeDisplayCutout();
  }
  
  @NonNull
  public WindowInsetsCompat consumeStableInsets() {
    return this.mImpl.consumeStableInsets();
  }
  
  @NonNull
  public WindowInsetsCompat consumeSystemWindowInsets() {
    return this.mImpl.consumeSystemWindowInsets();
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof WindowInsetsCompat))
      return false; 
    paramObject = paramObject;
    return ObjectsCompat.equals(this.mImpl, ((WindowInsetsCompat)paramObject).mImpl);
  }
  
  @Nullable
  public DisplayCutoutCompat getDisplayCutout() {
    return this.mImpl.getDisplayCutout();
  }
  
  @NonNull
  public Insets getMandatorySystemGestureInsets() {
    return this.mImpl.getMandatorySystemGestureInsets();
  }
  
  public int getStableInsetBottom() {
    return (getStableInsets()).bottom;
  }
  
  public int getStableInsetLeft() {
    return (getStableInsets()).left;
  }
  
  public int getStableInsetRight() {
    return (getStableInsets()).right;
  }
  
  public int getStableInsetTop() {
    return (getStableInsets()).top;
  }
  
  @NonNull
  public Insets getStableInsets() {
    return this.mImpl.getStableInsets();
  }
  
  @NonNull
  public Insets getSystemGestureInsets() {
    return this.mImpl.getSystemGestureInsets();
  }
  
  public int getSystemWindowInsetBottom() {
    return (getSystemWindowInsets()).bottom;
  }
  
  public int getSystemWindowInsetLeft() {
    return (getSystemWindowInsets()).left;
  }
  
  public int getSystemWindowInsetRight() {
    return (getSystemWindowInsets()).right;
  }
  
  public int getSystemWindowInsetTop() {
    return (getSystemWindowInsets()).top;
  }
  
  @NonNull
  public Insets getSystemWindowInsets() {
    return this.mImpl.getSystemWindowInsets();
  }
  
  @NonNull
  public Insets getTappableElementInsets() {
    return this.mImpl.getTappableElementInsets();
  }
  
  public boolean hasInsets() {
    return (hasSystemWindowInsets() || hasStableInsets() || getDisplayCutout() != null || !getSystemGestureInsets().equals(Insets.NONE) || !getMandatorySystemGestureInsets().equals(Insets.NONE) || !getTappableElementInsets().equals(Insets.NONE));
  }
  
  public boolean hasStableInsets() {
    return getStableInsets().equals(Insets.NONE) ^ true;
  }
  
  public boolean hasSystemWindowInsets() {
    return getSystemWindowInsets().equals(Insets.NONE) ^ true;
  }
  
  public int hashCode() {
    Impl impl = this.mImpl;
    return (impl == null) ? 0 : impl.hashCode();
  }
  
  @NonNull
  public WindowInsetsCompat inset(@IntRange(from = 0L) int paramInt1, @IntRange(from = 0L) int paramInt2, @IntRange(from = 0L) int paramInt3, @IntRange(from = 0L) int paramInt4) {
    return this.mImpl.inset(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  @NonNull
  public WindowInsetsCompat inset(@NonNull Insets paramInsets) {
    return inset(paramInsets.left, paramInsets.top, paramInsets.right, paramInsets.bottom);
  }
  
  public boolean isConsumed() {
    return this.mImpl.isConsumed();
  }
  
  public boolean isRound() {
    return this.mImpl.isRound();
  }
  
  @Deprecated
  @NonNull
  public WindowInsetsCompat replaceSystemWindowInsets(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return (new Builder(this)).setSystemWindowInsets(Insets.of(paramInt1, paramInt2, paramInt3, paramInt4)).build();
  }
  
  @Deprecated
  @NonNull
  public WindowInsetsCompat replaceSystemWindowInsets(@NonNull Rect paramRect) {
    return (new Builder(this)).setSystemWindowInsets(Insets.of(paramRect)).build();
  }
  
  @Nullable
  @RequiresApi(20)
  public WindowInsets toWindowInsets() {
    Impl impl = this.mImpl;
    return (impl instanceof Impl20) ? ((Impl20)impl).mPlatformInsets : null;
  }
  
  public static final class Builder {
    private final WindowInsetsCompat.BuilderImpl mImpl;
    
    public Builder() {
      if (Build.VERSION.SDK_INT >= 29) {
        this.mImpl = new WindowInsetsCompat.BuilderImpl29();
        return;
      } 
      if (Build.VERSION.SDK_INT >= 20) {
        this.mImpl = new WindowInsetsCompat.BuilderImpl20();
        return;
      } 
      this.mImpl = new WindowInsetsCompat.BuilderImpl();
    }
    
    public Builder(@NonNull WindowInsetsCompat param1WindowInsetsCompat) {
      if (Build.VERSION.SDK_INT >= 29) {
        this.mImpl = new WindowInsetsCompat.BuilderImpl29(param1WindowInsetsCompat);
        return;
      } 
      if (Build.VERSION.SDK_INT >= 20) {
        this.mImpl = new WindowInsetsCompat.BuilderImpl20(param1WindowInsetsCompat);
        return;
      } 
      this.mImpl = new WindowInsetsCompat.BuilderImpl(param1WindowInsetsCompat);
    }
    
    @NonNull
    public WindowInsetsCompat build() {
      return this.mImpl.build();
    }
    
    @NonNull
    public Builder setDisplayCutout(@Nullable DisplayCutoutCompat param1DisplayCutoutCompat) {
      this.mImpl.setDisplayCutout(param1DisplayCutoutCompat);
      return this;
    }
    
    @NonNull
    public Builder setMandatorySystemGestureInsets(@NonNull Insets param1Insets) {
      this.mImpl.setMandatorySystemGestureInsets(param1Insets);
      return this;
    }
    
    @NonNull
    public Builder setStableInsets(@NonNull Insets param1Insets) {
      this.mImpl.setStableInsets(param1Insets);
      return this;
    }
    
    @NonNull
    public Builder setSystemGestureInsets(@NonNull Insets param1Insets) {
      this.mImpl.setSystemGestureInsets(param1Insets);
      return this;
    }
    
    @NonNull
    public Builder setSystemWindowInsets(@NonNull Insets param1Insets) {
      this.mImpl.setSystemWindowInsets(param1Insets);
      return this;
    }
    
    @NonNull
    public Builder setTappableElementInsets(@NonNull Insets param1Insets) {
      this.mImpl.setTappableElementInsets(param1Insets);
      return this;
    }
  }
  
  private static class BuilderImpl {
    private final WindowInsetsCompat mInsets;
    
    BuilderImpl() {
      this(new WindowInsetsCompat((WindowInsetsCompat)null));
    }
    
    BuilderImpl(@NonNull WindowInsetsCompat param1WindowInsetsCompat) {
      this.mInsets = param1WindowInsetsCompat;
    }
    
    @NonNull
    WindowInsetsCompat build() {
      return this.mInsets;
    }
    
    void setDisplayCutout(@Nullable DisplayCutoutCompat param1DisplayCutoutCompat) {}
    
    void setMandatorySystemGestureInsets(@NonNull Insets param1Insets) {}
    
    void setStableInsets(@NonNull Insets param1Insets) {}
    
    void setSystemGestureInsets(@NonNull Insets param1Insets) {}
    
    void setSystemWindowInsets(@NonNull Insets param1Insets) {}
    
    void setTappableElementInsets(@NonNull Insets param1Insets) {}
  }
  
  @RequiresApi(api = 20)
  private static class BuilderImpl20 extends BuilderImpl {
    private static Constructor<WindowInsets> sConstructor;
    
    private static boolean sConstructorFetched = false;
    
    private static Field sConsumedField;
    
    private static boolean sConsumedFieldFetched = false;
    
    private WindowInsets mInsets = createWindowInsetsInstance();
    
    BuilderImpl20() {}
    
    BuilderImpl20(@NonNull WindowInsetsCompat param1WindowInsetsCompat) {}
    
    @Nullable
    private static WindowInsets createWindowInsetsInstance() {
      if (!sConsumedFieldFetched) {
        try {
          sConsumedField = WindowInsets.class.getDeclaredField("CONSUMED");
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets.CONSUMED field", reflectiveOperationException);
        } 
        sConsumedFieldFetched = true;
      } 
      Field field = sConsumedField;
      if (field != null)
        try {
          WindowInsets windowInsets = (WindowInsets)field.get(null);
          if (windowInsets != null)
            return new WindowInsets(windowInsets); 
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not get value from WindowInsets.CONSUMED field", reflectiveOperationException);
        }  
      if (!sConstructorFetched) {
        try {
          sConstructor = WindowInsets.class.getConstructor(new Class[] { Rect.class });
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets(Rect) constructor", reflectiveOperationException);
        } 
        sConstructorFetched = true;
      } 
      Constructor<WindowInsets> constructor = sConstructor;
      if (constructor != null)
        try {
          return constructor.newInstance(new Object[] { new Rect() });
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not invoke WindowInsets(Rect) constructor", reflectiveOperationException);
        }  
      return null;
    }
    
    @NonNull
    WindowInsetsCompat build() {
      return WindowInsetsCompat.toWindowInsetsCompat(this.mInsets);
    }
    
    void setSystemWindowInsets(@NonNull Insets param1Insets) {
      WindowInsets windowInsets = this.mInsets;
      if (windowInsets != null)
        this.mInsets = windowInsets.replaceSystemWindowInsets(param1Insets.left, param1Insets.top, param1Insets.right, param1Insets.bottom); 
    }
  }
  
  @RequiresApi(api = 29)
  private static class BuilderImpl29 extends BuilderImpl {
    final WindowInsets.Builder mPlatBuilder;
    
    BuilderImpl29() {
      this.mPlatBuilder = new WindowInsets.Builder();
    }
    
    BuilderImpl29(@NonNull WindowInsetsCompat param1WindowInsetsCompat) {
      WindowInsets.Builder builder;
      WindowInsets windowInsets = param1WindowInsetsCompat.toWindowInsets();
      if (windowInsets != null) {
        builder = new WindowInsets.Builder(windowInsets);
      } else {
        builder = new WindowInsets.Builder();
      } 
      this.mPlatBuilder = builder;
    }
    
    @NonNull
    WindowInsetsCompat build() {
      return WindowInsetsCompat.toWindowInsetsCompat(this.mPlatBuilder.build());
    }
    
    void setDisplayCutout(@Nullable DisplayCutoutCompat param1DisplayCutoutCompat) {
      WindowInsets.Builder builder = this.mPlatBuilder;
      if (param1DisplayCutoutCompat != null) {
        DisplayCutout displayCutout = param1DisplayCutoutCompat.unwrap();
      } else {
        param1DisplayCutoutCompat = null;
      } 
      builder.setDisplayCutout((DisplayCutout)param1DisplayCutoutCompat);
    }
    
    void setMandatorySystemGestureInsets(@NonNull Insets param1Insets) {
      this.mPlatBuilder.setMandatorySystemGestureInsets(param1Insets.toPlatformInsets());
    }
    
    void setStableInsets(@NonNull Insets param1Insets) {
      this.mPlatBuilder.setStableInsets(param1Insets.toPlatformInsets());
    }
    
    void setSystemGestureInsets(@NonNull Insets param1Insets) {
      this.mPlatBuilder.setSystemGestureInsets(param1Insets.toPlatformInsets());
    }
    
    void setSystemWindowInsets(@NonNull Insets param1Insets) {
      this.mPlatBuilder.setSystemWindowInsets(param1Insets.toPlatformInsets());
    }
    
    void setTappableElementInsets(@NonNull Insets param1Insets) {
      this.mPlatBuilder.setTappableElementInsets(param1Insets.toPlatformInsets());
    }
  }
  
  private static class Impl {
    final WindowInsetsCompat mHost;
    
    Impl(@NonNull WindowInsetsCompat param1WindowInsetsCompat) {
      this.mHost = param1WindowInsetsCompat;
    }
    
    @NonNull
    WindowInsetsCompat consumeDisplayCutout() {
      return this.mHost;
    }
    
    @NonNull
    WindowInsetsCompat consumeStableInsets() {
      return this.mHost;
    }
    
    @NonNull
    WindowInsetsCompat consumeSystemWindowInsets() {
      return this.mHost;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof Impl))
        return false; 
      param1Object = param1Object;
      return (isRound() == param1Object.isRound() && isConsumed() == param1Object.isConsumed() && ObjectsCompat.equals(getSystemWindowInsets(), param1Object.getSystemWindowInsets()) && ObjectsCompat.equals(getStableInsets(), param1Object.getStableInsets()) && ObjectsCompat.equals(getDisplayCutout(), param1Object.getDisplayCutout()));
    }
    
    @Nullable
    DisplayCutoutCompat getDisplayCutout() {
      return null;
    }
    
    @NonNull
    Insets getMandatorySystemGestureInsets() {
      return getSystemWindowInsets();
    }
    
    @NonNull
    Insets getStableInsets() {
      return Insets.NONE;
    }
    
    @NonNull
    Insets getSystemGestureInsets() {
      return getSystemWindowInsets();
    }
    
    @NonNull
    Insets getSystemWindowInsets() {
      return Insets.NONE;
    }
    
    @NonNull
    Insets getTappableElementInsets() {
      return getSystemWindowInsets();
    }
    
    public int hashCode() {
      return ObjectsCompat.hash(new Object[] { Boolean.valueOf(isRound()), Boolean.valueOf(isConsumed()), getSystemWindowInsets(), getStableInsets(), getDisplayCutout() });
    }
    
    @NonNull
    WindowInsetsCompat inset(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      return WindowInsetsCompat.CONSUMED;
    }
    
    boolean isConsumed() {
      return false;
    }
    
    boolean isRound() {
      return false;
    }
  }
  
  @RequiresApi(20)
  private static class Impl20 extends Impl {
    @NonNull
    final WindowInsets mPlatformInsets;
    
    private Insets mSystemWindowInsets = null;
    
    Impl20(@NonNull WindowInsetsCompat param1WindowInsetsCompat, @NonNull WindowInsets param1WindowInsets) {
      super(param1WindowInsetsCompat);
      this.mPlatformInsets = param1WindowInsets;
    }
    
    Impl20(@NonNull WindowInsetsCompat param1WindowInsetsCompat, @NonNull Impl20 param1Impl20) {
      this(param1WindowInsetsCompat, new WindowInsets(param1Impl20.mPlatformInsets));
    }
    
    @NonNull
    final Insets getSystemWindowInsets() {
      if (this.mSystemWindowInsets == null)
        this.mSystemWindowInsets = Insets.of(this.mPlatformInsets.getSystemWindowInsetLeft(), this.mPlatformInsets.getSystemWindowInsetTop(), this.mPlatformInsets.getSystemWindowInsetRight(), this.mPlatformInsets.getSystemWindowInsetBottom()); 
      return this.mSystemWindowInsets;
    }
    
    @NonNull
    WindowInsetsCompat inset(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      WindowInsetsCompat.Builder builder = new WindowInsetsCompat.Builder(WindowInsetsCompat.toWindowInsetsCompat(this.mPlatformInsets));
      builder.setSystemWindowInsets(WindowInsetsCompat.insetInsets(getSystemWindowInsets(), param1Int1, param1Int2, param1Int3, param1Int4));
      builder.setStableInsets(WindowInsetsCompat.insetInsets(getStableInsets(), param1Int1, param1Int2, param1Int3, param1Int4));
      return builder.build();
    }
    
    boolean isRound() {
      return this.mPlatformInsets.isRound();
    }
  }
  
  @RequiresApi(21)
  private static class Impl21 extends Impl20 {
    private Insets mStableInsets = null;
    
    Impl21(@NonNull WindowInsetsCompat param1WindowInsetsCompat, @NonNull WindowInsets param1WindowInsets) {
      super(param1WindowInsetsCompat, param1WindowInsets);
    }
    
    Impl21(@NonNull WindowInsetsCompat param1WindowInsetsCompat, @NonNull Impl21 param1Impl21) {
      super(param1WindowInsetsCompat, param1Impl21);
    }
    
    @NonNull
    WindowInsetsCompat consumeStableInsets() {
      return WindowInsetsCompat.toWindowInsetsCompat(this.mPlatformInsets.consumeStableInsets());
    }
    
    @NonNull
    WindowInsetsCompat consumeSystemWindowInsets() {
      return WindowInsetsCompat.toWindowInsetsCompat(this.mPlatformInsets.consumeSystemWindowInsets());
    }
    
    @NonNull
    final Insets getStableInsets() {
      if (this.mStableInsets == null)
        this.mStableInsets = Insets.of(this.mPlatformInsets.getStableInsetLeft(), this.mPlatformInsets.getStableInsetTop(), this.mPlatformInsets.getStableInsetRight(), this.mPlatformInsets.getStableInsetBottom()); 
      return this.mStableInsets;
    }
    
    boolean isConsumed() {
      return this.mPlatformInsets.isConsumed();
    }
  }
  
  @RequiresApi(28)
  private static class Impl28 extends Impl21 {
    Impl28(@NonNull WindowInsetsCompat param1WindowInsetsCompat, @NonNull WindowInsets param1WindowInsets) {
      super(param1WindowInsetsCompat, param1WindowInsets);
    }
    
    Impl28(@NonNull WindowInsetsCompat param1WindowInsetsCompat, @NonNull Impl28 param1Impl28) {
      super(param1WindowInsetsCompat, param1Impl28);
    }
    
    @NonNull
    WindowInsetsCompat consumeDisplayCutout() {
      return WindowInsetsCompat.toWindowInsetsCompat(this.mPlatformInsets.consumeDisplayCutout());
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof Impl28))
        return false; 
      param1Object = param1Object;
      return Objects.equals(this.mPlatformInsets, ((Impl28)param1Object).mPlatformInsets);
    }
    
    @Nullable
    DisplayCutoutCompat getDisplayCutout() {
      return DisplayCutoutCompat.wrap(this.mPlatformInsets.getDisplayCutout());
    }
    
    public int hashCode() {
      return this.mPlatformInsets.hashCode();
    }
  }
  
  @RequiresApi(29)
  private static class Impl29 extends Impl28 {
    private Insets mMandatorySystemGestureInsets = null;
    
    private Insets mSystemGestureInsets = null;
    
    private Insets mTappableElementInsets = null;
    
    Impl29(@NonNull WindowInsetsCompat param1WindowInsetsCompat, @NonNull WindowInsets param1WindowInsets) {
      super(param1WindowInsetsCompat, param1WindowInsets);
    }
    
    Impl29(@NonNull WindowInsetsCompat param1WindowInsetsCompat, @NonNull Impl29 param1Impl29) {
      super(param1WindowInsetsCompat, param1Impl29);
    }
    
    @NonNull
    Insets getMandatorySystemGestureInsets() {
      if (this.mMandatorySystemGestureInsets == null)
        this.mMandatorySystemGestureInsets = Insets.toCompatInsets(this.mPlatformInsets.getMandatorySystemGestureInsets()); 
      return this.mMandatorySystemGestureInsets;
    }
    
    @NonNull
    Insets getSystemGestureInsets() {
      if (this.mSystemGestureInsets == null)
        this.mSystemGestureInsets = Insets.toCompatInsets(this.mPlatformInsets.getSystemGestureInsets()); 
      return this.mSystemGestureInsets;
    }
    
    @NonNull
    Insets getTappableElementInsets() {
      if (this.mTappableElementInsets == null)
        this.mTappableElementInsets = Insets.toCompatInsets(this.mPlatformInsets.getTappableElementInsets()); 
      return this.mTappableElementInsets;
    }
    
    @NonNull
    WindowInsetsCompat inset(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      return WindowInsetsCompat.toWindowInsetsCompat(this.mPlatformInsets.inset(param1Int1, param1Int2, param1Int3, param1Int4));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Arm Wrestling1-dex2jar.jar!\androidx\core\view\WindowInsetsCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */