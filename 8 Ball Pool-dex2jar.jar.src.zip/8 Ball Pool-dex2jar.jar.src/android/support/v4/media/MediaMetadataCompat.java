package android.support.v4.media;

import android.graphics.Bitmap;
import android.media.MediaMetadata;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.session.MediaSessionCompat;
import android.text.TextUtils;
import android.util.Log;
import androidx.collection.ArrayMap;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.util.Set;

public final class MediaMetadataCompat implements Parcelable {
  public static final Parcelable.Creator<MediaMetadataCompat> CREATOR;
  
  static final ArrayMap<String, Integer> METADATA_KEYS_TYPE;
  
  public static final String METADATA_KEY_ADVERTISEMENT = v416f9e89.xbd520268("543");
  
  public static final String METADATA_KEY_ALBUM = v416f9e89.xbd520268("544");
  
  public static final String METADATA_KEY_ALBUM_ART = v416f9e89.xbd520268("545");
  
  public static final String METADATA_KEY_ALBUM_ARTIST = v416f9e89.xbd520268("546");
  
  public static final String METADATA_KEY_ALBUM_ART_URI = v416f9e89.xbd520268("547");
  
  public static final String METADATA_KEY_ART = v416f9e89.xbd520268("548");
  
  public static final String METADATA_KEY_ARTIST = v416f9e89.xbd520268("549");
  
  public static final String METADATA_KEY_ART_URI = v416f9e89.xbd520268("550");
  
  public static final String METADATA_KEY_AUTHOR = v416f9e89.xbd520268("551");
  
  public static final String METADATA_KEY_BT_FOLDER_TYPE = v416f9e89.xbd520268("552");
  
  public static final String METADATA_KEY_COMPILATION = v416f9e89.xbd520268("553");
  
  public static final String METADATA_KEY_COMPOSER = v416f9e89.xbd520268("554");
  
  public static final String METADATA_KEY_DATE = v416f9e89.xbd520268("555");
  
  public static final String METADATA_KEY_DISC_NUMBER = v416f9e89.xbd520268("556");
  
  public static final String METADATA_KEY_DISPLAY_DESCRIPTION = v416f9e89.xbd520268("557");
  
  public static final String METADATA_KEY_DISPLAY_ICON = v416f9e89.xbd520268("558");
  
  public static final String METADATA_KEY_DISPLAY_ICON_URI = v416f9e89.xbd520268("559");
  
  public static final String METADATA_KEY_DISPLAY_SUBTITLE = v416f9e89.xbd520268("560");
  
  public static final String METADATA_KEY_DISPLAY_TITLE = v416f9e89.xbd520268("561");
  
  public static final String METADATA_KEY_DOWNLOAD_STATUS = v416f9e89.xbd520268("562");
  
  public static final String METADATA_KEY_DURATION = v416f9e89.xbd520268("563");
  
  public static final String METADATA_KEY_GENRE = v416f9e89.xbd520268("564");
  
  public static final String METADATA_KEY_MEDIA_ID = v416f9e89.xbd520268("565");
  
  public static final String METADATA_KEY_MEDIA_URI = v416f9e89.xbd520268("566");
  
  public static final String METADATA_KEY_NUM_TRACKS = v416f9e89.xbd520268("567");
  
  public static final String METADATA_KEY_RATING = v416f9e89.xbd520268("568");
  
  public static final String METADATA_KEY_TITLE = v416f9e89.xbd520268("569");
  
  public static final String METADATA_KEY_TRACK_NUMBER = v416f9e89.xbd520268("570");
  
  public static final String METADATA_KEY_USER_RATING = v416f9e89.xbd520268("571");
  
  public static final String METADATA_KEY_WRITER = v416f9e89.xbd520268("572");
  
  public static final String METADATA_KEY_YEAR = v416f9e89.xbd520268("573");
  
  static final int METADATA_TYPE_BITMAP = 2;
  
  static final int METADATA_TYPE_LONG = 0;
  
  static final int METADATA_TYPE_RATING = 3;
  
  static final int METADATA_TYPE_TEXT = 1;
  
  private static final String[] PREFERRED_BITMAP_ORDER;
  
  private static final String[] PREFERRED_DESCRIPTION_ORDER;
  
  private static final String[] PREFERRED_URI_ORDER;
  
  private static final String TAG = v416f9e89.xbd520268("574");
  
  final Bundle mBundle;
  
  private MediaDescriptionCompat mDescription;
  
  private MediaMetadata mMetadataFwk;
  
  static {
    ArrayMap<String, Integer> arrayMap = new ArrayMap();
    METADATA_KEYS_TYPE = arrayMap;
    Integer integer1 = Integer.valueOf(1);
    arrayMap.put(v416f9e89.xbd520268("575"), integer1);
    arrayMap.put(v416f9e89.xbd520268("576"), integer1);
    Integer integer2 = Integer.valueOf(0);
    arrayMap.put(v416f9e89.xbd520268("577"), integer2);
    arrayMap.put(v416f9e89.xbd520268("578"), integer1);
    arrayMap.put(v416f9e89.xbd520268("579"), integer1);
    arrayMap.put(v416f9e89.xbd520268("580"), integer1);
    arrayMap.put(v416f9e89.xbd520268("581"), integer1);
    arrayMap.put(v416f9e89.xbd520268("582"), integer1);
    arrayMap.put(v416f9e89.xbd520268("583"), integer1);
    arrayMap.put(v416f9e89.xbd520268("584"), integer2);
    arrayMap.put(v416f9e89.xbd520268("585"), integer1);
    arrayMap.put(v416f9e89.xbd520268("586"), integer2);
    arrayMap.put(v416f9e89.xbd520268("587"), integer2);
    arrayMap.put(v416f9e89.xbd520268("588"), integer2);
    arrayMap.put(v416f9e89.xbd520268("589"), integer1);
    Integer integer3 = Integer.valueOf(2);
    String str1 = v416f9e89.xbd520268("590");
    arrayMap.put(str1, integer3);
    String str2 = v416f9e89.xbd520268("591");
    arrayMap.put(str2, integer1);
    String str3 = v416f9e89.xbd520268("592");
    arrayMap.put(str3, integer3);
    String str4 = v416f9e89.xbd520268("593");
    arrayMap.put(str4, integer1);
    Integer integer4 = Integer.valueOf(3);
    arrayMap.put(v416f9e89.xbd520268("594"), integer4);
    arrayMap.put(v416f9e89.xbd520268("595"), integer4);
    arrayMap.put(v416f9e89.xbd520268("596"), integer1);
    arrayMap.put(v416f9e89.xbd520268("597"), integer1);
    arrayMap.put(v416f9e89.xbd520268("598"), integer1);
    String str6 = v416f9e89.xbd520268("599");
    arrayMap.put(str6, integer3);
    String str5 = v416f9e89.xbd520268("600");
    arrayMap.put(str5, integer1);
    arrayMap.put(v416f9e89.xbd520268("601"), integer1);
    arrayMap.put(v416f9e89.xbd520268("602"), integer2);
    arrayMap.put(v416f9e89.xbd520268("603"), integer1);
    arrayMap.put(v416f9e89.xbd520268("604"), integer2);
    arrayMap.put(v416f9e89.xbd520268("605"), integer2);
    PREFERRED_DESCRIPTION_ORDER = new String[] { v416f9e89.xbd520268("606"), v416f9e89.xbd520268("607"), v416f9e89.xbd520268("608"), v416f9e89.xbd520268("609"), v416f9e89.xbd520268("610"), v416f9e89.xbd520268("611"), v416f9e89.xbd520268("612") };
    PREFERRED_BITMAP_ORDER = new String[] { str6, str1, str3 };
    PREFERRED_URI_ORDER = new String[] { str5, str2, str4 };
    CREATOR = new Parcelable.Creator<MediaMetadataCompat>() {
        public MediaMetadataCompat createFromParcel(Parcel param1Parcel) {
          return new MediaMetadataCompat(param1Parcel);
        }
        
        public MediaMetadataCompat[] newArray(int param1Int) {
          return new MediaMetadataCompat[param1Int];
        }
      };
  }
  
  MediaMetadataCompat(Bundle paramBundle) {
    paramBundle = new Bundle(paramBundle);
    this.mBundle = paramBundle;
    MediaSessionCompat.ensureClassLoader(paramBundle);
  }
  
  MediaMetadataCompat(Parcel paramParcel) {
    this.mBundle = paramParcel.readBundle(MediaSessionCompat.class.getClassLoader());
  }
  
  public static MediaMetadataCompat fromMediaMetadata(Object paramObject) {
    if (paramObject != null && Build.VERSION.SDK_INT >= 21) {
      Parcel parcel = Parcel.obtain();
      paramObject = paramObject;
      paramObject.writeToParcel(parcel, 0);
      parcel.setDataPosition(0);
      MediaMetadataCompat mediaMetadataCompat = (MediaMetadataCompat)CREATOR.createFromParcel(parcel);
      parcel.recycle();
      mediaMetadataCompat.mMetadataFwk = (MediaMetadata)paramObject;
      return mediaMetadataCompat;
    } 
    return null;
  }
  
  public boolean containsKey(String paramString) {
    return this.mBundle.containsKey(paramString);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public Bitmap getBitmap(String paramString) {
    try {
      return (Bitmap)this.mBundle.getParcelable(paramString);
    } catch (Exception exception) {
      Log.w(v416f9e89.xbd520268("613"), v416f9e89.xbd520268("614"), exception);
      return null;
    } 
  }
  
  public Bundle getBundle() {
    return new Bundle(this.mBundle);
  }
  
  public MediaDescriptionCompat getDescription() {
    String[] arrayOfString1;
    String[] arrayOfString2;
    Uri uri;
    MediaDescriptionCompat mediaDescriptionCompat2 = this.mDescription;
    if (mediaDescriptionCompat2 != null)
      return mediaDescriptionCompat2; 
    String str2 = getString(v416f9e89.xbd520268("615"));
    CharSequence[] arrayOfCharSequence = new CharSequence[3];
    CharSequence charSequence = getText(v416f9e89.xbd520268("616"));
    if (!TextUtils.isEmpty(charSequence)) {
      arrayOfCharSequence[0] = charSequence;
      arrayOfCharSequence[1] = getText(v416f9e89.xbd520268("617"));
      arrayOfCharSequence[2] = getText(v416f9e89.xbd520268("618"));
    } else {
      int k = 0;
      int j = 0;
      while (k < 3) {
        arrayOfString1 = PREFERRED_DESCRIPTION_ORDER;
        if (j < arrayOfString1.length) {
          CharSequence charSequence1 = getText(arrayOfString1[j]);
          int m = k;
          if (!TextUtils.isEmpty(charSequence1)) {
            arrayOfCharSequence[k] = charSequence1;
            m = k + 1;
          } 
          j++;
          k = m;
        } 
      } 
    } 
    int i = 0;
    while (true) {
      arrayOfString1 = PREFERRED_BITMAP_ORDER;
      int j = arrayOfString1.length;
      uri = null;
      if (i < j) {
        Bitmap bitmap = getBitmap(arrayOfString1[i]);
        if (bitmap != null)
          break; 
        i++;
        continue;
      } 
      arrayOfString1 = null;
      break;
    } 
    i = 0;
    while (true) {
      arrayOfString2 = PREFERRED_URI_ORDER;
      if (i < arrayOfString2.length) {
        String str = getString(arrayOfString2[i]);
        if (!TextUtils.isEmpty(str)) {
          Uri uri1 = Uri.parse(str);
          break;
        } 
        i++;
        continue;
      } 
      arrayOfString2 = null;
      break;
    } 
    String str3 = getString(v416f9e89.xbd520268("619"));
    if (!TextUtils.isEmpty(str3))
      uri = Uri.parse(str3); 
    MediaDescriptionCompat.Builder builder = new MediaDescriptionCompat.Builder();
    builder.setMediaId(str2);
    builder.setTitle(arrayOfCharSequence[0]);
    builder.setSubtitle(arrayOfCharSequence[1]);
    builder.setDescription(arrayOfCharSequence[2]);
    builder.setIconBitmap((Bitmap)arrayOfString1);
    builder.setIconUri((Uri)arrayOfString2);
    builder.setMediaUri(uri);
    Bundle bundle1 = new Bundle();
    Bundle bundle2 = this.mBundle;
    String str1 = v416f9e89.xbd520268("620");
    if (bundle2.containsKey(str1)) {
      long l = getLong(str1);
      bundle1.putLong(v416f9e89.xbd520268("621"), l);
    } 
    bundle2 = this.mBundle;
    str1 = v416f9e89.xbd520268("622");
    if (bundle2.containsKey(str1)) {
      long l = getLong(str1);
      bundle1.putLong(v416f9e89.xbd520268("623"), l);
    } 
    if (!bundle1.isEmpty())
      builder.setExtras(bundle1); 
    MediaDescriptionCompat mediaDescriptionCompat1 = builder.build();
    this.mDescription = mediaDescriptionCompat1;
    return mediaDescriptionCompat1;
  }
  
  public long getLong(String paramString) {
    return this.mBundle.getLong(paramString, 0L);
  }
  
  public Object getMediaMetadata() {
    if (this.mMetadataFwk == null && Build.VERSION.SDK_INT >= 21) {
      Parcel parcel = Parcel.obtain();
      writeToParcel(parcel, 0);
      parcel.setDataPosition(0);
      this.mMetadataFwk = (MediaMetadata)MediaMetadata.CREATOR.createFromParcel(parcel);
      parcel.recycle();
    } 
    return this.mMetadataFwk;
  }
  
  public RatingCompat getRating(String paramString) {
    try {
      return (Build.VERSION.SDK_INT >= 19) ? RatingCompat.fromRating(this.mBundle.getParcelable(paramString)) : (RatingCompat)this.mBundle.getParcelable(paramString);
    } catch (Exception exception) {
      Log.w(v416f9e89.xbd520268("624"), v416f9e89.xbd520268("625"), exception);
      return null;
    } 
  }
  
  public String getString(String paramString) {
    CharSequence charSequence = this.mBundle.getCharSequence(paramString);
    return (charSequence != null) ? charSequence.toString() : null;
  }
  
  public CharSequence getText(String paramString) {
    return this.mBundle.getCharSequence(paramString);
  }
  
  public Set<String> keySet() {
    return this.mBundle.keySet();
  }
  
  public int size() {
    return this.mBundle.size();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeBundle(this.mBundle);
  }
  
  public static final class Builder {
    private final Bundle mBundle;
    
    public Builder() {
      this.mBundle = new Bundle();
    }
    
    public Builder(MediaMetadataCompat param1MediaMetadataCompat) {
      Bundle bundle = new Bundle(param1MediaMetadataCompat.mBundle);
      this.mBundle = bundle;
      MediaSessionCompat.ensureClassLoader(bundle);
    }
    
    public Builder(MediaMetadataCompat param1MediaMetadataCompat, int param1Int) {
      this(param1MediaMetadataCompat);
      for (String str : this.mBundle.keySet()) {
        Object object = this.mBundle.get(str);
        if (object instanceof Bitmap) {
          object = object;
          if (object.getHeight() > param1Int || object.getWidth() > param1Int)
            putBitmap(str, scaleBitmap((Bitmap)object, param1Int)); 
        } 
      } 
    }
    
    private Bitmap scaleBitmap(Bitmap param1Bitmap, int param1Int) {
      float f = param1Int;
      f = Math.min(f / param1Bitmap.getWidth(), f / param1Bitmap.getHeight());
      param1Int = (int)(param1Bitmap.getHeight() * f);
      return Bitmap.createScaledBitmap(param1Bitmap, (int)(param1Bitmap.getWidth() * f), param1Int, true);
    }
    
    public MediaMetadataCompat build() {
      return new MediaMetadataCompat(this.mBundle);
    }
    
    public Builder putBitmap(String param1String, Bitmap param1Bitmap) {
      if (!MediaMetadataCompat.METADATA_KEYS_TYPE.containsKey(param1String) || ((Integer)MediaMetadataCompat.METADATA_KEYS_TYPE.get(param1String)).intValue() == 2) {
        this.mBundle.putParcelable(param1String, (Parcelable)param1Bitmap);
        return this;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("491"));
      stringBuilder.append(param1String);
      stringBuilder.append(v416f9e89.xbd520268("492"));
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public Builder putLong(String param1String, long param1Long) {
      if (!MediaMetadataCompat.METADATA_KEYS_TYPE.containsKey(param1String) || ((Integer)MediaMetadataCompat.METADATA_KEYS_TYPE.get(param1String)).intValue() == 0) {
        this.mBundle.putLong(param1String, param1Long);
        return this;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("493"));
      stringBuilder.append(param1String);
      stringBuilder.append(v416f9e89.xbd520268("494"));
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public Builder putRating(String param1String, RatingCompat param1RatingCompat) {
      if (!MediaMetadataCompat.METADATA_KEYS_TYPE.containsKey(param1String) || ((Integer)MediaMetadataCompat.METADATA_KEYS_TYPE.get(param1String)).intValue() == 3) {
        if (Build.VERSION.SDK_INT >= 19) {
          this.mBundle.putParcelable(param1String, (Parcelable)param1RatingCompat.getRating());
          return this;
        } 
        this.mBundle.putParcelable(param1String, param1RatingCompat);
        return this;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("495"));
      stringBuilder.append(param1String);
      stringBuilder.append(v416f9e89.xbd520268("496"));
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public Builder putString(String param1String1, String param1String2) {
      if (!MediaMetadataCompat.METADATA_KEYS_TYPE.containsKey(param1String1) || ((Integer)MediaMetadataCompat.METADATA_KEYS_TYPE.get(param1String1)).intValue() == 1) {
        this.mBundle.putCharSequence(param1String1, param1String2);
        return this;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("497"));
      stringBuilder.append(param1String1);
      stringBuilder.append(v416f9e89.xbd520268("498"));
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public Builder putText(String param1String, CharSequence param1CharSequence) {
      if (!MediaMetadataCompat.METADATA_KEYS_TYPE.containsKey(param1String) || ((Integer)MediaMetadataCompat.METADATA_KEYS_TYPE.get(param1String)).intValue() == 1) {
        this.mBundle.putCharSequence(param1String, param1CharSequence);
        return this;
      } 
      param1CharSequence = new StringBuilder();
      param1CharSequence.append(v416f9e89.xbd520268("499"));
      param1CharSequence.append(param1String);
      param1CharSequence.append(v416f9e89.xbd520268("500"));
      throw new IllegalArgumentException(param1CharSequence.toString());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\android\support\v4\media\MediaMetadataCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */