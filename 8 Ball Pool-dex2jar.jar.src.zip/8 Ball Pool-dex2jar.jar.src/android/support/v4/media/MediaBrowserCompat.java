package android.support.v4.media;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.media.browse.MediaBrowser;
import android.os.BadParcelableException;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Process;
import android.os.RemoteException;
import android.support.v4.media.session.IMediaSession;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.os.ResultReceiver;
import android.text.TextUtils;
import android.util.Log;
import androidx.collection.ArrayMap;
import androidx.core.app.BundleCompat;
import androidx.media.MediaBrowserCompatUtils;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class MediaBrowserCompat {
  public static final String CUSTOM_ACTION_DOWNLOAD = v416f9e89.xbd520268("408");
  
  public static final String CUSTOM_ACTION_REMOVE_DOWNLOADED_FILE = v416f9e89.xbd520268("409");
  
  static final boolean DEBUG;
  
  public static final String EXTRA_DOWNLOAD_PROGRESS = v416f9e89.xbd520268("410");
  
  public static final String EXTRA_MEDIA_ID = v416f9e89.xbd520268("411");
  
  public static final String EXTRA_PAGE = v416f9e89.xbd520268("412");
  
  public static final String EXTRA_PAGE_SIZE = v416f9e89.xbd520268("413");
  
  static final String TAG = v416f9e89.xbd520268("414");
  
  private final MediaBrowserImpl mImpl;
  
  static {
    DEBUG = Log.isLoggable(v416f9e89.xbd520268("415"), 3);
  }
  
  public MediaBrowserCompat(Context paramContext, ComponentName paramComponentName, ConnectionCallback paramConnectionCallback, Bundle paramBundle) {
    if (Build.VERSION.SDK_INT >= 26) {
      this.mImpl = new MediaBrowserImplApi26(paramContext, paramComponentName, paramConnectionCallback, paramBundle);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 23) {
      this.mImpl = new MediaBrowserImplApi23(paramContext, paramComponentName, paramConnectionCallback, paramBundle);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 21) {
      this.mImpl = new MediaBrowserImplApi21(paramContext, paramComponentName, paramConnectionCallback, paramBundle);
      return;
    } 
    this.mImpl = new MediaBrowserImplBase(paramContext, paramComponentName, paramConnectionCallback, paramBundle);
  }
  
  public void connect() {
    Log.d(v416f9e89.xbd520268("416"), v416f9e89.xbd520268("417"));
    this.mImpl.connect();
  }
  
  public void disconnect() {
    this.mImpl.disconnect();
  }
  
  public Bundle getExtras() {
    return this.mImpl.getExtras();
  }
  
  public void getItem(String paramString, ItemCallback paramItemCallback) {
    this.mImpl.getItem(paramString, paramItemCallback);
  }
  
  public Bundle getNotifyChildrenChangedOptions() {
    return this.mImpl.getNotifyChildrenChangedOptions();
  }
  
  public String getRoot() {
    return this.mImpl.getRoot();
  }
  
  public ComponentName getServiceComponent() {
    return this.mImpl.getServiceComponent();
  }
  
  public MediaSessionCompat.Token getSessionToken() {
    return this.mImpl.getSessionToken();
  }
  
  public boolean isConnected() {
    return this.mImpl.isConnected();
  }
  
  public void search(String paramString, Bundle paramBundle, SearchCallback paramSearchCallback) {
    if (!TextUtils.isEmpty(paramString)) {
      if (paramSearchCallback != null) {
        this.mImpl.search(paramString, paramBundle, paramSearchCallback);
        return;
      } 
      throw new IllegalArgumentException(v416f9e89.xbd520268("418"));
    } 
    throw new IllegalArgumentException(v416f9e89.xbd520268("419"));
  }
  
  public void sendCustomAction(String paramString, Bundle paramBundle, CustomActionCallback paramCustomActionCallback) {
    if (!TextUtils.isEmpty(paramString)) {
      this.mImpl.sendCustomAction(paramString, paramBundle, paramCustomActionCallback);
      return;
    } 
    throw new IllegalArgumentException(v416f9e89.xbd520268("420"));
  }
  
  public void subscribe(String paramString, Bundle paramBundle, SubscriptionCallback paramSubscriptionCallback) {
    if (!TextUtils.isEmpty(paramString)) {
      if (paramSubscriptionCallback != null) {
        if (paramBundle != null) {
          this.mImpl.subscribe(paramString, paramBundle, paramSubscriptionCallback);
          return;
        } 
        throw new IllegalArgumentException(v416f9e89.xbd520268("421"));
      } 
      throw new IllegalArgumentException(v416f9e89.xbd520268("422"));
    } 
    throw new IllegalArgumentException(v416f9e89.xbd520268("423"));
  }
  
  public void subscribe(String paramString, SubscriptionCallback paramSubscriptionCallback) {
    if (!TextUtils.isEmpty(paramString)) {
      if (paramSubscriptionCallback != null) {
        this.mImpl.subscribe(paramString, null, paramSubscriptionCallback);
        return;
      } 
      throw new IllegalArgumentException(v416f9e89.xbd520268("424"));
    } 
    throw new IllegalArgumentException(v416f9e89.xbd520268("425"));
  }
  
  public void unsubscribe(String paramString) {
    if (!TextUtils.isEmpty(paramString)) {
      this.mImpl.unsubscribe(paramString, null);
      return;
    } 
    throw new IllegalArgumentException(v416f9e89.xbd520268("426"));
  }
  
  public void unsubscribe(String paramString, SubscriptionCallback paramSubscriptionCallback) {
    if (!TextUtils.isEmpty(paramString)) {
      if (paramSubscriptionCallback != null) {
        this.mImpl.unsubscribe(paramString, paramSubscriptionCallback);
        return;
      } 
      throw new IllegalArgumentException(v416f9e89.xbd520268("427"));
    } 
    throw new IllegalArgumentException(v416f9e89.xbd520268("428"));
  }
  
  private static class CallbackHandler extends Handler {
    private final WeakReference<MediaBrowserCompat.MediaBrowserServiceCallbackImpl> mCallbackImplRef;
    
    private WeakReference<Messenger> mCallbacksMessengerRef;
    
    CallbackHandler(MediaBrowserCompat.MediaBrowserServiceCallbackImpl param1MediaBrowserServiceCallbackImpl) {
      this.mCallbackImplRef = new WeakReference<MediaBrowserCompat.MediaBrowserServiceCallbackImpl>(param1MediaBrowserServiceCallbackImpl);
    }
    
    public void handleMessage(Message param1Message) {
      String str = v416f9e89.xbd520268("530");
      WeakReference<Messenger> weakReference = this.mCallbacksMessengerRef;
      if (weakReference != null && weakReference.get() != null) {
        if (this.mCallbackImplRef.get() == null)
          return; 
        Bundle bundle = param1Message.getData();
        MediaSessionCompat.ensureClassLoader(bundle);
        MediaBrowserCompat.MediaBrowserServiceCallbackImpl mediaBrowserServiceCallbackImpl = this.mCallbackImplRef.get();
        Messenger messenger = this.mCallbacksMessengerRef.get();
        try {
          StringBuilder stringBuilder;
          int i = param1Message.what;
          String str1 = v416f9e89.xbd520268("531");
          if (i != 1) {
            if (i != 2) {
              if (i != 3) {
                stringBuilder = new StringBuilder();
                stringBuilder.append(v416f9e89.xbd520268("532"));
                stringBuilder.append(param1Message);
                stringBuilder.append(v416f9e89.xbd520268("533"));
                stringBuilder.append(1);
                stringBuilder.append(v416f9e89.xbd520268("534"));
                stringBuilder.append(param1Message.arg1);
                Log.w(str, stringBuilder.toString());
                return;
              } 
              Bundle bundle2 = stringBuilder.getBundle(v416f9e89.xbd520268("535"));
              MediaSessionCompat.ensureClassLoader(bundle2);
              Bundle bundle3 = stringBuilder.getBundle(v416f9e89.xbd520268("536"));
              MediaSessionCompat.ensureClassLoader(bundle3);
              mediaBrowserServiceCallbackImpl.onLoadChildren(messenger, stringBuilder.getString(str1), stringBuilder.getParcelableArrayList(v416f9e89.xbd520268("537")), bundle2, bundle3);
              return;
            } 
            mediaBrowserServiceCallbackImpl.onConnectionFailed(messenger);
            return;
          } 
          Bundle bundle1 = stringBuilder.getBundle(v416f9e89.xbd520268("538"));
          MediaSessionCompat.ensureClassLoader(bundle1);
          mediaBrowserServiceCallbackImpl.onServiceConnected(messenger, stringBuilder.getString(str1), (MediaSessionCompat.Token)stringBuilder.getParcelable(v416f9e89.xbd520268("539")), bundle1);
          return;
        } catch (BadParcelableException badParcelableException) {
          Log.e(str, v416f9e89.xbd520268("540"));
          if (param1Message.what == 1)
            mediaBrowserServiceCallbackImpl.onConnectionFailed(messenger); 
        } 
      } 
    }
    
    void setCallbacksMessenger(Messenger param1Messenger) {
      this.mCallbacksMessengerRef = new WeakReference<Messenger>(param1Messenger);
    }
  }
  
  public static class ConnectionCallback {
    final MediaBrowser.ConnectionCallback mConnectionCallbackFwk;
    
    ConnectionCallbackInternal mConnectionCallbackInternal;
    
    public ConnectionCallback() {
      if (Build.VERSION.SDK_INT >= 21) {
        this.mConnectionCallbackFwk = new ConnectionCallbackApi21();
        return;
      } 
      this.mConnectionCallbackFwk = null;
    }
    
    public void onConnected() {}
    
    public void onConnectionFailed() {}
    
    public void onConnectionSuspended() {}
    
    void setInternalConnectionCallback(ConnectionCallbackInternal param1ConnectionCallbackInternal) {
      this.mConnectionCallbackInternal = param1ConnectionCallbackInternal;
    }
    
    private class ConnectionCallbackApi21 extends MediaBrowser.ConnectionCallback {
      public void onConnected() {
        if (MediaBrowserCompat.ConnectionCallback.this.mConnectionCallbackInternal != null)
          MediaBrowserCompat.ConnectionCallback.this.mConnectionCallbackInternal.onConnected(); 
        MediaBrowserCompat.ConnectionCallback.this.onConnected();
      }
      
      public void onConnectionFailed() {
        if (MediaBrowserCompat.ConnectionCallback.this.mConnectionCallbackInternal != null)
          MediaBrowserCompat.ConnectionCallback.this.mConnectionCallbackInternal.onConnectionFailed(); 
        MediaBrowserCompat.ConnectionCallback.this.onConnectionFailed();
      }
      
      public void onConnectionSuspended() {
        if (MediaBrowserCompat.ConnectionCallback.this.mConnectionCallbackInternal != null)
          MediaBrowserCompat.ConnectionCallback.this.mConnectionCallbackInternal.onConnectionSuspended(); 
        MediaBrowserCompat.ConnectionCallback.this.onConnectionSuspended();
      }
    }
    
    static interface ConnectionCallbackInternal {
      void onConnected();
      
      void onConnectionFailed();
      
      void onConnectionSuspended();
    }
  }
  
  private class ConnectionCallbackApi21 extends MediaBrowser.ConnectionCallback {
    public void onConnected() {
      if (this.this$0.mConnectionCallbackInternal != null)
        this.this$0.mConnectionCallbackInternal.onConnected(); 
      this.this$0.onConnected();
    }
    
    public void onConnectionFailed() {
      if (this.this$0.mConnectionCallbackInternal != null)
        this.this$0.mConnectionCallbackInternal.onConnectionFailed(); 
      this.this$0.onConnectionFailed();
    }
    
    public void onConnectionSuspended() {
      if (this.this$0.mConnectionCallbackInternal != null)
        this.this$0.mConnectionCallbackInternal.onConnectionSuspended(); 
      this.this$0.onConnectionSuspended();
    }
  }
  
  static interface ConnectionCallbackInternal {
    void onConnected();
    
    void onConnectionFailed();
    
    void onConnectionSuspended();
  }
  
  public static abstract class CustomActionCallback {
    public void onError(String param1String, Bundle param1Bundle1, Bundle param1Bundle2) {}
    
    public void onProgressUpdate(String param1String, Bundle param1Bundle1, Bundle param1Bundle2) {}
    
    public void onResult(String param1String, Bundle param1Bundle1, Bundle param1Bundle2) {}
  }
  
  private static class CustomActionResultReceiver extends ResultReceiver {
    private final String mAction;
    
    private final MediaBrowserCompat.CustomActionCallback mCallback;
    
    private final Bundle mExtras;
    
    CustomActionResultReceiver(String param1String, Bundle param1Bundle, MediaBrowserCompat.CustomActionCallback param1CustomActionCallback, Handler param1Handler) {
      super(param1Handler);
      this.mAction = param1String;
      this.mExtras = param1Bundle;
      this.mCallback = param1CustomActionCallback;
    }
    
    protected void onReceiveResult(int param1Int, Bundle param1Bundle) {
      String str;
      if (this.mCallback == null)
        return; 
      MediaSessionCompat.ensureClassLoader(param1Bundle);
      if (param1Int != -1) {
        if (param1Int != 0) {
          if (param1Int != 1) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(v416f9e89.xbd520268("510"));
            stringBuilder.append(param1Int);
            stringBuilder.append(v416f9e89.xbd520268("511"));
            stringBuilder.append(this.mExtras);
            stringBuilder.append(v416f9e89.xbd520268("512"));
            stringBuilder.append(param1Bundle);
            stringBuilder.append(v416f9e89.xbd520268("513"));
            str = stringBuilder.toString();
            Log.w(v416f9e89.xbd520268("514"), str);
            return;
          } 
          this.mCallback.onProgressUpdate(this.mAction, this.mExtras, (Bundle)str);
          return;
        } 
        this.mCallback.onResult(this.mAction, this.mExtras, (Bundle)str);
        return;
      } 
      this.mCallback.onError(this.mAction, this.mExtras, (Bundle)str);
    }
  }
  
  public static abstract class ItemCallback {
    final MediaBrowser.ItemCallback mItemCallbackFwk;
    
    public ItemCallback() {
      if (Build.VERSION.SDK_INT >= 23) {
        this.mItemCallbackFwk = new ItemCallbackApi23();
        return;
      } 
      this.mItemCallbackFwk = null;
    }
    
    public void onError(String param1String) {}
    
    public void onItemLoaded(MediaBrowserCompat.MediaItem param1MediaItem) {}
    
    private class ItemCallbackApi23 extends MediaBrowser.ItemCallback {
      public void onError(String param2String) {
        MediaBrowserCompat.ItemCallback.this.onError(param2String);
      }
      
      public void onItemLoaded(MediaBrowser.MediaItem param2MediaItem) {
        MediaBrowserCompat.ItemCallback.this.onItemLoaded(MediaBrowserCompat.MediaItem.fromMediaItem(param2MediaItem));
      }
    }
  }
  
  private class ItemCallbackApi23 extends MediaBrowser.ItemCallback {
    public void onError(String param1String) {
      this.this$0.onError(param1String);
    }
    
    public void onItemLoaded(MediaBrowser.MediaItem param1MediaItem) {
      this.this$0.onItemLoaded(MediaBrowserCompat.MediaItem.fromMediaItem(param1MediaItem));
    }
  }
  
  private static class ItemReceiver extends ResultReceiver {
    private final MediaBrowserCompat.ItemCallback mCallback;
    
    private final String mMediaId;
    
    ItemReceiver(String param1String, MediaBrowserCompat.ItemCallback param1ItemCallback, Handler param1Handler) {
      super(param1Handler);
      this.mMediaId = param1String;
      this.mCallback = param1ItemCallback;
    }
    
    protected void onReceiveResult(int param1Int, Bundle param1Bundle) {
      Bundle bundle = param1Bundle;
      if (param1Bundle != null)
        bundle = MediaSessionCompat.unparcelWithClassLoader(param1Bundle); 
      if (param1Int == 0 && bundle != null) {
        String str = v416f9e89.xbd520268("659");
        if (bundle.containsKey(str)) {
          Parcelable parcelable = bundle.getParcelable(str);
          if (parcelable == null || parcelable instanceof MediaBrowserCompat.MediaItem) {
            this.mCallback.onItemLoaded((MediaBrowserCompat.MediaItem)parcelable);
            return;
          } 
          this.mCallback.onError(this.mMediaId);
          return;
        } 
      } 
      this.mCallback.onError(this.mMediaId);
    }
  }
  
  static interface MediaBrowserImpl {
    void connect();
    
    void disconnect();
    
    Bundle getExtras();
    
    void getItem(String param1String, MediaBrowserCompat.ItemCallback param1ItemCallback);
    
    Bundle getNotifyChildrenChangedOptions();
    
    String getRoot();
    
    ComponentName getServiceComponent();
    
    MediaSessionCompat.Token getSessionToken();
    
    boolean isConnected();
    
    void search(String param1String, Bundle param1Bundle, MediaBrowserCompat.SearchCallback param1SearchCallback);
    
    void sendCustomAction(String param1String, Bundle param1Bundle, MediaBrowserCompat.CustomActionCallback param1CustomActionCallback);
    
    void subscribe(String param1String, Bundle param1Bundle, MediaBrowserCompat.SubscriptionCallback param1SubscriptionCallback);
    
    void unsubscribe(String param1String, MediaBrowserCompat.SubscriptionCallback param1SubscriptionCallback);
  }
  
  static class MediaBrowserImplApi21 implements MediaBrowserImpl, MediaBrowserServiceCallbackImpl, ConnectionCallback.ConnectionCallbackInternal {
    protected final MediaBrowser mBrowserFwk;
    
    protected Messenger mCallbacksMessenger;
    
    final Context mContext;
    
    protected final MediaBrowserCompat.CallbackHandler mHandler = new MediaBrowserCompat.CallbackHandler(this);
    
    private MediaSessionCompat.Token mMediaSessionToken;
    
    private Bundle mNotifyChildrenChangedOptions;
    
    protected final Bundle mRootHints;
    
    protected MediaBrowserCompat.ServiceBinderWrapper mServiceBinderWrapper;
    
    protected int mServiceVersion;
    
    private final ArrayMap<String, MediaBrowserCompat.Subscription> mSubscriptions = new ArrayMap();
    
    MediaBrowserImplApi21(Context param1Context, ComponentName param1ComponentName, MediaBrowserCompat.ConnectionCallback param1ConnectionCallback, Bundle param1Bundle) {
      this.mContext = param1Context;
      if (param1Bundle != null) {
        param1Bundle = new Bundle(param1Bundle);
      } else {
        param1Bundle = new Bundle();
      } 
      this.mRootHints = param1Bundle;
      param1Bundle.putInt(v416f9e89.xbd520268("23"), 1);
      int i = Process.myPid();
      param1Bundle.putInt(v416f9e89.xbd520268("24"), i);
      param1ConnectionCallback.setInternalConnectionCallback(this);
      this.mBrowserFwk = new MediaBrowser(param1Context, param1ComponentName, param1ConnectionCallback.mConnectionCallbackFwk, param1Bundle);
    }
    
    public void connect() {
      this.mBrowserFwk.connect();
    }
    
    public void disconnect() {
      MediaBrowserCompat.ServiceBinderWrapper serviceBinderWrapper = this.mServiceBinderWrapper;
      if (serviceBinderWrapper != null) {
        Messenger messenger = this.mCallbacksMessenger;
        if (messenger != null)
          try {
            serviceBinderWrapper.unregisterCallbackMessenger(messenger);
          } catch (RemoteException remoteException) {
            Log.i(v416f9e89.xbd520268("25"), v416f9e89.xbd520268("26"));
          }  
      } 
      this.mBrowserFwk.disconnect();
    }
    
    public Bundle getExtras() {
      return this.mBrowserFwk.getExtras();
    }
    
    public void getItem(final String mediaId, final MediaBrowserCompat.ItemCallback cb) {
      if (!TextUtils.isEmpty(mediaId)) {
        if (cb != null) {
          boolean bool = this.mBrowserFwk.isConnected();
          String str = v416f9e89.xbd520268("27");
          if (!bool) {
            Log.i(str, v416f9e89.xbd520268("28"));
            this.mHandler.post(new Runnable() {
                  public void run() {
                    cb.onError(mediaId);
                  }
                });
            return;
          } 
          if (this.mServiceBinderWrapper == null) {
            this.mHandler.post(new Runnable() {
                  public void run() {
                    cb.onError(mediaId);
                  }
                });
            return;
          } 
          MediaBrowserCompat.ItemReceiver itemReceiver = new MediaBrowserCompat.ItemReceiver(mediaId, cb, this.mHandler);
          try {
            this.mServiceBinderWrapper.getMediaItem(mediaId, itemReceiver, this.mCallbacksMessenger);
            return;
          } catch (RemoteException remoteException) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(v416f9e89.xbd520268("29"));
            stringBuilder.append(mediaId);
            Log.i(str, stringBuilder.toString());
            this.mHandler.post(new Runnable() {
                  public void run() {
                    cb.onError(mediaId);
                  }
                });
            return;
          } 
        } 
        throw new IllegalArgumentException(v416f9e89.xbd520268("30"));
      } 
      throw new IllegalArgumentException(v416f9e89.xbd520268("31"));
    }
    
    public Bundle getNotifyChildrenChangedOptions() {
      return this.mNotifyChildrenChangedOptions;
    }
    
    public String getRoot() {
      return this.mBrowserFwk.getRoot();
    }
    
    public ComponentName getServiceComponent() {
      return this.mBrowserFwk.getServiceComponent();
    }
    
    public MediaSessionCompat.Token getSessionToken() {
      if (this.mMediaSessionToken == null)
        this.mMediaSessionToken = MediaSessionCompat.Token.fromToken(this.mBrowserFwk.getSessionToken()); 
      return this.mMediaSessionToken;
    }
    
    public boolean isConnected() {
      return this.mBrowserFwk.isConnected();
    }
    
    public void onConnected() {
      IMediaSession iMediaSession;
      String str = v416f9e89.xbd520268("32");
      try {
        Bundle bundle = this.mBrowserFwk.getExtras();
        if (bundle == null)
          return; 
        this.mServiceVersion = bundle.getInt(v416f9e89.xbd520268("33"), 0);
        IBinder iBinder = BundleCompat.getBinder(bundle, v416f9e89.xbd520268("34"));
        if (iBinder != null) {
          this.mServiceBinderWrapper = new MediaBrowserCompat.ServiceBinderWrapper(iBinder, this.mRootHints);
          Messenger messenger = new Messenger(this.mHandler);
          this.mCallbacksMessenger = messenger;
          this.mHandler.setCallbacksMessenger(messenger);
          try {
            this.mServiceBinderWrapper.registerCallbackMessenger(this.mContext, this.mCallbacksMessenger);
          } catch (RemoteException remoteException) {
            Log.i(str, v416f9e89.xbd520268("35"));
          } 
        } 
        iMediaSession = IMediaSession.Stub.asInterface(BundleCompat.getBinder(bundle, v416f9e89.xbd520268("36")));
        if (iMediaSession != null)
          this.mMediaSessionToken = MediaSessionCompat.Token.fromToken(this.mBrowserFwk.getSessionToken(), iMediaSession); 
        return;
      } catch (IllegalStateException illegalStateException) {
        Log.e((String)iMediaSession, v416f9e89.xbd520268("37"), illegalStateException);
        return;
      } 
    }
    
    public void onConnectionFailed() {}
    
    public void onConnectionFailed(Messenger param1Messenger) {}
    
    public void onConnectionSuspended() {
      this.mServiceBinderWrapper = null;
      this.mCallbacksMessenger = null;
      this.mMediaSessionToken = null;
      this.mHandler.setCallbacksMessenger((Messenger)null);
    }
    
    public void onLoadChildren(Messenger param1Messenger, String param1String, List<MediaBrowserCompat.MediaItem> param1List, Bundle param1Bundle1, Bundle param1Bundle2) {
      String str;
      if (this.mCallbacksMessenger != param1Messenger)
        return; 
      MediaBrowserCompat.Subscription subscription = (MediaBrowserCompat.Subscription)this.mSubscriptions.get(param1String);
      if (subscription == null) {
        if (MediaBrowserCompat.DEBUG) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(v416f9e89.xbd520268("38"));
          stringBuilder.append(param1String);
          str = stringBuilder.toString();
          Log.d(v416f9e89.xbd520268("39"), str);
        } 
        return;
      } 
      MediaBrowserCompat.SubscriptionCallback subscriptionCallback = str.getCallback(param1Bundle1);
      if (subscriptionCallback != null) {
        if (param1Bundle1 == null) {
          if (param1List == null) {
            subscriptionCallback.onError(param1String);
            return;
          } 
          this.mNotifyChildrenChangedOptions = param1Bundle2;
          subscriptionCallback.onChildrenLoaded(param1String, param1List);
          this.mNotifyChildrenChangedOptions = null;
          return;
        } 
        if (param1List == null) {
          subscriptionCallback.onError(param1String, param1Bundle1);
          return;
        } 
        this.mNotifyChildrenChangedOptions = param1Bundle2;
        subscriptionCallback.onChildrenLoaded(param1String, param1List, param1Bundle1);
        this.mNotifyChildrenChangedOptions = null;
      } 
    }
    
    public void onServiceConnected(Messenger param1Messenger, String param1String, MediaSessionCompat.Token param1Token, Bundle param1Bundle) {}
    
    public void search(final String query, final Bundle extras, final MediaBrowserCompat.SearchCallback callback) {
      if (isConnected()) {
        MediaBrowserCompat.ServiceBinderWrapper serviceBinderWrapper = this.mServiceBinderWrapper;
        String str = v416f9e89.xbd520268("40");
        if (serviceBinderWrapper == null) {
          Log.i(str, v416f9e89.xbd520268("41"));
          this.mHandler.post(new Runnable() {
                public void run() {
                  callback.onError(query, extras);
                }
              });
          return;
        } 
        MediaBrowserCompat.SearchResultReceiver searchResultReceiver = new MediaBrowserCompat.SearchResultReceiver(query, extras, callback, this.mHandler);
        try {
          this.mServiceBinderWrapper.search(query, extras, searchResultReceiver, this.mCallbacksMessenger);
          return;
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(v416f9e89.xbd520268("42"));
          stringBuilder.append(query);
          Log.i(str, stringBuilder.toString(), (Throwable)remoteException);
          this.mHandler.post(new Runnable() {
                public void run() {
                  callback.onError(query, extras);
                }
              });
          return;
        } 
      } 
      throw new IllegalStateException(v416f9e89.xbd520268("43"));
    }
    
    public void sendCustomAction(final String action, final Bundle extras, final MediaBrowserCompat.CustomActionCallback callback) {
      if (isConnected()) {
        MediaBrowserCompat.ServiceBinderWrapper serviceBinderWrapper = this.mServiceBinderWrapper;
        String str = v416f9e89.xbd520268("44");
        if (serviceBinderWrapper == null) {
          Log.i(str, v416f9e89.xbd520268("45"));
          if (callback != null)
            this.mHandler.post(new Runnable() {
                  public void run() {
                    callback.onError(action, extras, null);
                  }
                }); 
        } 
        MediaBrowserCompat.CustomActionResultReceiver customActionResultReceiver = new MediaBrowserCompat.CustomActionResultReceiver(action, extras, callback, this.mHandler);
        try {
          this.mServiceBinderWrapper.sendCustomAction(action, extras, customActionResultReceiver, this.mCallbacksMessenger);
          return;
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(v416f9e89.xbd520268("46"));
          stringBuilder1.append(action);
          stringBuilder1.append(v416f9e89.xbd520268("47"));
          stringBuilder1.append(extras);
          Log.i(str, stringBuilder1.toString(), (Throwable)remoteException);
          if (callback != null)
            this.mHandler.post(new Runnable() {
                  public void run() {
                    callback.onError(action, extras, null);
                  }
                }); 
          return;
        } 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("48"));
      stringBuilder.append(action);
      stringBuilder.append(v416f9e89.xbd520268("49"));
      stringBuilder.append(extras);
      stringBuilder.append(v416f9e89.xbd520268("50"));
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void subscribe(String param1String, Bundle param1Bundle, MediaBrowserCompat.SubscriptionCallback param1SubscriptionCallback) {
      MediaBrowserCompat.Subscription subscription2 = (MediaBrowserCompat.Subscription)this.mSubscriptions.get(param1String);
      MediaBrowserCompat.Subscription subscription1 = subscription2;
      if (subscription2 == null) {
        subscription1 = new MediaBrowserCompat.Subscription();
        this.mSubscriptions.put(param1String, subscription1);
      } 
      param1SubscriptionCallback.setSubscription(subscription1);
      if (param1Bundle == null) {
        param1Bundle = null;
      } else {
        param1Bundle = new Bundle(param1Bundle);
      } 
      subscription1.putCallback(param1Bundle, param1SubscriptionCallback);
      MediaBrowserCompat.ServiceBinderWrapper serviceBinderWrapper = this.mServiceBinderWrapper;
      if (serviceBinderWrapper == null) {
        this.mBrowserFwk.subscribe(param1String, param1SubscriptionCallback.mSubscriptionCallbackFwk);
        return;
      } 
      try {
        serviceBinderWrapper.addSubscription(param1String, param1SubscriptionCallback.mToken, param1Bundle, this.mCallbacksMessenger);
        return;
      } catch (RemoteException remoteException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(v416f9e89.xbd520268("51"));
        stringBuilder.append(param1String);
        param1String = stringBuilder.toString();
        Log.i(v416f9e89.xbd520268("52"), param1String);
        return;
      } 
    }
    
    public void unsubscribe(String param1String, MediaBrowserCompat.SubscriptionCallback param1SubscriptionCallback) {
      List<MediaBrowserCompat.SubscriptionCallback> list;
      MediaBrowserCompat.Subscription subscription = (MediaBrowserCompat.Subscription)this.mSubscriptions.get(param1String);
      if (subscription == null)
        return; 
      MediaBrowserCompat.ServiceBinderWrapper serviceBinderWrapper = this.mServiceBinderWrapper;
      if (serviceBinderWrapper == null) {
        if (param1SubscriptionCallback == null) {
          this.mBrowserFwk.unsubscribe(param1String);
        } else {
          list = subscription.getCallbacks();
          List<Bundle> list1 = subscription.getOptionsList();
          for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i) == param1SubscriptionCallback) {
              list.remove(i);
              list1.remove(i);
            } 
          } 
          if (list.size() == 0)
            this.mBrowserFwk.unsubscribe(param1String); 
        } 
      } else if (param1SubscriptionCallback == null) {
        try {
          list.removeSubscription(param1String, null, this.mCallbacksMessenger);
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(v416f9e89.xbd520268("53"));
          stringBuilder.append(param1String);
          String str = stringBuilder.toString();
          Log.d(v416f9e89.xbd520268("54"), str);
        } 
      } else {
        list = subscription.getCallbacks();
        List<Bundle> list1 = subscription.getOptionsList();
        for (int i = list.size() - 1; i >= 0; i--) {
          if (list.get(i) == param1SubscriptionCallback) {
            this.mServiceBinderWrapper.removeSubscription(param1String, param1SubscriptionCallback.mToken, this.mCallbacksMessenger);
            list.remove(i);
            list1.remove(i);
          } 
        } 
      } 
      if (subscription.isEmpty() || param1SubscriptionCallback == null)
        this.mSubscriptions.remove(param1String); 
    }
  }
  
  class null implements Runnable {
    public void run() {
      cb.onError(mediaId);
    }
  }
  
  class null implements Runnable {
    public void run() {
      cb.onError(mediaId);
    }
  }
  
  class null implements Runnable {
    public void run() {
      cb.onError(mediaId);
    }
  }
  
  class null implements Runnable {
    public void run() {
      callback.onError(query, extras);
    }
  }
  
  class null implements Runnable {
    public void run() {
      callback.onError(query, extras);
    }
  }
  
  class null implements Runnable {
    public void run() {
      callback.onError(action, extras, null);
    }
  }
  
  class null implements Runnable {
    public void run() {
      callback.onError(action, extras, null);
    }
  }
  
  static class MediaBrowserImplApi23 extends MediaBrowserImplApi21 {
    MediaBrowserImplApi23(Context param1Context, ComponentName param1ComponentName, MediaBrowserCompat.ConnectionCallback param1ConnectionCallback, Bundle param1Bundle) {
      super(param1Context, param1ComponentName, param1ConnectionCallback, param1Bundle);
    }
    
    public void getItem(String param1String, MediaBrowserCompat.ItemCallback param1ItemCallback) {
      if (this.mServiceBinderWrapper == null) {
        this.mBrowserFwk.getItem(param1String, param1ItemCallback.mItemCallbackFwk);
        return;
      } 
      super.getItem(param1String, param1ItemCallback);
    }
  }
  
  static class MediaBrowserImplApi26 extends MediaBrowserImplApi23 {
    MediaBrowserImplApi26(Context param1Context, ComponentName param1ComponentName, MediaBrowserCompat.ConnectionCallback param1ConnectionCallback, Bundle param1Bundle) {
      super(param1Context, param1ComponentName, param1ConnectionCallback, param1Bundle);
    }
    
    public void subscribe(String param1String, Bundle param1Bundle, MediaBrowserCompat.SubscriptionCallback param1SubscriptionCallback) {
      if (this.mServiceBinderWrapper == null || this.mServiceVersion < 2) {
        if (param1Bundle == null) {
          this.mBrowserFwk.subscribe(param1String, param1SubscriptionCallback.mSubscriptionCallbackFwk);
          return;
        } 
        this.mBrowserFwk.subscribe(param1String, param1Bundle, param1SubscriptionCallback.mSubscriptionCallbackFwk);
        return;
      } 
      super.subscribe(param1String, param1Bundle, param1SubscriptionCallback);
    }
    
    public void unsubscribe(String param1String, MediaBrowserCompat.SubscriptionCallback param1SubscriptionCallback) {
      if (this.mServiceBinderWrapper == null || this.mServiceVersion < 2) {
        if (param1SubscriptionCallback == null) {
          this.mBrowserFwk.unsubscribe(param1String);
          return;
        } 
        this.mBrowserFwk.unsubscribe(param1String, param1SubscriptionCallback.mSubscriptionCallbackFwk);
        return;
      } 
      super.unsubscribe(param1String, param1SubscriptionCallback);
    }
  }
  
  static class MediaBrowserImplBase implements MediaBrowserImpl, MediaBrowserServiceCallbackImpl {
    static final int CONNECT_STATE_CONNECTED = 3;
    
    static final int CONNECT_STATE_CONNECTING = 2;
    
    static final int CONNECT_STATE_DISCONNECTED = 1;
    
    static final int CONNECT_STATE_DISCONNECTING = 0;
    
    static final int CONNECT_STATE_SUSPENDED = 4;
    
    final MediaBrowserCompat.ConnectionCallback mCallback;
    
    Messenger mCallbacksMessenger;
    
    final Context mContext;
    
    private Bundle mExtras;
    
    final MediaBrowserCompat.CallbackHandler mHandler = new MediaBrowserCompat.CallbackHandler(this);
    
    private MediaSessionCompat.Token mMediaSessionToken;
    
    private Bundle mNotifyChildrenChangedOptions;
    
    final Bundle mRootHints;
    
    private String mRootId;
    
    MediaBrowserCompat.ServiceBinderWrapper mServiceBinderWrapper;
    
    final ComponentName mServiceComponent;
    
    MediaServiceConnection mServiceConnection;
    
    int mState = 1;
    
    private final ArrayMap<String, MediaBrowserCompat.Subscription> mSubscriptions = new ArrayMap();
    
    public MediaBrowserImplBase(Context param1Context, ComponentName param1ComponentName, MediaBrowserCompat.ConnectionCallback param1ConnectionCallback, Bundle param1Bundle) {
      if (param1Context != null) {
        if (param1ComponentName != null) {
          if (param1ConnectionCallback != null) {
            Bundle bundle;
            this.mContext = param1Context;
            this.mServiceComponent = param1ComponentName;
            this.mCallback = param1ConnectionCallback;
            if (param1Bundle == null) {
              param1Context = null;
            } else {
              bundle = new Bundle(param1Bundle);
            } 
            this.mRootHints = bundle;
            return;
          } 
          throw new IllegalArgumentException(v416f9e89.xbd520268("259"));
        } 
        throw new IllegalArgumentException(v416f9e89.xbd520268("260"));
      } 
      throw new IllegalArgumentException(v416f9e89.xbd520268("261"));
    }
    
    private static String getStateLabel(int param1Int) {
      if (param1Int != 0) {
        if (param1Int != 1) {
          if (param1Int != 2) {
            if (param1Int != 3) {
              if (param1Int != 4) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(v416f9e89.xbd520268("262"));
                stringBuilder.append(param1Int);
                return stringBuilder.toString();
              } 
              return v416f9e89.xbd520268("263");
            } 
            return v416f9e89.xbd520268("264");
          } 
          return v416f9e89.xbd520268("265");
        } 
        return v416f9e89.xbd520268("266");
      } 
      return v416f9e89.xbd520268("267");
    }
    
    private boolean isCurrent(Messenger param1Messenger, String param1String) {
      if (this.mCallbacksMessenger == param1Messenger) {
        int j = this.mState;
        if (j != 0 && j != 1)
          return true; 
      } 
      int i = this.mState;
      if (i != 0 && i != 1) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(param1String);
        stringBuilder.append(v416f9e89.xbd520268("268"));
        stringBuilder.append(this.mServiceComponent);
        stringBuilder.append(v416f9e89.xbd520268("269"));
        stringBuilder.append(this.mCallbacksMessenger);
        stringBuilder.append(v416f9e89.xbd520268("270"));
        stringBuilder.append(this);
        String str = stringBuilder.toString();
        Log.i(v416f9e89.xbd520268("271"), str);
      } 
      return false;
    }
    
    public void connect() {
      int i = this.mState;
      if (i == 0 || i == 1) {
        this.mState = 2;
        this.mHandler.post(new Runnable() {
              public void run() {
                String str = v416f9e89.xbd520268("111");
                if (MediaBrowserCompat.MediaBrowserImplBase.this.mState == 0)
                  return; 
                MediaBrowserCompat.MediaBrowserImplBase.this.mState = 2;
                if (!MediaBrowserCompat.DEBUG || MediaBrowserCompat.MediaBrowserImplBase.this.mServiceConnection == null) {
                  if (MediaBrowserCompat.MediaBrowserImplBase.this.mServiceBinderWrapper == null) {
                    if (MediaBrowserCompat.MediaBrowserImplBase.this.mCallbacksMessenger == null) {
                      Intent intent = new Intent(v416f9e89.xbd520268("113"));
                      intent.setComponent(MediaBrowserCompat.MediaBrowserImplBase.this.mServiceComponent);
                      MediaBrowserCompat.MediaBrowserImplBase mediaBrowserImplBase = MediaBrowserCompat.MediaBrowserImplBase.this;
                      mediaBrowserImplBase.mServiceConnection = new MediaBrowserCompat.MediaBrowserImplBase.MediaServiceConnection();
                      boolean bool = false;
                      try {
                        boolean bool1 = MediaBrowserCompat.MediaBrowserImplBase.this.mContext.bindService(intent, MediaBrowserCompat.MediaBrowserImplBase.this.mServiceConnection, 1);
                        bool = bool1;
                      } catch (Exception exception) {
                        StringBuilder stringBuilder3 = new StringBuilder();
                        stringBuilder3.append(v416f9e89.xbd520268("114"));
                        stringBuilder3.append(MediaBrowserCompat.MediaBrowserImplBase.this.mServiceComponent);
                        Log.e(str, stringBuilder3.toString());
                      } 
                      if (!bool) {
                        MediaBrowserCompat.MediaBrowserImplBase.this.forceCloseConnection();
                        MediaBrowserCompat.MediaBrowserImplBase.this.mCallback.onConnectionFailed();
                      } 
                      if (MediaBrowserCompat.DEBUG) {
                        Log.d(str, v416f9e89.xbd520268("115"));
                        MediaBrowserCompat.MediaBrowserImplBase.this.dump();
                      } 
                      return;
                    } 
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(v416f9e89.xbd520268("116"));
                    stringBuilder2.append(MediaBrowserCompat.MediaBrowserImplBase.this.mCallbacksMessenger);
                    throw new RuntimeException(stringBuilder2.toString());
                  } 
                  StringBuilder stringBuilder1 = new StringBuilder();
                  stringBuilder1.append(v416f9e89.xbd520268("117"));
                  stringBuilder1.append(MediaBrowserCompat.MediaBrowserImplBase.this.mServiceBinderWrapper);
                  throw new RuntimeException(stringBuilder1.toString());
                } 
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(v416f9e89.xbd520268("112"));
                stringBuilder.append(MediaBrowserCompat.MediaBrowserImplBase.this.mServiceConnection);
                throw new RuntimeException(stringBuilder.toString());
              }
            });
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("272"));
      stringBuilder.append(getStateLabel(this.mState));
      stringBuilder.append(v416f9e89.xbd520268("273"));
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void disconnect() {
      this.mState = 0;
      this.mHandler.post(new Runnable() {
            public void run() {
              Messenger messenger = MediaBrowserCompat.MediaBrowserImplBase.this.mCallbacksMessenger;
              String str = v416f9e89.xbd520268("119");
              if (messenger != null)
                try {
                  MediaBrowserCompat.MediaBrowserImplBase.this.mServiceBinderWrapper.disconnect(MediaBrowserCompat.MediaBrowserImplBase.this.mCallbacksMessenger);
                } catch (RemoteException remoteException) {
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append(v416f9e89.xbd520268("120"));
                  stringBuilder.append(MediaBrowserCompat.MediaBrowserImplBase.this.mServiceComponent);
                  Log.w(str, stringBuilder.toString());
                }  
              int i = MediaBrowserCompat.MediaBrowserImplBase.this.mState;
              MediaBrowserCompat.MediaBrowserImplBase.this.forceCloseConnection();
              if (i != 0)
                MediaBrowserCompat.MediaBrowserImplBase.this.mState = i; 
              if (MediaBrowserCompat.DEBUG) {
                Log.d(str, v416f9e89.xbd520268("121"));
                MediaBrowserCompat.MediaBrowserImplBase.this.dump();
              } 
            }
          });
    }
    
    void dump() {
      String str = v416f9e89.xbd520268("274");
      Log.d(str, v416f9e89.xbd520268("275"));
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("276"));
      stringBuilder.append(this.mServiceComponent);
      Log.d(str, stringBuilder.toString());
      stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("277"));
      stringBuilder.append(this.mCallback);
      Log.d(str, stringBuilder.toString());
      stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("278"));
      stringBuilder.append(this.mRootHints);
      Log.d(str, stringBuilder.toString());
      stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("279"));
      stringBuilder.append(getStateLabel(this.mState));
      Log.d(str, stringBuilder.toString());
      stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("280"));
      stringBuilder.append(this.mServiceConnection);
      Log.d(str, stringBuilder.toString());
      stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("281"));
      stringBuilder.append(this.mServiceBinderWrapper);
      Log.d(str, stringBuilder.toString());
      stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("282"));
      stringBuilder.append(this.mCallbacksMessenger);
      Log.d(str, stringBuilder.toString());
      stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("283"));
      stringBuilder.append(this.mRootId);
      Log.d(str, stringBuilder.toString());
      stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("284"));
      stringBuilder.append(this.mMediaSessionToken);
      Log.d(str, stringBuilder.toString());
    }
    
    void forceCloseConnection() {
      MediaServiceConnection mediaServiceConnection = this.mServiceConnection;
      if (mediaServiceConnection != null)
        this.mContext.unbindService(mediaServiceConnection); 
      this.mState = 1;
      this.mServiceConnection = null;
      this.mServiceBinderWrapper = null;
      this.mCallbacksMessenger = null;
      this.mHandler.setCallbacksMessenger((Messenger)null);
      this.mRootId = null;
      this.mMediaSessionToken = null;
    }
    
    public Bundle getExtras() {
      if (isConnected())
        return this.mExtras; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("285"));
      stringBuilder.append(getStateLabel(this.mState));
      stringBuilder.append(v416f9e89.xbd520268("286"));
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void getItem(final String mediaId, final MediaBrowserCompat.ItemCallback cb) {
      if (!TextUtils.isEmpty(mediaId)) {
        if (cb != null) {
          boolean bool = isConnected();
          String str = v416f9e89.xbd520268("287");
          if (!bool) {
            Log.i(str, v416f9e89.xbd520268("288"));
            this.mHandler.post(new Runnable() {
                  public void run() {
                    cb.onError(mediaId);
                  }
                });
            return;
          } 
          MediaBrowserCompat.ItemReceiver itemReceiver = new MediaBrowserCompat.ItemReceiver(mediaId, cb, this.mHandler);
          try {
            this.mServiceBinderWrapper.getMediaItem(mediaId, itemReceiver, this.mCallbacksMessenger);
            return;
          } catch (RemoteException remoteException) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(v416f9e89.xbd520268("289"));
            stringBuilder.append(mediaId);
            Log.i(str, stringBuilder.toString());
            this.mHandler.post(new Runnable() {
                  public void run() {
                    cb.onError(mediaId);
                  }
                });
            return;
          } 
        } 
        throw new IllegalArgumentException(v416f9e89.xbd520268("290"));
      } 
      throw new IllegalArgumentException(v416f9e89.xbd520268("291"));
    }
    
    public Bundle getNotifyChildrenChangedOptions() {
      return this.mNotifyChildrenChangedOptions;
    }
    
    public String getRoot() {
      if (isConnected())
        return this.mRootId; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("292"));
      stringBuilder.append(getStateLabel(this.mState));
      stringBuilder.append(v416f9e89.xbd520268("293"));
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public ComponentName getServiceComponent() {
      if (isConnected())
        return this.mServiceComponent; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("294"));
      stringBuilder.append(this.mState);
      stringBuilder.append(v416f9e89.xbd520268("295"));
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public MediaSessionCompat.Token getSessionToken() {
      if (isConnected())
        return this.mMediaSessionToken; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("296"));
      stringBuilder.append(this.mState);
      stringBuilder.append(v416f9e89.xbd520268("297"));
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public boolean isConnected() {
      return (this.mState == 3);
    }
    
    public void onConnectionFailed(Messenger param1Messenger) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("298"));
      stringBuilder.append(this.mServiceComponent);
      String str2 = stringBuilder.toString();
      String str1 = v416f9e89.xbd520268("299");
      Log.e(str1, str2);
      if (!isCurrent(param1Messenger, v416f9e89.xbd520268("300")))
        return; 
      if (this.mState != 2) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(v416f9e89.xbd520268("301"));
        stringBuilder1.append(getStateLabel(this.mState));
        stringBuilder1.append(v416f9e89.xbd520268("302"));
        Log.w(str1, stringBuilder1.toString());
        return;
      } 
      forceCloseConnection();
      this.mCallback.onConnectionFailed();
    }
    
    public void onLoadChildren(Messenger param1Messenger, String param1String, List<MediaBrowserCompat.MediaItem> param1List, Bundle param1Bundle1, Bundle param1Bundle2) {
      StringBuilder stringBuilder;
      if (!isCurrent(param1Messenger, v416f9e89.xbd520268("303")))
        return; 
      boolean bool = MediaBrowserCompat.DEBUG;
      String str = v416f9e89.xbd520268("304");
      if (bool) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(v416f9e89.xbd520268("305"));
        stringBuilder1.append(this.mServiceComponent);
        stringBuilder1.append(v416f9e89.xbd520268("306"));
        stringBuilder1.append(param1String);
        Log.d(str, stringBuilder1.toString());
      } 
      MediaBrowserCompat.Subscription subscription = (MediaBrowserCompat.Subscription)this.mSubscriptions.get(param1String);
      if (subscription == null) {
        if (MediaBrowserCompat.DEBUG) {
          stringBuilder = new StringBuilder();
          stringBuilder.append(v416f9e89.xbd520268("307"));
          stringBuilder.append(param1String);
          Log.d(str, stringBuilder.toString());
        } 
        return;
      } 
      MediaBrowserCompat.SubscriptionCallback subscriptionCallback = subscription.getCallback(param1Bundle1);
      if (subscriptionCallback != null) {
        if (param1Bundle1 == null) {
          if (stringBuilder == null) {
            subscriptionCallback.onError(param1String);
            return;
          } 
          this.mNotifyChildrenChangedOptions = param1Bundle2;
          subscriptionCallback.onChildrenLoaded(param1String, (List<MediaBrowserCompat.MediaItem>)stringBuilder);
          this.mNotifyChildrenChangedOptions = null;
          return;
        } 
        if (stringBuilder == null) {
          subscriptionCallback.onError(param1String, param1Bundle1);
          return;
        } 
        this.mNotifyChildrenChangedOptions = param1Bundle2;
        subscriptionCallback.onChildrenLoaded(param1String, (List<MediaBrowserCompat.MediaItem>)stringBuilder, param1Bundle1);
        this.mNotifyChildrenChangedOptions = null;
      } 
    }
    
    public void onServiceConnected(Messenger param1Messenger, String param1String, MediaSessionCompat.Token param1Token, Bundle param1Bundle) {
      StringBuilder stringBuilder;
      if (!isCurrent(param1Messenger, v416f9e89.xbd520268("308")))
        return; 
      int i = this.mState;
      String str = v416f9e89.xbd520268("309");
      if (i != 2) {
        stringBuilder = new StringBuilder();
        stringBuilder.append(v416f9e89.xbd520268("310"));
        stringBuilder.append(getStateLabel(this.mState));
        stringBuilder.append(v416f9e89.xbd520268("311"));
        Log.w(str, stringBuilder.toString());
        return;
      } 
      this.mRootId = (String)stringBuilder;
      this.mMediaSessionToken = param1Token;
      this.mExtras = param1Bundle;
      this.mState = 3;
      if (MediaBrowserCompat.DEBUG) {
        Log.d(str, v416f9e89.xbd520268("312"));
        dump();
      } 
      this.mCallback.onConnected();
      try {
        for (Map.Entry entry : this.mSubscriptions.entrySet()) {
          String str1 = (String)entry.getKey();
          MediaBrowserCompat.Subscription subscription = (MediaBrowserCompat.Subscription)entry.getValue();
          List<MediaBrowserCompat.SubscriptionCallback> list = subscription.getCallbacks();
          List<Bundle> list1 = subscription.getOptionsList();
          for (i = 0; i < list.size(); i++)
            this.mServiceBinderWrapper.addSubscription(str1, ((MediaBrowserCompat.SubscriptionCallback)list.get(i)).mToken, list1.get(i), this.mCallbacksMessenger); 
        } 
      } catch (RemoteException remoteException) {
        Log.d(str, v416f9e89.xbd520268("313"));
      } 
    }
    
    public void search(final String query, final Bundle extras, final MediaBrowserCompat.SearchCallback callback) {
      if (isConnected()) {
        MediaBrowserCompat.SearchResultReceiver searchResultReceiver = new MediaBrowserCompat.SearchResultReceiver(query, extras, callback, this.mHandler);
        try {
          this.mServiceBinderWrapper.search(query, extras, searchResultReceiver, this.mCallbacksMessenger);
          return;
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(v416f9e89.xbd520268("314"));
          stringBuilder1.append(query);
          String str = stringBuilder1.toString();
          Log.i(v416f9e89.xbd520268("315"), str, (Throwable)remoteException);
          this.mHandler.post(new Runnable() {
                public void run() {
                  callback.onError(query, extras);
                }
              });
          return;
        } 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("316"));
      stringBuilder.append(getStateLabel(this.mState));
      stringBuilder.append(v416f9e89.xbd520268("317"));
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void sendCustomAction(final String action, final Bundle extras, final MediaBrowserCompat.CustomActionCallback callback) {
      if (isConnected()) {
        MediaBrowserCompat.CustomActionResultReceiver customActionResultReceiver = new MediaBrowserCompat.CustomActionResultReceiver(action, extras, callback, this.mHandler);
        try {
          this.mServiceBinderWrapper.sendCustomAction(action, extras, customActionResultReceiver, this.mCallbacksMessenger);
          return;
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(v416f9e89.xbd520268("318"));
          stringBuilder1.append(action);
          stringBuilder1.append(v416f9e89.xbd520268("319"));
          stringBuilder1.append(extras);
          String str = stringBuilder1.toString();
          Log.i(v416f9e89.xbd520268("320"), str, (Throwable)remoteException);
          if (callback != null)
            this.mHandler.post(new Runnable() {
                  public void run() {
                    callback.onError(action, extras, null);
                  }
                }); 
          return;
        } 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("321"));
      stringBuilder.append(action);
      stringBuilder.append(v416f9e89.xbd520268("322"));
      stringBuilder.append(extras);
      stringBuilder.append(v416f9e89.xbd520268("323"));
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void subscribe(String param1String, Bundle param1Bundle, MediaBrowserCompat.SubscriptionCallback param1SubscriptionCallback) {
      MediaBrowserCompat.Subscription subscription2 = (MediaBrowserCompat.Subscription)this.mSubscriptions.get(param1String);
      MediaBrowserCompat.Subscription subscription1 = subscription2;
      if (subscription2 == null) {
        subscription1 = new MediaBrowserCompat.Subscription();
        this.mSubscriptions.put(param1String, subscription1);
      } 
      if (param1Bundle == null) {
        param1Bundle = null;
      } else {
        param1Bundle = new Bundle(param1Bundle);
      } 
      subscription1.putCallback(param1Bundle, param1SubscriptionCallback);
      if (isConnected())
        try {
          this.mServiceBinderWrapper.addSubscription(param1String, param1SubscriptionCallback.mToken, param1Bundle, this.mCallbacksMessenger);
          return;
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(v416f9e89.xbd520268("324"));
          stringBuilder.append(param1String);
          param1String = stringBuilder.toString();
          Log.d(v416f9e89.xbd520268("325"), param1String);
        }  
    }
    
    public void unsubscribe(String param1String, MediaBrowserCompat.SubscriptionCallback param1SubscriptionCallback) {
      MediaBrowserCompat.Subscription subscription = (MediaBrowserCompat.Subscription)this.mSubscriptions.get(param1String);
      if (subscription == null)
        return; 
      if (param1SubscriptionCallback == null) {
        try {
          if (isConnected())
            this.mServiceBinderWrapper.removeSubscription(param1String, null, this.mCallbacksMessenger); 
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(v416f9e89.xbd520268("326"));
          stringBuilder.append(param1String);
          String str = stringBuilder.toString();
          Log.d(v416f9e89.xbd520268("327"), str);
        } 
      } else {
        List<MediaBrowserCompat.SubscriptionCallback> list = subscription.getCallbacks();
        List<Bundle> list1 = subscription.getOptionsList();
        for (int i = list.size() - 1; i >= 0; i--) {
          if (list.get(i) == param1SubscriptionCallback) {
            if (isConnected())
              this.mServiceBinderWrapper.removeSubscription(param1String, param1SubscriptionCallback.mToken, this.mCallbacksMessenger); 
            list.remove(i);
            list1.remove(i);
          } 
        } 
      } 
      if (subscription.isEmpty() || param1SubscriptionCallback == null)
        this.mSubscriptions.remove(param1String); 
    }
    
    private class MediaServiceConnection implements ServiceConnection {
      private void postOrRun(Runnable param2Runnable) {
        if (Thread.currentThread() == MediaBrowserCompat.MediaBrowserImplBase.this.mHandler.getLooper().getThread()) {
          param2Runnable.run();
          return;
        } 
        MediaBrowserCompat.MediaBrowserImplBase.this.mHandler.post(param2Runnable);
      }
      
      boolean isCurrent(String param2String) {
        if (MediaBrowserCompat.MediaBrowserImplBase.this.mServiceConnection != this || MediaBrowserCompat.MediaBrowserImplBase.this.mState == 0 || MediaBrowserCompat.MediaBrowserImplBase.this.mState == 1) {
          if (MediaBrowserCompat.MediaBrowserImplBase.this.mState != 0 && MediaBrowserCompat.MediaBrowserImplBase.this.mState != 1) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(param2String);
            stringBuilder.append(v416f9e89.xbd520268("213"));
            stringBuilder.append(MediaBrowserCompat.MediaBrowserImplBase.this.mServiceComponent);
            stringBuilder.append(v416f9e89.xbd520268("214"));
            stringBuilder.append(MediaBrowserCompat.MediaBrowserImplBase.this.mServiceConnection);
            stringBuilder.append(v416f9e89.xbd520268("215"));
            stringBuilder.append(this);
            param2String = stringBuilder.toString();
            Log.i(v416f9e89.xbd520268("216"), param2String);
          } 
          return false;
        } 
        return true;
      }
      
      public void onServiceConnected(final ComponentName name, final IBinder binder) {
        postOrRun(new Runnable() {
              public void run() {
                String str1 = v416f9e89.xbd520268("207");
                boolean bool = MediaBrowserCompat.DEBUG;
                String str2 = v416f9e89.xbd520268("208");
                if (bool) {
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append(v416f9e89.xbd520268("209"));
                  stringBuilder.append(name);
                  stringBuilder.append(v416f9e89.xbd520268("210"));
                  stringBuilder.append(binder);
                  Log.d(str2, stringBuilder.toString());
                  MediaBrowserCompat.MediaBrowserImplBase.this.dump();
                } 
                if (!MediaBrowserCompat.MediaBrowserImplBase.MediaServiceConnection.this.isCurrent(v416f9e89.xbd520268("211")))
                  return; 
                MediaBrowserCompat.MediaBrowserImplBase.this.mServiceBinderWrapper = new MediaBrowserCompat.ServiceBinderWrapper(binder, MediaBrowserCompat.MediaBrowserImplBase.this.mRootHints);
                MediaBrowserCompat.MediaBrowserImplBase.this.mCallbacksMessenger = new Messenger(MediaBrowserCompat.MediaBrowserImplBase.this.mHandler);
                MediaBrowserCompat.MediaBrowserImplBase.this.mHandler.setCallbacksMessenger(MediaBrowserCompat.MediaBrowserImplBase.this.mCallbacksMessenger);
                MediaBrowserCompat.MediaBrowserImplBase.this.mState = 2;
                try {
                  if (MediaBrowserCompat.DEBUG) {
                    Log.d(str2, str1);
                    MediaBrowserCompat.MediaBrowserImplBase.this.dump();
                  } 
                  MediaBrowserCompat.MediaBrowserImplBase.this.mServiceBinderWrapper.connect(MediaBrowserCompat.MediaBrowserImplBase.this.mContext, MediaBrowserCompat.MediaBrowserImplBase.this.mCallbacksMessenger);
                  return;
                } catch (RemoteException remoteException) {
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append(v416f9e89.xbd520268("212"));
                  stringBuilder.append(MediaBrowserCompat.MediaBrowserImplBase.this.mServiceComponent);
                  Log.w(str2, stringBuilder.toString());
                  if (MediaBrowserCompat.DEBUG) {
                    Log.d(str2, str1);
                    MediaBrowserCompat.MediaBrowserImplBase.this.dump();
                  } 
                  return;
                } 
              }
            });
      }
      
      public void onServiceDisconnected(final ComponentName name) {
        postOrRun(new Runnable() {
              public void run() {
                if (MediaBrowserCompat.DEBUG) {
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append(v416f9e89.xbd520268("240"));
                  stringBuilder.append(name);
                  stringBuilder.append(v416f9e89.xbd520268("241"));
                  stringBuilder.append(this);
                  stringBuilder.append(v416f9e89.xbd520268("242"));
                  stringBuilder.append(MediaBrowserCompat.MediaBrowserImplBase.this.mServiceConnection);
                  String str = stringBuilder.toString();
                  Log.d(v416f9e89.xbd520268("243"), str);
                  MediaBrowserCompat.MediaBrowserImplBase.this.dump();
                } 
                if (!MediaBrowserCompat.MediaBrowserImplBase.MediaServiceConnection.this.isCurrent(v416f9e89.xbd520268("244")))
                  return; 
                MediaBrowserCompat.MediaBrowserImplBase.this.mServiceBinderWrapper = null;
                MediaBrowserCompat.MediaBrowserImplBase.this.mCallbacksMessenger = null;
                MediaBrowserCompat.MediaBrowserImplBase.this.mHandler.setCallbacksMessenger((Messenger)null);
                MediaBrowserCompat.MediaBrowserImplBase.this.mState = 4;
                MediaBrowserCompat.MediaBrowserImplBase.this.mCallback.onConnectionSuspended();
              }
            });
      }
    }
    
    class null implements Runnable {
      public void run() {
        String str1 = v416f9e89.xbd520268("207");
        boolean bool = MediaBrowserCompat.DEBUG;
        String str2 = v416f9e89.xbd520268("208");
        if (bool) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(v416f9e89.xbd520268("209"));
          stringBuilder.append(name);
          stringBuilder.append(v416f9e89.xbd520268("210"));
          stringBuilder.append(binder);
          Log.d(str2, stringBuilder.toString());
          MediaBrowserCompat.MediaBrowserImplBase.this.dump();
        } 
        if (!this.this$1.isCurrent(v416f9e89.xbd520268("211")))
          return; 
        MediaBrowserCompat.MediaBrowserImplBase.this.mServiceBinderWrapper = new MediaBrowserCompat.ServiceBinderWrapper(binder, MediaBrowserCompat.MediaBrowserImplBase.this.mRootHints);
        MediaBrowserCompat.MediaBrowserImplBase.this.mCallbacksMessenger = new Messenger(MediaBrowserCompat.MediaBrowserImplBase.this.mHandler);
        MediaBrowserCompat.MediaBrowserImplBase.this.mHandler.setCallbacksMessenger(MediaBrowserCompat.MediaBrowserImplBase.this.mCallbacksMessenger);
        MediaBrowserCompat.MediaBrowserImplBase.this.mState = 2;
        try {
          if (MediaBrowserCompat.DEBUG) {
            Log.d(str2, str1);
            MediaBrowserCompat.MediaBrowserImplBase.this.dump();
          } 
          MediaBrowserCompat.MediaBrowserImplBase.this.mServiceBinderWrapper.connect(MediaBrowserCompat.MediaBrowserImplBase.this.mContext, MediaBrowserCompat.MediaBrowserImplBase.this.mCallbacksMessenger);
          return;
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(v416f9e89.xbd520268("212"));
          stringBuilder.append(MediaBrowserCompat.MediaBrowserImplBase.this.mServiceComponent);
          Log.w(str2, stringBuilder.toString());
          if (MediaBrowserCompat.DEBUG) {
            Log.d(str2, str1);
            MediaBrowserCompat.MediaBrowserImplBase.this.dump();
          } 
          return;
        } 
      }
    }
    
    class null implements Runnable {
      public void run() {
        if (MediaBrowserCompat.DEBUG) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(v416f9e89.xbd520268("240"));
          stringBuilder.append(name);
          stringBuilder.append(v416f9e89.xbd520268("241"));
          stringBuilder.append(this);
          stringBuilder.append(v416f9e89.xbd520268("242"));
          stringBuilder.append(MediaBrowserCompat.MediaBrowserImplBase.this.mServiceConnection);
          String str = stringBuilder.toString();
          Log.d(v416f9e89.xbd520268("243"), str);
          MediaBrowserCompat.MediaBrowserImplBase.this.dump();
        } 
        if (!this.this$1.isCurrent(v416f9e89.xbd520268("244")))
          return; 
        MediaBrowserCompat.MediaBrowserImplBase.this.mServiceBinderWrapper = null;
        MediaBrowserCompat.MediaBrowserImplBase.this.mCallbacksMessenger = null;
        MediaBrowserCompat.MediaBrowserImplBase.this.mHandler.setCallbacksMessenger((Messenger)null);
        MediaBrowserCompat.MediaBrowserImplBase.this.mState = 4;
        MediaBrowserCompat.MediaBrowserImplBase.this.mCallback.onConnectionSuspended();
      }
    }
  }
  
  class null implements Runnable {
    public void run() {
      String str = v416f9e89.xbd520268("111");
      if (this.this$0.mState == 0)
        return; 
      this.this$0.mState = 2;
      if (!MediaBrowserCompat.DEBUG || this.this$0.mServiceConnection == null) {
        if (this.this$0.mServiceBinderWrapper == null) {
          if (this.this$0.mCallbacksMessenger == null) {
            Intent intent = new Intent(v416f9e89.xbd520268("113"));
            intent.setComponent(this.this$0.mServiceComponent);
            MediaBrowserCompat.MediaBrowserImplBase mediaBrowserImplBase = this.this$0;
            mediaBrowserImplBase.mServiceConnection = new MediaBrowserCompat.MediaBrowserImplBase.MediaServiceConnection();
            boolean bool = false;
            try {
              boolean bool1 = this.this$0.mContext.bindService(intent, this.this$0.mServiceConnection, 1);
              bool = bool1;
            } catch (Exception exception) {
              StringBuilder stringBuilder3 = new StringBuilder();
              stringBuilder3.append(v416f9e89.xbd520268("114"));
              stringBuilder3.append(this.this$0.mServiceComponent);
              Log.e(str, stringBuilder3.toString());
            } 
            if (!bool) {
              this.this$0.forceCloseConnection();
              this.this$0.mCallback.onConnectionFailed();
            } 
            if (MediaBrowserCompat.DEBUG) {
              Log.d(str, v416f9e89.xbd520268("115"));
              this.this$0.dump();
            } 
            return;
          } 
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append(v416f9e89.xbd520268("116"));
          stringBuilder2.append(this.this$0.mCallbacksMessenger);
          throw new RuntimeException(stringBuilder2.toString());
        } 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(v416f9e89.xbd520268("117"));
        stringBuilder1.append(this.this$0.mServiceBinderWrapper);
        throw new RuntimeException(stringBuilder1.toString());
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("112"));
      stringBuilder.append(this.this$0.mServiceConnection);
      throw new RuntimeException(stringBuilder.toString());
    }
  }
  
  class null implements Runnable {
    public void run() {
      Messenger messenger = this.this$0.mCallbacksMessenger;
      String str = v416f9e89.xbd520268("119");
      if (messenger != null)
        try {
          this.this$0.mServiceBinderWrapper.disconnect(this.this$0.mCallbacksMessenger);
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(v416f9e89.xbd520268("120"));
          stringBuilder.append(this.this$0.mServiceComponent);
          Log.w(str, stringBuilder.toString());
        }  
      int i = this.this$0.mState;
      this.this$0.forceCloseConnection();
      if (i != 0)
        this.this$0.mState = i; 
      if (MediaBrowserCompat.DEBUG) {
        Log.d(str, v416f9e89.xbd520268("121"));
        this.this$0.dump();
      } 
    }
  }
  
  class null implements Runnable {
    public void run() {
      cb.onError(mediaId);
    }
  }
  
  class null implements Runnable {
    public void run() {
      cb.onError(mediaId);
    }
  }
  
  class null implements Runnable {
    public void run() {
      callback.onError(query, extras);
    }
  }
  
  class null implements Runnable {
    public void run() {
      callback.onError(action, extras, null);
    }
  }
  
  private class MediaServiceConnection implements ServiceConnection {
    private void postOrRun(Runnable param1Runnable) {
      if (Thread.currentThread() == this.this$0.mHandler.getLooper().getThread()) {
        param1Runnable.run();
        return;
      } 
      this.this$0.mHandler.post(param1Runnable);
    }
    
    boolean isCurrent(String param1String) {
      if (this.this$0.mServiceConnection != this || this.this$0.mState == 0 || this.this$0.mState == 1) {
        if (this.this$0.mState != 0 && this.this$0.mState != 1) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(param1String);
          stringBuilder.append(v416f9e89.xbd520268("213"));
          stringBuilder.append(this.this$0.mServiceComponent);
          stringBuilder.append(v416f9e89.xbd520268("214"));
          stringBuilder.append(this.this$0.mServiceConnection);
          stringBuilder.append(v416f9e89.xbd520268("215"));
          stringBuilder.append(this);
          param1String = stringBuilder.toString();
          Log.i(v416f9e89.xbd520268("216"), param1String);
        } 
        return false;
      } 
      return true;
    }
    
    public void onServiceConnected(final ComponentName name, final IBinder binder) {
      postOrRun(new Runnable() {
            public void run() {
              String str1 = v416f9e89.xbd520268("207");
              boolean bool = MediaBrowserCompat.DEBUG;
              String str2 = v416f9e89.xbd520268("208");
              if (bool) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(v416f9e89.xbd520268("209"));
                stringBuilder.append(name);
                stringBuilder.append(v416f9e89.xbd520268("210"));
                stringBuilder.append(binder);
                Log.d(str2, stringBuilder.toString());
                this.this$1.this$0.dump();
              } 
              if (!MediaBrowserCompat.MediaBrowserImplBase.MediaServiceConnection.this.isCurrent(v416f9e89.xbd520268("211")))
                return; 
              this.this$1.this$0.mServiceBinderWrapper = new MediaBrowserCompat.ServiceBinderWrapper(binder, this.this$1.this$0.mRootHints);
              this.this$1.this$0.mCallbacksMessenger = new Messenger(this.this$1.this$0.mHandler);
              this.this$1.this$0.mHandler.setCallbacksMessenger(this.this$1.this$0.mCallbacksMessenger);
              this.this$1.this$0.mState = 2;
              try {
                if (MediaBrowserCompat.DEBUG) {
                  Log.d(str2, str1);
                  this.this$1.this$0.dump();
                } 
                this.this$1.this$0.mServiceBinderWrapper.connect(this.this$1.this$0.mContext, this.this$1.this$0.mCallbacksMessenger);
                return;
              } catch (RemoteException remoteException) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(v416f9e89.xbd520268("212"));
                stringBuilder.append(this.this$1.this$0.mServiceComponent);
                Log.w(str2, stringBuilder.toString());
                if (MediaBrowserCompat.DEBUG) {
                  Log.d(str2, str1);
                  this.this$1.this$0.dump();
                } 
                return;
              } 
            }
          });
    }
    
    public void onServiceDisconnected(final ComponentName name) {
      postOrRun(new Runnable() {
            public void run() {
              if (MediaBrowserCompat.DEBUG) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(v416f9e89.xbd520268("240"));
                stringBuilder.append(name);
                stringBuilder.append(v416f9e89.xbd520268("241"));
                stringBuilder.append(this);
                stringBuilder.append(v416f9e89.xbd520268("242"));
                stringBuilder.append(this.this$1.this$0.mServiceConnection);
                String str = stringBuilder.toString();
                Log.d(v416f9e89.xbd520268("243"), str);
                this.this$1.this$0.dump();
              } 
              if (!MediaBrowserCompat.MediaBrowserImplBase.MediaServiceConnection.this.isCurrent(v416f9e89.xbd520268("244")))
                return; 
              this.this$1.this$0.mServiceBinderWrapper = null;
              this.this$1.this$0.mCallbacksMessenger = null;
              this.this$1.this$0.mHandler.setCallbacksMessenger((Messenger)null);
              this.this$1.this$0.mState = 4;
              this.this$1.this$0.mCallback.onConnectionSuspended();
            }
          });
    }
  }
  
  class null implements Runnable {
    public void run() {
      String str1 = v416f9e89.xbd520268("207");
      boolean bool = MediaBrowserCompat.DEBUG;
      String str2 = v416f9e89.xbd520268("208");
      if (bool) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(v416f9e89.xbd520268("209"));
        stringBuilder.append(name);
        stringBuilder.append(v416f9e89.xbd520268("210"));
        stringBuilder.append(binder);
        Log.d(str2, stringBuilder.toString());
        this.this$1.this$0.dump();
      } 
      if (!this.this$1.isCurrent(v416f9e89.xbd520268("211")))
        return; 
      this.this$1.this$0.mServiceBinderWrapper = new MediaBrowserCompat.ServiceBinderWrapper(binder, this.this$1.this$0.mRootHints);
      this.this$1.this$0.mCallbacksMessenger = new Messenger(this.this$1.this$0.mHandler);
      this.this$1.this$0.mHandler.setCallbacksMessenger(this.this$1.this$0.mCallbacksMessenger);
      this.this$1.this$0.mState = 2;
      try {
        if (MediaBrowserCompat.DEBUG) {
          Log.d(str2, str1);
          this.this$1.this$0.dump();
        } 
        this.this$1.this$0.mServiceBinderWrapper.connect(this.this$1.this$0.mContext, this.this$1.this$0.mCallbacksMessenger);
        return;
      } catch (RemoteException remoteException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(v416f9e89.xbd520268("212"));
        stringBuilder.append(this.this$1.this$0.mServiceComponent);
        Log.w(str2, stringBuilder.toString());
        if (MediaBrowserCompat.DEBUG) {
          Log.d(str2, str1);
          this.this$1.this$0.dump();
        } 
        return;
      } 
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (MediaBrowserCompat.DEBUG) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(v416f9e89.xbd520268("240"));
        stringBuilder.append(name);
        stringBuilder.append(v416f9e89.xbd520268("241"));
        stringBuilder.append(this);
        stringBuilder.append(v416f9e89.xbd520268("242"));
        stringBuilder.append(this.this$1.this$0.mServiceConnection);
        String str = stringBuilder.toString();
        Log.d(v416f9e89.xbd520268("243"), str);
        this.this$1.this$0.dump();
      } 
      if (!this.this$1.isCurrent(v416f9e89.xbd520268("244")))
        return; 
      this.this$1.this$0.mServiceBinderWrapper = null;
      this.this$1.this$0.mCallbacksMessenger = null;
      this.this$1.this$0.mHandler.setCallbacksMessenger((Messenger)null);
      this.this$1.this$0.mState = 4;
      this.this$1.this$0.mCallback.onConnectionSuspended();
    }
  }
  
  static interface MediaBrowserServiceCallbackImpl {
    void onConnectionFailed(Messenger param1Messenger);
    
    void onLoadChildren(Messenger param1Messenger, String param1String, List<MediaBrowserCompat.MediaItem> param1List, Bundle param1Bundle1, Bundle param1Bundle2);
    
    void onServiceConnected(Messenger param1Messenger, String param1String, MediaSessionCompat.Token param1Token, Bundle param1Bundle);
  }
  
  public static class MediaItem implements Parcelable {
    public static final Parcelable.Creator<MediaItem> CREATOR = new Parcelable.Creator<MediaItem>() {
        public MediaBrowserCompat.MediaItem createFromParcel(Parcel param2Parcel) {
          return new MediaBrowserCompat.MediaItem(param2Parcel);
        }
        
        public MediaBrowserCompat.MediaItem[] newArray(int param2Int) {
          return new MediaBrowserCompat.MediaItem[param2Int];
        }
      };
    
    public static final int FLAG_BROWSABLE = 1;
    
    public static final int FLAG_PLAYABLE = 2;
    
    private final MediaDescriptionCompat mDescription;
    
    private final int mFlags;
    
    MediaItem(Parcel param1Parcel) {
      this.mFlags = param1Parcel.readInt();
      this.mDescription = (MediaDescriptionCompat)MediaDescriptionCompat.CREATOR.createFromParcel(param1Parcel);
    }
    
    public MediaItem(MediaDescriptionCompat param1MediaDescriptionCompat, int param1Int) {
      if (param1MediaDescriptionCompat != null) {
        if (!TextUtils.isEmpty(param1MediaDescriptionCompat.getMediaId())) {
          this.mFlags = param1Int;
          this.mDescription = param1MediaDescriptionCompat;
          return;
        } 
        throw new IllegalArgumentException(v416f9e89.xbd520268("328"));
      } 
      throw new IllegalArgumentException(v416f9e89.xbd520268("329"));
    }
    
    public static MediaItem fromMediaItem(Object param1Object) {
      if (param1Object == null || Build.VERSION.SDK_INT < 21)
        return null; 
      param1Object = param1Object;
      int i = param1Object.getFlags();
      return new MediaItem(MediaDescriptionCompat.fromMediaDescription(param1Object.getDescription()), i);
    }
    
    public static List<MediaItem> fromMediaItemList(List<?> param1List) {
      if (param1List == null || Build.VERSION.SDK_INT < 21)
        return null; 
      ArrayList<MediaItem> arrayList = new ArrayList(param1List.size());
      Iterator<?> iterator = param1List.iterator();
      while (iterator.hasNext())
        arrayList.add(fromMediaItem(iterator.next())); 
      return arrayList;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public MediaDescriptionCompat getDescription() {
      return this.mDescription;
    }
    
    public int getFlags() {
      return this.mFlags;
    }
    
    public String getMediaId() {
      return this.mDescription.getMediaId();
    }
    
    public boolean isBrowsable() {
      return ((this.mFlags & 0x1) != 0);
    }
    
    public boolean isPlayable() {
      return ((this.mFlags & 0x2) != 0);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder(v416f9e89.xbd520268("330"));
      stringBuilder.append(v416f9e89.xbd520268("331"));
      stringBuilder.append(this.mFlags);
      stringBuilder.append(v416f9e89.xbd520268("332"));
      stringBuilder.append(this.mDescription);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeInt(this.mFlags);
      this.mDescription.writeToParcel(param1Parcel, param1Int);
    }
  }
  
  class null implements Parcelable.Creator<MediaItem> {
    public MediaBrowserCompat.MediaItem createFromParcel(Parcel param1Parcel) {
      return new MediaBrowserCompat.MediaItem(param1Parcel);
    }
    
    public MediaBrowserCompat.MediaItem[] newArray(int param1Int) {
      return new MediaBrowserCompat.MediaItem[param1Int];
    }
  }
  
  public static abstract class SearchCallback {
    public void onError(String param1String, Bundle param1Bundle) {}
    
    public void onSearchResult(String param1String, Bundle param1Bundle, List<MediaBrowserCompat.MediaItem> param1List) {}
  }
  
  private static class SearchResultReceiver extends ResultReceiver {
    private final MediaBrowserCompat.SearchCallback mCallback;
    
    private final Bundle mExtras;
    
    private final String mQuery;
    
    SearchResultReceiver(String param1String, Bundle param1Bundle, MediaBrowserCompat.SearchCallback param1SearchCallback, Handler param1Handler) {
      super(param1Handler);
      this.mQuery = param1String;
      this.mExtras = param1Bundle;
      this.mCallback = param1SearchCallback;
    }
    
    protected void onReceiveResult(int param1Int, Bundle param1Bundle) {
      Bundle bundle = param1Bundle;
      if (param1Bundle != null)
        bundle = MediaSessionCompat.unparcelWithClassLoader(param1Bundle); 
      if (param1Int == 0 && bundle != null) {
        String str = v416f9e89.xbd520268("343");
        if (bundle.containsKey(str)) {
          Parcelable[] arrayOfParcelable = bundle.getParcelableArray(str);
          if (arrayOfParcelable != null) {
            ArrayList<MediaBrowserCompat.MediaItem> arrayList = new ArrayList();
            int i = arrayOfParcelable.length;
            for (param1Int = 0; param1Int < i; param1Int++)
              arrayList.add((MediaBrowserCompat.MediaItem)arrayOfParcelable[param1Int]); 
            this.mCallback.onSearchResult(this.mQuery, this.mExtras, arrayList);
            return;
          } 
          this.mCallback.onError(this.mQuery, this.mExtras);
          return;
        } 
      } 
      this.mCallback.onError(this.mQuery, this.mExtras);
    }
  }
  
  private static class ServiceBinderWrapper {
    private Messenger mMessenger;
    
    private Bundle mRootHints;
    
    public ServiceBinderWrapper(IBinder param1IBinder, Bundle param1Bundle) {
      this.mMessenger = new Messenger(param1IBinder);
      this.mRootHints = param1Bundle;
    }
    
    private void sendRequest(int param1Int, Bundle param1Bundle, Messenger param1Messenger) throws RemoteException {
      Message message = Message.obtain();
      message.what = param1Int;
      message.arg1 = 1;
      message.setData(param1Bundle);
      message.replyTo = param1Messenger;
      this.mMessenger.send(message);
    }
    
    void addSubscription(String param1String, IBinder param1IBinder, Bundle param1Bundle, Messenger param1Messenger) throws RemoteException {
      Bundle bundle = new Bundle();
      bundle.putString(v416f9e89.xbd520268("348"), param1String);
      BundleCompat.putBinder(bundle, v416f9e89.xbd520268("349"), param1IBinder);
      bundle.putBundle(v416f9e89.xbd520268("350"), param1Bundle);
      sendRequest(3, bundle, param1Messenger);
    }
    
    void connect(Context param1Context, Messenger param1Messenger) throws RemoteException {
      Bundle bundle2 = new Bundle();
      String str = param1Context.getPackageName();
      bundle2.putString(v416f9e89.xbd520268("351"), str);
      int i = Process.myPid();
      bundle2.putInt(v416f9e89.xbd520268("352"), i);
      Bundle bundle1 = this.mRootHints;
      bundle2.putBundle(v416f9e89.xbd520268("353"), bundle1);
      sendRequest(1, bundle2, param1Messenger);
    }
    
    void disconnect(Messenger param1Messenger) throws RemoteException {
      sendRequest(2, null, param1Messenger);
    }
    
    void getMediaItem(String param1String, ResultReceiver param1ResultReceiver, Messenger param1Messenger) throws RemoteException {
      Bundle bundle = new Bundle();
      bundle.putString(v416f9e89.xbd520268("354"), param1String);
      bundle.putParcelable(v416f9e89.xbd520268("355"), (Parcelable)param1ResultReceiver);
      sendRequest(5, bundle, param1Messenger);
    }
    
    void registerCallbackMessenger(Context param1Context, Messenger param1Messenger) throws RemoteException {
      Bundle bundle2 = new Bundle();
      String str = param1Context.getPackageName();
      bundle2.putString(v416f9e89.xbd520268("356"), str);
      int i = Process.myPid();
      bundle2.putInt(v416f9e89.xbd520268("357"), i);
      Bundle bundle1 = this.mRootHints;
      bundle2.putBundle(v416f9e89.xbd520268("358"), bundle1);
      sendRequest(6, bundle2, param1Messenger);
    }
    
    void removeSubscription(String param1String, IBinder param1IBinder, Messenger param1Messenger) throws RemoteException {
      Bundle bundle = new Bundle();
      bundle.putString(v416f9e89.xbd520268("359"), param1String);
      BundleCompat.putBinder(bundle, v416f9e89.xbd520268("360"), param1IBinder);
      sendRequest(4, bundle, param1Messenger);
    }
    
    void search(String param1String, Bundle param1Bundle, ResultReceiver param1ResultReceiver, Messenger param1Messenger) throws RemoteException {
      Bundle bundle = new Bundle();
      bundle.putString(v416f9e89.xbd520268("361"), param1String);
      bundle.putBundle(v416f9e89.xbd520268("362"), param1Bundle);
      bundle.putParcelable(v416f9e89.xbd520268("363"), (Parcelable)param1ResultReceiver);
      sendRequest(8, bundle, param1Messenger);
    }
    
    void sendCustomAction(String param1String, Bundle param1Bundle, ResultReceiver param1ResultReceiver, Messenger param1Messenger) throws RemoteException {
      Bundle bundle = new Bundle();
      bundle.putString(v416f9e89.xbd520268("364"), param1String);
      bundle.putBundle(v416f9e89.xbd520268("365"), param1Bundle);
      bundle.putParcelable(v416f9e89.xbd520268("366"), (Parcelable)param1ResultReceiver);
      sendRequest(9, bundle, param1Messenger);
    }
    
    void unregisterCallbackMessenger(Messenger param1Messenger) throws RemoteException {
      sendRequest(7, null, param1Messenger);
    }
  }
  
  private static class Subscription {
    private final List<MediaBrowserCompat.SubscriptionCallback> mCallbacks = new ArrayList<MediaBrowserCompat.SubscriptionCallback>();
    
    private final List<Bundle> mOptionsList = new ArrayList<Bundle>();
    
    public MediaBrowserCompat.SubscriptionCallback getCallback(Bundle param1Bundle) {
      for (int i = 0; i < this.mOptionsList.size(); i++) {
        if (MediaBrowserCompatUtils.areSameOptions(this.mOptionsList.get(i), param1Bundle))
          return this.mCallbacks.get(i); 
      } 
      return null;
    }
    
    public List<MediaBrowserCompat.SubscriptionCallback> getCallbacks() {
      return this.mCallbacks;
    }
    
    public List<Bundle> getOptionsList() {
      return this.mOptionsList;
    }
    
    public boolean isEmpty() {
      return this.mCallbacks.isEmpty();
    }
    
    public void putCallback(Bundle param1Bundle, MediaBrowserCompat.SubscriptionCallback param1SubscriptionCallback) {
      for (int i = 0; i < this.mOptionsList.size(); i++) {
        if (MediaBrowserCompatUtils.areSameOptions(this.mOptionsList.get(i), param1Bundle)) {
          this.mCallbacks.set(i, param1SubscriptionCallback);
          return;
        } 
      } 
      this.mCallbacks.add(param1SubscriptionCallback);
      this.mOptionsList.add(param1Bundle);
    }
  }
  
  public static abstract class SubscriptionCallback {
    final MediaBrowser.SubscriptionCallback mSubscriptionCallbackFwk;
    
    WeakReference<MediaBrowserCompat.Subscription> mSubscriptionRef;
    
    final IBinder mToken = (IBinder)new Binder();
    
    public SubscriptionCallback() {
      if (Build.VERSION.SDK_INT >= 26) {
        this.mSubscriptionCallbackFwk = new SubscriptionCallbackApi26();
        return;
      } 
      if (Build.VERSION.SDK_INT >= 21) {
        this.mSubscriptionCallbackFwk = new SubscriptionCallbackApi21();
        return;
      } 
      this.mSubscriptionCallbackFwk = null;
    }
    
    public void onChildrenLoaded(String param1String, List<MediaBrowserCompat.MediaItem> param1List) {}
    
    public void onChildrenLoaded(String param1String, List<MediaBrowserCompat.MediaItem> param1List, Bundle param1Bundle) {}
    
    public void onError(String param1String) {}
    
    public void onError(String param1String, Bundle param1Bundle) {}
    
    void setSubscription(MediaBrowserCompat.Subscription param1Subscription) {
      this.mSubscriptionRef = new WeakReference<MediaBrowserCompat.Subscription>(param1Subscription);
    }
    
    private class SubscriptionCallbackApi21 extends MediaBrowser.SubscriptionCallback {
      List<MediaBrowserCompat.MediaItem> applyOptions(List<MediaBrowserCompat.MediaItem> param2List, Bundle param2Bundle) {
        if (param2List == null)
          return null; 
        int i = param2Bundle.getInt(v416f9e89.xbd520268("370"), -1);
        int m = param2Bundle.getInt(v416f9e89.xbd520268("371"), -1);
        if (i == -1 && m == -1)
          return param2List; 
        int k = m * i;
        int j = k + m;
        if (i < 0 || m < 1 || k >= param2List.size())
          return Collections.emptyList(); 
        i = j;
        if (j > param2List.size())
          i = param2List.size(); 
        return param2List.subList(k, i);
      }
      
      public void onChildrenLoaded(String param2String, List<MediaBrowser.MediaItem> param2List) {
        MediaBrowserCompat.Subscription subscription;
        if (MediaBrowserCompat.SubscriptionCallback.this.mSubscriptionRef == null) {
          subscription = null;
        } else {
          subscription = MediaBrowserCompat.SubscriptionCallback.this.mSubscriptionRef.get();
        } 
        if (subscription == null) {
          MediaBrowserCompat.SubscriptionCallback.this.onChildrenLoaded(param2String, MediaBrowserCompat.MediaItem.fromMediaItemList(param2List));
          return;
        } 
        param2List = (List)MediaBrowserCompat.MediaItem.fromMediaItemList(param2List);
        List<MediaBrowserCompat.SubscriptionCallback> list1 = subscription.getCallbacks();
        List<Bundle> list = subscription.getOptionsList();
        for (int i = 0; i < list1.size(); i++) {
          Bundle bundle = list.get(i);
          if (bundle == null) {
            MediaBrowserCompat.SubscriptionCallback.this.onChildrenLoaded(param2String, (List)param2List);
          } else {
            MediaBrowserCompat.SubscriptionCallback.this.onChildrenLoaded(param2String, applyOptions((List)param2List, bundle), bundle);
          } 
        } 
      }
      
      public void onError(String param2String) {
        MediaBrowserCompat.SubscriptionCallback.this.onError(param2String);
      }
    }
    
    private class SubscriptionCallbackApi26 extends SubscriptionCallbackApi21 {
      public void onChildrenLoaded(String param2String, List<MediaBrowser.MediaItem> param2List, Bundle param2Bundle) {
        MediaSessionCompat.ensureClassLoader(param2Bundle);
        MediaBrowserCompat.SubscriptionCallback.this.onChildrenLoaded(param2String, MediaBrowserCompat.MediaItem.fromMediaItemList(param2List), param2Bundle);
      }
      
      public void onError(String param2String, Bundle param2Bundle) {
        MediaSessionCompat.ensureClassLoader(param2Bundle);
        MediaBrowserCompat.SubscriptionCallback.this.onError(param2String, param2Bundle);
      }
    }
  }
  
  private class SubscriptionCallbackApi21 extends MediaBrowser.SubscriptionCallback {
    List<MediaBrowserCompat.MediaItem> applyOptions(List<MediaBrowserCompat.MediaItem> param1List, Bundle param1Bundle) {
      if (param1List == null)
        return null; 
      int i = param1Bundle.getInt(v416f9e89.xbd520268("370"), -1);
      int m = param1Bundle.getInt(v416f9e89.xbd520268("371"), -1);
      if (i == -1 && m == -1)
        return param1List; 
      int k = m * i;
      int j = k + m;
      if (i < 0 || m < 1 || k >= param1List.size())
        return Collections.emptyList(); 
      i = j;
      if (j > param1List.size())
        i = param1List.size(); 
      return param1List.subList(k, i);
    }
    
    public void onChildrenLoaded(String param1String, List<MediaBrowser.MediaItem> param1List) {
      MediaBrowserCompat.Subscription subscription;
      if (this.this$0.mSubscriptionRef == null) {
        subscription = null;
      } else {
        subscription = this.this$0.mSubscriptionRef.get();
      } 
      if (subscription == null) {
        this.this$0.onChildrenLoaded(param1String, MediaBrowserCompat.MediaItem.fromMediaItemList(param1List));
        return;
      } 
      param1List = (List)MediaBrowserCompat.MediaItem.fromMediaItemList(param1List);
      List<MediaBrowserCompat.SubscriptionCallback> list1 = subscription.getCallbacks();
      List<Bundle> list = subscription.getOptionsList();
      for (int i = 0; i < list1.size(); i++) {
        Bundle bundle = list.get(i);
        if (bundle == null) {
          this.this$0.onChildrenLoaded(param1String, (List)param1List);
        } else {
          this.this$0.onChildrenLoaded(param1String, applyOptions((List)param1List, bundle), bundle);
        } 
      } 
    }
    
    public void onError(String param1String) {
      this.this$0.onError(param1String);
    }
  }
  
  private class SubscriptionCallbackApi26 extends SubscriptionCallback.SubscriptionCallbackApi21 {
    SubscriptionCallbackApi26() {
      super((MediaBrowserCompat.SubscriptionCallback)MediaBrowserCompat.this);
    }
    
    public void onChildrenLoaded(String param1String, List<MediaBrowser.MediaItem> param1List, Bundle param1Bundle) {
      MediaSessionCompat.ensureClassLoader(param1Bundle);
      this.this$0.onChildrenLoaded(param1String, MediaBrowserCompat.MediaItem.fromMediaItemList(param1List), param1Bundle);
    }
    
    public void onError(String param1String, Bundle param1Bundle) {
      MediaSessionCompat.ensureClassLoader(param1Bundle);
      this.this$0.onError(param1String, param1Bundle);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\android\support\v4\media\MediaBrowserCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */