package androidx.concurrent.futures;

import h8800e55c.pc41fcc5f.v416f9e89;
import java.util.concurrent.Executor;

public enum DirectExecutor implements Executor {
  INSTANCE;
  
  static {
    DirectExecutor directExecutor = new DirectExecutor(v416f9e89.xbd520268("2015"), 0);
    INSTANCE = directExecutor;
    $VALUES = new DirectExecutor[] { directExecutor };
  }
  
  public void execute(Runnable paramRunnable) {
    paramRunnable.run();
  }
  
  public String toString() {
    return v416f9e89.xbd520268("2016");
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\concurrent\futures\DirectExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */