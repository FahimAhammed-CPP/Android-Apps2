package androidx.collection;

import h8800e55c.pc41fcc5f.v416f9e89;
import java.util.LinkedHashMap;
import java.util.Map;

public class LruCache<K, V> {
  private int createCount;
  
  private int evictionCount;
  
  private int hitCount;
  
  private final LinkedHashMap<K, V> map;
  
  private int maxSize;
  
  private int missCount;
  
  private int putCount;
  
  private int size;
  
  public LruCache(int paramInt) {
    if (paramInt > 0) {
      this.maxSize = paramInt;
      this.map = new LinkedHashMap<K, V>(0, 0.75F, true);
      return;
    } 
    throw new IllegalArgumentException(v416f9e89.xbd520268("1854"));
  }
  
  private int safeSizeOf(K paramK, V paramV) {
    int i = sizeOf(paramK, paramV);
    if (i >= 0)
      return i; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(v416f9e89.xbd520268("1855"));
    stringBuilder.append(paramK);
    stringBuilder.append(v416f9e89.xbd520268("1856"));
    stringBuilder.append(paramV);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  protected V create(K paramK) {
    return null;
  }
  
  public final int createCount() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield createCount : I
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  protected void entryRemoved(boolean paramBoolean, K paramK, V paramV1, V paramV2) {}
  
  public final void evictAll() {
    trimToSize(-1);
  }
  
  public final int evictionCount() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield evictionCount : I
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public final V get(K paramK) {
    // Byte code:
    //   0: aload_1
    //   1: ldc '1857'
    //   3: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   6: invokestatic requireNonNull : (Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    //   9: pop
    //   10: aload_0
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield map : Ljava/util/LinkedHashMap;
    //   16: aload_1
    //   17: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   20: astore_2
    //   21: aload_2
    //   22: ifnull -> 39
    //   25: aload_0
    //   26: aload_0
    //   27: getfield hitCount : I
    //   30: iconst_1
    //   31: iadd
    //   32: putfield hitCount : I
    //   35: aload_0
    //   36: monitorexit
    //   37: aload_2
    //   38: areturn
    //   39: aload_0
    //   40: aload_0
    //   41: getfield missCount : I
    //   44: iconst_1
    //   45: iadd
    //   46: putfield missCount : I
    //   49: aload_0
    //   50: monitorexit
    //   51: aload_0
    //   52: aload_1
    //   53: invokevirtual create : (Ljava/lang/Object;)Ljava/lang/Object;
    //   56: astore_2
    //   57: aload_2
    //   58: ifnonnull -> 63
    //   61: aconst_null
    //   62: areturn
    //   63: aload_0
    //   64: monitorenter
    //   65: aload_0
    //   66: aload_0
    //   67: getfield createCount : I
    //   70: iconst_1
    //   71: iadd
    //   72: putfield createCount : I
    //   75: aload_0
    //   76: getfield map : Ljava/util/LinkedHashMap;
    //   79: aload_1
    //   80: aload_2
    //   81: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   84: astore_3
    //   85: aload_3
    //   86: ifnull -> 102
    //   89: aload_0
    //   90: getfield map : Ljava/util/LinkedHashMap;
    //   93: aload_1
    //   94: aload_3
    //   95: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   98: pop
    //   99: goto -> 117
    //   102: aload_0
    //   103: aload_0
    //   104: getfield size : I
    //   107: aload_0
    //   108: aload_1
    //   109: aload_2
    //   110: invokespecial safeSizeOf : (Ljava/lang/Object;Ljava/lang/Object;)I
    //   113: iadd
    //   114: putfield size : I
    //   117: aload_0
    //   118: monitorexit
    //   119: aload_3
    //   120: ifnull -> 133
    //   123: aload_0
    //   124: iconst_0
    //   125: aload_1
    //   126: aload_2
    //   127: aload_3
    //   128: invokevirtual entryRemoved : (ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    //   131: aload_3
    //   132: areturn
    //   133: aload_0
    //   134: aload_0
    //   135: getfield maxSize : I
    //   138: invokevirtual trimToSize : (I)V
    //   141: aload_2
    //   142: areturn
    //   143: astore_1
    //   144: aload_0
    //   145: monitorexit
    //   146: aload_1
    //   147: athrow
    //   148: astore_1
    //   149: aload_0
    //   150: monitorexit
    //   151: aload_1
    //   152: athrow
    // Exception table:
    //   from	to	target	type
    //   12	21	148	finally
    //   25	37	148	finally
    //   39	51	148	finally
    //   65	85	143	finally
    //   89	99	143	finally
    //   102	117	143	finally
    //   117	119	143	finally
    //   144	146	143	finally
    //   149	151	148	finally
  }
  
  public final int hitCount() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield hitCount : I
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public final int maxSize() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield maxSize : I
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public final int missCount() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield missCount : I
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public final V put(K paramK, V paramV) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 93
    //   4: aload_2
    //   5: ifnull -> 93
    //   8: aload_0
    //   9: monitorenter
    //   10: aload_0
    //   11: aload_0
    //   12: getfield putCount : I
    //   15: iconst_1
    //   16: iadd
    //   17: putfield putCount : I
    //   20: aload_0
    //   21: aload_0
    //   22: getfield size : I
    //   25: aload_0
    //   26: aload_1
    //   27: aload_2
    //   28: invokespecial safeSizeOf : (Ljava/lang/Object;Ljava/lang/Object;)I
    //   31: iadd
    //   32: putfield size : I
    //   35: aload_0
    //   36: getfield map : Ljava/util/LinkedHashMap;
    //   39: aload_1
    //   40: aload_2
    //   41: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   44: astore_3
    //   45: aload_3
    //   46: ifnull -> 64
    //   49: aload_0
    //   50: aload_0
    //   51: getfield size : I
    //   54: aload_0
    //   55: aload_1
    //   56: aload_3
    //   57: invokespecial safeSizeOf : (Ljava/lang/Object;Ljava/lang/Object;)I
    //   60: isub
    //   61: putfield size : I
    //   64: aload_0
    //   65: monitorexit
    //   66: aload_3
    //   67: ifnull -> 78
    //   70: aload_0
    //   71: iconst_0
    //   72: aload_1
    //   73: aload_3
    //   74: aload_2
    //   75: invokevirtual entryRemoved : (ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    //   78: aload_0
    //   79: aload_0
    //   80: getfield maxSize : I
    //   83: invokevirtual trimToSize : (I)V
    //   86: aload_3
    //   87: areturn
    //   88: astore_1
    //   89: aload_0
    //   90: monitorexit
    //   91: aload_1
    //   92: athrow
    //   93: new java/lang/NullPointerException
    //   96: dup
    //   97: ldc '1858'
    //   99: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   102: invokespecial <init> : (Ljava/lang/String;)V
    //   105: athrow
    // Exception table:
    //   from	to	target	type
    //   10	45	88	finally
    //   49	64	88	finally
    //   64	66	88	finally
    //   89	91	88	finally
  }
  
  public final int putCount() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield putCount : I
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public final V remove(K paramK) {
    // Byte code:
    //   0: aload_1
    //   1: ldc '1859'
    //   3: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   6: invokestatic requireNonNull : (Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    //   9: pop
    //   10: aload_0
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield map : Ljava/util/LinkedHashMap;
    //   16: aload_1
    //   17: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   20: astore_2
    //   21: aload_2
    //   22: ifnull -> 40
    //   25: aload_0
    //   26: aload_0
    //   27: getfield size : I
    //   30: aload_0
    //   31: aload_1
    //   32: aload_2
    //   33: invokespecial safeSizeOf : (Ljava/lang/Object;Ljava/lang/Object;)I
    //   36: isub
    //   37: putfield size : I
    //   40: aload_0
    //   41: monitorexit
    //   42: aload_2
    //   43: ifnull -> 54
    //   46: aload_0
    //   47: iconst_0
    //   48: aload_1
    //   49: aload_2
    //   50: aconst_null
    //   51: invokevirtual entryRemoved : (ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    //   54: aload_2
    //   55: areturn
    //   56: astore_1
    //   57: aload_0
    //   58: monitorexit
    //   59: aload_1
    //   60: athrow
    // Exception table:
    //   from	to	target	type
    //   12	21	56	finally
    //   25	40	56	finally
    //   40	42	56	finally
    //   57	59	56	finally
  }
  
  public void resize(int paramInt) {
    // Byte code:
    //   0: iload_1
    //   1: ifle -> 24
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: iload_1
    //   8: putfield maxSize : I
    //   11: aload_0
    //   12: monitorexit
    //   13: aload_0
    //   14: iload_1
    //   15: invokevirtual trimToSize : (I)V
    //   18: return
    //   19: astore_2
    //   20: aload_0
    //   21: monitorexit
    //   22: aload_2
    //   23: athrow
    //   24: new java/lang/IllegalArgumentException
    //   27: dup
    //   28: ldc '1860'
    //   30: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   33: invokespecial <init> : (Ljava/lang/String;)V
    //   36: athrow
    // Exception table:
    //   from	to	target	type
    //   6	13	19	finally
    //   20	22	19	finally
  }
  
  public final int size() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield size : I
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  protected int sizeOf(K paramK, V paramV) {
    return 1;
  }
  
  public final Map<K, V> snapshot() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new java/util/LinkedHashMap
    //   5: dup
    //   6: aload_0
    //   7: getfield map : Ljava/util/LinkedHashMap;
    //   10: invokespecial <init> : (Ljava/util/Map;)V
    //   13: astore_1
    //   14: aload_0
    //   15: monitorexit
    //   16: aload_1
    //   17: areturn
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_1
    //   22: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	18	finally
  }
  
  public final String toString() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield hitCount : I
    //   6: istore_1
    //   7: aload_0
    //   8: getfield missCount : I
    //   11: iload_1
    //   12: iadd
    //   13: istore_2
    //   14: iload_2
    //   15: ifeq -> 90
    //   18: iload_1
    //   19: bipush #100
    //   21: imul
    //   22: iload_2
    //   23: idiv
    //   24: istore_1
    //   25: goto -> 28
    //   28: getstatic java/util/Locale.US : Ljava/util/Locale;
    //   31: ldc '1861'
    //   33: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   36: iconst_4
    //   37: anewarray java/lang/Object
    //   40: dup
    //   41: iconst_0
    //   42: aload_0
    //   43: getfield maxSize : I
    //   46: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   49: aastore
    //   50: dup
    //   51: iconst_1
    //   52: aload_0
    //   53: getfield hitCount : I
    //   56: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   59: aastore
    //   60: dup
    //   61: iconst_2
    //   62: aload_0
    //   63: getfield missCount : I
    //   66: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   69: aastore
    //   70: dup
    //   71: iconst_3
    //   72: iload_1
    //   73: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   76: aastore
    //   77: invokestatic format : (Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   80: astore_3
    //   81: aload_0
    //   82: monitorexit
    //   83: aload_3
    //   84: areturn
    //   85: astore_3
    //   86: aload_0
    //   87: monitorexit
    //   88: aload_3
    //   89: athrow
    //   90: iconst_0
    //   91: istore_1
    //   92: goto -> 28
    // Exception table:
    //   from	to	target	type
    //   2	14	85	finally
    //   18	25	85	finally
    //   28	81	85	finally
  }
  
  public void trimToSize(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield size : I
    //   6: iflt -> 132
    //   9: aload_0
    //   10: getfield map : Ljava/util/LinkedHashMap;
    //   13: invokevirtual isEmpty : ()Z
    //   16: ifeq -> 26
    //   19: aload_0
    //   20: getfield size : I
    //   23: ifne -> 132
    //   26: aload_0
    //   27: getfield size : I
    //   30: iload_1
    //   31: if_icmple -> 129
    //   34: aload_0
    //   35: getfield map : Ljava/util/LinkedHashMap;
    //   38: invokevirtual isEmpty : ()Z
    //   41: ifeq -> 47
    //   44: goto -> 129
    //   47: aload_0
    //   48: getfield map : Ljava/util/LinkedHashMap;
    //   51: invokevirtual entrySet : ()Ljava/util/Set;
    //   54: invokeinterface iterator : ()Ljava/util/Iterator;
    //   59: invokeinterface next : ()Ljava/lang/Object;
    //   64: checkcast java/util/Map$Entry
    //   67: astore_3
    //   68: aload_3
    //   69: invokeinterface getKey : ()Ljava/lang/Object;
    //   74: astore_2
    //   75: aload_3
    //   76: invokeinterface getValue : ()Ljava/lang/Object;
    //   81: astore_3
    //   82: aload_0
    //   83: getfield map : Ljava/util/LinkedHashMap;
    //   86: aload_2
    //   87: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   90: pop
    //   91: aload_0
    //   92: aload_0
    //   93: getfield size : I
    //   96: aload_0
    //   97: aload_2
    //   98: aload_3
    //   99: invokespecial safeSizeOf : (Ljava/lang/Object;Ljava/lang/Object;)I
    //   102: isub
    //   103: putfield size : I
    //   106: aload_0
    //   107: aload_0
    //   108: getfield evictionCount : I
    //   111: iconst_1
    //   112: iadd
    //   113: putfield evictionCount : I
    //   116: aload_0
    //   117: monitorexit
    //   118: aload_0
    //   119: iconst_1
    //   120: aload_2
    //   121: aload_3
    //   122: aconst_null
    //   123: invokevirtual entryRemoved : (ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    //   126: goto -> 0
    //   129: aload_0
    //   130: monitorexit
    //   131: return
    //   132: new java/lang/StringBuilder
    //   135: dup
    //   136: invokespecial <init> : ()V
    //   139: astore_2
    //   140: aload_2
    //   141: aload_0
    //   142: invokevirtual getClass : ()Ljava/lang/Class;
    //   145: invokevirtual getName : ()Ljava/lang/String;
    //   148: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   151: pop
    //   152: aload_2
    //   153: ldc '1862'
    //   155: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   158: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   161: pop
    //   162: new java/lang/IllegalStateException
    //   165: dup
    //   166: aload_2
    //   167: invokevirtual toString : ()Ljava/lang/String;
    //   170: invokespecial <init> : (Ljava/lang/String;)V
    //   173: athrow
    //   174: astore_2
    //   175: aload_0
    //   176: monitorexit
    //   177: aload_2
    //   178: athrow
    // Exception table:
    //   from	to	target	type
    //   2	26	174	finally
    //   26	44	174	finally
    //   47	118	174	finally
    //   129	131	174	finally
    //   132	174	174	finally
    //   175	177	174	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\collection\LruCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */