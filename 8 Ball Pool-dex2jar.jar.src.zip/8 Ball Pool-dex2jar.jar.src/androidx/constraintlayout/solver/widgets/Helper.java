package androidx.constraintlayout.solver.widgets;

public interface Helper {
  void add(ConstraintWidget paramConstraintWidget);
  
  void removeAllIds();
  
  void updateConstraints(ConstraintWidgetContainer paramConstraintWidgetContainer);
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\constraintlayout\solver\widgets\Helper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */