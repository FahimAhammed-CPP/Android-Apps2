package androidx.constraintlayout.solver.widgets.analyzer;

import androidx.constraintlayout.solver.LinearSystem;
import androidx.constraintlayout.solver.Metrics;
import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.solver.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.solver.widgets.Optimizer;
import androidx.constraintlayout.solver.widgets.VirtualLayout;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.util.ArrayList;

public class BasicMeasure {
  public static final int AT_MOST = -2147483648;
  
  private static final boolean DEBUG = false;
  
  public static final int EXACTLY = 1073741824;
  
  public static final int FIXED = -3;
  
  public static final int MATCH_PARENT = -1;
  
  private static final int MODE_SHIFT = 30;
  
  public static final int UNSPECIFIED = 0;
  
  public static final int WRAP_CONTENT = -2;
  
  private ConstraintWidgetContainer constraintWidgetContainer;
  
  private Measure mMeasure = new Measure();
  
  private final ArrayList<ConstraintWidget> mVariableDimensionsWidgets = new ArrayList<ConstraintWidget>();
  
  public BasicMeasure(ConstraintWidgetContainer paramConstraintWidgetContainer) {
    this.constraintWidgetContainer = paramConstraintWidgetContainer;
  }
  
  private boolean measure(Measurer paramMeasurer, ConstraintWidget paramConstraintWidget, boolean paramBoolean) {
    boolean bool1;
    boolean bool2;
    this.mMeasure.horizontalBehavior = paramConstraintWidget.getHorizontalDimensionBehaviour();
    this.mMeasure.verticalBehavior = paramConstraintWidget.getVerticalDimensionBehaviour();
    this.mMeasure.horizontalDimension = paramConstraintWidget.getWidth();
    this.mMeasure.verticalDimension = paramConstraintWidget.getHeight();
    this.mMeasure.measuredNeedsSolverPass = false;
    this.mMeasure.useCurrentDimensions = paramBoolean;
    if (this.mMeasure.horizontalBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (this.mMeasure.verticalBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool2 && paramConstraintWidget.mDimensionRatio > 0.0F) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (bool1 && paramConstraintWidget.mDimensionRatio > 0.0F) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool2 && paramConstraintWidget.mResolvedMatchConstraintDefault[0] == 4)
      this.mMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED; 
    if (bool1 && paramConstraintWidget.mResolvedMatchConstraintDefault[1] == 4)
      this.mMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED; 
    paramMeasurer.measure(paramConstraintWidget, this.mMeasure);
    paramConstraintWidget.setWidth(this.mMeasure.measuredWidth);
    paramConstraintWidget.setHeight(this.mMeasure.measuredHeight);
    paramConstraintWidget.setHasBaseline(this.mMeasure.measuredHasBaseline);
    paramConstraintWidget.setBaselineDistance(this.mMeasure.measuredBaseline);
    this.mMeasure.useCurrentDimensions = false;
    return this.mMeasure.measuredNeedsSolverPass;
  }
  
  private void measureChildren(ConstraintWidgetContainer paramConstraintWidgetContainer) {
    int j = paramConstraintWidgetContainer.mChildren.size();
    Measurer measurer = paramConstraintWidgetContainer.getMeasurer();
    for (int i = 0; i < j; i++) {
      ConstraintWidget constraintWidget = paramConstraintWidgetContainer.mChildren.get(i);
      if (!(constraintWidget instanceof androidx.constraintlayout.solver.widgets.Guideline) && (!constraintWidget.horizontalRun.dimension.resolved || !constraintWidget.verticalRun.dimension.resolved)) {
        ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = constraintWidget.getDimensionBehaviour(0);
        boolean bool = true;
        ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = constraintWidget.getDimensionBehaviour(1);
        if (dimensionBehaviour1 != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT || constraintWidget.mMatchConstraintDefaultWidth == 1 || dimensionBehaviour2 != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT || constraintWidget.mMatchConstraintDefaultHeight == 1)
          bool = false; 
        if (!bool) {
          measure(measurer, constraintWidget, false);
          if (paramConstraintWidgetContainer.mMetrics != null) {
            Metrics metrics = paramConstraintWidgetContainer.mMetrics;
            metrics.measuredWidgets++;
          } 
        } 
      } 
    } 
    measurer.didMeasures();
  }
  
  private void solveLinearSystem(ConstraintWidgetContainer paramConstraintWidgetContainer, String paramString, int paramInt1, int paramInt2) {
    int i = paramConstraintWidgetContainer.getMinWidth();
    int j = paramConstraintWidgetContainer.getMinHeight();
    paramConstraintWidgetContainer.setMinWidth(0);
    paramConstraintWidgetContainer.setMinHeight(0);
    paramConstraintWidgetContainer.setWidth(paramInt1);
    paramConstraintWidgetContainer.setHeight(paramInt2);
    paramConstraintWidgetContainer.setMinWidth(i);
    paramConstraintWidgetContainer.setMinHeight(j);
    this.constraintWidgetContainer.layout();
  }
  
  public long solverMeasure(ConstraintWidgetContainer paramConstraintWidgetContainer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9) {
    Measurer measurer = paramConstraintWidgetContainer.getMeasurer();
    paramInt9 = paramConstraintWidgetContainer.mChildren.size();
    int i = paramConstraintWidgetContainer.getWidth();
    int j = paramConstraintWidgetContainer.getHeight();
    boolean bool = Optimizer.enabled(paramInt1, 128);
    if (bool || Optimizer.enabled(paramInt1, 64)) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    paramInt3 = paramInt1;
    if (paramInt1 != 0) {
      paramInt2 = 0;
      while (true) {
        paramInt3 = paramInt1;
        if (paramInt2 < paramInt9) {
          ConstraintWidget constraintWidget = paramConstraintWidgetContainer.mChildren.get(paramInt2);
          if (constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
            paramInt3 = 1;
          } else {
            paramInt3 = 0;
          } 
          if (constraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
            paramInt8 = 1;
          } else {
            paramInt8 = 0;
          } 
          if (paramInt3 != 0 && paramInt8 != 0 && constraintWidget.getDimensionRatio() > 0.0F) {
            paramInt3 = 1;
          } else {
            paramInt3 = 0;
          } 
          if ((constraintWidget.isInHorizontalChain() && paramInt3 != 0) || (constraintWidget.isInVerticalChain() && paramInt3 != 0) || constraintWidget instanceof VirtualLayout || constraintWidget.isInHorizontalChain() || constraintWidget.isInVerticalChain()) {
            paramInt3 = 0;
            break;
          } 
          paramInt2++;
          continue;
        } 
        break;
      } 
    } 
    if (paramInt3 != 0 && LinearSystem.sMetrics != null) {
      Metrics metrics = LinearSystem.sMetrics;
      metrics.measures++;
    } 
    if ((paramInt4 == 1073741824 && paramInt6 == 1073741824) || bool) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    if ((paramInt3 & paramInt1) != 0) {
      boolean bool1;
      paramInt1 = Math.min(paramConstraintWidgetContainer.getMaxWidth(), paramInt5);
      paramInt2 = Math.min(paramConstraintWidgetContainer.getMaxHeight(), paramInt7);
      if (paramInt4 == 1073741824 && paramConstraintWidgetContainer.getWidth() != paramInt1) {
        paramConstraintWidgetContainer.setWidth(paramInt1);
        paramConstraintWidgetContainer.invalidateGraph();
      } 
      if (paramInt6 == 1073741824 && paramConstraintWidgetContainer.getHeight() != paramInt2) {
        paramConstraintWidgetContainer.setHeight(paramInt2);
        paramConstraintWidgetContainer.invalidateGraph();
      } 
      if (paramInt4 == 1073741824 && paramInt6 == 1073741824) {
        bool1 = paramConstraintWidgetContainer.directMeasure(bool);
        paramInt1 = 2;
      } else {
        bool1 = paramConstraintWidgetContainer.directMeasureSetup(bool);
        if (paramInt4 == 1073741824) {
          bool1 &= paramConstraintWidgetContainer.directMeasureWithOrientation(bool, 0);
          paramInt1 = 1;
        } else {
          paramInt1 = 0;
        } 
        if (paramInt6 == 1073741824) {
          bool = paramConstraintWidgetContainer.directMeasureWithOrientation(bool, 1);
          paramInt1++;
          bool1 = bool & bool1;
        } 
      } 
      bool = bool1;
      paramInt2 = paramInt1;
      if (bool1) {
        boolean bool2;
        if (paramInt4 == 1073741824) {
          bool = true;
        } else {
          bool = false;
        } 
        if (paramInt6 == 1073741824) {
          bool2 = true;
        } else {
          bool2 = false;
        } 
        paramConstraintWidgetContainer.updateFromRuns(bool, bool2);
        bool = bool1;
        paramInt2 = paramInt1;
      } 
    } else {
      bool = false;
      paramInt2 = 0;
    } 
    if (!bool || paramInt2 != 2) {
      if (paramInt9 > 0)
        measureChildren(paramConstraintWidgetContainer); 
      paramInt3 = paramConstraintWidgetContainer.getOptimizationLevel();
      int k = this.mVariableDimensionsWidgets.size();
      if (paramInt9 > 0)
        solveLinearSystem(paramConstraintWidgetContainer, v416f9e89.xbd520268("2536"), i, j); 
      paramInt1 = paramInt3;
      if (k > 0) {
        boolean bool2;
        if (paramConstraintWidgetContainer.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
          paramInt8 = 1;
        } else {
          paramInt8 = 0;
        } 
        if (paramConstraintWidgetContainer.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
          paramInt9 = 1;
        } else {
          paramInt9 = 0;
        } 
        paramInt2 = Math.max(paramConstraintWidgetContainer.getWidth(), this.constraintWidgetContainer.getMinWidth());
        paramInt1 = Math.max(paramConstraintWidgetContainer.getHeight(), this.constraintWidgetContainer.getMinHeight());
        int n = 0;
        paramInt6 = 0;
        paramInt4 = j;
        paramInt5 = i;
        while (n < k) {
          boolean bool3;
          ConstraintWidget constraintWidget = this.mVariableDimensionsWidgets.get(n);
          if (!(constraintWidget instanceof VirtualLayout)) {
            paramInt7 = paramInt6;
          } else {
            int i1 = constraintWidget.getWidth();
            i = constraintWidget.getHeight();
            bool3 = paramInt6 | measure(measurer, constraintWidget, true);
            if (paramConstraintWidgetContainer.mMetrics != null) {
              Metrics metrics = paramConstraintWidgetContainer.mMetrics;
              metrics.measuredMatchWidgets++;
            } 
            int i2 = constraintWidget.getWidth();
            j = constraintWidget.getHeight();
            paramInt6 = paramInt2;
            if (i2 != i1) {
              constraintWidget.setWidth(i2);
              paramInt6 = paramInt2;
              if (paramInt8 != 0) {
                paramInt6 = paramInt2;
                if (constraintWidget.getRight() > paramInt2)
                  paramInt6 = Math.max(paramInt2, constraintWidget.getRight() + constraintWidget.getAnchor(ConstraintAnchor.Type.RIGHT).getMargin()); 
              } 
              bool3 = true;
            } 
            paramInt2 = paramInt1;
            if (j != i) {
              constraintWidget.setHeight(j);
              paramInt2 = paramInt1;
              if (paramInt9 != 0) {
                paramInt2 = paramInt1;
                if (constraintWidget.getBottom() > paramInt1)
                  paramInt2 = Math.max(paramInt1, constraintWidget.getBottom() + constraintWidget.getAnchor(ConstraintAnchor.Type.BOTTOM).getMargin()); 
              } 
              bool3 = true;
            } 
            bool3 |= ((VirtualLayout)constraintWidget).needSolverPass();
            paramInt1 = paramInt2;
            paramInt2 = paramInt6;
          } 
          n++;
          bool2 = bool3;
        } 
        j = 0;
        n = paramInt4;
        i = paramInt5;
        boolean bool1 = bool2;
        paramInt7 = paramInt1;
        paramInt4 = k;
        int m = j;
        while (m < 2) {
          k = 0;
          paramInt1 = paramInt7;
          j = m;
          while (k < paramInt4) {
            boolean bool3;
            int i1;
            ConstraintWidget constraintWidget = this.mVariableDimensionsWidgets.get(k);
            if ((constraintWidget instanceof androidx.constraintlayout.solver.widgets.Helper && !(constraintWidget instanceof VirtualLayout)) || constraintWidget instanceof androidx.constraintlayout.solver.widgets.Guideline || constraintWidget.getVisibility() == 8 || (constraintWidget.horizontalRun.dimension.resolved && constraintWidget.verticalRun.dimension.resolved) || constraintWidget instanceof VirtualLayout) {
              i1 = paramInt2;
              bool3 = bool1;
            } else {
              paramInt7 = constraintWidget.getWidth();
              i1 = constraintWidget.getHeight();
              int i3 = constraintWidget.getBaselineDistance();
              bool3 = bool1 | measure(measurer, constraintWidget, true);
              if (paramConstraintWidgetContainer.mMetrics != null) {
                Metrics metrics = paramConstraintWidgetContainer.mMetrics;
                metrics.measuredMatchWidgets++;
              } 
              int i5 = constraintWidget.getWidth();
              int i4 = constraintWidget.getHeight();
              int i2 = paramInt2;
              if (i5 != paramInt7) {
                constraintWidget.setWidth(i5);
                i2 = paramInt2;
                if (paramInt8 != 0) {
                  i2 = paramInt2;
                  if (constraintWidget.getRight() > paramInt2)
                    i2 = Math.max(paramInt2, constraintWidget.getRight() + constraintWidget.getAnchor(ConstraintAnchor.Type.RIGHT).getMargin()); 
                } 
                bool3 = true;
              } 
              paramInt2 = paramInt1;
              boolean bool4 = bool3;
              if (i4 != i1) {
                constraintWidget.setHeight(i4);
                paramInt2 = paramInt1;
                if (paramInt9 != 0) {
                  paramInt2 = paramInt1;
                  if (constraintWidget.getBottom() > paramInt1)
                    paramInt2 = Math.max(paramInt1, constraintWidget.getBottom() + constraintWidget.getAnchor(ConstraintAnchor.Type.BOTTOM).getMargin()); 
                } 
                bool4 = true;
              } 
              i1 = i2;
              paramInt1 = paramInt2;
              bool3 = bool4;
              if (constraintWidget.hasBaseline()) {
                i1 = i2;
                paramInt1 = paramInt2;
                bool3 = bool4;
                if (i3 != constraintWidget.getBaselineDistance()) {
                  bool3 = true;
                  paramInt1 = paramInt2;
                  i1 = i2;
                } 
              } 
            } 
            k++;
            paramInt2 = i1;
            bool1 = bool3;
          } 
          if (bool1) {
            solveLinearSystem(paramConstraintWidgetContainer, v416f9e89.xbd520268("2537"), i, n);
            bool1 = false;
          } 
          m = j + 1;
          paramInt7 = paramInt1;
        } 
        if (bool1) {
          solveLinearSystem(paramConstraintWidgetContainer, v416f9e89.xbd520268("2538"), i, n);
          if (paramConstraintWidgetContainer.getWidth() < paramInt2) {
            paramConstraintWidgetContainer.setWidth(paramInt2);
            paramInt1 = 1;
          } else {
            paramInt1 = 0;
          } 
          if (paramConstraintWidgetContainer.getHeight() < paramInt7) {
            paramConstraintWidgetContainer.setHeight(paramInt7);
            paramInt1 = 1;
          } 
          if (paramInt1 != 0)
            solveLinearSystem(paramConstraintWidgetContainer, v416f9e89.xbd520268("2539"), i, n); 
        } 
        paramInt1 = paramInt3;
      } 
      paramConstraintWidgetContainer.setOptimizationLevel(paramInt1);
    } 
    return 0L;
  }
  
  public void updateHierarchy(ConstraintWidgetContainer paramConstraintWidgetContainer) {
    this.mVariableDimensionsWidgets.clear();
    int j = paramConstraintWidgetContainer.mChildren.size();
    for (int i = 0; i < j; i++) {
      ConstraintWidget constraintWidget = paramConstraintWidgetContainer.mChildren.get(i);
      if (constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT || constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_PARENT || constraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT || constraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_PARENT)
        this.mVariableDimensionsWidgets.add(constraintWidget); 
    } 
    paramConstraintWidgetContainer.invalidateGraph();
  }
  
  public static class Measure {
    public ConstraintWidget.DimensionBehaviour horizontalBehavior;
    
    public int horizontalDimension;
    
    public int measuredBaseline;
    
    public boolean measuredHasBaseline;
    
    public int measuredHeight;
    
    public boolean measuredNeedsSolverPass;
    
    public int measuredWidth;
    
    public boolean useCurrentDimensions;
    
    public ConstraintWidget.DimensionBehaviour verticalBehavior;
    
    public int verticalDimension;
  }
  
  public enum MeasureType {
  
  }
  
  public static interface Measurer {
    void didMeasures();
    
    void measure(ConstraintWidget param1ConstraintWidget, BasicMeasure.Measure param1Measure);
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\constraintlayout\solver\widgets\analyzer\BasicMeasure.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */