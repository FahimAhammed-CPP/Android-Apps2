package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.Log;
import android.util.SparseArray;
import android.util.Xml;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.io.IOException;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class ConstraintLayoutStates {
  private static final boolean DEBUG = false;
  
  public static final String TAG = v416f9e89.xbd520268("3080");
  
  private final ConstraintLayout mConstraintLayout;
  
  private SparseArray<ConstraintSet> mConstraintSetMap = new SparseArray();
  
  private ConstraintsChangedListener mConstraintsChangedListener = null;
  
  int mCurrentConstraintNumber = -1;
  
  int mCurrentStateId = -1;
  
  ConstraintSet mDefaultConstraintSet;
  
  private SparseArray<State> mStateList = new SparseArray();
  
  ConstraintLayoutStates(Context paramContext, ConstraintLayout paramConstraintLayout, int paramInt) {
    this.mConstraintLayout = paramConstraintLayout;
    load(paramContext, paramInt);
  }
  
  private void load(Context paramContext, int paramInt) {
    XmlResourceParser xmlResourceParser = paramContext.getResources().getXml(paramInt);
    String str = null;
    try {
      paramInt = xmlResourceParser.getEventType();
    } catch (XmlPullParserException xmlPullParserException) {
      xmlPullParserException.printStackTrace();
      return;
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return;
    } 
    while (true) {
      if (paramInt != 1) {
        String str1;
        if (paramInt != 0) {
          if (paramInt != 2) {
            str1 = str;
          } else {
            String str2 = xmlResourceParser.getName();
            paramInt = -1;
            switch (str2.hashCode()) {
              case 1901439077:
                if (str2.equals(v416f9e89.xbd520268("3081")))
                  paramInt = 3; 
                break;
              case 1657696882:
                if (str2.equals(v416f9e89.xbd520268("3082")))
                  paramInt = 0; 
                break;
              case 1382829617:
                if (str2.equals(v416f9e89.xbd520268("3083")))
                  paramInt = 1; 
                break;
              case 80204913:
                if (str2.equals(v416f9e89.xbd520268("3084")))
                  paramInt = 2; 
                break;
              case -1349929691:
                if (str2.equals(v416f9e89.xbd520268("3085")))
                  paramInt = 4; 
                break;
            } 
            str1 = str;
            if (paramInt != 0) {
              str1 = str;
              if (paramInt != 1)
                if (paramInt != 2) {
                  if (paramInt != 3) {
                    if (paramInt != 4) {
                      str1 = v416f9e89.xbd520268("3086");
                      StringBuilder stringBuilder = new StringBuilder();
                      stringBuilder.append(v416f9e89.xbd520268("3087"));
                      stringBuilder.append(str2);
                      Log.v(str1, stringBuilder.toString());
                      str1 = str;
                    } else {
                      parseConstraintSet((Context)iOException, (XmlPullParser)xmlResourceParser);
                      str1 = str;
                    } 
                  } else {
                    Variant variant = new Variant((Context)iOException, (XmlPullParser)xmlResourceParser);
                    str1 = str;
                    if (str != null) {
                      str.add(variant);
                      str1 = str;
                    } 
                  } 
                } else {
                  State state = new State((Context)iOException, (XmlPullParser)xmlResourceParser);
                  this.mStateList.put(state.mId, state);
                }  
            } 
          } 
        } else {
          xmlResourceParser.getName();
          str1 = str;
        } 
        paramInt = xmlResourceParser.next();
        str = str1;
        continue;
      } 
      return;
    } 
  }
  
  private void parseConstraintSet(Context paramContext, XmlPullParser paramXmlPullParser) {
    ConstraintSet constraintSet = new ConstraintSet();
    int j = paramXmlPullParser.getAttributeCount();
    for (int i = 0; i < j; i++) {
      String str2 = paramXmlPullParser.getAttributeName(i);
      String str1 = v416f9e89.xbd520268("3088");
      if (str1.equals(str2)) {
        str2 = paramXmlPullParser.getAttributeValue(i);
        if (str2.contains(v416f9e89.xbd520268("3089"))) {
          String str = str2.substring(str2.indexOf('/') + 1);
          i = paramContext.getResources().getIdentifier(str, str1, paramContext.getPackageName());
        } else {
          i = -1;
        } 
        j = i;
        if (i == -1)
          if (str2 != null && str2.length() > 1) {
            j = Integer.parseInt(str2.substring(1));
          } else {
            Log.e(v416f9e89.xbd520268("3090"), v416f9e89.xbd520268("3091"));
            j = i;
          }  
        constraintSet.load(paramContext, paramXmlPullParser);
        this.mConstraintSetMap.put(j, constraintSet);
        return;
      } 
    } 
  }
  
  public boolean needsToChange(int paramInt, float paramFloat1, float paramFloat2) {
    int i = this.mCurrentStateId;
    if (i != paramInt)
      return true; 
    if (paramInt == -1) {
      object = this.mStateList.valueAt(0);
    } else {
      object = this.mStateList.get(i);
    } 
    Object object = object;
    return (this.mCurrentConstraintNumber != -1 && ((Variant)((State)object).mVariants.get(this.mCurrentConstraintNumber)).match(paramFloat1, paramFloat2)) ? false : (!(this.mCurrentConstraintNumber == object.findMatch(paramFloat1, paramFloat2)));
  }
  
  public void setOnConstraintsChanged(ConstraintsChangedListener paramConstraintsChangedListener) {
    this.mConstraintsChangedListener = paramConstraintsChangedListener;
  }
  
  public void updateConstraints(int paramInt, float paramFloat1, float paramFloat2) {
    int i = this.mCurrentStateId;
    if (i == paramInt) {
      State state;
      ConstraintSet constraintSet;
      if (paramInt == -1) {
        state = (State)this.mStateList.valueAt(0);
      } else {
        state = (State)this.mStateList.get(i);
      } 
      if (this.mCurrentConstraintNumber != -1 && ((Variant)state.mVariants.get(this.mCurrentConstraintNumber)).match(paramFloat1, paramFloat2))
        return; 
      i = state.findMatch(paramFloat1, paramFloat2);
      if (this.mCurrentConstraintNumber == i)
        return; 
      if (i == -1) {
        constraintSet = this.mDefaultConstraintSet;
      } else {
        constraintSet = ((Variant)state.mVariants.get(i)).mConstraintSet;
      } 
      if (i == -1) {
        paramInt = state.mConstraintID;
      } else {
        paramInt = ((Variant)state.mVariants.get(i)).mConstraintID;
      } 
      if (constraintSet == null)
        return; 
      this.mCurrentConstraintNumber = i;
      ConstraintsChangedListener constraintsChangedListener = this.mConstraintsChangedListener;
      if (constraintsChangedListener != null)
        constraintsChangedListener.preLayoutChange(-1, paramInt); 
      constraintSet.applyTo(this.mConstraintLayout);
      constraintsChangedListener = this.mConstraintsChangedListener;
      if (constraintsChangedListener != null) {
        constraintsChangedListener.postLayoutChange(-1, paramInt);
        return;
      } 
    } else {
      ConstraintSet constraintSet;
      String str;
      this.mCurrentStateId = paramInt;
      State state = (State)this.mStateList.get(paramInt);
      int j = state.findMatch(paramFloat1, paramFloat2);
      if (j == -1) {
        constraintSet = state.mConstraintSet;
      } else {
        constraintSet = ((Variant)state.mVariants.get(j)).mConstraintSet;
      } 
      if (j == -1) {
        i = state.mConstraintID;
      } else {
        i = ((Variant)state.mVariants.get(j)).mConstraintID;
      } 
      if (constraintSet == null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(v416f9e89.xbd520268("3092"));
        stringBuilder.append(paramInt);
        stringBuilder.append(v416f9e89.xbd520268("3093"));
        stringBuilder.append(paramFloat1);
        stringBuilder.append(v416f9e89.xbd520268("3094"));
        stringBuilder.append(paramFloat2);
        str = stringBuilder.toString();
        Log.v(v416f9e89.xbd520268("3095"), str);
        return;
      } 
      this.mCurrentConstraintNumber = j;
      ConstraintsChangedListener constraintsChangedListener2 = this.mConstraintsChangedListener;
      if (constraintsChangedListener2 != null)
        constraintsChangedListener2.preLayoutChange(paramInt, i); 
      str.applyTo(this.mConstraintLayout);
      ConstraintsChangedListener constraintsChangedListener1 = this.mConstraintsChangedListener;
      if (constraintsChangedListener1 != null)
        constraintsChangedListener1.postLayoutChange(paramInt, i); 
    } 
  }
  
  static class State {
    int mConstraintID = -1;
    
    ConstraintSet mConstraintSet;
    
    int mId;
    
    ArrayList<ConstraintLayoutStates.Variant> mVariants = new ArrayList<ConstraintLayoutStates.Variant>();
    
    public State(Context param1Context, XmlPullParser param1XmlPullParser) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(Xml.asAttributeSet(param1XmlPullParser), R.styleable.State);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == R.styleable.State_android_id) {
          this.mId = typedArray.getResourceId(k, this.mId);
        } else if (k == R.styleable.State_constraints) {
          this.mConstraintID = typedArray.getResourceId(k, this.mConstraintID);
          String str = param1Context.getResources().getResourceTypeName(this.mConstraintID);
          param1Context.getResources().getResourceName(this.mConstraintID);
          if (v416f9e89.xbd520268("3025").equals(str)) {
            ConstraintSet constraintSet = new ConstraintSet();
            this.mConstraintSet = constraintSet;
            constraintSet.clone(param1Context, this.mConstraintID);
          } 
        } 
      } 
      typedArray.recycle();
    }
    
    void add(ConstraintLayoutStates.Variant param1Variant) {
      this.mVariants.add(param1Variant);
    }
    
    public int findMatch(float param1Float1, float param1Float2) {
      for (int i = 0; i < this.mVariants.size(); i++) {
        if (((ConstraintLayoutStates.Variant)this.mVariants.get(i)).match(param1Float1, param1Float2))
          return i; 
      } 
      return -1;
    }
  }
  
  static class Variant {
    int mConstraintID = -1;
    
    ConstraintSet mConstraintSet;
    
    int mId;
    
    float mMaxHeight = Float.NaN;
    
    float mMaxWidth = Float.NaN;
    
    float mMinHeight = Float.NaN;
    
    float mMinWidth = Float.NaN;
    
    public Variant(Context param1Context, XmlPullParser param1XmlPullParser) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(Xml.asAttributeSet(param1XmlPullParser), R.styleable.Variant);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == R.styleable.Variant_constraints) {
          this.mConstraintID = typedArray.getResourceId(k, this.mConstraintID);
          String str = param1Context.getResources().getResourceTypeName(this.mConstraintID);
          param1Context.getResources().getResourceName(this.mConstraintID);
          if (v416f9e89.xbd520268("3026").equals(str)) {
            ConstraintSet constraintSet = new ConstraintSet();
            this.mConstraintSet = constraintSet;
            constraintSet.clone(param1Context, this.mConstraintID);
          } 
        } else if (k == R.styleable.Variant_region_heightLessThan) {
          this.mMaxHeight = typedArray.getDimension(k, this.mMaxHeight);
        } else if (k == R.styleable.Variant_region_heightMoreThan) {
          this.mMinHeight = typedArray.getDimension(k, this.mMinHeight);
        } else if (k == R.styleable.Variant_region_widthLessThan) {
          this.mMaxWidth = typedArray.getDimension(k, this.mMaxWidth);
        } else if (k == R.styleable.Variant_region_widthMoreThan) {
          this.mMinWidth = typedArray.getDimension(k, this.mMinWidth);
        } else {
          Log.v(v416f9e89.xbd520268("3027"), v416f9e89.xbd520268("3028"));
        } 
      } 
      typedArray.recycle();
    }
    
    boolean match(float param1Float1, float param1Float2) {
      return (!Float.isNaN(this.mMinWidth) && param1Float1 < this.mMinWidth) ? false : ((!Float.isNaN(this.mMinHeight) && param1Float2 < this.mMinHeight) ? false : ((!Float.isNaN(this.mMaxWidth) && param1Float1 > this.mMaxWidth) ? false : (!(!Float.isNaN(this.mMaxHeight) && param1Float2 > this.mMaxHeight))));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\constraintlayout\widget\ConstraintLayoutStates.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */