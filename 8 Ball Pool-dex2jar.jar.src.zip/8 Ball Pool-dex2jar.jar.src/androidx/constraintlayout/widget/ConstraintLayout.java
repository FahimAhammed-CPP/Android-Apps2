package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Build;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.solver.Metrics;
import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.solver.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.solver.widgets.Guideline;
import androidx.constraintlayout.solver.widgets.analyzer.BasicMeasure;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.util.ArrayList;
import java.util.HashMap;

public class ConstraintLayout extends ViewGroup {
  private static final boolean DEBUG = false;
  
  private static final boolean DEBUG_DRAW_CONSTRAINTS = false;
  
  public static final int DESIGN_INFO_ID = 0;
  
  private static final boolean MEASURE = false;
  
  private static final String TAG = v416f9e89.xbd520268("2979");
  
  private static final boolean USE_CONSTRAINTS_HELPER = true;
  
  public static final String VERSION = v416f9e89.xbd520268("2980");
  
  SparseArray<View> mChildrenByIds = new SparseArray();
  
  private ArrayList<ConstraintHelper> mConstraintHelpers = new ArrayList<ConstraintHelper>(4);
  
  protected ConstraintLayoutStates mConstraintLayoutSpec = null;
  
  private ConstraintSet mConstraintSet = null;
  
  private int mConstraintSetId = -1;
  
  private ConstraintsChangedListener mConstraintsChangedListener;
  
  private HashMap<String, Integer> mDesignIds = new HashMap<String, Integer>();
  
  protected boolean mDirtyHierarchy = true;
  
  private int mLastMeasureHeight = -1;
  
  int mLastMeasureHeightMode = 0;
  
  int mLastMeasureHeightSize = -1;
  
  private int mLastMeasureWidth = -1;
  
  int mLastMeasureWidthMode = 0;
  
  int mLastMeasureWidthSize = -1;
  
  protected ConstraintWidgetContainer mLayoutWidget = new ConstraintWidgetContainer();
  
  private int mMaxHeight = Integer.MAX_VALUE;
  
  private int mMaxWidth = Integer.MAX_VALUE;
  
  Measurer mMeasurer = new Measurer(this);
  
  private Metrics mMetrics;
  
  private int mMinHeight = 0;
  
  private int mMinWidth = 0;
  
  private int mOnMeasureHeightMeasureSpec = 0;
  
  private int mOnMeasureWidthMeasureSpec = 0;
  
  private int mOptimizationLevel = 263;
  
  private SparseArray<ConstraintWidget> mTempMapIdToWidget = new SparseArray();
  
  public ConstraintLayout(Context paramContext) {
    super(paramContext);
    init((AttributeSet)null, 0, 0);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    init(paramAttributeSet, 0, 0);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    init(paramAttributeSet, paramInt, 0);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    init(paramAttributeSet, paramInt1, paramInt2);
  }
  
  private int getPaddingWidth() {
    int j = getPaddingLeft();
    int i = 0;
    j = Math.max(0, j) + Math.max(0, getPaddingRight());
    if (Build.VERSION.SDK_INT >= 17) {
      i = Math.max(0, getPaddingStart());
      i = Math.max(0, getPaddingEnd()) + i;
    } 
    if (i > 0)
      j = i; 
    return j;
  }
  
  private final ConstraintWidget getTargetWidget(int paramInt) {
    if (paramInt == 0)
      return (ConstraintWidget)this.mLayoutWidget; 
    View view2 = (View)this.mChildrenByIds.get(paramInt);
    View view1 = view2;
    if (view2 == null) {
      view2 = findViewById(paramInt);
      view1 = view2;
      if (view2 != null) {
        view1 = view2;
        if (view2 != this) {
          view1 = view2;
          if (view2.getParent() == this) {
            onViewAdded(view2);
            view1 = view2;
          } 
        } 
      } 
    } 
    return (ConstraintWidget)((view1 == this) ? this.mLayoutWidget : ((view1 == null) ? null : ((LayoutParams)view1.getLayoutParams()).widget));
  }
  
  private void init(AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this.mLayoutWidget.setCompanionWidget(this);
    this.mLayoutWidget.setMeasurer(this.mMeasurer);
    this.mChildrenByIds.put(getId(), this);
    this.mConstraintSet = null;
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, R.styleable.ConstraintLayout_Layout, paramInt1, paramInt2);
      paramInt2 = typedArray.getIndexCount();
      paramInt1 = 0;
      while (true) {
        if (paramInt1 < paramInt2) {
          int i = typedArray.getIndex(paramInt1);
          if (i == R.styleable.ConstraintLayout_Layout_android_minWidth) {
            this.mMinWidth = typedArray.getDimensionPixelOffset(i, this.mMinWidth);
          } else if (i == R.styleable.ConstraintLayout_Layout_android_minHeight) {
            this.mMinHeight = typedArray.getDimensionPixelOffset(i, this.mMinHeight);
          } else if (i == R.styleable.ConstraintLayout_Layout_android_maxWidth) {
            this.mMaxWidth = typedArray.getDimensionPixelOffset(i, this.mMaxWidth);
          } else if (i == R.styleable.ConstraintLayout_Layout_android_maxHeight) {
            this.mMaxHeight = typedArray.getDimensionPixelOffset(i, this.mMaxHeight);
          } else if (i == R.styleable.ConstraintLayout_Layout_layout_optimizationLevel) {
            this.mOptimizationLevel = typedArray.getInt(i, this.mOptimizationLevel);
          } else if (i == R.styleable.ConstraintLayout_Layout_layoutDescription) {
            i = typedArray.getResourceId(i, 0);
            if (i != 0)
              try {
                parseLayoutDescription(i);
              } catch (android.content.res.Resources.NotFoundException notFoundException) {
                this.mConstraintLayoutSpec = null;
              }  
          } else if (i == R.styleable.ConstraintLayout_Layout_constraintSet) {
            i = typedArray.getResourceId(i, 0);
            try {
              ConstraintSet constraintSet = new ConstraintSet();
              this.mConstraintSet = constraintSet;
              constraintSet.load(getContext(), i);
            } catch (android.content.res.Resources.NotFoundException notFoundException) {
              this.mConstraintSet = null;
            } 
            this.mConstraintSetId = i;
          } 
          paramInt1++;
          continue;
        } 
        typedArray.recycle();
        this.mLayoutWidget.setOptimizationLevel(this.mOptimizationLevel);
        return;
      } 
    } 
    this.mLayoutWidget.setOptimizationLevel(this.mOptimizationLevel);
  }
  
  private void markHierarchyDirty() {
    this.mDirtyHierarchy = true;
    this.mLastMeasureWidth = -1;
    this.mLastMeasureHeight = -1;
    this.mLastMeasureWidthSize = -1;
    this.mLastMeasureHeightSize = -1;
    this.mLastMeasureWidthMode = 0;
    this.mLastMeasureHeightMode = 0;
  }
  
  private void setChildrenConstraints() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual isInEditMode : ()Z
    //   4: istore #4
    //   6: aload_0
    //   7: invokevirtual getChildCount : ()I
    //   10: istore_2
    //   11: iconst_0
    //   12: istore_1
    //   13: iload_1
    //   14: iload_2
    //   15: if_icmpge -> 49
    //   18: aload_0
    //   19: aload_0
    //   20: iload_1
    //   21: invokevirtual getChildAt : (I)Landroid/view/View;
    //   24: invokevirtual getViewWidget : (Landroid/view/View;)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   27: astore #5
    //   29: aload #5
    //   31: ifnonnull -> 37
    //   34: goto -> 42
    //   37: aload #5
    //   39: invokevirtual reset : ()V
    //   42: iload_1
    //   43: iconst_1
    //   44: iadd
    //   45: istore_1
    //   46: goto -> 13
    //   49: iload #4
    //   51: ifeq -> 145
    //   54: iconst_0
    //   55: istore_1
    //   56: iload_1
    //   57: iload_2
    //   58: if_icmpge -> 145
    //   61: aload_0
    //   62: iload_1
    //   63: invokevirtual getChildAt : (I)Landroid/view/View;
    //   66: astore #7
    //   68: aload_0
    //   69: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   72: aload #7
    //   74: invokevirtual getId : ()I
    //   77: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   80: astore #6
    //   82: aload_0
    //   83: iconst_0
    //   84: aload #6
    //   86: aload #7
    //   88: invokevirtual getId : ()I
    //   91: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   94: invokevirtual setDesignInformation : (ILjava/lang/Object;Ljava/lang/Object;)V
    //   97: aload #6
    //   99: bipush #47
    //   101: invokevirtual indexOf : (I)I
    //   104: istore_3
    //   105: aload #6
    //   107: astore #5
    //   109: iload_3
    //   110: iconst_m1
    //   111: if_icmpeq -> 124
    //   114: aload #6
    //   116: iload_3
    //   117: iconst_1
    //   118: iadd
    //   119: invokevirtual substring : (I)Ljava/lang/String;
    //   122: astore #5
    //   124: aload_0
    //   125: aload #7
    //   127: invokevirtual getId : ()I
    //   130: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   133: aload #5
    //   135: invokevirtual setDebugName : (Ljava/lang/String;)V
    //   138: iload_1
    //   139: iconst_1
    //   140: iadd
    //   141: istore_1
    //   142: goto -> 56
    //   145: aload_0
    //   146: getfield mConstraintSetId : I
    //   149: iconst_m1
    //   150: if_icmpeq -> 206
    //   153: iconst_0
    //   154: istore_1
    //   155: iload_1
    //   156: iload_2
    //   157: if_icmpge -> 206
    //   160: aload_0
    //   161: iload_1
    //   162: invokevirtual getChildAt : (I)Landroid/view/View;
    //   165: astore #5
    //   167: aload #5
    //   169: invokevirtual getId : ()I
    //   172: aload_0
    //   173: getfield mConstraintSetId : I
    //   176: if_icmpne -> 199
    //   179: aload #5
    //   181: instanceof androidx/constraintlayout/widget/Constraints
    //   184: ifeq -> 199
    //   187: aload_0
    //   188: aload #5
    //   190: checkcast androidx/constraintlayout/widget/Constraints
    //   193: invokevirtual getConstraintSet : ()Landroidx/constraintlayout/widget/ConstraintSet;
    //   196: putfield mConstraintSet : Landroidx/constraintlayout/widget/ConstraintSet;
    //   199: iload_1
    //   200: iconst_1
    //   201: iadd
    //   202: istore_1
    //   203: goto -> 155
    //   206: aload_0
    //   207: getfield mConstraintSet : Landroidx/constraintlayout/widget/ConstraintSet;
    //   210: astore #5
    //   212: aload #5
    //   214: ifnull -> 224
    //   217: aload #5
    //   219: aload_0
    //   220: iconst_1
    //   221: invokevirtual applyToInternal : (Landroidx/constraintlayout/widget/ConstraintLayout;Z)V
    //   224: aload_0
    //   225: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   228: invokevirtual removeAllChildren : ()V
    //   231: aload_0
    //   232: getfield mConstraintHelpers : Ljava/util/ArrayList;
    //   235: invokevirtual size : ()I
    //   238: istore_3
    //   239: iload_3
    //   240: ifle -> 272
    //   243: iconst_0
    //   244: istore_1
    //   245: iload_1
    //   246: iload_3
    //   247: if_icmpge -> 272
    //   250: aload_0
    //   251: getfield mConstraintHelpers : Ljava/util/ArrayList;
    //   254: iload_1
    //   255: invokevirtual get : (I)Ljava/lang/Object;
    //   258: checkcast androidx/constraintlayout/widget/ConstraintHelper
    //   261: aload_0
    //   262: invokevirtual updatePreLayout : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   265: iload_1
    //   266: iconst_1
    //   267: iadd
    //   268: istore_1
    //   269: goto -> 245
    //   272: iconst_0
    //   273: istore_1
    //   274: iload_1
    //   275: iload_2
    //   276: if_icmpge -> 310
    //   279: aload_0
    //   280: iload_1
    //   281: invokevirtual getChildAt : (I)Landroid/view/View;
    //   284: astore #5
    //   286: aload #5
    //   288: instanceof androidx/constraintlayout/widget/Placeholder
    //   291: ifeq -> 303
    //   294: aload #5
    //   296: checkcast androidx/constraintlayout/widget/Placeholder
    //   299: aload_0
    //   300: invokevirtual updatePreLayout : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   303: iload_1
    //   304: iconst_1
    //   305: iadd
    //   306: istore_1
    //   307: goto -> 274
    //   310: aload_0
    //   311: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   314: invokevirtual clear : ()V
    //   317: aload_0
    //   318: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   321: iconst_0
    //   322: aload_0
    //   323: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   326: invokevirtual put : (ILjava/lang/Object;)V
    //   329: aload_0
    //   330: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   333: aload_0
    //   334: invokevirtual getId : ()I
    //   337: aload_0
    //   338: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   341: invokevirtual put : (ILjava/lang/Object;)V
    //   344: iconst_0
    //   345: istore_1
    //   346: iload_1
    //   347: iload_2
    //   348: if_icmpge -> 387
    //   351: aload_0
    //   352: iload_1
    //   353: invokevirtual getChildAt : (I)Landroid/view/View;
    //   356: astore #5
    //   358: aload_0
    //   359: aload #5
    //   361: invokevirtual getViewWidget : (Landroid/view/View;)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   364: astore #6
    //   366: aload_0
    //   367: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   370: aload #5
    //   372: invokevirtual getId : ()I
    //   375: aload #6
    //   377: invokevirtual put : (ILjava/lang/Object;)V
    //   380: iload_1
    //   381: iconst_1
    //   382: iadd
    //   383: istore_1
    //   384: goto -> 346
    //   387: iconst_0
    //   388: istore_1
    //   389: iload_1
    //   390: iload_2
    //   391: if_icmpge -> 459
    //   394: aload_0
    //   395: iload_1
    //   396: invokevirtual getChildAt : (I)Landroid/view/View;
    //   399: astore #5
    //   401: aload_0
    //   402: aload #5
    //   404: invokevirtual getViewWidget : (Landroid/view/View;)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   407: astore #6
    //   409: aload #6
    //   411: ifnonnull -> 417
    //   414: goto -> 452
    //   417: aload #5
    //   419: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   422: checkcast androidx/constraintlayout/widget/ConstraintLayout$LayoutParams
    //   425: astore #7
    //   427: aload_0
    //   428: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   431: aload #6
    //   433: invokevirtual add : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;)V
    //   436: aload_0
    //   437: iload #4
    //   439: aload #5
    //   441: aload #6
    //   443: aload #7
    //   445: aload_0
    //   446: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   449: invokevirtual applyConstraintsFromLayoutParams : (ZLandroid/view/View;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;Landroid/util/SparseArray;)V
    //   452: iload_1
    //   453: iconst_1
    //   454: iadd
    //   455: istore_1
    //   456: goto -> 389
    //   459: return
    //   460: astore #5
    //   462: goto -> 138
    // Exception table:
    //   from	to	target	type
    //   68	105	460	android/content/res/Resources$NotFoundException
    //   114	124	460	android/content/res/Resources$NotFoundException
    //   124	138	460	android/content/res/Resources$NotFoundException
  }
  
  private boolean updateHierarchy() {
    boolean bool1;
    int j = getChildCount();
    boolean bool2 = false;
    int i = 0;
    while (true) {
      bool1 = bool2;
      if (i < j) {
        if (getChildAt(i).isLayoutRequested()) {
          bool1 = true;
          break;
        } 
        i++;
        continue;
      } 
      break;
    } 
    if (bool1)
      setChildrenConstraints(); 
    return bool1;
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    super.addView(paramView, paramInt, paramLayoutParams);
    if (Build.VERSION.SDK_INT < 14)
      onViewAdded(paramView); 
  }
  
  protected void applyConstraintsFromLayoutParams(boolean paramBoolean, View paramView, ConstraintWidget paramConstraintWidget, LayoutParams paramLayoutParams, SparseArray<ConstraintWidget> paramSparseArray) {
    paramLayoutParams.validate();
    paramLayoutParams.helped = false;
    paramConstraintWidget.setVisibility(paramView.getVisibility());
    if (paramLayoutParams.isInPlaceholder) {
      paramConstraintWidget.setInPlaceholder(true);
      paramConstraintWidget.setVisibility(8);
    } 
    paramConstraintWidget.setCompanionWidget(paramView);
    if (paramView instanceof ConstraintHelper)
      ((ConstraintHelper)paramView).resolveRtl(paramConstraintWidget, this.mLayoutWidget.isRtl()); 
    if (paramLayoutParams.isGuideline) {
      Guideline guideline = (Guideline)paramConstraintWidget;
      int i = paramLayoutParams.resolvedGuideBegin;
      int j = paramLayoutParams.resolvedGuideEnd;
      float f = paramLayoutParams.resolvedGuidePercent;
      if (Build.VERSION.SDK_INT < 17) {
        i = paramLayoutParams.guideBegin;
        j = paramLayoutParams.guideEnd;
        f = paramLayoutParams.guidePercent;
      } 
      if (f != -1.0F) {
        guideline.setGuidePercent(f);
        return;
      } 
      if (i != -1) {
        guideline.setGuideBegin(i);
        return;
      } 
      if (j != -1) {
        guideline.setGuideEnd(j);
        return;
      } 
    } else {
      int i = paramLayoutParams.resolvedLeftToLeft;
      int j = paramLayoutParams.resolvedLeftToRight;
      int m = paramLayoutParams.resolvedRightToLeft;
      int k = paramLayoutParams.resolvedRightToRight;
      int i1 = paramLayoutParams.resolveGoneLeftMargin;
      int n = paramLayoutParams.resolveGoneRightMargin;
      float f = paramLayoutParams.resolvedHorizontalBias;
      if (Build.VERSION.SDK_INT < 17) {
        k = paramLayoutParams.leftToLeft;
        m = paramLayoutParams.leftToRight;
        int i2 = paramLayoutParams.rightToLeft;
        int i3 = paramLayoutParams.rightToRight;
        i1 = paramLayoutParams.goneLeftMargin;
        n = paramLayoutParams.goneRightMargin;
        f = paramLayoutParams.horizontalBias;
        i = k;
        j = m;
        if (k == -1) {
          i = k;
          j = m;
          if (m == -1)
            if (paramLayoutParams.startToStart != -1) {
              i = paramLayoutParams.startToStart;
              j = m;
            } else {
              i = k;
              j = m;
              if (paramLayoutParams.startToEnd != -1) {
                j = paramLayoutParams.startToEnd;
                i = k;
              } 
            }  
        } 
        m = i2;
        k = i3;
        if (i2 == -1) {
          m = i2;
          k = i3;
          if (i3 == -1)
            if (paramLayoutParams.endToStart != -1) {
              m = paramLayoutParams.endToStart;
              k = i3;
            } else {
              m = i2;
              k = i3;
              if (paramLayoutParams.endToEnd != -1) {
                k = paramLayoutParams.endToEnd;
                m = i2;
              } 
            }  
        } 
      } 
      if (paramLayoutParams.circleConstraint != -1) {
        ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.circleConstraint);
        if (constraintWidget != null)
          paramConstraintWidget.connectCircularConstraint(constraintWidget, paramLayoutParams.circleAngle, paramLayoutParams.circleRadius); 
      } else {
        if (i != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(i);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.LEFT, constraintWidget, ConstraintAnchor.Type.LEFT, paramLayoutParams.leftMargin, i1); 
        } else if (j != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(j);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.LEFT, constraintWidget, ConstraintAnchor.Type.RIGHT, paramLayoutParams.leftMargin, i1); 
        } 
        if (m != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(m);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.RIGHT, constraintWidget, ConstraintAnchor.Type.LEFT, paramLayoutParams.rightMargin, n); 
        } else if (k != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(k);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.RIGHT, constraintWidget, ConstraintAnchor.Type.RIGHT, paramLayoutParams.rightMargin, n); 
        } 
        if (paramLayoutParams.topToTop != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.topToTop);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.TOP, constraintWidget, ConstraintAnchor.Type.TOP, paramLayoutParams.topMargin, paramLayoutParams.goneTopMargin); 
        } else if (paramLayoutParams.topToBottom != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.topToBottom);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.TOP, constraintWidget, ConstraintAnchor.Type.BOTTOM, paramLayoutParams.topMargin, paramLayoutParams.goneTopMargin); 
        } 
        if (paramLayoutParams.bottomToTop != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.bottomToTop);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.BOTTOM, constraintWidget, ConstraintAnchor.Type.TOP, paramLayoutParams.bottomMargin, paramLayoutParams.goneBottomMargin); 
        } else if (paramLayoutParams.bottomToBottom != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.bottomToBottom);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.BOTTOM, constraintWidget, ConstraintAnchor.Type.BOTTOM, paramLayoutParams.bottomMargin, paramLayoutParams.goneBottomMargin); 
        } 
        if (paramLayoutParams.baselineToBaseline != -1) {
          paramView = (View)this.mChildrenByIds.get(paramLayoutParams.baselineToBaseline);
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.baselineToBaseline);
          if (constraintWidget != null && paramView != null && paramView.getLayoutParams() instanceof LayoutParams) {
            LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
            paramLayoutParams.needsBaseline = true;
            layoutParams.needsBaseline = true;
            paramConstraintWidget.getAnchor(ConstraintAnchor.Type.BASELINE).connect(constraintWidget.getAnchor(ConstraintAnchor.Type.BASELINE), 0, -1, true);
            paramConstraintWidget.setHasBaseline(true);
            layoutParams.widget.setHasBaseline(true);
            paramConstraintWidget.getAnchor(ConstraintAnchor.Type.TOP).reset();
            paramConstraintWidget.getAnchor(ConstraintAnchor.Type.BOTTOM).reset();
          } 
        } 
        if (f >= 0.0F)
          paramConstraintWidget.setHorizontalBiasPercent(f); 
        if (paramLayoutParams.verticalBias >= 0.0F)
          paramConstraintWidget.setVerticalBiasPercent(paramLayoutParams.verticalBias); 
      } 
      if (paramBoolean && (paramLayoutParams.editorAbsoluteX != -1 || paramLayoutParams.editorAbsoluteY != -1))
        paramConstraintWidget.setOrigin(paramLayoutParams.editorAbsoluteX, paramLayoutParams.editorAbsoluteY); 
      if (!paramLayoutParams.horizontalDimensionFixed) {
        if (paramLayoutParams.width == -1) {
          if (paramLayoutParams.constrainedWidth) {
            paramConstraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
          } else {
            paramConstraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_PARENT);
          } 
          (paramConstraintWidget.getAnchor(ConstraintAnchor.Type.LEFT)).mMargin = paramLayoutParams.leftMargin;
          (paramConstraintWidget.getAnchor(ConstraintAnchor.Type.RIGHT)).mMargin = paramLayoutParams.rightMargin;
        } else {
          paramConstraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
          paramConstraintWidget.setWidth(0);
        } 
      } else {
        paramConstraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
        paramConstraintWidget.setWidth(paramLayoutParams.width);
        if (paramLayoutParams.width == -2)
          paramConstraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.WRAP_CONTENT); 
      } 
      if (!paramLayoutParams.verticalDimensionFixed) {
        if (paramLayoutParams.height == -1) {
          if (paramLayoutParams.constrainedHeight) {
            paramConstraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
          } else {
            paramConstraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_PARENT);
          } 
          (paramConstraintWidget.getAnchor(ConstraintAnchor.Type.TOP)).mMargin = paramLayoutParams.topMargin;
          (paramConstraintWidget.getAnchor(ConstraintAnchor.Type.BOTTOM)).mMargin = paramLayoutParams.bottomMargin;
        } else {
          paramConstraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
          paramConstraintWidget.setHeight(0);
        } 
      } else {
        paramConstraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
        paramConstraintWidget.setHeight(paramLayoutParams.height);
        if (paramLayoutParams.height == -2)
          paramConstraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.WRAP_CONTENT); 
      } 
      paramConstraintWidget.setDimensionRatio(paramLayoutParams.dimensionRatio);
      paramConstraintWidget.setHorizontalWeight(paramLayoutParams.horizontalWeight);
      paramConstraintWidget.setVerticalWeight(paramLayoutParams.verticalWeight);
      paramConstraintWidget.setHorizontalChainStyle(paramLayoutParams.horizontalChainStyle);
      paramConstraintWidget.setVerticalChainStyle(paramLayoutParams.verticalChainStyle);
      paramConstraintWidget.setHorizontalMatchStyle(paramLayoutParams.matchConstraintDefaultWidth, paramLayoutParams.matchConstraintMinWidth, paramLayoutParams.matchConstraintMaxWidth, paramLayoutParams.matchConstraintPercentWidth);
      paramConstraintWidget.setVerticalMatchStyle(paramLayoutParams.matchConstraintDefaultHeight, paramLayoutParams.matchConstraintMinHeight, paramLayoutParams.matchConstraintMaxHeight, paramLayoutParams.matchConstraintPercentHeight);
    } 
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  protected void dispatchDraw(Canvas paramCanvas) {
    ArrayList<ConstraintHelper> arrayList = this.mConstraintHelpers;
    if (arrayList != null) {
      int i = arrayList.size();
      if (i > 0) {
        int j;
        for (j = 0; j < i; j++)
          ((ConstraintHelper)this.mConstraintHelpers.get(j)).updatePreDraw(this); 
      } 
    } 
    super.dispatchDraw(paramCanvas);
    if (isInEditMode()) {
      int j = getChildCount();
      float f1 = getWidth();
      float f2 = getHeight();
      int i;
      for (i = 0; i < j; i++) {
        View view = getChildAt(i);
        if (view.getVisibility() != 8) {
          Object object = view.getTag();
          if (object != null && object instanceof String) {
            object = ((String)object).split(v416f9e89.xbd520268("2981"));
            if (object.length == 4) {
              int m = Integer.parseInt((String)object[0]);
              int i1 = Integer.parseInt((String)object[1]);
              int n = Integer.parseInt((String)object[2]);
              int k = Integer.parseInt((String)object[3]);
              m = (int)(m / 1080.0F * f1);
              i1 = (int)(i1 / 1920.0F * f2);
              n = (int)(n / 1080.0F * f1);
              k = (int)(k / 1920.0F * f2);
              object = new Paint();
              object.setColor(-65536);
              float f3 = m;
              float f4 = i1;
              float f5 = (m + n);
              paramCanvas.drawLine(f3, f4, f5, f4, (Paint)object);
              float f6 = (i1 + k);
              paramCanvas.drawLine(f5, f4, f5, f6, (Paint)object);
              paramCanvas.drawLine(f5, f6, f3, f6, (Paint)object);
              paramCanvas.drawLine(f3, f6, f3, f4, (Paint)object);
              object.setColor(-16711936);
              paramCanvas.drawLine(f3, f4, f5, f6, (Paint)object);
              paramCanvas.drawLine(f3, f6, f5, f4, (Paint)object);
            } 
          } 
        } 
      } 
    } 
  }
  
  public void fillMetrics(Metrics paramMetrics) {
    this.mMetrics = paramMetrics;
    this.mLayoutWidget.fillMetrics(paramMetrics);
  }
  
  public void forceLayout() {
    markHierarchyDirty();
    super.forceLayout();
  }
  
  protected LayoutParams generateDefaultLayoutParams() {
    return new LayoutParams(-2, -2);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new LayoutParams(paramLayoutParams);
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  public Object getDesignInformation(int paramInt, Object paramObject) {
    if (paramInt == 0 && paramObject instanceof String) {
      paramObject = paramObject;
      HashMap<String, Integer> hashMap = this.mDesignIds;
      if (hashMap != null && hashMap.containsKey(paramObject))
        return this.mDesignIds.get(paramObject); 
    } 
    return null;
  }
  
  public int getMaxHeight() {
    return this.mMaxHeight;
  }
  
  public int getMaxWidth() {
    return this.mMaxWidth;
  }
  
  public int getMinHeight() {
    return this.mMinHeight;
  }
  
  public int getMinWidth() {
    return this.mMinWidth;
  }
  
  public int getOptimizationLevel() {
    return this.mLayoutWidget.getOptimizationLevel();
  }
  
  public View getViewById(int paramInt) {
    return (View)this.mChildrenByIds.get(paramInt);
  }
  
  public final ConstraintWidget getViewWidget(View paramView) {
    return (ConstraintWidget)((paramView == this) ? this.mLayoutWidget : ((paramView == null) ? null : ((LayoutParams)paramView.getLayoutParams()).widget));
  }
  
  protected boolean isRtl() {
    int i = Build.VERSION.SDK_INT;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i >= 17) {
      if (((getContext().getApplicationInfo()).flags & 0x400000) != 0) {
        i = 1;
      } else {
        i = 0;
      } 
      bool1 = bool2;
      if (i != 0) {
        bool1 = bool2;
        if (1 == getLayoutDirection())
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public void loadLayoutDescription(int paramInt) {
    if (paramInt != 0)
      try {
        this.mConstraintLayoutSpec = new ConstraintLayoutStates(getContext(), this, paramInt);
        return;
      } catch (android.content.res.Resources.NotFoundException notFoundException) {
        this.mConstraintLayoutSpec = null;
        return;
      }  
    this.mConstraintLayoutSpec = null;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt3 = getChildCount();
    paramBoolean = isInEditMode();
    paramInt2 = 0;
    for (paramInt1 = 0; paramInt1 < paramInt3; paramInt1++) {
      View view = getChildAt(paramInt1);
      LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
      ConstraintWidget constraintWidget = layoutParams.widget;
      if ((view.getVisibility() != 8 || layoutParams.isGuideline || layoutParams.isHelper || layoutParams.isVirtualGroup || paramBoolean) && !layoutParams.isInPlaceholder) {
        paramInt4 = constraintWidget.getX();
        int i = constraintWidget.getY();
        int j = constraintWidget.getWidth() + paramInt4;
        int k = constraintWidget.getHeight() + i;
        view.layout(paramInt4, i, j, k);
        if (view instanceof Placeholder) {
          view = ((Placeholder)view).getContent();
          if (view != null) {
            view.setVisibility(0);
            view.layout(paramInt4, i, j, k);
          } 
        } 
      } 
    } 
    paramInt3 = this.mConstraintHelpers.size();
    if (paramInt3 > 0)
      for (paramInt1 = paramInt2; paramInt1 < paramInt3; paramInt1++)
        ((ConstraintHelper)this.mConstraintHelpers.get(paramInt1)).updatePostLayout(this);  
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    this.mOnMeasureWidthMeasureSpec = paramInt1;
    this.mOnMeasureHeightMeasureSpec = paramInt2;
    this.mLayoutWidget.setRtl(isRtl());
    if (this.mDirtyHierarchy) {
      this.mDirtyHierarchy = false;
      if (updateHierarchy())
        this.mLayoutWidget.updateHierarchy(); 
    } 
    resolveSystem(this.mLayoutWidget, this.mOptimizationLevel, paramInt1, paramInt2);
    resolveMeasuredDimension(paramInt1, paramInt2, this.mLayoutWidget.getWidth(), this.mLayoutWidget.getHeight(), this.mLayoutWidget.isWidthMeasuredTooSmall(), this.mLayoutWidget.isHeightMeasuredTooSmall());
  }
  
  public void onViewAdded(View paramView) {
    if (Build.VERSION.SDK_INT >= 14)
      super.onViewAdded(paramView); 
    ConstraintWidget constraintWidget = getViewWidget(paramView);
    if (paramView instanceof Guideline && !(constraintWidget instanceof Guideline)) {
      LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
      layoutParams.widget = (ConstraintWidget)new Guideline();
      layoutParams.isGuideline = true;
      ((Guideline)layoutParams.widget).setOrientation(layoutParams.orientation);
    } 
    if (paramView instanceof ConstraintHelper) {
      ConstraintHelper constraintHelper = (ConstraintHelper)paramView;
      constraintHelper.validateParams();
      ((LayoutParams)paramView.getLayoutParams()).isHelper = true;
      if (!this.mConstraintHelpers.contains(constraintHelper))
        this.mConstraintHelpers.add(constraintHelper); 
    } 
    this.mChildrenByIds.put(paramView.getId(), paramView);
    this.mDirtyHierarchy = true;
  }
  
  public void onViewRemoved(View paramView) {
    if (Build.VERSION.SDK_INT >= 14)
      super.onViewRemoved(paramView); 
    this.mChildrenByIds.remove(paramView.getId());
    ConstraintWidget constraintWidget = getViewWidget(paramView);
    this.mLayoutWidget.remove(constraintWidget);
    this.mConstraintHelpers.remove(paramView);
    this.mDirtyHierarchy = true;
  }
  
  protected void parseLayoutDescription(int paramInt) {
    this.mConstraintLayoutSpec = new ConstraintLayoutStates(getContext(), this, paramInt);
  }
  
  public void removeView(View paramView) {
    super.removeView(paramView);
    if (Build.VERSION.SDK_INT < 14)
      onViewRemoved(paramView); 
  }
  
  public void requestLayout() {
    markHierarchyDirty();
    super.requestLayout();
  }
  
  protected void resolveMeasuredDimension(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, boolean paramBoolean2) {
    int i = this.mMeasurer.paddingHeight;
    paramInt3 += this.mMeasurer.paddingWidth;
    paramInt4 += i;
    if (Build.VERSION.SDK_INT >= 11) {
      paramInt1 = resolveSizeAndState(paramInt3, paramInt1, 0);
      paramInt3 = resolveSizeAndState(paramInt4, paramInt2, 0);
      paramInt2 = Math.min(this.mMaxWidth, paramInt1 & 0xFFFFFF);
      paramInt3 = Math.min(this.mMaxHeight, paramInt3 & 0xFFFFFF);
      paramInt1 = paramInt2;
      if (paramBoolean1)
        paramInt1 = paramInt2 | 0x1000000; 
      paramInt2 = paramInt3;
      if (paramBoolean2)
        paramInt2 = paramInt3 | 0x1000000; 
      setMeasuredDimension(paramInt1, paramInt2);
      this.mLastMeasureWidth = paramInt1;
      this.mLastMeasureHeight = paramInt2;
      return;
    } 
    setMeasuredDimension(paramInt3, paramInt4);
    this.mLastMeasureWidth = paramInt3;
    this.mLastMeasureHeight = paramInt4;
  }
  
  protected void resolveSystem(ConstraintWidgetContainer paramConstraintWidgetContainer, int paramInt1, int paramInt2, int paramInt3) {
    int i = View.MeasureSpec.getMode(paramInt2);
    int i1 = View.MeasureSpec.getSize(paramInt2);
    int j = View.MeasureSpec.getMode(paramInt3);
    int m = View.MeasureSpec.getSize(paramInt3);
    int k = Math.max(0, getPaddingTop());
    int i3 = Math.max(0, getPaddingBottom());
    int n = k + i3;
    int i2 = getPaddingWidth();
    this.mMeasurer.captureLayoutInfos(paramInt2, paramInt3, k, i3, i2, n);
    if (Build.VERSION.SDK_INT >= 17) {
      paramInt2 = Math.max(0, getPaddingStart());
      paramInt3 = Math.max(0, getPaddingEnd());
      if (paramInt2 > 0 || paramInt3 > 0) {
        if (isRtl())
          paramInt2 = paramInt3; 
      } else {
        paramInt2 = Math.max(0, getPaddingLeft());
      } 
    } else {
      paramInt2 = Math.max(0, getPaddingLeft());
    } 
    paramInt3 = i1 - i2;
    m -= n;
    setSelfDimensionBehaviour(paramConstraintWidgetContainer, i, paramInt3, j, m);
    paramConstraintWidgetContainer.measure(paramInt1, i, paramInt3, j, m, this.mLastMeasureWidth, this.mLastMeasureHeight, paramInt2, k);
  }
  
  public void setConstraintSet(ConstraintSet paramConstraintSet) {
    this.mConstraintSet = paramConstraintSet;
  }
  
  public void setDesignInformation(int paramInt, Object paramObject1, Object paramObject2) {
    if (paramInt == 0 && paramObject1 instanceof String && paramObject2 instanceof Integer) {
      if (this.mDesignIds == null)
        this.mDesignIds = new HashMap<String, Integer>(); 
      String str = (String)paramObject1;
      paramInt = str.indexOf(v416f9e89.xbd520268("2982"));
      paramObject1 = str;
      if (paramInt != -1)
        paramObject1 = str.substring(paramInt + 1); 
      paramInt = ((Integer)paramObject2).intValue();
      this.mDesignIds.put(paramObject1, Integer.valueOf(paramInt));
    } 
  }
  
  public void setId(int paramInt) {
    this.mChildrenByIds.remove(getId());
    super.setId(paramInt);
    this.mChildrenByIds.put(getId(), this);
  }
  
  public void setMaxHeight(int paramInt) {
    if (paramInt == this.mMaxHeight)
      return; 
    this.mMaxHeight = paramInt;
    requestLayout();
  }
  
  public void setMaxWidth(int paramInt) {
    if (paramInt == this.mMaxWidth)
      return; 
    this.mMaxWidth = paramInt;
    requestLayout();
  }
  
  public void setMinHeight(int paramInt) {
    if (paramInt == this.mMinHeight)
      return; 
    this.mMinHeight = paramInt;
    requestLayout();
  }
  
  public void setMinWidth(int paramInt) {
    if (paramInt == this.mMinWidth)
      return; 
    this.mMinWidth = paramInt;
    requestLayout();
  }
  
  public void setOnConstraintsChanged(ConstraintsChangedListener paramConstraintsChangedListener) {
    this.mConstraintsChangedListener = paramConstraintsChangedListener;
    ConstraintLayoutStates constraintLayoutStates = this.mConstraintLayoutSpec;
    if (constraintLayoutStates != null)
      constraintLayoutStates.setOnConstraintsChanged(paramConstraintsChangedListener); 
  }
  
  public void setOptimizationLevel(int paramInt) {
    this.mOptimizationLevel = paramInt;
    this.mLayoutWidget.setOptimizationLevel(paramInt);
  }
  
  protected void setSelfDimensionBehaviour(ConstraintWidgetContainer paramConstraintWidgetContainer, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mMeasurer : Landroidx/constraintlayout/widget/ConstraintLayout$Measurer;
    //   4: getfield paddingHeight : I
    //   7: istore #6
    //   9: aload_0
    //   10: getfield mMeasurer : Landroidx/constraintlayout/widget/ConstraintLayout$Measurer;
    //   13: getfield paddingWidth : I
    //   16: istore #7
    //   18: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   21: astore #9
    //   23: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   26: astore #10
    //   28: aload_0
    //   29: invokevirtual getChildCount : ()I
    //   32: istore #8
    //   34: iload_2
    //   35: ldc_w -2147483648
    //   38: if_icmpeq -> 102
    //   41: iload_2
    //   42: ifeq -> 72
    //   45: iload_2
    //   46: ldc_w 1073741824
    //   49: if_icmpeq -> 57
    //   52: iconst_0
    //   53: istore_3
    //   54: goto -> 129
    //   57: aload_0
    //   58: getfield mMaxWidth : I
    //   61: iload #7
    //   63: isub
    //   64: iload_3
    //   65: invokestatic min : (II)I
    //   68: istore_3
    //   69: goto -> 129
    //   72: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   75: astore #11
    //   77: aload #11
    //   79: astore #9
    //   81: iload #8
    //   83: ifne -> 52
    //   86: iconst_0
    //   87: aload_0
    //   88: getfield mMinWidth : I
    //   91: invokestatic max : (II)I
    //   94: istore_3
    //   95: aload #11
    //   97: astore #9
    //   99: goto -> 129
    //   102: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   105: astore #11
    //   107: aload #11
    //   109: astore #9
    //   111: iload #8
    //   113: ifne -> 129
    //   116: iconst_0
    //   117: aload_0
    //   118: getfield mMinWidth : I
    //   121: invokestatic max : (II)I
    //   124: istore_3
    //   125: aload #11
    //   127: astore #9
    //   129: iload #4
    //   131: ldc_w -2147483648
    //   134: if_icmpeq -> 204
    //   137: iload #4
    //   139: ifeq -> 173
    //   142: iload #4
    //   144: ldc_w 1073741824
    //   147: if_icmpeq -> 156
    //   150: iconst_0
    //   151: istore #5
    //   153: goto -> 232
    //   156: aload_0
    //   157: getfield mMaxHeight : I
    //   160: iload #6
    //   162: isub
    //   163: iload #5
    //   165: invokestatic min : (II)I
    //   168: istore #5
    //   170: goto -> 232
    //   173: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   176: astore #11
    //   178: aload #11
    //   180: astore #10
    //   182: iload #8
    //   184: ifne -> 150
    //   187: iconst_0
    //   188: aload_0
    //   189: getfield mMinHeight : I
    //   192: invokestatic max : (II)I
    //   195: istore #5
    //   197: aload #11
    //   199: astore #10
    //   201: goto -> 232
    //   204: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   207: astore #11
    //   209: aload #11
    //   211: astore #10
    //   213: iload #8
    //   215: ifne -> 232
    //   218: iconst_0
    //   219: aload_0
    //   220: getfield mMinHeight : I
    //   223: invokestatic max : (II)I
    //   226: istore #5
    //   228: aload #11
    //   230: astore #10
    //   232: iload_3
    //   233: aload_1
    //   234: invokevirtual getWidth : ()I
    //   237: if_icmpne -> 249
    //   240: iload #5
    //   242: aload_1
    //   243: invokevirtual getHeight : ()I
    //   246: if_icmpeq -> 253
    //   249: aload_1
    //   250: invokevirtual invalidateMeasures : ()V
    //   253: aload_1
    //   254: iconst_0
    //   255: invokevirtual setX : (I)V
    //   258: aload_1
    //   259: iconst_0
    //   260: invokevirtual setY : (I)V
    //   263: aload_1
    //   264: aload_0
    //   265: getfield mMaxWidth : I
    //   268: iload #7
    //   270: isub
    //   271: invokevirtual setMaxWidth : (I)V
    //   274: aload_1
    //   275: aload_0
    //   276: getfield mMaxHeight : I
    //   279: iload #6
    //   281: isub
    //   282: invokevirtual setMaxHeight : (I)V
    //   285: aload_1
    //   286: iconst_0
    //   287: invokevirtual setMinWidth : (I)V
    //   290: aload_1
    //   291: iconst_0
    //   292: invokevirtual setMinHeight : (I)V
    //   295: aload_1
    //   296: aload #9
    //   298: invokevirtual setHorizontalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   301: aload_1
    //   302: iload_3
    //   303: invokevirtual setWidth : (I)V
    //   306: aload_1
    //   307: aload #10
    //   309: invokevirtual setVerticalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   312: aload_1
    //   313: iload #5
    //   315: invokevirtual setHeight : (I)V
    //   318: aload_1
    //   319: aload_0
    //   320: getfield mMinWidth : I
    //   323: iload #7
    //   325: isub
    //   326: invokevirtual setMinWidth : (I)V
    //   329: aload_1
    //   330: aload_0
    //   331: getfield mMinHeight : I
    //   334: iload #6
    //   336: isub
    //   337: invokevirtual setMinHeight : (I)V
    //   340: return
  }
  
  public void setState(int paramInt1, int paramInt2, int paramInt3) {
    ConstraintLayoutStates constraintLayoutStates = this.mConstraintLayoutSpec;
    if (constraintLayoutStates != null)
      constraintLayoutStates.updateConstraints(paramInt1, paramInt2, paramInt3); 
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public static class LayoutParams extends ViewGroup.MarginLayoutParams {
    public static final int BASELINE = 5;
    
    public static final int BOTTOM = 4;
    
    public static final int CHAIN_PACKED = 2;
    
    public static final int CHAIN_SPREAD = 0;
    
    public static final int CHAIN_SPREAD_INSIDE = 1;
    
    public static final int END = 7;
    
    public static final int HORIZONTAL = 0;
    
    public static final int LEFT = 1;
    
    public static final int MATCH_CONSTRAINT = 0;
    
    public static final int MATCH_CONSTRAINT_PERCENT = 2;
    
    public static final int MATCH_CONSTRAINT_SPREAD = 0;
    
    public static final int MATCH_CONSTRAINT_WRAP = 1;
    
    public static final int PARENT_ID = 0;
    
    public static final int RIGHT = 2;
    
    public static final int START = 6;
    
    public static final int TOP = 3;
    
    public static final int UNSET = -1;
    
    public static final int VERTICAL = 1;
    
    public int baselineToBaseline = -1;
    
    public int bottomToBottom = -1;
    
    public int bottomToTop = -1;
    
    public float circleAngle = 0.0F;
    
    public int circleConstraint = -1;
    
    public int circleRadius = 0;
    
    public boolean constrainedHeight = false;
    
    public boolean constrainedWidth = false;
    
    public String constraintTag = null;
    
    public String dimensionRatio = null;
    
    int dimensionRatioSide = 1;
    
    float dimensionRatioValue = 0.0F;
    
    public int editorAbsoluteX = -1;
    
    public int editorAbsoluteY = -1;
    
    public int endToEnd = -1;
    
    public int endToStart = -1;
    
    public int goneBottomMargin = -1;
    
    public int goneEndMargin = -1;
    
    public int goneLeftMargin = -1;
    
    public int goneRightMargin = -1;
    
    public int goneStartMargin = -1;
    
    public int goneTopMargin = -1;
    
    public int guideBegin = -1;
    
    public int guideEnd = -1;
    
    public float guidePercent = -1.0F;
    
    public boolean helped = false;
    
    public float horizontalBias = 0.5F;
    
    public int horizontalChainStyle = 0;
    
    boolean horizontalDimensionFixed = true;
    
    public float horizontalWeight = -1.0F;
    
    boolean isGuideline = false;
    
    boolean isHelper = false;
    
    boolean isInPlaceholder = false;
    
    boolean isVirtualGroup = false;
    
    public int leftToLeft = -1;
    
    public int leftToRight = -1;
    
    public int matchConstraintDefaultHeight = 0;
    
    public int matchConstraintDefaultWidth = 0;
    
    public int matchConstraintMaxHeight = 0;
    
    public int matchConstraintMaxWidth = 0;
    
    public int matchConstraintMinHeight = 0;
    
    public int matchConstraintMinWidth = 0;
    
    public float matchConstraintPercentHeight = 1.0F;
    
    public float matchConstraintPercentWidth = 1.0F;
    
    boolean needsBaseline = false;
    
    public int orientation = -1;
    
    int resolveGoneLeftMargin = -1;
    
    int resolveGoneRightMargin = -1;
    
    int resolvedGuideBegin;
    
    int resolvedGuideEnd;
    
    float resolvedGuidePercent;
    
    float resolvedHorizontalBias = 0.5F;
    
    int resolvedLeftToLeft = -1;
    
    int resolvedLeftToRight = -1;
    
    int resolvedRightToLeft = -1;
    
    int resolvedRightToRight = -1;
    
    public int rightToLeft = -1;
    
    public int rightToRight = -1;
    
    public int startToEnd = -1;
    
    public int startToStart = -1;
    
    public int topToBottom = -1;
    
    public int topToTop = -1;
    
    public float verticalBias = 0.5F;
    
    public int verticalChainStyle = 0;
    
    boolean verticalDimensionFixed = true;
    
    public float verticalWeight = -1.0F;
    
    ConstraintWidget widget = new ConstraintWidget();
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: aload_2
      //   3: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
      //   6: aload_0
      //   7: iconst_m1
      //   8: putfield guideBegin : I
      //   11: aload_0
      //   12: iconst_m1
      //   13: putfield guideEnd : I
      //   16: aload_0
      //   17: ldc -1.0
      //   19: putfield guidePercent : F
      //   22: aload_0
      //   23: iconst_m1
      //   24: putfield leftToLeft : I
      //   27: aload_0
      //   28: iconst_m1
      //   29: putfield leftToRight : I
      //   32: aload_0
      //   33: iconst_m1
      //   34: putfield rightToLeft : I
      //   37: aload_0
      //   38: iconst_m1
      //   39: putfield rightToRight : I
      //   42: aload_0
      //   43: iconst_m1
      //   44: putfield topToTop : I
      //   47: aload_0
      //   48: iconst_m1
      //   49: putfield topToBottom : I
      //   52: aload_0
      //   53: iconst_m1
      //   54: putfield bottomToTop : I
      //   57: aload_0
      //   58: iconst_m1
      //   59: putfield bottomToBottom : I
      //   62: aload_0
      //   63: iconst_m1
      //   64: putfield baselineToBaseline : I
      //   67: aload_0
      //   68: iconst_m1
      //   69: putfield circleConstraint : I
      //   72: aload_0
      //   73: iconst_0
      //   74: putfield circleRadius : I
      //   77: aload_0
      //   78: fconst_0
      //   79: putfield circleAngle : F
      //   82: aload_0
      //   83: iconst_m1
      //   84: putfield startToEnd : I
      //   87: aload_0
      //   88: iconst_m1
      //   89: putfield startToStart : I
      //   92: aload_0
      //   93: iconst_m1
      //   94: putfield endToStart : I
      //   97: aload_0
      //   98: iconst_m1
      //   99: putfield endToEnd : I
      //   102: aload_0
      //   103: iconst_m1
      //   104: putfield goneLeftMargin : I
      //   107: aload_0
      //   108: iconst_m1
      //   109: putfield goneTopMargin : I
      //   112: aload_0
      //   113: iconst_m1
      //   114: putfield goneRightMargin : I
      //   117: aload_0
      //   118: iconst_m1
      //   119: putfield goneBottomMargin : I
      //   122: aload_0
      //   123: iconst_m1
      //   124: putfield goneStartMargin : I
      //   127: aload_0
      //   128: iconst_m1
      //   129: putfield goneEndMargin : I
      //   132: aload_0
      //   133: ldc 0.5
      //   135: putfield horizontalBias : F
      //   138: aload_0
      //   139: ldc 0.5
      //   141: putfield verticalBias : F
      //   144: aload_0
      //   145: aconst_null
      //   146: putfield dimensionRatio : Ljava/lang/String;
      //   149: aload_0
      //   150: fconst_0
      //   151: putfield dimensionRatioValue : F
      //   154: aload_0
      //   155: iconst_1
      //   156: putfield dimensionRatioSide : I
      //   159: aload_0
      //   160: ldc -1.0
      //   162: putfield horizontalWeight : F
      //   165: aload_0
      //   166: ldc -1.0
      //   168: putfield verticalWeight : F
      //   171: aload_0
      //   172: iconst_0
      //   173: putfield horizontalChainStyle : I
      //   176: aload_0
      //   177: iconst_0
      //   178: putfield verticalChainStyle : I
      //   181: aload_0
      //   182: iconst_0
      //   183: putfield matchConstraintDefaultWidth : I
      //   186: aload_0
      //   187: iconst_0
      //   188: putfield matchConstraintDefaultHeight : I
      //   191: aload_0
      //   192: iconst_0
      //   193: putfield matchConstraintMinWidth : I
      //   196: aload_0
      //   197: iconst_0
      //   198: putfield matchConstraintMinHeight : I
      //   201: aload_0
      //   202: iconst_0
      //   203: putfield matchConstraintMaxWidth : I
      //   206: aload_0
      //   207: iconst_0
      //   208: putfield matchConstraintMaxHeight : I
      //   211: aload_0
      //   212: fconst_1
      //   213: putfield matchConstraintPercentWidth : F
      //   216: aload_0
      //   217: fconst_1
      //   218: putfield matchConstraintPercentHeight : F
      //   221: aload_0
      //   222: iconst_m1
      //   223: putfield editorAbsoluteX : I
      //   226: aload_0
      //   227: iconst_m1
      //   228: putfield editorAbsoluteY : I
      //   231: aload_0
      //   232: iconst_m1
      //   233: putfield orientation : I
      //   236: aload_0
      //   237: iconst_0
      //   238: putfield constrainedWidth : Z
      //   241: aload_0
      //   242: iconst_0
      //   243: putfield constrainedHeight : Z
      //   246: aload_0
      //   247: aconst_null
      //   248: putfield constraintTag : Ljava/lang/String;
      //   251: aload_0
      //   252: iconst_1
      //   253: putfield horizontalDimensionFixed : Z
      //   256: aload_0
      //   257: iconst_1
      //   258: putfield verticalDimensionFixed : Z
      //   261: aload_0
      //   262: iconst_0
      //   263: putfield needsBaseline : Z
      //   266: aload_0
      //   267: iconst_0
      //   268: putfield isGuideline : Z
      //   271: aload_0
      //   272: iconst_0
      //   273: putfield isHelper : Z
      //   276: aload_0
      //   277: iconst_0
      //   278: putfield isInPlaceholder : Z
      //   281: aload_0
      //   282: iconst_0
      //   283: putfield isVirtualGroup : Z
      //   286: aload_0
      //   287: iconst_m1
      //   288: putfield resolvedLeftToLeft : I
      //   291: aload_0
      //   292: iconst_m1
      //   293: putfield resolvedLeftToRight : I
      //   296: aload_0
      //   297: iconst_m1
      //   298: putfield resolvedRightToLeft : I
      //   301: aload_0
      //   302: iconst_m1
      //   303: putfield resolvedRightToRight : I
      //   306: aload_0
      //   307: iconst_m1
      //   308: putfield resolveGoneLeftMargin : I
      //   311: aload_0
      //   312: iconst_m1
      //   313: putfield resolveGoneRightMargin : I
      //   316: aload_0
      //   317: ldc 0.5
      //   319: putfield resolvedHorizontalBias : F
      //   322: aload_0
      //   323: new androidx/constraintlayout/solver/widgets/ConstraintWidget
      //   326: dup
      //   327: invokespecial <init> : ()V
      //   330: putfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
      //   333: aload_0
      //   334: iconst_0
      //   335: putfield helped : Z
      //   338: aload_1
      //   339: aload_2
      //   340: getstatic androidx/constraintlayout/widget/R$styleable.ConstraintLayout_Layout : [I
      //   343: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
      //   346: astore_1
      //   347: aload_1
      //   348: invokevirtual getIndexCount : ()I
      //   351: istore #7
      //   353: iconst_0
      //   354: istore #5
      //   356: iload #5
      //   358: iload #7
      //   360: if_icmpge -> 2112
      //   363: aload_1
      //   364: iload #5
      //   366: invokevirtual getIndex : (I)I
      //   369: istore #6
      //   371: getstatic androidx/constraintlayout/widget/ConstraintLayout$LayoutParams$Table.map : Landroid/util/SparseIntArray;
      //   374: iload #6
      //   376: invokevirtual get : (I)I
      //   379: istore #8
      //   381: ldc_w '2837'
      //   384: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
      //   387: astore_2
      //   388: iload #8
      //   390: tableswitch default -> 556, 1 -> 2089, 2 -> 2051, 3 -> 2034, 4 -> 1992, 5 -> 1975, 6 -> 1958, 7 -> 1941, 8 -> 1903, 9 -> 1865, 10 -> 1827, 11 -> 1789, 12 -> 1751, 13 -> 1713, 14 -> 1675, 15 -> 1637, 16 -> 1599, 17 -> 1561, 18 -> 1523, 19 -> 1485, 20 -> 1447, 21 -> 1430, 22 -> 1413, 23 -> 1396, 24 -> 1379, 25 -> 1362, 26 -> 1345, 27 -> 1328, 28 -> 1311, 29 -> 1294, 30 -> 1277, 31 -> 1242, 32 -> 1207, 33 -> 1166, 34 -> 1125, 35 -> 1099, 36 -> 1058, 37 -> 1017, 38 -> 991
      //   556: iload #8
      //   558: tableswitch default -> 604, 44 -> 716, 45 -> 699, 46 -> 682, 47 -> 668, 48 -> 654, 49 -> 637, 50 -> 620, 51 -> 607
      //   604: goto -> 2103
      //   607: aload_0
      //   608: aload_1
      //   609: iload #6
      //   611: invokevirtual getString : (I)Ljava/lang/String;
      //   614: putfield constraintTag : Ljava/lang/String;
      //   617: goto -> 2103
      //   620: aload_0
      //   621: aload_1
      //   622: iload #6
      //   624: aload_0
      //   625: getfield editorAbsoluteY : I
      //   628: invokevirtual getDimensionPixelOffset : (II)I
      //   631: putfield editorAbsoluteY : I
      //   634: goto -> 2103
      //   637: aload_0
      //   638: aload_1
      //   639: iload #6
      //   641: aload_0
      //   642: getfield editorAbsoluteX : I
      //   645: invokevirtual getDimensionPixelOffset : (II)I
      //   648: putfield editorAbsoluteX : I
      //   651: goto -> 2103
      //   654: aload_0
      //   655: aload_1
      //   656: iload #6
      //   658: iconst_0
      //   659: invokevirtual getInt : (II)I
      //   662: putfield verticalChainStyle : I
      //   665: goto -> 2103
      //   668: aload_0
      //   669: aload_1
      //   670: iload #6
      //   672: iconst_0
      //   673: invokevirtual getInt : (II)I
      //   676: putfield horizontalChainStyle : I
      //   679: goto -> 2103
      //   682: aload_0
      //   683: aload_1
      //   684: iload #6
      //   686: aload_0
      //   687: getfield verticalWeight : F
      //   690: invokevirtual getFloat : (IF)F
      //   693: putfield verticalWeight : F
      //   696: goto -> 2103
      //   699: aload_0
      //   700: aload_1
      //   701: iload #6
      //   703: aload_0
      //   704: getfield horizontalWeight : F
      //   707: invokevirtual getFloat : (IF)F
      //   710: putfield horizontalWeight : F
      //   713: goto -> 2103
      //   716: aload_1
      //   717: iload #6
      //   719: invokevirtual getString : (I)Ljava/lang/String;
      //   722: astore_2
      //   723: aload_0
      //   724: aload_2
      //   725: putfield dimensionRatio : Ljava/lang/String;
      //   728: aload_0
      //   729: ldc_w NaN
      //   732: putfield dimensionRatioValue : F
      //   735: aload_0
      //   736: iconst_m1
      //   737: putfield dimensionRatioSide : I
      //   740: aload_2
      //   741: ifnull -> 2103
      //   744: aload_2
      //   745: invokevirtual length : ()I
      //   748: istore #8
      //   750: aload_0
      //   751: getfield dimensionRatio : Ljava/lang/String;
      //   754: bipush #44
      //   756: invokevirtual indexOf : (I)I
      //   759: istore #6
      //   761: iload #6
      //   763: ifle -> 834
      //   766: iload #6
      //   768: iload #8
      //   770: iconst_1
      //   771: isub
      //   772: if_icmpge -> 834
      //   775: aload_0
      //   776: getfield dimensionRatio : Ljava/lang/String;
      //   779: iconst_0
      //   780: iload #6
      //   782: invokevirtual substring : (II)Ljava/lang/String;
      //   785: astore_2
      //   786: aload_2
      //   787: ldc_w '2838'
      //   790: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
      //   793: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
      //   796: ifeq -> 807
      //   799: aload_0
      //   800: iconst_0
      //   801: putfield dimensionRatioSide : I
      //   804: goto -> 825
      //   807: aload_2
      //   808: ldc_w '2839'
      //   811: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
      //   814: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
      //   817: ifeq -> 825
      //   820: aload_0
      //   821: iconst_1
      //   822: putfield dimensionRatioSide : I
      //   825: iload #6
      //   827: iconst_1
      //   828: iadd
      //   829: istore #6
      //   831: goto -> 837
      //   834: iconst_0
      //   835: istore #6
      //   837: aload_0
      //   838: getfield dimensionRatio : Ljava/lang/String;
      //   841: bipush #58
      //   843: invokevirtual indexOf : (I)I
      //   846: istore #9
      //   848: iload #9
      //   850: iflt -> 963
      //   853: iload #9
      //   855: iload #8
      //   857: iconst_1
      //   858: isub
      //   859: if_icmpge -> 963
      //   862: aload_0
      //   863: getfield dimensionRatio : Ljava/lang/String;
      //   866: iload #6
      //   868: iload #9
      //   870: invokevirtual substring : (II)Ljava/lang/String;
      //   873: astore_2
      //   874: aload_0
      //   875: getfield dimensionRatio : Ljava/lang/String;
      //   878: iload #9
      //   880: iconst_1
      //   881: iadd
      //   882: invokevirtual substring : (I)Ljava/lang/String;
      //   885: astore #10
      //   887: aload_2
      //   888: invokevirtual length : ()I
      //   891: ifle -> 2103
      //   894: aload #10
      //   896: invokevirtual length : ()I
      //   899: ifle -> 2103
      //   902: aload_2
      //   903: invokestatic parseFloat : (Ljava/lang/String;)F
      //   906: fstore_3
      //   907: aload #10
      //   909: invokestatic parseFloat : (Ljava/lang/String;)F
      //   912: fstore #4
      //   914: fload_3
      //   915: fconst_0
      //   916: fcmpl
      //   917: ifle -> 2103
      //   920: fload #4
      //   922: fconst_0
      //   923: fcmpl
      //   924: ifle -> 2103
      //   927: aload_0
      //   928: getfield dimensionRatioSide : I
      //   931: iconst_1
      //   932: if_icmpne -> 949
      //   935: aload_0
      //   936: fload #4
      //   938: fload_3
      //   939: fdiv
      //   940: invokestatic abs : (F)F
      //   943: putfield dimensionRatioValue : F
      //   946: goto -> 2103
      //   949: aload_0
      //   950: fload_3
      //   951: fload #4
      //   953: fdiv
      //   954: invokestatic abs : (F)F
      //   957: putfield dimensionRatioValue : F
      //   960: goto -> 2103
      //   963: aload_0
      //   964: getfield dimensionRatio : Ljava/lang/String;
      //   967: iload #6
      //   969: invokevirtual substring : (I)Ljava/lang/String;
      //   972: astore_2
      //   973: aload_2
      //   974: invokevirtual length : ()I
      //   977: ifle -> 2103
      //   980: aload_0
      //   981: aload_2
      //   982: invokestatic parseFloat : (Ljava/lang/String;)F
      //   985: putfield dimensionRatioValue : F
      //   988: goto -> 2103
      //   991: aload_0
      //   992: fconst_0
      //   993: aload_1
      //   994: iload #6
      //   996: aload_0
      //   997: getfield matchConstraintPercentHeight : F
      //   1000: invokevirtual getFloat : (IF)F
      //   1003: invokestatic max : (FF)F
      //   1006: putfield matchConstraintPercentHeight : F
      //   1009: aload_0
      //   1010: iconst_2
      //   1011: putfield matchConstraintDefaultHeight : I
      //   1014: goto -> 2103
      //   1017: aload_0
      //   1018: aload_1
      //   1019: iload #6
      //   1021: aload_0
      //   1022: getfield matchConstraintMaxHeight : I
      //   1025: invokevirtual getDimensionPixelSize : (II)I
      //   1028: putfield matchConstraintMaxHeight : I
      //   1031: goto -> 2103
      //   1034: aload_1
      //   1035: iload #6
      //   1037: aload_0
      //   1038: getfield matchConstraintMaxHeight : I
      //   1041: invokevirtual getInt : (II)I
      //   1044: bipush #-2
      //   1046: if_icmpne -> 2103
      //   1049: aload_0
      //   1050: bipush #-2
      //   1052: putfield matchConstraintMaxHeight : I
      //   1055: goto -> 2103
      //   1058: aload_0
      //   1059: aload_1
      //   1060: iload #6
      //   1062: aload_0
      //   1063: getfield matchConstraintMinHeight : I
      //   1066: invokevirtual getDimensionPixelSize : (II)I
      //   1069: putfield matchConstraintMinHeight : I
      //   1072: goto -> 2103
      //   1075: aload_1
      //   1076: iload #6
      //   1078: aload_0
      //   1079: getfield matchConstraintMinHeight : I
      //   1082: invokevirtual getInt : (II)I
      //   1085: bipush #-2
      //   1087: if_icmpne -> 2103
      //   1090: aload_0
      //   1091: bipush #-2
      //   1093: putfield matchConstraintMinHeight : I
      //   1096: goto -> 2103
      //   1099: aload_0
      //   1100: fconst_0
      //   1101: aload_1
      //   1102: iload #6
      //   1104: aload_0
      //   1105: getfield matchConstraintPercentWidth : F
      //   1108: invokevirtual getFloat : (IF)F
      //   1111: invokestatic max : (FF)F
      //   1114: putfield matchConstraintPercentWidth : F
      //   1117: aload_0
      //   1118: iconst_2
      //   1119: putfield matchConstraintDefaultWidth : I
      //   1122: goto -> 2103
      //   1125: aload_0
      //   1126: aload_1
      //   1127: iload #6
      //   1129: aload_0
      //   1130: getfield matchConstraintMaxWidth : I
      //   1133: invokevirtual getDimensionPixelSize : (II)I
      //   1136: putfield matchConstraintMaxWidth : I
      //   1139: goto -> 2103
      //   1142: aload_1
      //   1143: iload #6
      //   1145: aload_0
      //   1146: getfield matchConstraintMaxWidth : I
      //   1149: invokevirtual getInt : (II)I
      //   1152: bipush #-2
      //   1154: if_icmpne -> 2103
      //   1157: aload_0
      //   1158: bipush #-2
      //   1160: putfield matchConstraintMaxWidth : I
      //   1163: goto -> 2103
      //   1166: aload_0
      //   1167: aload_1
      //   1168: iload #6
      //   1170: aload_0
      //   1171: getfield matchConstraintMinWidth : I
      //   1174: invokevirtual getDimensionPixelSize : (II)I
      //   1177: putfield matchConstraintMinWidth : I
      //   1180: goto -> 2103
      //   1183: aload_1
      //   1184: iload #6
      //   1186: aload_0
      //   1187: getfield matchConstraintMinWidth : I
      //   1190: invokevirtual getInt : (II)I
      //   1193: bipush #-2
      //   1195: if_icmpne -> 2103
      //   1198: aload_0
      //   1199: bipush #-2
      //   1201: putfield matchConstraintMinWidth : I
      //   1204: goto -> 2103
      //   1207: aload_1
      //   1208: iload #6
      //   1210: iconst_0
      //   1211: invokevirtual getInt : (II)I
      //   1214: istore #6
      //   1216: aload_0
      //   1217: iload #6
      //   1219: putfield matchConstraintDefaultHeight : I
      //   1222: iload #6
      //   1224: iconst_1
      //   1225: if_icmpne -> 2103
      //   1228: aload_2
      //   1229: ldc_w '2840'
      //   1232: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
      //   1235: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
      //   1238: pop
      //   1239: goto -> 2103
      //   1242: aload_1
      //   1243: iload #6
      //   1245: iconst_0
      //   1246: invokevirtual getInt : (II)I
      //   1249: istore #6
      //   1251: aload_0
      //   1252: iload #6
      //   1254: putfield matchConstraintDefaultWidth : I
      //   1257: iload #6
      //   1259: iconst_1
      //   1260: if_icmpne -> 2103
      //   1263: aload_2
      //   1264: ldc_w '2841'
      //   1267: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
      //   1270: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
      //   1273: pop
      //   1274: goto -> 2103
      //   1277: aload_0
      //   1278: aload_1
      //   1279: iload #6
      //   1281: aload_0
      //   1282: getfield verticalBias : F
      //   1285: invokevirtual getFloat : (IF)F
      //   1288: putfield verticalBias : F
      //   1291: goto -> 2103
      //   1294: aload_0
      //   1295: aload_1
      //   1296: iload #6
      //   1298: aload_0
      //   1299: getfield horizontalBias : F
      //   1302: invokevirtual getFloat : (IF)F
      //   1305: putfield horizontalBias : F
      //   1308: goto -> 2103
      //   1311: aload_0
      //   1312: aload_1
      //   1313: iload #6
      //   1315: aload_0
      //   1316: getfield constrainedHeight : Z
      //   1319: invokevirtual getBoolean : (IZ)Z
      //   1322: putfield constrainedHeight : Z
      //   1325: goto -> 2103
      //   1328: aload_0
      //   1329: aload_1
      //   1330: iload #6
      //   1332: aload_0
      //   1333: getfield constrainedWidth : Z
      //   1336: invokevirtual getBoolean : (IZ)Z
      //   1339: putfield constrainedWidth : Z
      //   1342: goto -> 2103
      //   1345: aload_0
      //   1346: aload_1
      //   1347: iload #6
      //   1349: aload_0
      //   1350: getfield goneEndMargin : I
      //   1353: invokevirtual getDimensionPixelSize : (II)I
      //   1356: putfield goneEndMargin : I
      //   1359: goto -> 2103
      //   1362: aload_0
      //   1363: aload_1
      //   1364: iload #6
      //   1366: aload_0
      //   1367: getfield goneStartMargin : I
      //   1370: invokevirtual getDimensionPixelSize : (II)I
      //   1373: putfield goneStartMargin : I
      //   1376: goto -> 2103
      //   1379: aload_0
      //   1380: aload_1
      //   1381: iload #6
      //   1383: aload_0
      //   1384: getfield goneBottomMargin : I
      //   1387: invokevirtual getDimensionPixelSize : (II)I
      //   1390: putfield goneBottomMargin : I
      //   1393: goto -> 2103
      //   1396: aload_0
      //   1397: aload_1
      //   1398: iload #6
      //   1400: aload_0
      //   1401: getfield goneRightMargin : I
      //   1404: invokevirtual getDimensionPixelSize : (II)I
      //   1407: putfield goneRightMargin : I
      //   1410: goto -> 2103
      //   1413: aload_0
      //   1414: aload_1
      //   1415: iload #6
      //   1417: aload_0
      //   1418: getfield goneTopMargin : I
      //   1421: invokevirtual getDimensionPixelSize : (II)I
      //   1424: putfield goneTopMargin : I
      //   1427: goto -> 2103
      //   1430: aload_0
      //   1431: aload_1
      //   1432: iload #6
      //   1434: aload_0
      //   1435: getfield goneLeftMargin : I
      //   1438: invokevirtual getDimensionPixelSize : (II)I
      //   1441: putfield goneLeftMargin : I
      //   1444: goto -> 2103
      //   1447: aload_1
      //   1448: iload #6
      //   1450: aload_0
      //   1451: getfield endToEnd : I
      //   1454: invokevirtual getResourceId : (II)I
      //   1457: istore #8
      //   1459: aload_0
      //   1460: iload #8
      //   1462: putfield endToEnd : I
      //   1465: iload #8
      //   1467: iconst_m1
      //   1468: if_icmpne -> 2103
      //   1471: aload_0
      //   1472: aload_1
      //   1473: iload #6
      //   1475: iconst_m1
      //   1476: invokevirtual getInt : (II)I
      //   1479: putfield endToEnd : I
      //   1482: goto -> 2103
      //   1485: aload_1
      //   1486: iload #6
      //   1488: aload_0
      //   1489: getfield endToStart : I
      //   1492: invokevirtual getResourceId : (II)I
      //   1495: istore #8
      //   1497: aload_0
      //   1498: iload #8
      //   1500: putfield endToStart : I
      //   1503: iload #8
      //   1505: iconst_m1
      //   1506: if_icmpne -> 2103
      //   1509: aload_0
      //   1510: aload_1
      //   1511: iload #6
      //   1513: iconst_m1
      //   1514: invokevirtual getInt : (II)I
      //   1517: putfield endToStart : I
      //   1520: goto -> 2103
      //   1523: aload_1
      //   1524: iload #6
      //   1526: aload_0
      //   1527: getfield startToStart : I
      //   1530: invokevirtual getResourceId : (II)I
      //   1533: istore #8
      //   1535: aload_0
      //   1536: iload #8
      //   1538: putfield startToStart : I
      //   1541: iload #8
      //   1543: iconst_m1
      //   1544: if_icmpne -> 2103
      //   1547: aload_0
      //   1548: aload_1
      //   1549: iload #6
      //   1551: iconst_m1
      //   1552: invokevirtual getInt : (II)I
      //   1555: putfield startToStart : I
      //   1558: goto -> 2103
      //   1561: aload_1
      //   1562: iload #6
      //   1564: aload_0
      //   1565: getfield startToEnd : I
      //   1568: invokevirtual getResourceId : (II)I
      //   1571: istore #8
      //   1573: aload_0
      //   1574: iload #8
      //   1576: putfield startToEnd : I
      //   1579: iload #8
      //   1581: iconst_m1
      //   1582: if_icmpne -> 2103
      //   1585: aload_0
      //   1586: aload_1
      //   1587: iload #6
      //   1589: iconst_m1
      //   1590: invokevirtual getInt : (II)I
      //   1593: putfield startToEnd : I
      //   1596: goto -> 2103
      //   1599: aload_1
      //   1600: iload #6
      //   1602: aload_0
      //   1603: getfield baselineToBaseline : I
      //   1606: invokevirtual getResourceId : (II)I
      //   1609: istore #8
      //   1611: aload_0
      //   1612: iload #8
      //   1614: putfield baselineToBaseline : I
      //   1617: iload #8
      //   1619: iconst_m1
      //   1620: if_icmpne -> 2103
      //   1623: aload_0
      //   1624: aload_1
      //   1625: iload #6
      //   1627: iconst_m1
      //   1628: invokevirtual getInt : (II)I
      //   1631: putfield baselineToBaseline : I
      //   1634: goto -> 2103
      //   1637: aload_1
      //   1638: iload #6
      //   1640: aload_0
      //   1641: getfield bottomToBottom : I
      //   1644: invokevirtual getResourceId : (II)I
      //   1647: istore #8
      //   1649: aload_0
      //   1650: iload #8
      //   1652: putfield bottomToBottom : I
      //   1655: iload #8
      //   1657: iconst_m1
      //   1658: if_icmpne -> 2103
      //   1661: aload_0
      //   1662: aload_1
      //   1663: iload #6
      //   1665: iconst_m1
      //   1666: invokevirtual getInt : (II)I
      //   1669: putfield bottomToBottom : I
      //   1672: goto -> 2103
      //   1675: aload_1
      //   1676: iload #6
      //   1678: aload_0
      //   1679: getfield bottomToTop : I
      //   1682: invokevirtual getResourceId : (II)I
      //   1685: istore #8
      //   1687: aload_0
      //   1688: iload #8
      //   1690: putfield bottomToTop : I
      //   1693: iload #8
      //   1695: iconst_m1
      //   1696: if_icmpne -> 2103
      //   1699: aload_0
      //   1700: aload_1
      //   1701: iload #6
      //   1703: iconst_m1
      //   1704: invokevirtual getInt : (II)I
      //   1707: putfield bottomToTop : I
      //   1710: goto -> 2103
      //   1713: aload_1
      //   1714: iload #6
      //   1716: aload_0
      //   1717: getfield topToBottom : I
      //   1720: invokevirtual getResourceId : (II)I
      //   1723: istore #8
      //   1725: aload_0
      //   1726: iload #8
      //   1728: putfield topToBottom : I
      //   1731: iload #8
      //   1733: iconst_m1
      //   1734: if_icmpne -> 2103
      //   1737: aload_0
      //   1738: aload_1
      //   1739: iload #6
      //   1741: iconst_m1
      //   1742: invokevirtual getInt : (II)I
      //   1745: putfield topToBottom : I
      //   1748: goto -> 2103
      //   1751: aload_1
      //   1752: iload #6
      //   1754: aload_0
      //   1755: getfield topToTop : I
      //   1758: invokevirtual getResourceId : (II)I
      //   1761: istore #8
      //   1763: aload_0
      //   1764: iload #8
      //   1766: putfield topToTop : I
      //   1769: iload #8
      //   1771: iconst_m1
      //   1772: if_icmpne -> 2103
      //   1775: aload_0
      //   1776: aload_1
      //   1777: iload #6
      //   1779: iconst_m1
      //   1780: invokevirtual getInt : (II)I
      //   1783: putfield topToTop : I
      //   1786: goto -> 2103
      //   1789: aload_1
      //   1790: iload #6
      //   1792: aload_0
      //   1793: getfield rightToRight : I
      //   1796: invokevirtual getResourceId : (II)I
      //   1799: istore #8
      //   1801: aload_0
      //   1802: iload #8
      //   1804: putfield rightToRight : I
      //   1807: iload #8
      //   1809: iconst_m1
      //   1810: if_icmpne -> 2103
      //   1813: aload_0
      //   1814: aload_1
      //   1815: iload #6
      //   1817: iconst_m1
      //   1818: invokevirtual getInt : (II)I
      //   1821: putfield rightToRight : I
      //   1824: goto -> 2103
      //   1827: aload_1
      //   1828: iload #6
      //   1830: aload_0
      //   1831: getfield rightToLeft : I
      //   1834: invokevirtual getResourceId : (II)I
      //   1837: istore #8
      //   1839: aload_0
      //   1840: iload #8
      //   1842: putfield rightToLeft : I
      //   1845: iload #8
      //   1847: iconst_m1
      //   1848: if_icmpne -> 2103
      //   1851: aload_0
      //   1852: aload_1
      //   1853: iload #6
      //   1855: iconst_m1
      //   1856: invokevirtual getInt : (II)I
      //   1859: putfield rightToLeft : I
      //   1862: goto -> 2103
      //   1865: aload_1
      //   1866: iload #6
      //   1868: aload_0
      //   1869: getfield leftToRight : I
      //   1872: invokevirtual getResourceId : (II)I
      //   1875: istore #8
      //   1877: aload_0
      //   1878: iload #8
      //   1880: putfield leftToRight : I
      //   1883: iload #8
      //   1885: iconst_m1
      //   1886: if_icmpne -> 2103
      //   1889: aload_0
      //   1890: aload_1
      //   1891: iload #6
      //   1893: iconst_m1
      //   1894: invokevirtual getInt : (II)I
      //   1897: putfield leftToRight : I
      //   1900: goto -> 2103
      //   1903: aload_1
      //   1904: iload #6
      //   1906: aload_0
      //   1907: getfield leftToLeft : I
      //   1910: invokevirtual getResourceId : (II)I
      //   1913: istore #8
      //   1915: aload_0
      //   1916: iload #8
      //   1918: putfield leftToLeft : I
      //   1921: iload #8
      //   1923: iconst_m1
      //   1924: if_icmpne -> 2103
      //   1927: aload_0
      //   1928: aload_1
      //   1929: iload #6
      //   1931: iconst_m1
      //   1932: invokevirtual getInt : (II)I
      //   1935: putfield leftToLeft : I
      //   1938: goto -> 2103
      //   1941: aload_0
      //   1942: aload_1
      //   1943: iload #6
      //   1945: aload_0
      //   1946: getfield guidePercent : F
      //   1949: invokevirtual getFloat : (IF)F
      //   1952: putfield guidePercent : F
      //   1955: goto -> 2103
      //   1958: aload_0
      //   1959: aload_1
      //   1960: iload #6
      //   1962: aload_0
      //   1963: getfield guideEnd : I
      //   1966: invokevirtual getDimensionPixelOffset : (II)I
      //   1969: putfield guideEnd : I
      //   1972: goto -> 2103
      //   1975: aload_0
      //   1976: aload_1
      //   1977: iload #6
      //   1979: aload_0
      //   1980: getfield guideBegin : I
      //   1983: invokevirtual getDimensionPixelOffset : (II)I
      //   1986: putfield guideBegin : I
      //   1989: goto -> 2103
      //   1992: aload_1
      //   1993: iload #6
      //   1995: aload_0
      //   1996: getfield circleAngle : F
      //   1999: invokevirtual getFloat : (IF)F
      //   2002: ldc_w 360.0
      //   2005: frem
      //   2006: fstore_3
      //   2007: aload_0
      //   2008: fload_3
      //   2009: putfield circleAngle : F
      //   2012: fload_3
      //   2013: fconst_0
      //   2014: fcmpg
      //   2015: ifge -> 2103
      //   2018: aload_0
      //   2019: ldc_w 360.0
      //   2022: fload_3
      //   2023: fsub
      //   2024: ldc_w 360.0
      //   2027: frem
      //   2028: putfield circleAngle : F
      //   2031: goto -> 2103
      //   2034: aload_0
      //   2035: aload_1
      //   2036: iload #6
      //   2038: aload_0
      //   2039: getfield circleRadius : I
      //   2042: invokevirtual getDimensionPixelSize : (II)I
      //   2045: putfield circleRadius : I
      //   2048: goto -> 2103
      //   2051: aload_1
      //   2052: iload #6
      //   2054: aload_0
      //   2055: getfield circleConstraint : I
      //   2058: invokevirtual getResourceId : (II)I
      //   2061: istore #8
      //   2063: aload_0
      //   2064: iload #8
      //   2066: putfield circleConstraint : I
      //   2069: iload #8
      //   2071: iconst_m1
      //   2072: if_icmpne -> 2103
      //   2075: aload_0
      //   2076: aload_1
      //   2077: iload #6
      //   2079: iconst_m1
      //   2080: invokevirtual getInt : (II)I
      //   2083: putfield circleConstraint : I
      //   2086: goto -> 2103
      //   2089: aload_0
      //   2090: aload_1
      //   2091: iload #6
      //   2093: aload_0
      //   2094: getfield orientation : I
      //   2097: invokevirtual getInt : (II)I
      //   2100: putfield orientation : I
      //   2103: iload #5
      //   2105: iconst_1
      //   2106: iadd
      //   2107: istore #5
      //   2109: goto -> 356
      //   2112: aload_1
      //   2113: invokevirtual recycle : ()V
      //   2116: aload_0
      //   2117: invokevirtual validate : ()V
      //   2120: return
      //   2121: astore_2
      //   2122: goto -> 2103
      //   2125: astore_2
      //   2126: goto -> 1034
      //   2129: astore_2
      //   2130: goto -> 1075
      //   2133: astore_2
      //   2134: goto -> 1142
      //   2137: astore_2
      //   2138: goto -> 1183
      // Exception table:
      //   from	to	target	type
      //   902	914	2121	java/lang/NumberFormatException
      //   927	946	2121	java/lang/NumberFormatException
      //   949	960	2121	java/lang/NumberFormatException
      //   980	988	2121	java/lang/NumberFormatException
      //   1017	1031	2125	java/lang/Exception
      //   1058	1072	2129	java/lang/Exception
      //   1125	1139	2133	java/lang/Exception
      //   1166	1180	2137	java/lang/Exception
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
      this.guideBegin = param1LayoutParams.guideBegin;
      this.guideEnd = param1LayoutParams.guideEnd;
      this.guidePercent = param1LayoutParams.guidePercent;
      this.leftToLeft = param1LayoutParams.leftToLeft;
      this.leftToRight = param1LayoutParams.leftToRight;
      this.rightToLeft = param1LayoutParams.rightToLeft;
      this.rightToRight = param1LayoutParams.rightToRight;
      this.topToTop = param1LayoutParams.topToTop;
      this.topToBottom = param1LayoutParams.topToBottom;
      this.bottomToTop = param1LayoutParams.bottomToTop;
      this.bottomToBottom = param1LayoutParams.bottomToBottom;
      this.baselineToBaseline = param1LayoutParams.baselineToBaseline;
      this.circleConstraint = param1LayoutParams.circleConstraint;
      this.circleRadius = param1LayoutParams.circleRadius;
      this.circleAngle = param1LayoutParams.circleAngle;
      this.startToEnd = param1LayoutParams.startToEnd;
      this.startToStart = param1LayoutParams.startToStart;
      this.endToStart = param1LayoutParams.endToStart;
      this.endToEnd = param1LayoutParams.endToEnd;
      this.goneLeftMargin = param1LayoutParams.goneLeftMargin;
      this.goneTopMargin = param1LayoutParams.goneTopMargin;
      this.goneRightMargin = param1LayoutParams.goneRightMargin;
      this.goneBottomMargin = param1LayoutParams.goneBottomMargin;
      this.goneStartMargin = param1LayoutParams.goneStartMargin;
      this.goneEndMargin = param1LayoutParams.goneEndMargin;
      this.horizontalBias = param1LayoutParams.horizontalBias;
      this.verticalBias = param1LayoutParams.verticalBias;
      this.dimensionRatio = param1LayoutParams.dimensionRatio;
      this.dimensionRatioValue = param1LayoutParams.dimensionRatioValue;
      this.dimensionRatioSide = param1LayoutParams.dimensionRatioSide;
      this.horizontalWeight = param1LayoutParams.horizontalWeight;
      this.verticalWeight = param1LayoutParams.verticalWeight;
      this.horizontalChainStyle = param1LayoutParams.horizontalChainStyle;
      this.verticalChainStyle = param1LayoutParams.verticalChainStyle;
      this.constrainedWidth = param1LayoutParams.constrainedWidth;
      this.constrainedHeight = param1LayoutParams.constrainedHeight;
      this.matchConstraintDefaultWidth = param1LayoutParams.matchConstraintDefaultWidth;
      this.matchConstraintDefaultHeight = param1LayoutParams.matchConstraintDefaultHeight;
      this.matchConstraintMinWidth = param1LayoutParams.matchConstraintMinWidth;
      this.matchConstraintMaxWidth = param1LayoutParams.matchConstraintMaxWidth;
      this.matchConstraintMinHeight = param1LayoutParams.matchConstraintMinHeight;
      this.matchConstraintMaxHeight = param1LayoutParams.matchConstraintMaxHeight;
      this.matchConstraintPercentWidth = param1LayoutParams.matchConstraintPercentWidth;
      this.matchConstraintPercentHeight = param1LayoutParams.matchConstraintPercentHeight;
      this.editorAbsoluteX = param1LayoutParams.editorAbsoluteX;
      this.editorAbsoluteY = param1LayoutParams.editorAbsoluteY;
      this.orientation = param1LayoutParams.orientation;
      this.horizontalDimensionFixed = param1LayoutParams.horizontalDimensionFixed;
      this.verticalDimensionFixed = param1LayoutParams.verticalDimensionFixed;
      this.needsBaseline = param1LayoutParams.needsBaseline;
      this.isGuideline = param1LayoutParams.isGuideline;
      this.resolvedLeftToLeft = param1LayoutParams.resolvedLeftToLeft;
      this.resolvedLeftToRight = param1LayoutParams.resolvedLeftToRight;
      this.resolvedRightToLeft = param1LayoutParams.resolvedRightToLeft;
      this.resolvedRightToRight = param1LayoutParams.resolvedRightToRight;
      this.resolveGoneLeftMargin = param1LayoutParams.resolveGoneLeftMargin;
      this.resolveGoneRightMargin = param1LayoutParams.resolveGoneRightMargin;
      this.resolvedHorizontalBias = param1LayoutParams.resolvedHorizontalBias;
      this.constraintTag = param1LayoutParams.constraintTag;
      this.widget = param1LayoutParams.widget;
    }
    
    public String getConstraintTag() {
      return this.constraintTag;
    }
    
    public ConstraintWidget getConstraintWidget() {
      return this.widget;
    }
    
    public void reset() {
      ConstraintWidget constraintWidget = this.widget;
      if (constraintWidget != null)
        constraintWidget.reset(); 
    }
    
    public void resolveLayoutDirection(int param1Int) {
      // Byte code:
      //   0: aload_0
      //   1: getfield leftMargin : I
      //   4: istore #5
      //   6: aload_0
      //   7: getfield rightMargin : I
      //   10: istore #6
      //   12: getstatic android/os/Build$VERSION.SDK_INT : I
      //   15: istore #7
      //   17: iconst_0
      //   18: istore #4
      //   20: iload #7
      //   22: bipush #17
      //   24: if_icmplt -> 45
      //   27: aload_0
      //   28: iload_1
      //   29: invokespecial resolveLayoutDirection : (I)V
      //   32: iconst_1
      //   33: aload_0
      //   34: invokevirtual getLayoutDirection : ()I
      //   37: if_icmpne -> 45
      //   40: iconst_1
      //   41: istore_1
      //   42: goto -> 47
      //   45: iconst_0
      //   46: istore_1
      //   47: aload_0
      //   48: iconst_m1
      //   49: putfield resolvedRightToLeft : I
      //   52: aload_0
      //   53: iconst_m1
      //   54: putfield resolvedRightToRight : I
      //   57: aload_0
      //   58: iconst_m1
      //   59: putfield resolvedLeftToLeft : I
      //   62: aload_0
      //   63: iconst_m1
      //   64: putfield resolvedLeftToRight : I
      //   67: aload_0
      //   68: aload_0
      //   69: getfield goneLeftMargin : I
      //   72: putfield resolveGoneLeftMargin : I
      //   75: aload_0
      //   76: aload_0
      //   77: getfield goneRightMargin : I
      //   80: putfield resolveGoneRightMargin : I
      //   83: aload_0
      //   84: getfield horizontalBias : F
      //   87: fstore_2
      //   88: aload_0
      //   89: fload_2
      //   90: putfield resolvedHorizontalBias : F
      //   93: aload_0
      //   94: getfield guideBegin : I
      //   97: istore #7
      //   99: aload_0
      //   100: iload #7
      //   102: putfield resolvedGuideBegin : I
      //   105: aload_0
      //   106: getfield guideEnd : I
      //   109: istore #8
      //   111: aload_0
      //   112: iload #8
      //   114: putfield resolvedGuideEnd : I
      //   117: aload_0
      //   118: getfield guidePercent : F
      //   121: fstore_3
      //   122: aload_0
      //   123: fload_3
      //   124: putfield resolvedGuidePercent : F
      //   127: iload_1
      //   128: ifeq -> 356
      //   131: aload_0
      //   132: getfield startToEnd : I
      //   135: istore_1
      //   136: iload_1
      //   137: iconst_m1
      //   138: if_icmpeq -> 151
      //   141: aload_0
      //   142: iload_1
      //   143: putfield resolvedRightToLeft : I
      //   146: iconst_1
      //   147: istore_1
      //   148: goto -> 175
      //   151: aload_0
      //   152: getfield startToStart : I
      //   155: istore #9
      //   157: iload #4
      //   159: istore_1
      //   160: iload #9
      //   162: iconst_m1
      //   163: if_icmpeq -> 175
      //   166: aload_0
      //   167: iload #9
      //   169: putfield resolvedRightToRight : I
      //   172: goto -> 146
      //   175: aload_0
      //   176: getfield endToStart : I
      //   179: istore #4
      //   181: iload #4
      //   183: iconst_m1
      //   184: if_icmpeq -> 195
      //   187: aload_0
      //   188: iload #4
      //   190: putfield resolvedLeftToRight : I
      //   193: iconst_1
      //   194: istore_1
      //   195: aload_0
      //   196: getfield endToEnd : I
      //   199: istore #4
      //   201: iload #4
      //   203: iconst_m1
      //   204: if_icmpeq -> 215
      //   207: aload_0
      //   208: iload #4
      //   210: putfield resolvedLeftToLeft : I
      //   213: iconst_1
      //   214: istore_1
      //   215: aload_0
      //   216: getfield goneStartMargin : I
      //   219: istore #4
      //   221: iload #4
      //   223: iconst_m1
      //   224: if_icmpeq -> 233
      //   227: aload_0
      //   228: iload #4
      //   230: putfield resolveGoneRightMargin : I
      //   233: aload_0
      //   234: getfield goneEndMargin : I
      //   237: istore #4
      //   239: iload #4
      //   241: iconst_m1
      //   242: if_icmpeq -> 251
      //   245: aload_0
      //   246: iload #4
      //   248: putfield resolveGoneLeftMargin : I
      //   251: iload_1
      //   252: ifeq -> 262
      //   255: aload_0
      //   256: fconst_1
      //   257: fload_2
      //   258: fsub
      //   259: putfield resolvedHorizontalBias : F
      //   262: aload_0
      //   263: getfield isGuideline : Z
      //   266: ifeq -> 446
      //   269: aload_0
      //   270: getfield orientation : I
      //   273: iconst_1
      //   274: if_icmpne -> 446
      //   277: fload_3
      //   278: ldc -1.0
      //   280: fcmpl
      //   281: ifeq -> 304
      //   284: aload_0
      //   285: fconst_1
      //   286: fload_3
      //   287: fsub
      //   288: putfield resolvedGuidePercent : F
      //   291: aload_0
      //   292: iconst_m1
      //   293: putfield resolvedGuideBegin : I
      //   296: aload_0
      //   297: iconst_m1
      //   298: putfield resolvedGuideEnd : I
      //   301: goto -> 446
      //   304: iload #7
      //   306: iconst_m1
      //   307: if_icmpeq -> 330
      //   310: aload_0
      //   311: iload #7
      //   313: putfield resolvedGuideEnd : I
      //   316: aload_0
      //   317: iconst_m1
      //   318: putfield resolvedGuideBegin : I
      //   321: aload_0
      //   322: ldc -1.0
      //   324: putfield resolvedGuidePercent : F
      //   327: goto -> 446
      //   330: iload #8
      //   332: iconst_m1
      //   333: if_icmpeq -> 446
      //   336: aload_0
      //   337: iload #8
      //   339: putfield resolvedGuideBegin : I
      //   342: aload_0
      //   343: iconst_m1
      //   344: putfield resolvedGuideEnd : I
      //   347: aload_0
      //   348: ldc -1.0
      //   350: putfield resolvedGuidePercent : F
      //   353: goto -> 446
      //   356: aload_0
      //   357: getfield startToEnd : I
      //   360: istore_1
      //   361: iload_1
      //   362: iconst_m1
      //   363: if_icmpeq -> 371
      //   366: aload_0
      //   367: iload_1
      //   368: putfield resolvedLeftToRight : I
      //   371: aload_0
      //   372: getfield startToStart : I
      //   375: istore_1
      //   376: iload_1
      //   377: iconst_m1
      //   378: if_icmpeq -> 386
      //   381: aload_0
      //   382: iload_1
      //   383: putfield resolvedLeftToLeft : I
      //   386: aload_0
      //   387: getfield endToStart : I
      //   390: istore_1
      //   391: iload_1
      //   392: iconst_m1
      //   393: if_icmpeq -> 401
      //   396: aload_0
      //   397: iload_1
      //   398: putfield resolvedRightToLeft : I
      //   401: aload_0
      //   402: getfield endToEnd : I
      //   405: istore_1
      //   406: iload_1
      //   407: iconst_m1
      //   408: if_icmpeq -> 416
      //   411: aload_0
      //   412: iload_1
      //   413: putfield resolvedRightToRight : I
      //   416: aload_0
      //   417: getfield goneStartMargin : I
      //   420: istore_1
      //   421: iload_1
      //   422: iconst_m1
      //   423: if_icmpeq -> 431
      //   426: aload_0
      //   427: iload_1
      //   428: putfield resolveGoneLeftMargin : I
      //   431: aload_0
      //   432: getfield goneEndMargin : I
      //   435: istore_1
      //   436: iload_1
      //   437: iconst_m1
      //   438: if_icmpeq -> 446
      //   441: aload_0
      //   442: iload_1
      //   443: putfield resolveGoneRightMargin : I
      //   446: aload_0
      //   447: getfield endToStart : I
      //   450: iconst_m1
      //   451: if_icmpne -> 614
      //   454: aload_0
      //   455: getfield endToEnd : I
      //   458: iconst_m1
      //   459: if_icmpne -> 614
      //   462: aload_0
      //   463: getfield startToStart : I
      //   466: iconst_m1
      //   467: if_icmpne -> 614
      //   470: aload_0
      //   471: getfield startToEnd : I
      //   474: iconst_m1
      //   475: if_icmpne -> 614
      //   478: aload_0
      //   479: getfield rightToLeft : I
      //   482: istore_1
      //   483: iload_1
      //   484: iconst_m1
      //   485: if_icmpeq -> 514
      //   488: aload_0
      //   489: iload_1
      //   490: putfield resolvedRightToLeft : I
      //   493: aload_0
      //   494: getfield rightMargin : I
      //   497: ifgt -> 547
      //   500: iload #6
      //   502: ifle -> 547
      //   505: aload_0
      //   506: iload #6
      //   508: putfield rightMargin : I
      //   511: goto -> 547
      //   514: aload_0
      //   515: getfield rightToRight : I
      //   518: istore_1
      //   519: iload_1
      //   520: iconst_m1
      //   521: if_icmpeq -> 547
      //   524: aload_0
      //   525: iload_1
      //   526: putfield resolvedRightToRight : I
      //   529: aload_0
      //   530: getfield rightMargin : I
      //   533: ifgt -> 547
      //   536: iload #6
      //   538: ifle -> 547
      //   541: aload_0
      //   542: iload #6
      //   544: putfield rightMargin : I
      //   547: aload_0
      //   548: getfield leftToLeft : I
      //   551: istore_1
      //   552: iload_1
      //   553: iconst_m1
      //   554: if_icmpeq -> 581
      //   557: aload_0
      //   558: iload_1
      //   559: putfield resolvedLeftToLeft : I
      //   562: aload_0
      //   563: getfield leftMargin : I
      //   566: ifgt -> 614
      //   569: iload #5
      //   571: ifle -> 614
      //   574: aload_0
      //   575: iload #5
      //   577: putfield leftMargin : I
      //   580: return
      //   581: aload_0
      //   582: getfield leftToRight : I
      //   585: istore_1
      //   586: iload_1
      //   587: iconst_m1
      //   588: if_icmpeq -> 614
      //   591: aload_0
      //   592: iload_1
      //   593: putfield resolvedLeftToRight : I
      //   596: aload_0
      //   597: getfield leftMargin : I
      //   600: ifgt -> 614
      //   603: iload #5
      //   605: ifle -> 614
      //   608: aload_0
      //   609: iload #5
      //   611: putfield leftMargin : I
      //   614: return
    }
    
    public void setWidgetDebugName(String param1String) {
      this.widget.setDebugName(param1String);
    }
    
    public void validate() {
      this.isGuideline = false;
      this.horizontalDimensionFixed = true;
      this.verticalDimensionFixed = true;
      if (this.width == -2 && this.constrainedWidth) {
        this.horizontalDimensionFixed = false;
        if (this.matchConstraintDefaultWidth == 0)
          this.matchConstraintDefaultWidth = 1; 
      } 
      if (this.height == -2 && this.constrainedHeight) {
        this.verticalDimensionFixed = false;
        if (this.matchConstraintDefaultHeight == 0)
          this.matchConstraintDefaultHeight = 1; 
      } 
      if (this.width == 0 || this.width == -1) {
        this.horizontalDimensionFixed = false;
        if (this.width == 0 && this.matchConstraintDefaultWidth == 1) {
          this.width = -2;
          this.constrainedWidth = true;
        } 
      } 
      if (this.height == 0 || this.height == -1) {
        this.verticalDimensionFixed = false;
        if (this.height == 0 && this.matchConstraintDefaultHeight == 1) {
          this.height = -2;
          this.constrainedHeight = true;
        } 
      } 
      if (this.guidePercent != -1.0F || this.guideBegin != -1 || this.guideEnd != -1) {
        this.isGuideline = true;
        this.horizontalDimensionFixed = true;
        this.verticalDimensionFixed = true;
        if (!(this.widget instanceof Guideline))
          this.widget = (ConstraintWidget)new Guideline(); 
        ((Guideline)this.widget).setOrientation(this.orientation);
      } 
    }
    
    private static class Table {
      public static final int ANDROID_ORIENTATION = 1;
      
      public static final int LAYOUT_CONSTRAINED_HEIGHT = 28;
      
      public static final int LAYOUT_CONSTRAINED_WIDTH = 27;
      
      public static final int LAYOUT_CONSTRAINT_BASELINE_CREATOR = 43;
      
      public static final int LAYOUT_CONSTRAINT_BASELINE_TO_BASELINE_OF = 16;
      
      public static final int LAYOUT_CONSTRAINT_BOTTOM_CREATOR = 42;
      
      public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_BOTTOM_OF = 15;
      
      public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_TOP_OF = 14;
      
      public static final int LAYOUT_CONSTRAINT_CIRCLE = 2;
      
      public static final int LAYOUT_CONSTRAINT_CIRCLE_ANGLE = 4;
      
      public static final int LAYOUT_CONSTRAINT_CIRCLE_RADIUS = 3;
      
      public static final int LAYOUT_CONSTRAINT_DIMENSION_RATIO = 44;
      
      public static final int LAYOUT_CONSTRAINT_END_TO_END_OF = 20;
      
      public static final int LAYOUT_CONSTRAINT_END_TO_START_OF = 19;
      
      public static final int LAYOUT_CONSTRAINT_GUIDE_BEGIN = 5;
      
      public static final int LAYOUT_CONSTRAINT_GUIDE_END = 6;
      
      public static final int LAYOUT_CONSTRAINT_GUIDE_PERCENT = 7;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_DEFAULT = 32;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_MAX = 37;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_MIN = 36;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_PERCENT = 38;
      
      public static final int LAYOUT_CONSTRAINT_HORIZONTAL_BIAS = 29;
      
      public static final int LAYOUT_CONSTRAINT_HORIZONTAL_CHAINSTYLE = 47;
      
      public static final int LAYOUT_CONSTRAINT_HORIZONTAL_WEIGHT = 45;
      
      public static final int LAYOUT_CONSTRAINT_LEFT_CREATOR = 39;
      
      public static final int LAYOUT_CONSTRAINT_LEFT_TO_LEFT_OF = 8;
      
      public static final int LAYOUT_CONSTRAINT_LEFT_TO_RIGHT_OF = 9;
      
      public static final int LAYOUT_CONSTRAINT_RIGHT_CREATOR = 41;
      
      public static final int LAYOUT_CONSTRAINT_RIGHT_TO_LEFT_OF = 10;
      
      public static final int LAYOUT_CONSTRAINT_RIGHT_TO_RIGHT_OF = 11;
      
      public static final int LAYOUT_CONSTRAINT_START_TO_END_OF = 17;
      
      public static final int LAYOUT_CONSTRAINT_START_TO_START_OF = 18;
      
      public static final int LAYOUT_CONSTRAINT_TAG = 51;
      
      public static final int LAYOUT_CONSTRAINT_TOP_CREATOR = 40;
      
      public static final int LAYOUT_CONSTRAINT_TOP_TO_BOTTOM_OF = 13;
      
      public static final int LAYOUT_CONSTRAINT_TOP_TO_TOP_OF = 12;
      
      public static final int LAYOUT_CONSTRAINT_VERTICAL_BIAS = 30;
      
      public static final int LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE = 48;
      
      public static final int LAYOUT_CONSTRAINT_VERTICAL_WEIGHT = 46;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_DEFAULT = 31;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_MAX = 34;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_MIN = 33;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_PERCENT = 35;
      
      public static final int LAYOUT_EDITOR_ABSOLUTEX = 49;
      
      public static final int LAYOUT_EDITOR_ABSOLUTEY = 50;
      
      public static final int LAYOUT_GONE_MARGIN_BOTTOM = 24;
      
      public static final int LAYOUT_GONE_MARGIN_END = 26;
      
      public static final int LAYOUT_GONE_MARGIN_LEFT = 21;
      
      public static final int LAYOUT_GONE_MARGIN_RIGHT = 23;
      
      public static final int LAYOUT_GONE_MARGIN_START = 25;
      
      public static final int LAYOUT_GONE_MARGIN_TOP = 22;
      
      public static final int UNUSED = 0;
      
      public static final SparseIntArray map;
      
      static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        map = sparseIntArray;
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircle, 2);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_android_orientation, 1);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginTop, 22);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginRight, 23);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginStart, 25);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constrainedWidth, 27);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constrainedHeight, 28);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintTag, 51);
      }
    }
  }
  
  private static class Table {
    public static final int ANDROID_ORIENTATION = 1;
    
    public static final int LAYOUT_CONSTRAINED_HEIGHT = 28;
    
    public static final int LAYOUT_CONSTRAINED_WIDTH = 27;
    
    public static final int LAYOUT_CONSTRAINT_BASELINE_CREATOR = 43;
    
    public static final int LAYOUT_CONSTRAINT_BASELINE_TO_BASELINE_OF = 16;
    
    public static final int LAYOUT_CONSTRAINT_BOTTOM_CREATOR = 42;
    
    public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_BOTTOM_OF = 15;
    
    public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_TOP_OF = 14;
    
    public static final int LAYOUT_CONSTRAINT_CIRCLE = 2;
    
    public static final int LAYOUT_CONSTRAINT_CIRCLE_ANGLE = 4;
    
    public static final int LAYOUT_CONSTRAINT_CIRCLE_RADIUS = 3;
    
    public static final int LAYOUT_CONSTRAINT_DIMENSION_RATIO = 44;
    
    public static final int LAYOUT_CONSTRAINT_END_TO_END_OF = 20;
    
    public static final int LAYOUT_CONSTRAINT_END_TO_START_OF = 19;
    
    public static final int LAYOUT_CONSTRAINT_GUIDE_BEGIN = 5;
    
    public static final int LAYOUT_CONSTRAINT_GUIDE_END = 6;
    
    public static final int LAYOUT_CONSTRAINT_GUIDE_PERCENT = 7;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_DEFAULT = 32;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_MAX = 37;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_MIN = 36;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_PERCENT = 38;
    
    public static final int LAYOUT_CONSTRAINT_HORIZONTAL_BIAS = 29;
    
    public static final int LAYOUT_CONSTRAINT_HORIZONTAL_CHAINSTYLE = 47;
    
    public static final int LAYOUT_CONSTRAINT_HORIZONTAL_WEIGHT = 45;
    
    public static final int LAYOUT_CONSTRAINT_LEFT_CREATOR = 39;
    
    public static final int LAYOUT_CONSTRAINT_LEFT_TO_LEFT_OF = 8;
    
    public static final int LAYOUT_CONSTRAINT_LEFT_TO_RIGHT_OF = 9;
    
    public static final int LAYOUT_CONSTRAINT_RIGHT_CREATOR = 41;
    
    public static final int LAYOUT_CONSTRAINT_RIGHT_TO_LEFT_OF = 10;
    
    public static final int LAYOUT_CONSTRAINT_RIGHT_TO_RIGHT_OF = 11;
    
    public static final int LAYOUT_CONSTRAINT_START_TO_END_OF = 17;
    
    public static final int LAYOUT_CONSTRAINT_START_TO_START_OF = 18;
    
    public static final int LAYOUT_CONSTRAINT_TAG = 51;
    
    public static final int LAYOUT_CONSTRAINT_TOP_CREATOR = 40;
    
    public static final int LAYOUT_CONSTRAINT_TOP_TO_BOTTOM_OF = 13;
    
    public static final int LAYOUT_CONSTRAINT_TOP_TO_TOP_OF = 12;
    
    public static final int LAYOUT_CONSTRAINT_VERTICAL_BIAS = 30;
    
    public static final int LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE = 48;
    
    public static final int LAYOUT_CONSTRAINT_VERTICAL_WEIGHT = 46;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_DEFAULT = 31;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_MAX = 34;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_MIN = 33;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_PERCENT = 35;
    
    public static final int LAYOUT_EDITOR_ABSOLUTEX = 49;
    
    public static final int LAYOUT_EDITOR_ABSOLUTEY = 50;
    
    public static final int LAYOUT_GONE_MARGIN_BOTTOM = 24;
    
    public static final int LAYOUT_GONE_MARGIN_END = 26;
    
    public static final int LAYOUT_GONE_MARGIN_LEFT = 21;
    
    public static final int LAYOUT_GONE_MARGIN_RIGHT = 23;
    
    public static final int LAYOUT_GONE_MARGIN_START = 25;
    
    public static final int LAYOUT_GONE_MARGIN_TOP = 22;
    
    public static final int UNUSED = 0;
    
    public static final SparseIntArray map;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      map = sparseIntArray;
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircle, 2);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_android_orientation, 1);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginTop, 22);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginRight, 23);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginStart, 25);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constrainedWidth, 27);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constrainedHeight, 28);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintTag, 51);
    }
  }
  
  class Measurer implements BasicMeasure.Measurer {
    ConstraintLayout layout;
    
    int layoutHeightSpec;
    
    int layoutWidthSpec;
    
    int paddingBottom;
    
    int paddingHeight;
    
    int paddingTop;
    
    int paddingWidth;
    
    public Measurer(ConstraintLayout param1ConstraintLayout1) {
      this.layout = param1ConstraintLayout1;
    }
    
    public void captureLayoutInfos(int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
      this.paddingTop = param1Int3;
      this.paddingBottom = param1Int4;
      this.paddingWidth = param1Int5;
      this.paddingHeight = param1Int6;
      this.layoutWidthSpec = param1Int1;
      this.layoutHeightSpec = param1Int2;
    }
    
    public final void didMeasures() {
      int j = this.layout.getChildCount();
      boolean bool = false;
      int i;
      for (i = 0; i < j; i++) {
        View view = this.layout.getChildAt(i);
        if (view instanceof Placeholder)
          ((Placeholder)view).updatePostMeasure(this.layout); 
      } 
      j = this.layout.mConstraintHelpers.size();
      if (j > 0)
        for (i = bool; i < j; i++)
          ((ConstraintHelper)this.layout.mConstraintHelpers.get(i)).updatePostMeasure(this.layout);  
    }
    
    public final void measure(ConstraintWidget param1ConstraintWidget, BasicMeasure.Measure param1Measure) {
      // Byte code:
      //   0: aload_1
      //   1: ifnonnull -> 5
      //   4: return
      //   5: aload_1
      //   6: invokevirtual getVisibility : ()I
      //   9: bipush #8
      //   11: if_icmpne -> 37
      //   14: aload_1
      //   15: invokevirtual isInPlaceholder : ()Z
      //   18: ifne -> 37
      //   21: aload_2
      //   22: iconst_0
      //   23: putfield measuredWidth : I
      //   26: aload_2
      //   27: iconst_0
      //   28: putfield measuredHeight : I
      //   31: aload_2
      //   32: iconst_0
      //   33: putfield measuredBaseline : I
      //   36: return
      //   37: aload_2
      //   38: getfield horizontalBehavior : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   41: astore #19
      //   43: aload_2
      //   44: getfield verticalBehavior : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   47: astore #20
      //   49: aload_2
      //   50: getfield horizontalDimension : I
      //   53: istore #5
      //   55: aload_2
      //   56: getfield verticalDimension : I
      //   59: istore #8
      //   61: aload_0
      //   62: getfield paddingTop : I
      //   65: aload_0
      //   66: getfield paddingBottom : I
      //   69: iadd
      //   70: istore #9
      //   72: aload_0
      //   73: getfield paddingWidth : I
      //   76: istore #4
      //   78: aload_1
      //   79: invokevirtual getCompanionWidget : ()Ljava/lang/Object;
      //   82: checkcast android/view/View
      //   85: astore #18
      //   87: getstatic androidx/constraintlayout/widget/ConstraintLayout$1.$SwitchMap$androidx$constraintlayout$solver$widgets$ConstraintWidget$DimensionBehaviour : [I
      //   90: aload #19
      //   92: invokevirtual ordinal : ()I
      //   95: iaload
      //   96: istore #6
      //   98: iload #6
      //   100: iconst_1
      //   101: if_icmpeq -> 309
      //   104: iload #6
      //   106: iconst_2
      //   107: if_icmpeq -> 282
      //   110: iload #6
      //   112: iconst_3
      //   113: if_icmpeq -> 255
      //   116: iload #6
      //   118: iconst_4
      //   119: if_icmpeq -> 135
      //   122: iconst_0
      //   123: istore #4
      //   125: iconst_0
      //   126: istore #7
      //   128: iload #4
      //   130: istore #5
      //   132: goto -> 329
      //   135: aload_0
      //   136: getfield layoutWidthSpec : I
      //   139: iload #4
      //   141: bipush #-2
      //   143: invokestatic getChildMeasureSpec : (III)I
      //   146: istore #7
      //   148: aload_1
      //   149: getfield mMatchConstraintDefaultWidth : I
      //   152: iconst_1
      //   153: if_icmpne -> 162
      //   156: iconst_1
      //   157: istore #4
      //   159: goto -> 165
      //   162: iconst_0
      //   163: istore #4
      //   165: aload_1
      //   166: getfield wrapMeasure : [I
      //   169: iconst_2
      //   170: iconst_0
      //   171: iastore
      //   172: iload #7
      //   174: istore #5
      //   176: aload_2
      //   177: getfield useCurrentDimensions : Z
      //   180: ifeq -> 303
      //   183: iload #4
      //   185: ifeq -> 210
      //   188: aload_1
      //   189: getfield wrapMeasure : [I
      //   192: iconst_3
      //   193: iaload
      //   194: ifeq -> 210
      //   197: aload_1
      //   198: getfield wrapMeasure : [I
      //   201: iconst_0
      //   202: iaload
      //   203: aload_1
      //   204: invokevirtual getWidth : ()I
      //   207: if_icmpne -> 218
      //   210: aload #18
      //   212: instanceof androidx/constraintlayout/widget/Placeholder
      //   215: ifeq -> 224
      //   218: iconst_1
      //   219: istore #6
      //   221: goto -> 227
      //   224: iconst_0
      //   225: istore #6
      //   227: iload #4
      //   229: ifeq -> 241
      //   232: iload #7
      //   234: istore #5
      //   236: iload #6
      //   238: ifeq -> 303
      //   241: aload_1
      //   242: invokevirtual getWidth : ()I
      //   245: ldc 1073741824
      //   247: invokestatic makeMeasureSpec : (II)I
      //   250: istore #4
      //   252: goto -> 125
      //   255: aload_0
      //   256: getfield layoutWidthSpec : I
      //   259: iload #4
      //   261: aload_1
      //   262: invokevirtual getHorizontalMargin : ()I
      //   265: iadd
      //   266: iconst_m1
      //   267: invokestatic getChildMeasureSpec : (III)I
      //   270: istore #4
      //   272: aload_1
      //   273: getfield wrapMeasure : [I
      //   276: iconst_2
      //   277: iconst_m1
      //   278: iastore
      //   279: goto -> 125
      //   282: aload_0
      //   283: getfield layoutWidthSpec : I
      //   286: iload #4
      //   288: bipush #-2
      //   290: invokestatic getChildMeasureSpec : (III)I
      //   293: istore #5
      //   295: aload_1
      //   296: getfield wrapMeasure : [I
      //   299: iconst_2
      //   300: bipush #-2
      //   302: iastore
      //   303: iconst_1
      //   304: istore #7
      //   306: goto -> 329
      //   309: iload #5
      //   311: ldc 1073741824
      //   313: invokestatic makeMeasureSpec : (II)I
      //   316: istore #4
      //   318: aload_1
      //   319: getfield wrapMeasure : [I
      //   322: iconst_2
      //   323: iload #5
      //   325: iastore
      //   326: goto -> 125
      //   329: getstatic androidx/constraintlayout/widget/ConstraintLayout$1.$SwitchMap$androidx$constraintlayout$solver$widgets$ConstraintWidget$DimensionBehaviour : [I
      //   332: aload #20
      //   334: invokevirtual ordinal : ()I
      //   337: iaload
      //   338: istore #4
      //   340: iload #4
      //   342: iconst_1
      //   343: if_icmpeq -> 547
      //   346: iload #4
      //   348: iconst_2
      //   349: if_icmpeq -> 520
      //   352: iload #4
      //   354: iconst_3
      //   355: if_icmpeq -> 493
      //   358: iload #4
      //   360: iconst_4
      //   361: if_icmpeq -> 373
      //   364: iconst_0
      //   365: istore #6
      //   367: iconst_0
      //   368: istore #4
      //   370: goto -> 567
      //   373: aload_0
      //   374: getfield layoutHeightSpec : I
      //   377: iload #9
      //   379: bipush #-2
      //   381: invokestatic getChildMeasureSpec : (III)I
      //   384: istore #9
      //   386: aload_1
      //   387: getfield mMatchConstraintDefaultHeight : I
      //   390: iconst_1
      //   391: if_icmpne -> 400
      //   394: iconst_1
      //   395: istore #6
      //   397: goto -> 403
      //   400: iconst_0
      //   401: istore #6
      //   403: aload_1
      //   404: getfield wrapMeasure : [I
      //   407: iconst_3
      //   408: iconst_0
      //   409: iastore
      //   410: iload #9
      //   412: istore #4
      //   414: aload_2
      //   415: getfield useCurrentDimensions : Z
      //   418: ifeq -> 541
      //   421: iload #6
      //   423: ifeq -> 448
      //   426: aload_1
      //   427: getfield wrapMeasure : [I
      //   430: iconst_2
      //   431: iaload
      //   432: ifeq -> 448
      //   435: aload_1
      //   436: getfield wrapMeasure : [I
      //   439: iconst_1
      //   440: iaload
      //   441: aload_1
      //   442: invokevirtual getHeight : ()I
      //   445: if_icmpne -> 456
      //   448: aload #18
      //   450: instanceof androidx/constraintlayout/widget/Placeholder
      //   453: ifeq -> 462
      //   456: iconst_1
      //   457: istore #8
      //   459: goto -> 465
      //   462: iconst_0
      //   463: istore #8
      //   465: iload #6
      //   467: ifeq -> 479
      //   470: iload #9
      //   472: istore #4
      //   474: iload #8
      //   476: ifeq -> 541
      //   479: aload_1
      //   480: invokevirtual getHeight : ()I
      //   483: ldc 1073741824
      //   485: invokestatic makeMeasureSpec : (II)I
      //   488: istore #4
      //   490: goto -> 517
      //   493: aload_0
      //   494: getfield layoutHeightSpec : I
      //   497: iload #9
      //   499: aload_1
      //   500: invokevirtual getVerticalMargin : ()I
      //   503: iadd
      //   504: iconst_m1
      //   505: invokestatic getChildMeasureSpec : (III)I
      //   508: istore #4
      //   510: aload_1
      //   511: getfield wrapMeasure : [I
      //   514: iconst_3
      //   515: iconst_m1
      //   516: iastore
      //   517: goto -> 564
      //   520: aload_0
      //   521: getfield layoutHeightSpec : I
      //   524: iload #9
      //   526: bipush #-2
      //   528: invokestatic getChildMeasureSpec : (III)I
      //   531: istore #4
      //   533: aload_1
      //   534: getfield wrapMeasure : [I
      //   537: iconst_3
      //   538: bipush #-2
      //   540: iastore
      //   541: iconst_1
      //   542: istore #6
      //   544: goto -> 567
      //   547: iload #8
      //   549: ldc 1073741824
      //   551: invokestatic makeMeasureSpec : (II)I
      //   554: istore #4
      //   556: aload_1
      //   557: getfield wrapMeasure : [I
      //   560: iconst_3
      //   561: iload #8
      //   563: iastore
      //   564: iconst_0
      //   565: istore #6
      //   567: aload #19
      //   569: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   572: if_acmpne -> 581
      //   575: iconst_1
      //   576: istore #8
      //   578: goto -> 584
      //   581: iconst_0
      //   582: istore #8
      //   584: aload #20
      //   586: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   589: if_acmpne -> 598
      //   592: iconst_1
      //   593: istore #13
      //   595: goto -> 601
      //   598: iconst_0
      //   599: istore #13
      //   601: aload #20
      //   603: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   606: if_acmpeq -> 626
      //   609: aload #20
      //   611: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   614: if_acmpne -> 620
      //   617: goto -> 626
      //   620: iconst_0
      //   621: istore #9
      //   623: goto -> 629
      //   626: iconst_1
      //   627: istore #9
      //   629: aload #19
      //   631: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   634: if_acmpeq -> 654
      //   637: aload #19
      //   639: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   642: if_acmpne -> 648
      //   645: goto -> 654
      //   648: iconst_0
      //   649: istore #10
      //   651: goto -> 657
      //   654: iconst_1
      //   655: istore #10
      //   657: iload #8
      //   659: ifeq -> 677
      //   662: aload_1
      //   663: getfield mDimensionRatio : F
      //   666: fconst_0
      //   667: fcmpl
      //   668: ifle -> 677
      //   671: iconst_1
      //   672: istore #11
      //   674: goto -> 680
      //   677: iconst_0
      //   678: istore #11
      //   680: iload #13
      //   682: ifeq -> 700
      //   685: aload_1
      //   686: getfield mDimensionRatio : F
      //   689: fconst_0
      //   690: fcmpl
      //   691: ifle -> 700
      //   694: iconst_1
      //   695: istore #12
      //   697: goto -> 703
      //   700: iconst_0
      //   701: istore #12
      //   703: aload #18
      //   705: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
      //   708: checkcast androidx/constraintlayout/widget/ConstraintLayout$LayoutParams
      //   711: astore #19
      //   713: aload_2
      //   714: getfield useCurrentDimensions : Z
      //   717: ifne -> 759
      //   720: iload #8
      //   722: ifeq -> 759
      //   725: aload_1
      //   726: getfield mMatchConstraintDefaultWidth : I
      //   729: ifne -> 759
      //   732: iload #13
      //   734: ifeq -> 759
      //   737: aload_1
      //   738: getfield mMatchConstraintDefaultHeight : I
      //   741: ifeq -> 747
      //   744: goto -> 759
      //   747: iconst_0
      //   748: istore #6
      //   750: iconst_0
      //   751: istore #5
      //   753: iconst_0
      //   754: istore #4
      //   756: goto -> 1173
      //   759: aload #18
      //   761: instanceof androidx/constraintlayout/widget/VirtualLayout
      //   764: ifeq -> 797
      //   767: aload_1
      //   768: instanceof androidx/constraintlayout/solver/widgets/VirtualLayout
      //   771: ifeq -> 797
      //   774: aload_1
      //   775: checkcast androidx/constraintlayout/solver/widgets/VirtualLayout
      //   778: astore #20
      //   780: aload #18
      //   782: checkcast androidx/constraintlayout/widget/VirtualLayout
      //   785: aload #20
      //   787: iload #5
      //   789: iload #4
      //   791: invokevirtual onMeasure : (Landroidx/constraintlayout/solver/widgets/VirtualLayout;II)V
      //   794: goto -> 806
      //   797: aload #18
      //   799: iload #5
      //   801: iload #4
      //   803: invokevirtual measure : (II)V
      //   806: aload #18
      //   808: invokevirtual getMeasuredWidth : ()I
      //   811: istore #15
      //   813: aload #18
      //   815: invokevirtual getMeasuredHeight : ()I
      //   818: istore #13
      //   820: aload #18
      //   822: invokevirtual getBaseline : ()I
      //   825: istore #14
      //   827: iload #7
      //   829: ifeq -> 851
      //   832: aload_1
      //   833: getfield wrapMeasure : [I
      //   836: iconst_0
      //   837: iload #15
      //   839: iastore
      //   840: aload_1
      //   841: getfield wrapMeasure : [I
      //   844: iconst_2
      //   845: iload #13
      //   847: iastore
      //   848: goto -> 865
      //   851: aload_1
      //   852: getfield wrapMeasure : [I
      //   855: iconst_0
      //   856: iconst_0
      //   857: iastore
      //   858: aload_1
      //   859: getfield wrapMeasure : [I
      //   862: iconst_2
      //   863: iconst_0
      //   864: iastore
      //   865: iload #6
      //   867: ifeq -> 889
      //   870: aload_1
      //   871: getfield wrapMeasure : [I
      //   874: iconst_1
      //   875: iload #13
      //   877: iastore
      //   878: aload_1
      //   879: getfield wrapMeasure : [I
      //   882: iconst_3
      //   883: iload #15
      //   885: iastore
      //   886: goto -> 903
      //   889: aload_1
      //   890: getfield wrapMeasure : [I
      //   893: iconst_1
      //   894: iconst_0
      //   895: iastore
      //   896: aload_1
      //   897: getfield wrapMeasure : [I
      //   900: iconst_3
      //   901: iconst_0
      //   902: iastore
      //   903: aload_1
      //   904: getfield mMatchConstraintMinWidth : I
      //   907: ifle -> 924
      //   910: aload_1
      //   911: getfield mMatchConstraintMinWidth : I
      //   914: iload #15
      //   916: invokestatic max : (II)I
      //   919: istore #7
      //   921: goto -> 928
      //   924: iload #15
      //   926: istore #7
      //   928: iload #7
      //   930: istore #6
      //   932: aload_1
      //   933: getfield mMatchConstraintMaxWidth : I
      //   936: ifle -> 950
      //   939: aload_1
      //   940: getfield mMatchConstraintMaxWidth : I
      //   943: iload #7
      //   945: invokestatic min : (II)I
      //   948: istore #6
      //   950: aload_1
      //   951: getfield mMatchConstraintMinHeight : I
      //   954: ifle -> 971
      //   957: aload_1
      //   958: getfield mMatchConstraintMinHeight : I
      //   961: iload #13
      //   963: invokestatic max : (II)I
      //   966: istore #8
      //   968: goto -> 975
      //   971: iload #13
      //   973: istore #8
      //   975: iload #8
      //   977: istore #7
      //   979: aload_1
      //   980: getfield mMatchConstraintMaxHeight : I
      //   983: ifle -> 997
      //   986: aload_1
      //   987: getfield mMatchConstraintMaxHeight : I
      //   990: iload #8
      //   992: invokestatic min : (II)I
      //   995: istore #7
      //   997: iload #11
      //   999: ifeq -> 1030
      //   1002: iload #9
      //   1004: ifeq -> 1030
      //   1007: aload_1
      //   1008: getfield mDimensionRatio : F
      //   1011: fstore_3
      //   1012: iload #7
      //   1014: i2f
      //   1015: fload_3
      //   1016: fmul
      //   1017: ldc 0.5
      //   1019: fadd
      //   1020: f2i
      //   1021: istore #9
      //   1023: iload #7
      //   1025: istore #8
      //   1027: goto -> 1076
      //   1030: iload #6
      //   1032: istore #9
      //   1034: iload #7
      //   1036: istore #8
      //   1038: iload #12
      //   1040: ifeq -> 1076
      //   1043: iload #6
      //   1045: istore #9
      //   1047: iload #7
      //   1049: istore #8
      //   1051: iload #10
      //   1053: ifeq -> 1076
      //   1056: aload_1
      //   1057: getfield mDimensionRatio : F
      //   1060: fstore_3
      //   1061: iload #6
      //   1063: i2f
      //   1064: fload_3
      //   1065: fdiv
      //   1066: ldc 0.5
      //   1068: fadd
      //   1069: f2i
      //   1070: istore #8
      //   1072: iload #6
      //   1074: istore #9
      //   1076: iload #15
      //   1078: iload #9
      //   1080: if_icmpne -> 1108
      //   1083: iload #13
      //   1085: iload #8
      //   1087: if_icmpeq -> 1093
      //   1090: goto -> 1108
      //   1093: iload #9
      //   1095: istore #6
      //   1097: iload #8
      //   1099: istore #5
      //   1101: iload #14
      //   1103: istore #4
      //   1105: goto -> 1173
      //   1108: iload #15
      //   1110: iload #9
      //   1112: if_icmpeq -> 1124
      //   1115: iload #9
      //   1117: ldc 1073741824
      //   1119: invokestatic makeMeasureSpec : (II)I
      //   1122: istore #5
      //   1124: iload #13
      //   1126: iload #8
      //   1128: if_icmpeq -> 1140
      //   1131: iload #8
      //   1133: ldc 1073741824
      //   1135: invokestatic makeMeasureSpec : (II)I
      //   1138: istore #4
      //   1140: aload #18
      //   1142: iload #5
      //   1144: iload #4
      //   1146: invokevirtual measure : (II)V
      //   1149: aload #18
      //   1151: invokevirtual getMeasuredWidth : ()I
      //   1154: istore #6
      //   1156: aload #18
      //   1158: invokevirtual getMeasuredHeight : ()I
      //   1161: istore #5
      //   1163: aload #18
      //   1165: invokevirtual getBaseline : ()I
      //   1168: istore #4
      //   1170: goto -> 1105
      //   1173: iload #4
      //   1175: iconst_m1
      //   1176: if_icmpeq -> 1185
      //   1179: iconst_1
      //   1180: istore #16
      //   1182: goto -> 1188
      //   1185: iconst_0
      //   1186: istore #16
      //   1188: iload #6
      //   1190: aload_2
      //   1191: getfield horizontalDimension : I
      //   1194: if_icmpne -> 1215
      //   1197: iload #5
      //   1199: aload_2
      //   1200: getfield verticalDimension : I
      //   1203: if_icmpeq -> 1209
      //   1206: goto -> 1215
      //   1209: iconst_0
      //   1210: istore #17
      //   1212: goto -> 1218
      //   1215: iconst_1
      //   1216: istore #17
      //   1218: aload_2
      //   1219: iload #17
      //   1221: putfield measuredNeedsSolverPass : Z
      //   1224: aload #19
      //   1226: getfield needsBaseline : Z
      //   1229: ifeq -> 1238
      //   1232: iconst_1
      //   1233: istore #16
      //   1235: goto -> 1238
      //   1238: iload #16
      //   1240: ifeq -> 1263
      //   1243: iload #4
      //   1245: iconst_m1
      //   1246: if_icmpeq -> 1263
      //   1249: aload_1
      //   1250: invokevirtual getBaselineDistance : ()I
      //   1253: iload #4
      //   1255: if_icmpeq -> 1263
      //   1258: aload_2
      //   1259: iconst_1
      //   1260: putfield measuredNeedsSolverPass : Z
      //   1263: aload_2
      //   1264: iload #6
      //   1266: putfield measuredWidth : I
      //   1269: aload_2
      //   1270: iload #5
      //   1272: putfield measuredHeight : I
      //   1275: aload_2
      //   1276: iload #16
      //   1278: putfield measuredHasBaseline : Z
      //   1281: aload_2
      //   1282: iload #4
      //   1284: putfield measuredBaseline : I
      //   1287: return
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\constraintlayout\widget\ConstraintLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */