package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.util.AttributeSet;
import androidx.constraintlayout.widget.ConstraintAttribute;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.util.HashMap;
import java.util.HashSet;

public abstract class Key {
  static final String ALPHA = v416f9e89.xbd520268("2141");
  
  static final String CUSTOM = v416f9e89.xbd520268("2142");
  
  static final String ELEVATION = v416f9e89.xbd520268("2143");
  
  static final String PIVOT_X = v416f9e89.xbd520268("2144");
  
  static final String PIVOT_Y = v416f9e89.xbd520268("2145");
  
  static final String PROGRESS = v416f9e89.xbd520268("2146");
  
  static final String ROTATION = v416f9e89.xbd520268("2147");
  
  static final String ROTATION_X = v416f9e89.xbd520268("2148");
  
  static final String ROTATION_Y = v416f9e89.xbd520268("2149");
  
  static final String SCALE_X = v416f9e89.xbd520268("2150");
  
  static final String SCALE_Y = v416f9e89.xbd520268("2151");
  
  static final String TRANSITION_PATH_ROTATE = v416f9e89.xbd520268("2152");
  
  static final String TRANSLATION_X = v416f9e89.xbd520268("2153");
  
  static final String TRANSLATION_Y = v416f9e89.xbd520268("2154");
  
  static final String TRANSLATION_Z = v416f9e89.xbd520268("2155");
  
  public static int UNSET = -1;
  
  static final String WAVE_OFFSET = v416f9e89.xbd520268("2156");
  
  static final String WAVE_PERIOD = v416f9e89.xbd520268("2157");
  
  static final String WAVE_VARIES_BY = v416f9e89.xbd520268("2158");
  
  HashMap<String, ConstraintAttribute> mCustomConstraints;
  
  int mFramePosition;
  
  int mTargetId;
  
  String mTargetString;
  
  protected int mType;
  
  public Key() {
    int i = UNSET;
    this.mFramePosition = i;
    this.mTargetId = i;
    this.mTargetString = null;
  }
  
  public abstract void addValues(HashMap<String, SplineSet> paramHashMap);
  
  abstract void getAttributeNames(HashSet<String> paramHashSet);
  
  abstract void load(Context paramContext, AttributeSet paramAttributeSet);
  
  boolean matches(String paramString) {
    String str = this.mTargetString;
    return (str == null || paramString == null) ? false : paramString.matches(str);
  }
  
  public void setInterpolation(HashMap<String, Integer> paramHashMap) {}
  
  public abstract void setValue(String paramString, Object paramObject);
  
  boolean toBoolean(Object paramObject) {
    return (paramObject instanceof Boolean) ? ((Boolean)paramObject).booleanValue() : Boolean.parseBoolean(paramObject.toString());
  }
  
  float toFloat(Object paramObject) {
    return (paramObject instanceof Float) ? ((Float)paramObject).floatValue() : Float.parseFloat(paramObject.toString());
  }
  
  int toInt(Object paramObject) {
    return (paramObject instanceof Integer) ? ((Integer)paramObject).intValue() : Integer.parseInt(paramObject.toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\constraintlayout\motion\widget\Key.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */