package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.Resources;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.io.PrintStream;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

public class Debug {
  public static void dumpLayoutParams(ViewGroup.LayoutParams paramLayoutParams, String paramString) {
    StackTraceElement stackTraceElement = (new Throwable()).getStackTrace()[1];
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(v416f9e89.xbd520268("2017"));
    stringBuilder1.append(stackTraceElement.getFileName());
    stringBuilder1.append(v416f9e89.xbd520268("2018"));
    stringBuilder1.append(stackTraceElement.getLineNumber());
    stringBuilder1.append(v416f9e89.xbd520268("2019"));
    stringBuilder1.append(paramString);
    String str = v416f9e89.xbd520268("2020");
    stringBuilder1.append(str);
    paramString = stringBuilder1.toString();
    PrintStream printStream = System.out;
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(v416f9e89.xbd520268("2021"));
    stringBuilder2.append(paramString);
    stringBuilder2.append(str);
    stringBuilder2.append(paramLayoutParams.getClass().getName());
    printStream.println(stringBuilder2.toString());
    Field[] arrayOfField = paramLayoutParams.getClass().getFields();
    int i = 0;
    while (true) {
      if (i < arrayOfField.length) {
        Field field = arrayOfField[i];
        try {
          Object object = field.get(paramLayoutParams);
          String str1 = field.getName();
          if (str1.contains(v416f9e89.xbd520268("2022")) && !object.toString().equals(v416f9e89.xbd520268("2023"))) {
            PrintStream printStream2 = System.out;
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(paramString);
            stringBuilder3.append(v416f9e89.xbd520268("2024"));
            stringBuilder3.append(str1);
            stringBuilder3.append(v416f9e89.xbd520268("2025"));
            stringBuilder3.append(object);
            printStream2.println(stringBuilder3.toString());
          } 
        } catch (IllegalAccessException illegalAccessException) {}
        i++;
        continue;
      } 
      PrintStream printStream1 = System.out;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("2026"));
      stringBuilder.append(paramString);
      printStream1.println(stringBuilder.toString());
      return;
    } 
  }
  
  public static void dumpLayoutParams(ViewGroup paramViewGroup, String paramString) {
    StackTraceElement stackTraceElement = (new Throwable()).getStackTrace()[1];
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(v416f9e89.xbd520268("2027"));
    stringBuilder1.append(stackTraceElement.getFileName());
    stringBuilder1.append(v416f9e89.xbd520268("2028"));
    stringBuilder1.append(stackTraceElement.getLineNumber());
    stringBuilder1.append(v416f9e89.xbd520268("2029"));
    stringBuilder1.append(paramString);
    stringBuilder1.append(v416f9e89.xbd520268("2030"));
    String str = stringBuilder1.toString();
    int j = paramViewGroup.getChildCount();
    PrintStream printStream = System.out;
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append(v416f9e89.xbd520268("2031"));
    stringBuilder2.append(j);
    printStream.println(stringBuilder2.toString());
    int i = 0;
    label22: while (true) {
      if (i < j) {
        View view = paramViewGroup.getChildAt(i);
        printStream = System.out;
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append(str);
        stringBuilder2.append(v416f9e89.xbd520268("2032"));
        stringBuilder2.append(getName(view));
        printStream.println(stringBuilder2.toString());
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        Field[] arrayOfField = layoutParams.getClass().getFields();
        int k = 0;
        while (true) {
          if (k < arrayOfField.length) {
            Field field = arrayOfField[k];
            try {
              Object object = field.get(layoutParams);
              if (field.getName().contains(v416f9e89.xbd520268("2033")) && !object.toString().equals(v416f9e89.xbd520268("2034"))) {
                PrintStream printStream1 = System.out;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                stringBuilder.append(v416f9e89.xbd520268("2035"));
                stringBuilder.append(field.getName());
                stringBuilder.append(v416f9e89.xbd520268("2036"));
                stringBuilder.append(object);
                printStream1.println(stringBuilder.toString());
              } 
            } catch (IllegalAccessException illegalAccessException) {}
            k++;
            continue;
          } 
          i++;
          continue label22;
        } 
        break;
      } 
      return;
    } 
  }
  
  public static void dumpPoc(Object paramObject) {
    StackTraceElement stackTraceElement = (new Throwable()).getStackTrace()[1];
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(v416f9e89.xbd520268("2037"));
    stringBuilder1.append(stackTraceElement.getFileName());
    stringBuilder1.append(v416f9e89.xbd520268("2038"));
    stringBuilder1.append(stackTraceElement.getLineNumber());
    stringBuilder1.append(v416f9e89.xbd520268("2039"));
    String str1 = stringBuilder1.toString();
    Class<?> clazz = paramObject.getClass();
    PrintStream printStream = System.out;
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(str1);
    String str2 = v416f9e89.xbd520268("2040");
    stringBuilder2.append(str2);
    stringBuilder2.append(clazz.getName());
    String str3 = v416f9e89.xbd520268("2041");
    stringBuilder2.append(str3);
    printStream.println(stringBuilder2.toString());
    Field[] arrayOfField = clazz.getFields();
    int i = 0;
    while (true) {
      if (i < arrayOfField.length) {
        Field field = arrayOfField[i];
        try {
          Object object = field.get(paramObject);
          if (field.getName().startsWith(v416f9e89.xbd520268("2042")) && (!(object instanceof Integer) || !object.toString().equals(v416f9e89.xbd520268("2043"))) && (!(object instanceof Integer) || !object.toString().equals(v416f9e89.xbd520268("2044"))) && (!(object instanceof Float) || !object.toString().equals(v416f9e89.xbd520268("2045"))) && (!(object instanceof Float) || !object.toString().equals(v416f9e89.xbd520268("2046")))) {
            PrintStream printStream1 = System.out;
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(str1);
            stringBuilder3.append(v416f9e89.xbd520268("2047"));
            stringBuilder3.append(field.getName());
            stringBuilder3.append(v416f9e89.xbd520268("2048"));
            stringBuilder3.append(object);
            printStream1.println(stringBuilder3.toString());
          } 
        } catch (IllegalAccessException illegalAccessException) {}
        i++;
        continue;
      } 
      paramObject = System.out;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str1);
      stringBuilder.append(str2);
      stringBuilder.append(clazz.getSimpleName());
      stringBuilder.append(str3);
      paramObject.println(stringBuilder.toString());
      return;
    } 
  }
  
  public static String getActionType(MotionEvent paramMotionEvent) {
    int j = paramMotionEvent.getAction();
    Field[] arrayOfField = MotionEvent.class.getFields();
    int i = 0;
    while (true) {
      if (i < arrayOfField.length) {
        Field field = arrayOfField[i];
        try {
          if (Modifier.isStatic(field.getModifiers()) && field.getType().equals(int.class) && field.getInt(null) == j)
            return field.getName(); 
        } catch (IllegalAccessException illegalAccessException) {}
        i++;
        continue;
      } 
      return v416f9e89.xbd520268("2049");
    } 
  }
  
  public static String getCallFrom(int paramInt) {
    StackTraceElement stackTraceElement = (new Throwable()).getStackTrace()[paramInt + 2];
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(v416f9e89.xbd520268("2050"));
    stringBuilder.append(stackTraceElement.getFileName());
    stringBuilder.append(v416f9e89.xbd520268("2051"));
    stringBuilder.append(stackTraceElement.getLineNumber());
    stringBuilder.append(v416f9e89.xbd520268("2052"));
    return stringBuilder.toString();
  }
  
  public static String getLoc() {
    StackTraceElement stackTraceElement = (new Throwable()).getStackTrace()[1];
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(v416f9e89.xbd520268("2053"));
    stringBuilder.append(stackTraceElement.getFileName());
    stringBuilder.append(v416f9e89.xbd520268("2054"));
    stringBuilder.append(stackTraceElement.getLineNumber());
    stringBuilder.append(v416f9e89.xbd520268("2055"));
    stringBuilder.append(stackTraceElement.getMethodName());
    stringBuilder.append(v416f9e89.xbd520268("2056"));
    return stringBuilder.toString();
  }
  
  public static String getLocation() {
    StackTraceElement stackTraceElement = (new Throwable()).getStackTrace()[1];
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(v416f9e89.xbd520268("2057"));
    stringBuilder.append(stackTraceElement.getFileName());
    stringBuilder.append(v416f9e89.xbd520268("2058"));
    stringBuilder.append(stackTraceElement.getLineNumber());
    stringBuilder.append(v416f9e89.xbd520268("2059"));
    return stringBuilder.toString();
  }
  
  public static String getLocation2() {
    StackTraceElement stackTraceElement = (new Throwable()).getStackTrace()[2];
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(v416f9e89.xbd520268("2060"));
    stringBuilder.append(stackTraceElement.getFileName());
    stringBuilder.append(v416f9e89.xbd520268("2061"));
    stringBuilder.append(stackTraceElement.getLineNumber());
    stringBuilder.append(v416f9e89.xbd520268("2062"));
    return stringBuilder.toString();
  }
  
  public static String getName(Context paramContext, int paramInt) {
    if (paramInt != -1)
      try {
        return paramContext.getResources().getResourceEntryName(paramInt);
      } catch (Exception exception) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(v416f9e89.xbd520268("2063"));
        stringBuilder.append(paramInt);
        return stringBuilder.toString();
      }  
    return "UNKNOWN";
  }
  
  public static String getName(Context paramContext, int[] paramArrayOfint) {
    try {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramArrayOfint.length);
      stringBuilder.append(v416f9e89.xbd520268("2064"));
      String str = stringBuilder.toString();
      int i = 0;
      while (true) {
        String str1;
        if (i < paramArrayOfint.length) {
          StringBuilder stringBuilder3 = new StringBuilder();
          stringBuilder3.append(str);
          String str2 = v416f9e89.xbd520268("2065");
          if (i == 0) {
            str = "";
          } else {
            str = str2;
          } 
          stringBuilder3.append(str);
          String str3 = stringBuilder3.toString();
          try {
            str = paramContext.getResources().getResourceEntryName(paramArrayOfint[i]);
          } catch (android.content.res.Resources.NotFoundException notFoundException) {
            StringBuilder stringBuilder4 = new StringBuilder();
            stringBuilder4.append(v416f9e89.xbd520268("2066"));
            stringBuilder4.append(paramArrayOfint[i]);
            stringBuilder4.append(str2);
            str1 = stringBuilder4.toString();
          } 
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append(str3);
          stringBuilder2.append(str1);
          str1 = stringBuilder2.toString();
          i++;
          continue;
        } 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str1);
        stringBuilder1.append("]");
        return stringBuilder1.toString();
      } 
    } catch (Exception exception) {
      String str = exception.toString();
      Log.v(v416f9e89.xbd520268("2067"), str);
      return v416f9e89.xbd520268("2068");
    } 
  }
  
  public static String getName(View paramView) {
    try {
      return paramView.getContext().getResources().getResourceEntryName(paramView.getId());
    } catch (Exception exception) {
      return v416f9e89.xbd520268("2069");
    } 
  }
  
  public static String getState(MotionLayout paramMotionLayout, int paramInt) {
    return (paramInt == -1) ? v416f9e89.xbd520268("2070") : paramMotionLayout.getContext().getResources().getResourceEntryName(paramInt);
  }
  
  public static void logStack(String paramString1, String paramString2, int paramInt) {
    StackTraceElement[] arrayOfStackTraceElement = (new Throwable()).getStackTrace();
    int i = arrayOfStackTraceElement.length;
    boolean bool = true;
    i = Math.min(paramInt, i - 1);
    String str2 = v416f9e89.xbd520268("2071");
    String str1 = str2;
    for (paramInt = bool; paramInt <= i; paramInt++) {
      StackTraceElement stackTraceElement = arrayOfStackTraceElement[paramInt];
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(v416f9e89.xbd520268("2072"));
      stringBuilder1.append(arrayOfStackTraceElement[paramInt].getFileName());
      stringBuilder1.append(v416f9e89.xbd520268("2073"));
      stringBuilder1.append(arrayOfStackTraceElement[paramInt].getLineNumber());
      stringBuilder1.append(v416f9e89.xbd520268("2074"));
      stringBuilder1.append(arrayOfStackTraceElement[paramInt].getMethodName());
      String str = stringBuilder1.toString();
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str1);
      stringBuilder2.append(str2);
      str1 = stringBuilder2.toString();
      stringBuilder2 = new StringBuilder();
      stringBuilder2.append(paramString2);
      stringBuilder2.append(str1);
      stringBuilder2.append(str);
      stringBuilder2.append(str1);
      Log.v(paramString1, stringBuilder2.toString());
    } 
  }
  
  public static void printStack(String paramString, int paramInt) {
    StackTraceElement[] arrayOfStackTraceElement = (new Throwable()).getStackTrace();
    int i = arrayOfStackTraceElement.length;
    boolean bool = true;
    i = Math.min(paramInt, i - 1);
    String str2 = v416f9e89.xbd520268("2075");
    String str1 = str2;
    for (paramInt = bool; paramInt <= i; paramInt++) {
      StackTraceElement stackTraceElement = arrayOfStackTraceElement[paramInt];
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(v416f9e89.xbd520268("2076"));
      stringBuilder1.append(arrayOfStackTraceElement[paramInt].getFileName());
      stringBuilder1.append(v416f9e89.xbd520268("2077"));
      stringBuilder1.append(arrayOfStackTraceElement[paramInt].getLineNumber());
      stringBuilder1.append(v416f9e89.xbd520268("2078"));
      String str = stringBuilder1.toString();
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str1);
      stringBuilder2.append(str2);
      str1 = stringBuilder2.toString();
      PrintStream printStream = System.out;
      StringBuilder stringBuilder3 = new StringBuilder();
      stringBuilder3.append(paramString);
      stringBuilder3.append(str1);
      stringBuilder3.append(str);
      stringBuilder3.append(str1);
      printStream.println(stringBuilder3.toString());
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\constraintlayout\motion\widget\Debug.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */