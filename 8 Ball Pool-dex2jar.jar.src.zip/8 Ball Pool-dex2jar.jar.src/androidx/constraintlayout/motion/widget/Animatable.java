package androidx.constraintlayout.motion.widget;

public interface Animatable {
  float getProgress();
  
  void setProgress(float paramFloat);
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\constraintlayout\motion\widget\Animatable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */