package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.motion.utils.Easing;
import androidx.constraintlayout.widget.R;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.util.HashMap;

public class KeyPosition extends KeyPositionBase {
  static final int KEY_TYPE = 2;
  
  static final String NAME = v416f9e89.xbd520268("2518");
  
  private static final String PERCENT_X = v416f9e89.xbd520268("2519");
  
  private static final String PERCENT_Y = v416f9e89.xbd520268("2520");
  
  private static final String TAG = v416f9e89.xbd520268("2521");
  
  public static final int TYPE_CARTESIAN = 0;
  
  public static final int TYPE_PATH = 1;
  
  public static final int TYPE_SCREEN = 2;
  
  float mAltPercentX = Float.NaN;
  
  float mAltPercentY = Float.NaN;
  
  private float mCalculatedPositionX = Float.NaN;
  
  private float mCalculatedPositionY = Float.NaN;
  
  int mDrawPath = 0;
  
  int mPathMotionArc = UNSET;
  
  float mPercentHeight = Float.NaN;
  
  float mPercentWidth = Float.NaN;
  
  float mPercentX = Float.NaN;
  
  float mPercentY = Float.NaN;
  
  int mPositionType = 0;
  
  String mTransitionEasing = null;
  
  private void calcCartesianPosition(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    float f1;
    float f3 = paramFloat3 - paramFloat1;
    float f4 = paramFloat4 - paramFloat2;
    boolean bool = Float.isNaN(this.mPercentX);
    float f2 = 0.0F;
    if (bool) {
      paramFloat3 = 0.0F;
    } else {
      paramFloat3 = this.mPercentX;
    } 
    if (Float.isNaN(this.mAltPercentY)) {
      paramFloat4 = 0.0F;
    } else {
      paramFloat4 = this.mAltPercentY;
    } 
    if (Float.isNaN(this.mPercentY)) {
      f1 = 0.0F;
    } else {
      f1 = this.mPercentY;
    } 
    if (!Float.isNaN(this.mAltPercentX))
      f2 = this.mAltPercentX; 
    this.mCalculatedPositionX = (int)(paramFloat1 + paramFloat3 * f3 + f2 * f4);
    this.mCalculatedPositionY = (int)(paramFloat2 + f3 * paramFloat4 + f4 * f1);
  }
  
  private void calcPathPosition(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    paramFloat3 -= paramFloat1;
    paramFloat4 -= paramFloat2;
    float f1 = -paramFloat4;
    float f2 = this.mPercentX;
    float f3 = this.mPercentY;
    this.mCalculatedPositionX = paramFloat1 + paramFloat3 * f2 + f1 * f3;
    this.mCalculatedPositionY = paramFloat2 + paramFloat4 * f2 + paramFloat3 * f3;
  }
  
  private void calcScreenPosition(int paramInt1, int paramInt2) {
    float f1 = (paramInt1 - 0);
    float f2 = this.mPercentX;
    float f3 = false;
    this.mCalculatedPositionX = f1 * f2 + f3;
    this.mCalculatedPositionY = (paramInt2 - 0) * f2 + f3;
  }
  
  public void addValues(HashMap<String, SplineSet> paramHashMap) {}
  
  void calcPosition(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    int i = this.mPositionType;
    if (i != 1) {
      if (i != 2) {
        calcCartesianPosition(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
        return;
      } 
      calcScreenPosition(paramInt1, paramInt2);
      return;
    } 
    calcPathPosition(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  float getPositionX() {
    return this.mCalculatedPositionX;
  }
  
  float getPositionY() {
    return this.mCalculatedPositionY;
  }
  
  public boolean intersects(int paramInt1, int paramInt2, RectF paramRectF1, RectF paramRectF2, float paramFloat1, float paramFloat2) {
    calcPosition(paramInt1, paramInt2, paramRectF1.centerX(), paramRectF1.centerY(), paramRectF2.centerX(), paramRectF2.centerY());
    return (Math.abs(paramFloat1 - this.mCalculatedPositionX) < 20.0F && Math.abs(paramFloat2 - this.mCalculatedPositionY) < 20.0F);
  }
  
  public void load(Context paramContext, AttributeSet paramAttributeSet) {
    Loader.read(this, paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.KeyPosition));
  }
  
  public void positionAttributes(View paramView, RectF paramRectF1, RectF paramRectF2, float paramFloat1, float paramFloat2, String[] paramArrayOfString, float[] paramArrayOffloat) {
    int i = this.mPositionType;
    if (i != 1) {
      if (i != 2) {
        positionCartAttributes(paramRectF1, paramRectF2, paramFloat1, paramFloat2, paramArrayOfString, paramArrayOffloat);
        return;
      } 
      positionScreenAttributes(paramView, paramRectF1, paramRectF2, paramFloat1, paramFloat2, paramArrayOfString, paramArrayOffloat);
      return;
    } 
    positionPathAttributes(paramRectF1, paramRectF2, paramFloat1, paramFloat2, paramArrayOfString, paramArrayOffloat);
  }
  
  void positionCartAttributes(RectF paramRectF1, RectF paramRectF2, float paramFloat1, float paramFloat2, String[] paramArrayOfString, float[] paramArrayOffloat) {
    float f1 = paramRectF1.centerX();
    float f2 = paramRectF1.centerY();
    float f4 = paramRectF2.centerX();
    float f3 = paramRectF2.centerY();
    f4 -= f1;
    f3 -= f2;
    String str1 = paramArrayOfString[0];
    String str2 = v416f9e89.xbd520268("2522");
    if (str1 != null) {
      if (str2.equals(paramArrayOfString[0])) {
        paramArrayOffloat[0] = (paramFloat1 - f1) / f4;
        paramArrayOffloat[1] = (paramFloat2 - f2) / f3;
        return;
      } 
      paramArrayOffloat[1] = (paramFloat1 - f1) / f4;
      paramArrayOffloat[0] = (paramFloat2 - f2) / f3;
      return;
    } 
    paramArrayOfString[0] = str2;
    paramArrayOffloat[0] = (paramFloat1 - f1) / f4;
    paramArrayOfString[1] = v416f9e89.xbd520268("2523");
    paramArrayOffloat[1] = (paramFloat2 - f2) / f3;
  }
  
  void positionPathAttributes(RectF paramRectF1, RectF paramRectF2, float paramFloat1, float paramFloat2, String[] paramArrayOfString, float[] paramArrayOffloat) {
    float f1 = paramRectF1.centerX();
    float f3 = paramRectF1.centerY();
    float f4 = paramRectF2.centerX();
    float f2 = paramRectF2.centerY();
    f4 -= f1;
    float f5 = f2 - f3;
    f2 = (float)Math.hypot(f4, f5);
    if (f2 < 1.0E-4D) {
      System.out.println(v416f9e89.xbd520268("2524"));
      paramArrayOffloat[0] = 0.0F;
      paramArrayOffloat[1] = 0.0F;
      return;
    } 
    f4 /= f2;
    f5 /= f2;
    paramFloat2 -= f3;
    f1 = paramFloat1 - f1;
    paramFloat1 = (f4 * paramFloat2 - f1 * f5) / f2;
    paramFloat2 = (f4 * f1 + f5 * paramFloat2) / f2;
    String str1 = paramArrayOfString[0];
    String str2 = v416f9e89.xbd520268("2525");
    if (str1 != null) {
      if (str2.equals(paramArrayOfString[0])) {
        paramArrayOffloat[0] = paramFloat2;
        paramArrayOffloat[1] = paramFloat1;
        return;
      } 
    } else {
      paramArrayOfString[0] = str2;
      paramArrayOfString[1] = v416f9e89.xbd520268("2526");
      paramArrayOffloat[0] = paramFloat2;
      paramArrayOffloat[1] = paramFloat1;
    } 
  }
  
  void positionScreenAttributes(View paramView, RectF paramRectF1, RectF paramRectF2, float paramFloat1, float paramFloat2, String[] paramArrayOfString, float[] paramArrayOffloat) {
    paramRectF1.centerX();
    paramRectF1.centerY();
    paramRectF2.centerX();
    paramRectF2.centerY();
    ViewGroup viewGroup = (ViewGroup)paramView.getParent();
    int i = viewGroup.getWidth();
    int j = viewGroup.getHeight();
    String str1 = paramArrayOfString[0];
    String str2 = v416f9e89.xbd520268("2527");
    if (str1 != null) {
      if (str2.equals(paramArrayOfString[0])) {
        paramArrayOffloat[0] = paramFloat1 / i;
        paramArrayOffloat[1] = paramFloat2 / j;
        return;
      } 
      paramArrayOffloat[1] = paramFloat1 / i;
      paramArrayOffloat[0] = paramFloat2 / j;
      return;
    } 
    paramArrayOfString[0] = str2;
    paramArrayOffloat[0] = paramFloat1 / i;
    paramArrayOfString[1] = v416f9e89.xbd520268("2528");
    paramArrayOffloat[1] = paramFloat2 / j;
  }
  
  public void setValue(String paramString, Object paramObject) {
    float f;
    paramString.hashCode();
    int i = paramString.hashCode();
    byte b = -1;
    switch (i) {
      case 428090548:
        if (!paramString.equals(v416f9e89.xbd520268("2529")))
          break; 
        b = 6;
        break;
      case 428090547:
        if (!paramString.equals(v416f9e89.xbd520268("2530")))
          break; 
        b = 5;
        break;
      case -200259324:
        if (!paramString.equals(v416f9e89.xbd520268("2531")))
          break; 
        b = 4;
        break;
      case -827014263:
        if (!paramString.equals(v416f9e89.xbd520268("2532")))
          break; 
        b = 3;
        break;
      case -1017587252:
        if (!paramString.equals(v416f9e89.xbd520268("2533")))
          break; 
        b = 2;
        break;
      case -1127236479:
        if (!paramString.equals(v416f9e89.xbd520268("2534")))
          break; 
        b = 1;
        break;
      case -1812823328:
        if (!paramString.equals(v416f9e89.xbd520268("2535")))
          break; 
        b = 0;
        break;
    } 
    switch (b) {
      default:
        return;
      case 6:
        this.mPercentY = toFloat(paramObject);
        return;
      case 5:
        this.mPercentX = toFloat(paramObject);
        return;
      case 4:
        f = toFloat(paramObject);
        this.mPercentWidth = f;
        this.mPercentHeight = f;
        return;
      case 3:
        this.mDrawPath = toInt(paramObject);
        return;
      case 2:
        this.mPercentHeight = toFloat(paramObject);
        return;
      case 1:
        this.mPercentWidth = toFloat(paramObject);
        return;
      case 0:
        break;
    } 
    this.mTransitionEasing = paramObject.toString();
  }
  
  private static class Loader {
    private static final int CURVE_FIT = 4;
    
    private static final int DRAW_PATH = 5;
    
    private static final int FRAME_POSITION = 2;
    
    private static final int PATH_MOTION_ARC = 10;
    
    private static final int PERCENT_HEIGHT = 12;
    
    private static final int PERCENT_WIDTH = 11;
    
    private static final int PERCENT_X = 6;
    
    private static final int PERCENT_Y = 7;
    
    private static final int SIZE_PERCENT = 8;
    
    private static final int TARGET_ID = 1;
    
    private static final int TRANSITION_EASING = 3;
    
    private static final int TYPE = 9;
    
    private static SparseIntArray mAttrMap;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      mAttrMap = sparseIntArray;
      sparseIntArray.append(R.styleable.KeyPosition_motionTarget, 1);
      mAttrMap.append(R.styleable.KeyPosition_framePosition, 2);
      mAttrMap.append(R.styleable.KeyPosition_transitionEasing, 3);
      mAttrMap.append(R.styleable.KeyPosition_curveFit, 4);
      mAttrMap.append(R.styleable.KeyPosition_drawPath, 5);
      mAttrMap.append(R.styleable.KeyPosition_percentX, 6);
      mAttrMap.append(R.styleable.KeyPosition_percentY, 7);
      mAttrMap.append(R.styleable.KeyPosition_keyPositionType, 9);
      mAttrMap.append(R.styleable.KeyPosition_sizePercent, 8);
      mAttrMap.append(R.styleable.KeyPosition_percentWidth, 11);
      mAttrMap.append(R.styleable.KeyPosition_percentHeight, 12);
      mAttrMap.append(R.styleable.KeyPosition_pathMotionArc, 10);
    }
    
    private static void read(KeyPosition param1KeyPosition, TypedArray param1TypedArray) {
      int j = param1TypedArray.getIndexCount();
      int i = 0;
      while (true) {
        String str = v416f9e89.xbd520268("2514");
        if (i < j) {
          float f;
          StringBuilder stringBuilder;
          int k = param1TypedArray.getIndex(i);
          switch (mAttrMap.get(k)) {
            default:
              stringBuilder = new StringBuilder();
              stringBuilder.append(v416f9e89.xbd520268("2515"));
              stringBuilder.append(Integer.toHexString(k));
              stringBuilder.append(v416f9e89.xbd520268("2516"));
              stringBuilder.append(mAttrMap.get(k));
              Log.e(str, stringBuilder.toString());
              break;
            case 12:
              param1KeyPosition.mPercentHeight = param1TypedArray.getFloat(k, param1KeyPosition.mPercentHeight);
              break;
            case 11:
              param1KeyPosition.mPercentWidth = param1TypedArray.getFloat(k, param1KeyPosition.mPercentWidth);
              break;
            case 10:
              param1KeyPosition.mPathMotionArc = param1TypedArray.getInt(k, param1KeyPosition.mPathMotionArc);
              break;
            case 9:
              param1KeyPosition.mPositionType = param1TypedArray.getInt(k, param1KeyPosition.mPositionType);
              break;
            case 8:
              f = param1TypedArray.getFloat(k, param1KeyPosition.mPercentHeight);
              param1KeyPosition.mPercentWidth = f;
              param1KeyPosition.mPercentHeight = f;
              break;
            case 7:
              param1KeyPosition.mPercentY = param1TypedArray.getFloat(k, param1KeyPosition.mPercentY);
              break;
            case 6:
              param1KeyPosition.mPercentX = param1TypedArray.getFloat(k, param1KeyPosition.mPercentX);
              break;
            case 5:
              param1KeyPosition.mDrawPath = param1TypedArray.getInt(k, param1KeyPosition.mDrawPath);
              break;
            case 4:
              param1KeyPosition.mCurveFit = param1TypedArray.getInteger(k, param1KeyPosition.mCurveFit);
              break;
            case 3:
              if ((param1TypedArray.peekValue(k)).type == 3) {
                param1KeyPosition.mTransitionEasing = param1TypedArray.getString(k);
                break;
              } 
              param1KeyPosition.mTransitionEasing = Easing.NAMED_EASING[param1TypedArray.getInteger(k, 0)];
              break;
            case 2:
              param1KeyPosition.mFramePosition = param1TypedArray.getInt(k, param1KeyPosition.mFramePosition);
              break;
            case 1:
              if (MotionLayout.IS_IN_EDIT_MODE) {
                param1KeyPosition.mTargetId = param1TypedArray.getResourceId(k, param1KeyPosition.mTargetId);
                if (param1KeyPosition.mTargetId == -1)
                  param1KeyPosition.mTargetString = param1TypedArray.getString(k); 
                break;
              } 
              if ((param1TypedArray.peekValue(k)).type == 3) {
                param1KeyPosition.mTargetString = param1TypedArray.getString(k);
                break;
              } 
              param1KeyPosition.mTargetId = param1TypedArray.getResourceId(k, param1KeyPosition.mTargetId);
              break;
          } 
          i++;
          continue;
        } 
        if (param1KeyPosition.mFramePosition == -1)
          Log.e(str, v416f9e89.xbd520268("2517")); 
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\constraintlayout\motion\widget\KeyPosition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */