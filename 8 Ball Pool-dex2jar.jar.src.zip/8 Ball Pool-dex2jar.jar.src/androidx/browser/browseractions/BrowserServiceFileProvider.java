package androidx.browser.browseractions;

import android.content.ClipData;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import androidx.concurrent.futures.ResolvableFuture;
import androidx.core.content.FileProvider;
import androidx.core.util.AtomicFile;
import com.google.common.util.concurrent.ListenableFuture;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Deprecated
public final class BrowserServiceFileProvider extends FileProvider {
  private static final String AUTHORITY_SUFFIX = v416f9e89.xbd520268("1457");
  
  private static final String CLIP_DATA_LABEL = v416f9e89.xbd520268("1458");
  
  private static final String CONTENT_SCHEME = v416f9e89.xbd520268("1459");
  
  private static final String FILE_EXTENSION = v416f9e89.xbd520268("1460");
  
  private static final String FILE_SUB_DIR = v416f9e89.xbd520268("1461");
  
  private static final String FILE_SUB_DIR_NAME = v416f9e89.xbd520268("1462");
  
  private static final String LAST_CLEANUP_TIME_KEY = v416f9e89.xbd520268("1463");
  
  private static final String TAG = v416f9e89.xbd520268("1464");
  
  static Object sFileCleanupLock = new Object();
  
  private static Uri generateUri(Context paramContext, String paramString) {
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(v416f9e89.xbd520268("1465"));
    stringBuilder1.append(paramString);
    stringBuilder1.append(v416f9e89.xbd520268("1466"));
    paramString = stringBuilder1.toString();
    Uri.Builder builder = (new Uri.Builder()).scheme(v416f9e89.xbd520268("1467"));
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramContext.getPackageName());
    stringBuilder2.append(v416f9e89.xbd520268("1468"));
    return builder.authority(stringBuilder2.toString()).path(paramString).build();
  }
  
  public static void grantReadPermission(Intent paramIntent, List<Uri> paramList, Context paramContext) {
    if (paramList != null) {
      if (paramList.size() == 0)
        return; 
      ContentResolver contentResolver = paramContext.getContentResolver();
      int i = 1;
      paramIntent.addFlags(1);
      Uri uri = paramList.get(0);
      ClipData clipData = ClipData.newUri(contentResolver, v416f9e89.xbd520268("1469"), uri);
      while (i < paramList.size()) {
        clipData.addItem(new ClipData.Item(paramList.get(i)));
        i++;
      } 
      paramIntent.setClipData(clipData);
    } 
  }
  
  public static ListenableFuture<Bitmap> loadBitmap(final ContentResolver resolver, final Uri uri) {
    final ResolvableFuture result = ResolvableFuture.create();
    AsyncTask.THREAD_POOL_EXECUTOR.execute(new Runnable() {
          public void run() {
            try {
              ParcelFileDescriptor parcelFileDescriptor = resolver.openFileDescriptor(uri, v416f9e89.xbd520268("1435"));
              if (parcelFileDescriptor == null) {
                result.setException(new FileNotFoundException());
                return;
              } 
              Bitmap bitmap = BitmapFactory.decodeFileDescriptor(parcelFileDescriptor.getFileDescriptor());
              parcelFileDescriptor.close();
              if (bitmap == null) {
                result.setException(new IOException(v416f9e89.xbd520268("1436")));
                return;
              } 
              result.set(bitmap);
              return;
            } catch (IOException iOException) {
              result.setException(iOException);
              return;
            } 
          }
        });
    return (ListenableFuture<Bitmap>)resolvableFuture;
  }
  
  public static ResolvableFuture<Uri> saveBitmap(Context paramContext, Bitmap paramBitmap, String paramString, int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append(v416f9e89.xbd520268("1470"));
    stringBuilder.append(Integer.toString(paramInt));
    paramString = stringBuilder.toString();
    Uri uri = generateUri(paramContext, paramString);
    ResolvableFuture<Uri> resolvableFuture = ResolvableFuture.create();
    (new FileSaveTask(paramContext, paramString, paramBitmap, uri, resolvableFuture)).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Object[])new String[0]);
    return resolvableFuture;
  }
  
  private static class FileCleanupTask extends AsyncTask<Void, Void, Void> {
    private static final long CLEANUP_REQUIRED_TIME_SPAN = TimeUnit.DAYS.toMillis(7L);
    
    private static final long DELETION_FAILED_REATTEMPT_DURATION = TimeUnit.DAYS.toMillis(1L);
    
    private static final long IMAGE_RETENTION_DURATION = TimeUnit.DAYS.toMillis(7L);
    
    private final Context mAppContext;
    
    static {
    
    }
    
    FileCleanupTask(Context param1Context) {
      this.mAppContext = param1Context.getApplicationContext();
    }
    
    private static boolean isImageFile(File param1File) {
      return param1File.getName().endsWith(v416f9e89.xbd520268("1439"));
    }
    
    private static boolean shouldCleanUp(SharedPreferences param1SharedPreferences) {
      long l = System.currentTimeMillis();
      l = param1SharedPreferences.getLong(v416f9e89.xbd520268("1440"), l);
      return (System.currentTimeMillis() > l + CLEANUP_REQUIRED_TIME_SPAN);
    }
    
    protected Void doInBackground(Void... param1VarArgs) {
      Context context = this.mAppContext;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.mAppContext.getPackageName());
      stringBuilder.append(v416f9e89.xbd520268("1441"));
      null = context.getSharedPreferences(stringBuilder.toString(), 0);
      if (!shouldCleanUp(null))
        return null; 
      synchronized (BrowserServiceFileProvider.sFileCleanupLock) {
        File file = new File(this.mAppContext.getFilesDir(), v416f9e89.xbd520268("1442"));
        if (!file.exists())
          return null; 
        File[] arrayOfFile = file.listFiles();
        long l1 = System.currentTimeMillis();
        long l2 = IMAGE_RETENTION_DURATION;
        int j = arrayOfFile.length;
        boolean bool = true;
        int i = 0;
        while (true) {
          boolean bool1;
          if (i < j) {
            File file1 = arrayOfFile[i];
            if (!isImageFile(file1)) {
              bool1 = bool;
            } else {
              bool1 = bool;
              if (file1.lastModified() < l1 - l2) {
                bool1 = bool;
                if (!file1.delete()) {
                  String str = v416f9e89.xbd520268("1443");
                  StringBuilder stringBuilder1 = new StringBuilder();
                  stringBuilder1.append(v416f9e89.xbd520268("1444"));
                  stringBuilder1.append(file1.getAbsoluteFile());
                  Log.e(str, stringBuilder1.toString());
                  bool1 = false;
                } 
              } 
            } 
          } else {
            if (bool) {
              l1 = System.currentTimeMillis();
            } else {
              l1 = System.currentTimeMillis() - CLEANUP_REQUIRED_TIME_SPAN + DELETION_FAILED_REATTEMPT_DURATION;
            } 
            SharedPreferences.Editor editor = null.edit();
            editor.putLong(v416f9e89.xbd520268("1445"), l1);
            editor.apply();
            return null;
          } 
          i++;
          bool = bool1;
        } 
      } 
    }
  }
  
  private static class FileSaveTask extends AsyncTask<String, Void, Void> {
    private final Context mAppContext;
    
    private final Bitmap mBitmap;
    
    private final Uri mFileUri;
    
    private final String mFilename;
    
    private final ResolvableFuture<Uri> mResultFuture;
    
    FileSaveTask(Context param1Context, String param1String, Bitmap param1Bitmap, Uri param1Uri, ResolvableFuture<Uri> param1ResolvableFuture) {
      this.mAppContext = param1Context.getApplicationContext();
      this.mFilename = param1String;
      this.mBitmap = param1Bitmap;
      this.mFileUri = param1Uri;
      this.mResultFuture = param1ResolvableFuture;
    }
    
    private void saveFileBlocking(File param1File) {
      if (Build.VERSION.SDK_INT >= 22) {
        FileOutputStream fileOutputStream;
        AtomicFile atomicFile = new AtomicFile(param1File);
        try {
          fileOutputStream = atomicFile.startWrite();
          try {
            this.mBitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
            fileOutputStream.close();
            atomicFile.finishWrite(fileOutputStream);
            this.mResultFuture.set(this.mFileUri);
            return;
          } catch (IOException null) {}
        } catch (IOException iOException) {
          fileOutputStream = null;
        } 
        atomicFile.failWrite(fileOutputStream);
        this.mResultFuture.setException(iOException);
        return;
      } 
      try {
        FileOutputStream fileOutputStream = new FileOutputStream((File)iOException);
        this.mBitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
        fileOutputStream.close();
        this.mResultFuture.set(this.mFileUri);
        return;
      } catch (IOException iOException1) {
        this.mResultFuture.setException(iOException1);
        return;
      } 
    }
    
    private void saveFileIfNeededBlocking() {
      null = new File(this.mAppContext.getFilesDir(), v416f9e89.xbd520268("1453"));
      synchronized (BrowserServiceFileProvider.sFileCleanupLock) {
        if (!null.exists() && !null.mkdir()) {
          this.mResultFuture.setException(new IOException(v416f9e89.xbd520268("1454")));
          return;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.mFilename);
        stringBuilder.append(v416f9e89.xbd520268("1455"));
        null = new File(null, stringBuilder.toString());
        if (null.exists()) {
          this.mResultFuture.set(this.mFileUri);
        } else {
          saveFileBlocking(null);
        } 
        null.setLastModified(System.currentTimeMillis());
        return;
      } 
    }
    
    protected Void doInBackground(String... param1VarArgs) {
      saveFileIfNeededBlocking();
      return null;
    }
    
    protected void onPostExecute(Void param1Void) {
      (new BrowserServiceFileProvider.FileCleanupTask(this.mAppContext)).executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, (Object[])new Void[0]);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\browser\browseractions\BrowserServiceFileProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */