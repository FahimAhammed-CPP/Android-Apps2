package androidx.browser.browseractions;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.core.content.ContextCompat;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Deprecated
public class BrowserActionsIntent {
  public static final String ACTION_BROWSER_ACTIONS_OPEN = v416f9e89.xbd520268("1410");
  
  public static final String EXTRA_APP_ID = v416f9e89.xbd520268("1411");
  
  public static final String EXTRA_MENU_ITEMS = v416f9e89.xbd520268("1412");
  
  public static final String EXTRA_SELECTED_ACTION_PENDING_INTENT = v416f9e89.xbd520268("1413");
  
  public static final String EXTRA_TYPE = v416f9e89.xbd520268("1414");
  
  public static final int ITEM_COPY = 3;
  
  public static final int ITEM_DOWNLOAD = 2;
  
  public static final int ITEM_INVALID_ITEM = -1;
  
  public static final int ITEM_OPEN_IN_INCOGNITO = 1;
  
  public static final int ITEM_OPEN_IN_NEW_TAB = 0;
  
  public static final int ITEM_SHARE = 4;
  
  public static final String KEY_ACTION = v416f9e89.xbd520268("1415");
  
  public static final String KEY_ICON_ID = v416f9e89.xbd520268("1416");
  
  private static final String KEY_ICON_URI = v416f9e89.xbd520268("1417");
  
  public static final String KEY_TITLE = v416f9e89.xbd520268("1418");
  
  public static final int MAX_CUSTOM_ITEMS = 5;
  
  private static final String TAG = v416f9e89.xbd520268("1419");
  
  private static final String TEST_URL = v416f9e89.xbd520268("1420");
  
  public static final int URL_TYPE_AUDIO = 3;
  
  public static final int URL_TYPE_FILE = 4;
  
  public static final int URL_TYPE_IMAGE = 1;
  
  public static final int URL_TYPE_NONE = 0;
  
  public static final int URL_TYPE_PLUGIN = 5;
  
  public static final int URL_TYPE_VIDEO = 2;
  
  private static BrowserActionsFallDialogListener sDialogListenter;
  
  private final Intent mIntent;
  
  BrowserActionsIntent(Intent paramIntent) {
    this.mIntent = paramIntent;
  }
  
  public static List<ResolveInfo> getBrowserActionsIntentHandlers(Context paramContext) {
    Uri uri = Uri.parse(v416f9e89.xbd520268("1421"));
    Intent intent = new Intent(v416f9e89.xbd520268("1422"), uri);
    return paramContext.getPackageManager().queryIntentActivities(intent, 131072);
  }
  
  @Deprecated
  public static String getCreatorPackageName(Intent paramIntent) {
    return getUntrustedCreatorPackageName(paramIntent);
  }
  
  public static String getUntrustedCreatorPackageName(Intent paramIntent) {
    PendingIntent pendingIntent = (PendingIntent)paramIntent.getParcelableExtra(v416f9e89.xbd520268("1423"));
    return (pendingIntent != null) ? ((Build.VERSION.SDK_INT >= 17) ? pendingIntent.getCreatorPackage() : pendingIntent.getTargetPackage()) : null;
  }
  
  public static void launchIntent(Context paramContext, Intent paramIntent) {
    launchIntent(paramContext, paramIntent, getBrowserActionsIntentHandlers(paramContext));
  }
  
  static void launchIntent(Context paramContext, Intent paramIntent, List<ResolveInfo> paramList) {
    if (paramList == null || paramList.size() == 0) {
      openFallbackBrowserActionsMenu(paramContext, paramIntent);
      return;
    } 
    int j = paramList.size();
    int i = 0;
    if (j == 1) {
      paramIntent.setPackage(((ResolveInfo)paramList.get(0)).activityInfo.packageName);
    } else {
      Uri uri = Uri.parse(v416f9e89.xbd520268("1424"));
      Intent intent = new Intent(v416f9e89.xbd520268("1425"), uri);
      ResolveInfo resolveInfo = paramContext.getPackageManager().resolveActivity(intent, 65536);
      if (resolveInfo != null) {
        String str = resolveInfo.activityInfo.packageName;
        while (i < paramList.size()) {
          if (str.equals(((ResolveInfo)paramList.get(i)).activityInfo.packageName)) {
            paramIntent.setPackage(str);
            break;
          } 
          i++;
        } 
      } 
    } 
    ContextCompat.startActivity(paramContext, paramIntent, null);
  }
  
  public static void openBrowserAction(Context paramContext, Uri paramUri) {
    launchIntent(paramContext, (new Builder(paramContext, paramUri)).build().getIntent());
  }
  
  public static void openBrowserAction(Context paramContext, Uri paramUri, int paramInt, ArrayList<BrowserActionItem> paramArrayList, PendingIntent paramPendingIntent) {
    launchIntent(paramContext, (new Builder(paramContext, paramUri)).setUrlType(paramInt).setCustomItems(paramArrayList).setOnItemSelectedAction(paramPendingIntent).build().getIntent());
  }
  
  private static void openFallbackBrowserActionsMenu(Context paramContext, Intent paramIntent) {
    Uri uri = paramIntent.getData();
    ArrayList<Bundle> arrayList = paramIntent.getParcelableArrayListExtra(v416f9e89.xbd520268("1426"));
    if (arrayList != null) {
      List<BrowserActionItem> list = parseBrowserActionItems(arrayList);
    } else {
      arrayList = null;
    } 
    openFallbackBrowserActionsMenu(paramContext, uri, (List)arrayList);
  }
  
  private static void openFallbackBrowserActionsMenu(Context paramContext, Uri paramUri, List<BrowserActionItem> paramList) {
    (new BrowserActionsFallbackMenuUi(paramContext, paramUri, paramList)).displayMenu();
    BrowserActionsFallDialogListener browserActionsFallDialogListener = sDialogListenter;
    if (browserActionsFallDialogListener != null)
      browserActionsFallDialogListener.onDialogShown(); 
  }
  
  public static List<BrowserActionItem> parseBrowserActionItems(ArrayList<Bundle> paramArrayList) {
    ArrayList<BrowserActionItem> arrayList = new ArrayList();
    int i = 0;
    while (i < paramArrayList.size()) {
      Bundle bundle = paramArrayList.get(i);
      String str = bundle.getString(v416f9e89.xbd520268("1427"));
      PendingIntent pendingIntent = (PendingIntent)bundle.getParcelable(v416f9e89.xbd520268("1428"));
      int j = bundle.getInt(v416f9e89.xbd520268("1429"));
      Uri uri = (Uri)bundle.getParcelable(v416f9e89.xbd520268("1430"));
      if (!TextUtils.isEmpty(str) && pendingIntent != null) {
        BrowserActionItem browserActionItem;
        if (j != 0) {
          browserActionItem = new BrowserActionItem(str, pendingIntent, j);
        } else {
          browserActionItem = new BrowserActionItem((String)browserActionItem, pendingIntent, uri);
        } 
        arrayList.add(browserActionItem);
        i++;
        continue;
      } 
      throw new IllegalArgumentException(v416f9e89.xbd520268("1431"));
    } 
    return arrayList;
  }
  
  static void setDialogShownListenter(BrowserActionsFallDialogListener paramBrowserActionsFallDialogListener) {
    sDialogListenter = paramBrowserActionsFallDialogListener;
  }
  
  public Intent getIntent() {
    return this.mIntent;
  }
  
  static interface BrowserActionsFallDialogListener {
    void onDialogShown();
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface BrowserActionsItemId {}
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface BrowserActionsUrlType {}
  
  public static final class Builder {
    private Context mContext;
    
    private List<Uri> mImageUris = new ArrayList<Uri>();
    
    private final Intent mIntent = new Intent(v416f9e89.xbd520268("1390"));
    
    private ArrayList<Bundle> mMenuItems = new ArrayList<Bundle>();
    
    private PendingIntent mOnItemSelectedPendingIntent = null;
    
    private int mType = 0;
    
    private Uri mUri;
    
    public Builder(Context param1Context, Uri param1Uri) {
      this.mContext = param1Context;
      this.mUri = param1Uri;
    }
    
    private Bundle getBundleFromItem(BrowserActionItem param1BrowserActionItem) {
      Bundle bundle = new Bundle();
      String str = param1BrowserActionItem.getTitle();
      bundle.putString(v416f9e89.xbd520268("1391"), str);
      PendingIntent pendingIntent = param1BrowserActionItem.getAction();
      bundle.putParcelable(v416f9e89.xbd520268("1392"), (Parcelable)pendingIntent);
      if (param1BrowserActionItem.getIconId() != 0) {
        int i = param1BrowserActionItem.getIconId();
        bundle.putInt(v416f9e89.xbd520268("1393"), i);
      } 
      if (param1BrowserActionItem.getIconUri() != null) {
        Uri uri = param1BrowserActionItem.getIconUri();
        bundle.putParcelable(v416f9e89.xbd520268("1394"), (Parcelable)uri);
      } 
      return bundle;
    }
    
    public BrowserActionsIntent build() {
      this.mIntent.setData(this.mUri);
      Intent intent = this.mIntent;
      int i = this.mType;
      intent.putExtra(v416f9e89.xbd520268("1395"), i);
      intent = this.mIntent;
      ArrayList<Bundle> arrayList = this.mMenuItems;
      intent.putParcelableArrayListExtra(v416f9e89.xbd520268("1396"), arrayList);
      PendingIntent pendingIntent = PendingIntent.getActivity(this.mContext, 0, new Intent(), 67108864);
      this.mIntent.putExtra(v416f9e89.xbd520268("1397"), (Parcelable)pendingIntent);
      pendingIntent = this.mOnItemSelectedPendingIntent;
      if (pendingIntent != null)
        this.mIntent.putExtra(v416f9e89.xbd520268("1398"), (Parcelable)pendingIntent); 
      BrowserServiceFileProvider.grantReadPermission(this.mIntent, this.mImageUris, this.mContext);
      return new BrowserActionsIntent(this.mIntent);
    }
    
    public Builder setCustomItems(ArrayList<BrowserActionItem> param1ArrayList) {
      if (param1ArrayList.size() <= 5) {
        int i = 0;
        while (i < param1ArrayList.size()) {
          if (!TextUtils.isEmpty(((BrowserActionItem)param1ArrayList.get(i)).getTitle()) && ((BrowserActionItem)param1ArrayList.get(i)).getAction() != null) {
            this.mMenuItems.add(getBundleFromItem(param1ArrayList.get(i)));
            if (((BrowserActionItem)param1ArrayList.get(i)).getIconUri() != null)
              this.mImageUris.add(((BrowserActionItem)param1ArrayList.get(i)).getIconUri()); 
            i++;
            continue;
          } 
          throw new IllegalArgumentException(v416f9e89.xbd520268("1399"));
        } 
        return this;
      } 
      throw new IllegalStateException(v416f9e89.xbd520268("1400"));
    }
    
    public Builder setCustomItems(BrowserActionItem... param1VarArgs) {
      return setCustomItems(new ArrayList<BrowserActionItem>(Arrays.asList(param1VarArgs)));
    }
    
    public Builder setOnItemSelectedAction(PendingIntent param1PendingIntent) {
      this.mOnItemSelectedPendingIntent = param1PendingIntent;
      return this;
    }
    
    public Builder setUrlType(int param1Int) {
      this.mType = param1Int;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\browser\browseractions\BrowserActionsIntent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */