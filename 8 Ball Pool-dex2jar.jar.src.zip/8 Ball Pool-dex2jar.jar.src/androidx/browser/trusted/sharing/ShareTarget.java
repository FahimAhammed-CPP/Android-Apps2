package androidx.browser.trusted.sharing;

import android.os.Bundle;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public final class ShareTarget {
  public static final String ENCODING_TYPE_MULTIPART = v416f9e89.xbd520268("1658");
  
  public static final String ENCODING_TYPE_URL_ENCODED = v416f9e89.xbd520268("1659");
  
  public static final String KEY_ACTION = v416f9e89.xbd520268("1660");
  
  public static final String KEY_ENCTYPE = v416f9e89.xbd520268("1661");
  
  public static final String KEY_METHOD = v416f9e89.xbd520268("1662");
  
  public static final String KEY_PARAMS = v416f9e89.xbd520268("1663");
  
  public static final String METHOD_GET = v416f9e89.xbd520268("1664");
  
  public static final String METHOD_POST = v416f9e89.xbd520268("1665");
  
  public final String action;
  
  public final String encodingType;
  
  public final String method;
  
  public final Params params;
  
  public ShareTarget(String paramString1, String paramString2, String paramString3, Params paramParams) {
    this.action = paramString1;
    this.method = paramString2;
    this.encodingType = paramString3;
    this.params = paramParams;
  }
  
  public static ShareTarget fromBundle(Bundle paramBundle) {
    String str1 = paramBundle.getString(v416f9e89.xbd520268("1666"));
    String str2 = paramBundle.getString(v416f9e89.xbd520268("1667"));
    String str3 = paramBundle.getString(v416f9e89.xbd520268("1668"));
    Params params = Params.fromBundle(paramBundle.getBundle(v416f9e89.xbd520268("1669")));
    return (str1 == null || params == null) ? null : new ShareTarget(str1, str2, str3, params);
  }
  
  public Bundle toBundle() {
    Bundle bundle1 = new Bundle();
    String str = this.action;
    bundle1.putString(v416f9e89.xbd520268("1670"), str);
    str = this.method;
    bundle1.putString(v416f9e89.xbd520268("1671"), str);
    str = this.encodingType;
    bundle1.putString(v416f9e89.xbd520268("1672"), str);
    Bundle bundle2 = this.params.toBundle();
    bundle1.putBundle(v416f9e89.xbd520268("1673"), bundle2);
    return bundle1;
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface EncodingType {}
  
  public static final class FileFormField {
    public static final String KEY_ACCEPTED_TYPES = v416f9e89.xbd520268("1633");
    
    public static final String KEY_NAME = v416f9e89.xbd520268("1634");
    
    public final List<String> acceptedTypes;
    
    public final String name;
    
    public FileFormField(String param1String, List<String> param1List) {
      this.name = param1String;
      this.acceptedTypes = Collections.unmodifiableList(param1List);
    }
    
    static FileFormField fromBundle(Bundle param1Bundle) {
      FileFormField fileFormField;
      Bundle bundle = null;
      if (param1Bundle == null)
        return null; 
      String str = param1Bundle.getString(v416f9e89.xbd520268("1635"));
      ArrayList<String> arrayList = param1Bundle.getStringArrayList(v416f9e89.xbd520268("1636"));
      param1Bundle = bundle;
      if (str != null) {
        if (arrayList == null)
          return null; 
        fileFormField = new FileFormField(str, arrayList);
      } 
      return fileFormField;
    }
    
    Bundle toBundle() {
      Bundle bundle = new Bundle();
      String str = this.name;
      bundle.putString(v416f9e89.xbd520268("1637"), str);
      ArrayList<String> arrayList = new ArrayList<String>(this.acceptedTypes);
      bundle.putStringArrayList(v416f9e89.xbd520268("1638"), arrayList);
      return bundle;
    }
  }
  
  public static class Params {
    public static final String KEY_FILES = v416f9e89.xbd520268("1639");
    
    public static final String KEY_TEXT = v416f9e89.xbd520268("1640");
    
    public static final String KEY_TITLE = v416f9e89.xbd520268("1641");
    
    public final List<ShareTarget.FileFormField> files;
    
    public final String text;
    
    public final String title;
    
    public Params(String param1String1, String param1String2, List<ShareTarget.FileFormField> param1List) {
      this.title = param1String1;
      this.text = param1String2;
      this.files = param1List;
    }
    
    static Params fromBundle(Bundle param1Bundle) {
      ArrayList<ShareTarget.FileFormField> arrayList = null;
      if (param1Bundle == null)
        return null; 
      ArrayList arrayList1 = param1Bundle.getParcelableArrayList(v416f9e89.xbd520268("1642"));
      if (arrayList1 != null) {
        ArrayList<ShareTarget.FileFormField> arrayList2 = new ArrayList();
        Iterator<Bundle> iterator = arrayList1.iterator();
        while (true) {
          arrayList = arrayList2;
          if (iterator.hasNext()) {
            arrayList2.add(ShareTarget.FileFormField.fromBundle(iterator.next()));
            continue;
          } 
          break;
        } 
      } 
      return new Params(param1Bundle.getString(v416f9e89.xbd520268("1643")), param1Bundle.getString(v416f9e89.xbd520268("1644")), arrayList);
    }
    
    Bundle toBundle() {
      Bundle bundle = new Bundle();
      String str = this.title;
      bundle.putString(v416f9e89.xbd520268("1645"), str);
      str = this.text;
      bundle.putString(v416f9e89.xbd520268("1646"), str);
      if (this.files != null) {
        ArrayList<Bundle> arrayList = new ArrayList();
        Iterator<ShareTarget.FileFormField> iterator = this.files.iterator();
        while (iterator.hasNext())
          arrayList.add(((ShareTarget.FileFormField)iterator.next()).toBundle()); 
        bundle.putParcelableArrayList(v416f9e89.xbd520268("1647"), arrayList);
      } 
      return bundle;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface RequestMethod {}
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\browser\trusted\sharing\ShareTarget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */