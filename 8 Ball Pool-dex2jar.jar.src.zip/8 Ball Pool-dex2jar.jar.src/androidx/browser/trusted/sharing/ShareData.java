package androidx.browser.trusted.sharing;

import android.net.Uri;
import android.os.Bundle;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.util.ArrayList;
import java.util.List;

public final class ShareData {
  public static final String KEY_TEXT = v416f9e89.xbd520268("1623");
  
  public static final String KEY_TITLE = v416f9e89.xbd520268("1624");
  
  public static final String KEY_URIS = v416f9e89.xbd520268("1625");
  
  public final String text;
  
  public final String title;
  
  public final List<Uri> uris;
  
  public ShareData(String paramString1, String paramString2, List<Uri> paramList) {
    this.title = paramString1;
    this.text = paramString2;
    this.uris = paramList;
  }
  
  public static ShareData fromBundle(Bundle paramBundle) {
    return new ShareData(paramBundle.getString(v416f9e89.xbd520268("1626")), paramBundle.getString(v416f9e89.xbd520268("1627")), paramBundle.getParcelableArrayList(v416f9e89.xbd520268("1628")));
  }
  
  public Bundle toBundle() {
    Bundle bundle = new Bundle();
    String str = this.title;
    bundle.putString(v416f9e89.xbd520268("1629"), str);
    str = this.text;
    bundle.putString(v416f9e89.xbd520268("1630"), str);
    if (this.uris != null) {
      ArrayList<Uri> arrayList = new ArrayList<Uri>(this.uris);
      bundle.putParcelableArrayList(v416f9e89.xbd520268("1631"), arrayList);
    } 
    return bundle;
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\browser\trusted\sharing\ShareData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */