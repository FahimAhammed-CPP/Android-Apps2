package androidx.browser;

public final class R {
  public static final class color {
    public static final int browser_actions_bg_grey = 2131099725;
    
    public static final int browser_actions_divider_color = 2131099726;
    
    public static final int browser_actions_text_color = 2131099727;
    
    public static final int browser_actions_title_color = 2131099728;
  }
  
  public static final class dimen {
    public static final int browser_actions_context_menu_max_width = 2131165331;
    
    public static final int browser_actions_context_menu_min_padding = 2131165332;
  }
  
  public static final class id {
    public static final int browser_actions_header_text = 2131361989;
    
    public static final int browser_actions_menu_item_icon = 2131361990;
    
    public static final int browser_actions_menu_item_text = 2131361991;
    
    public static final int browser_actions_menu_items = 2131361992;
    
    public static final int browser_actions_menu_view = 2131361993;
  }
  
  public static final class layout {
    public static final int browser_actions_context_menu_page = 2131558458;
    
    public static final int browser_actions_context_menu_row = 2131558459;
  }
  
  public static final class string {
    public static final int copy_toast_msg = 2131886346;
    
    public static final int fallback_menu_item_copy_link = 2131886417;
    
    public static final int fallback_menu_item_open_in_browser = 2131886418;
    
    public static final int fallback_menu_item_share_link = 2131886419;
  }
  
  public static final class xml {
    public static final int image_share_filepaths = 2132082690;
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\browser\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */