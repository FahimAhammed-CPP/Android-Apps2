package androidx.browser.customtabs;

import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.customtabs.ICustomTabsCallback;
import android.util.Log;
import androidx.core.app.BundleCompat;
import h8800e55c.pc41fcc5f.v416f9e89;

public class CustomTabsSessionToken {
  private static final String TAG = v416f9e89.xbd520268("1734");
  
  private final CustomTabsCallback mCallback;
  
  final ICustomTabsCallback mCallbackBinder;
  
  private final PendingIntent mSessionId;
  
  CustomTabsSessionToken(ICustomTabsCallback paramICustomTabsCallback, PendingIntent paramPendingIntent) {
    if (paramICustomTabsCallback != null || paramPendingIntent != null) {
      CustomTabsCallback customTabsCallback;
      this.mCallbackBinder = paramICustomTabsCallback;
      this.mSessionId = paramPendingIntent;
      if (paramICustomTabsCallback == null) {
        paramICustomTabsCallback = null;
      } else {
        customTabsCallback = new CustomTabsCallback() {
            public void extraCallback(String param1String, Bundle param1Bundle) {
              try {
                CustomTabsSessionToken.this.mCallbackBinder.extraCallback(param1String, param1Bundle);
                return;
              } catch (RemoteException remoteException) {
                Log.e(v416f9e89.xbd520268("1679"), v416f9e89.xbd520268("1680"));
                return;
              } 
            }
            
            public Bundle extraCallbackWithResult(String param1String, Bundle param1Bundle) {
              try {
                return CustomTabsSessionToken.this.mCallbackBinder.extraCallbackWithResult(param1String, param1Bundle);
              } catch (RemoteException remoteException) {
                Log.e(v416f9e89.xbd520268("1681"), v416f9e89.xbd520268("1682"));
                return null;
              } 
            }
            
            public void onMessageChannelReady(Bundle param1Bundle) {
              try {
                CustomTabsSessionToken.this.mCallbackBinder.onMessageChannelReady(param1Bundle);
                return;
              } catch (RemoteException remoteException) {
                Log.e(v416f9e89.xbd520268("1683"), v416f9e89.xbd520268("1684"));
                return;
              } 
            }
            
            public void onNavigationEvent(int param1Int, Bundle param1Bundle) {
              try {
                CustomTabsSessionToken.this.mCallbackBinder.onNavigationEvent(param1Int, param1Bundle);
                return;
              } catch (RemoteException remoteException) {
                Log.e(v416f9e89.xbd520268("1685"), v416f9e89.xbd520268("1686"));
                return;
              } 
            }
            
            public void onPostMessage(String param1String, Bundle param1Bundle) {
              try {
                CustomTabsSessionToken.this.mCallbackBinder.onPostMessage(param1String, param1Bundle);
                return;
              } catch (RemoteException remoteException) {
                Log.e(v416f9e89.xbd520268("1687"), v416f9e89.xbd520268("1688"));
                return;
              } 
            }
            
            public void onRelationshipValidationResult(int param1Int, Uri param1Uri, boolean param1Boolean, Bundle param1Bundle) {
              try {
                CustomTabsSessionToken.this.mCallbackBinder.onRelationshipValidationResult(param1Int, param1Uri, param1Boolean, param1Bundle);
                return;
              } catch (RemoteException remoteException) {
                Log.e(v416f9e89.xbd520268("1689"), v416f9e89.xbd520268("1690"));
                return;
              } 
            }
          };
      } 
      this.mCallback = customTabsCallback;
      return;
    } 
    throw new IllegalStateException(v416f9e89.xbd520268("1735"));
  }
  
  public static CustomTabsSessionToken createMockSessionTokenForTesting() {
    return new CustomTabsSessionToken((ICustomTabsCallback)new MockCallback(), null);
  }
  
  private IBinder getCallbackBinderAssertNotNull() {
    ICustomTabsCallback iCustomTabsCallback = this.mCallbackBinder;
    if (iCustomTabsCallback != null)
      return iCustomTabsCallback.asBinder(); 
    throw new IllegalStateException(v416f9e89.xbd520268("1736"));
  }
  
  public static CustomTabsSessionToken getSessionTokenFromIntent(Intent paramIntent) {
    ICustomTabsCallback iCustomTabsCallback;
    Bundle bundle = paramIntent.getExtras();
    Intent intent = null;
    if (bundle == null)
      return null; 
    IBinder iBinder = BundleCompat.getBinder(bundle, v416f9e89.xbd520268("1737"));
    PendingIntent pendingIntent = (PendingIntent)paramIntent.getParcelableExtra(v416f9e89.xbd520268("1738"));
    if (iBinder == null && pendingIntent == null)
      return null; 
    if (iBinder == null) {
      paramIntent = intent;
    } else {
      iCustomTabsCallback = ICustomTabsCallback.Stub.asInterface(iBinder);
    } 
    return new CustomTabsSessionToken(iCustomTabsCallback, pendingIntent);
  }
  
  public boolean equals(Object paramObject) {
    boolean bool1;
    if (!(paramObject instanceof CustomTabsSessionToken))
      return false; 
    paramObject = paramObject;
    PendingIntent pendingIntent1 = paramObject.getId();
    PendingIntent pendingIntent2 = this.mSessionId;
    boolean bool2 = true;
    if (pendingIntent2 == null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (pendingIntent1 != null)
      bool2 = false; 
    return (bool1 != bool2) ? false : ((pendingIntent2 != null) ? pendingIntent2.equals(pendingIntent1) : getCallbackBinderAssertNotNull().equals(paramObject.getCallbackBinderAssertNotNull()));
  }
  
  public CustomTabsCallback getCallback() {
    return this.mCallback;
  }
  
  IBinder getCallbackBinder() {
    ICustomTabsCallback iCustomTabsCallback = this.mCallbackBinder;
    return (iCustomTabsCallback == null) ? null : iCustomTabsCallback.asBinder();
  }
  
  PendingIntent getId() {
    return this.mSessionId;
  }
  
  public boolean hasCallback() {
    return (this.mCallbackBinder != null);
  }
  
  public boolean hasId() {
    return (this.mSessionId != null);
  }
  
  public int hashCode() {
    PendingIntent pendingIntent = this.mSessionId;
    return (pendingIntent != null) ? pendingIntent.hashCode() : getCallbackBinderAssertNotNull().hashCode();
  }
  
  public boolean isAssociatedWith(CustomTabsSession paramCustomTabsSession) {
    return paramCustomTabsSession.getBinder().equals(this.mCallbackBinder);
  }
  
  static class MockCallback extends ICustomTabsCallback.Stub {
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public void extraCallback(String param1String, Bundle param1Bundle) {}
    
    public Bundle extraCallbackWithResult(String param1String, Bundle param1Bundle) {
      return null;
    }
    
    public void onMessageChannelReady(Bundle param1Bundle) {}
    
    public void onNavigationEvent(int param1Int, Bundle param1Bundle) {}
    
    public void onPostMessage(String param1String, Bundle param1Bundle) {}
    
    public void onRelationshipValidationResult(int param1Int, Uri param1Uri, boolean param1Boolean, Bundle param1Bundle) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\browser\customtabs\CustomTabsSessionToken.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */