package androidx.browser.customtabs;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.util.SparseArray;
import android.widget.RemoteViews;
import androidx.core.app.ActivityOptionsCompat;
import androidx.core.app.BundleCompat;
import androidx.core.content.ContextCompat;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;

public final class CustomTabsIntent {
  public static final int COLOR_SCHEME_DARK = 2;
  
  public static final int COLOR_SCHEME_LIGHT = 1;
  
  private static final int COLOR_SCHEME_MAX = 2;
  
  public static final int COLOR_SCHEME_SYSTEM = 0;
  
  public static final String EXTRA_ACTION_BUTTON_BUNDLE = v416f9e89.xbd520268("1589");
  
  public static final String EXTRA_CLOSE_BUTTON_ICON = v416f9e89.xbd520268("1590");
  
  public static final String EXTRA_COLOR_SCHEME = v416f9e89.xbd520268("1591");
  
  public static final String EXTRA_COLOR_SCHEME_PARAMS = v416f9e89.xbd520268("1592");
  
  @Deprecated
  public static final String EXTRA_DEFAULT_SHARE_MENU_ITEM = v416f9e89.xbd520268("1593");
  
  public static final String EXTRA_ENABLE_INSTANT_APPS = v416f9e89.xbd520268("1594");
  
  public static final String EXTRA_ENABLE_URLBAR_HIDING = v416f9e89.xbd520268("1595");
  
  public static final String EXTRA_EXIT_ANIMATION_BUNDLE = v416f9e89.xbd520268("1596");
  
  public static final String EXTRA_MENU_ITEMS = v416f9e89.xbd520268("1597");
  
  public static final String EXTRA_NAVIGATION_BAR_COLOR = v416f9e89.xbd520268("1598");
  
  public static final String EXTRA_NAVIGATION_BAR_DIVIDER_COLOR = v416f9e89.xbd520268("1599");
  
  public static final String EXTRA_REMOTEVIEWS = v416f9e89.xbd520268("1600");
  
  public static final String EXTRA_REMOTEVIEWS_CLICKED_ID = v416f9e89.xbd520268("1601");
  
  public static final String EXTRA_REMOTEVIEWS_PENDINGINTENT = v416f9e89.xbd520268("1602");
  
  public static final String EXTRA_REMOTEVIEWS_VIEW_IDS = v416f9e89.xbd520268("1603");
  
  public static final String EXTRA_SECONDARY_TOOLBAR_COLOR = v416f9e89.xbd520268("1604");
  
  public static final String EXTRA_SESSION = v416f9e89.xbd520268("1605");
  
  public static final String EXTRA_SESSION_ID = v416f9e89.xbd520268("1606");
  
  public static final String EXTRA_SHARE_STATE = v416f9e89.xbd520268("1607");
  
  public static final String EXTRA_TINT_ACTION_BUTTON = v416f9e89.xbd520268("1608");
  
  public static final String EXTRA_TITLE_VISIBILITY_STATE = v416f9e89.xbd520268("1609");
  
  public static final String EXTRA_TOOLBAR_COLOR = v416f9e89.xbd520268("1610");
  
  public static final String EXTRA_TOOLBAR_ITEMS = v416f9e89.xbd520268("1611");
  
  private static final String EXTRA_USER_OPT_OUT_FROM_CUSTOM_TABS = v416f9e89.xbd520268("1612");
  
  public static final String KEY_DESCRIPTION = v416f9e89.xbd520268("1613");
  
  public static final String KEY_ICON = v416f9e89.xbd520268("1614");
  
  public static final String KEY_ID = v416f9e89.xbd520268("1615");
  
  public static final String KEY_MENU_ITEM_TITLE = v416f9e89.xbd520268("1616");
  
  public static final String KEY_PENDING_INTENT = v416f9e89.xbd520268("1617");
  
  private static final int MAX_TOOLBAR_ITEMS = 5;
  
  public static final int NO_TITLE = 0;
  
  public static final int SHARE_STATE_DEFAULT = 0;
  
  private static final int SHARE_STATE_MAX = 2;
  
  public static final int SHARE_STATE_OFF = 2;
  
  public static final int SHARE_STATE_ON = 1;
  
  public static final int SHOW_PAGE_TITLE = 1;
  
  public static final int TOOLBAR_ACTION_BUTTON_ID = 0;
  
  public final Intent intent;
  
  public final Bundle startAnimationBundle;
  
  CustomTabsIntent(Intent paramIntent, Bundle paramBundle) {
    this.intent = paramIntent;
    this.startAnimationBundle = paramBundle;
  }
  
  public static CustomTabColorSchemeParams getColorSchemeParams(Intent paramIntent, int paramInt) {
    if (paramInt >= 0 && paramInt <= 2 && paramInt != 0) {
      Bundle bundle = paramIntent.getExtras();
      if (bundle == null)
        return CustomTabColorSchemeParams.fromBundle(null); 
      CustomTabColorSchemeParams customTabColorSchemeParams = CustomTabColorSchemeParams.fromBundle(bundle);
      SparseArray sparseArray = bundle.getSparseParcelableArray(v416f9e89.xbd520268("1618"));
      if (sparseArray != null) {
        Bundle bundle1 = (Bundle)sparseArray.get(paramInt);
        if (bundle1 != null)
          return CustomTabColorSchemeParams.fromBundle(bundle1).withDefaults(customTabColorSchemeParams); 
      } 
      return customTabColorSchemeParams;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(v416f9e89.xbd520268("1619"));
    stringBuilder.append(paramInt);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public static int getMaxToolbarItems() {
    return 5;
  }
  
  public static Intent setAlwaysUseBrowserUI(Intent paramIntent) {
    Intent intent = paramIntent;
    if (paramIntent == null)
      intent = new Intent(v416f9e89.xbd520268("1620")); 
    intent.addFlags(268435456);
    intent.putExtra(v416f9e89.xbd520268("1621"), true);
    return intent;
  }
  
  public static boolean shouldAlwaysUseBrowserUI(Intent paramIntent) {
    String str = v416f9e89.xbd520268("1622");
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (paramIntent.getBooleanExtra(str, false)) {
      bool1 = bool2;
      if ((paramIntent.getFlags() & 0x10000000) != 0)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public void launchUrl(Context paramContext, Uri paramUri) {
    this.intent.setData(paramUri);
    ContextCompat.startActivity(paramContext, this.intent, this.startAnimationBundle);
  }
  
  public static final class Builder {
    private ArrayList<Bundle> mActionButtons;
    
    private SparseArray<Bundle> mColorSchemeParamBundles;
    
    private final CustomTabColorSchemeParams.Builder mDefaultColorSchemeBuilder = new CustomTabColorSchemeParams.Builder();
    
    private Bundle mDefaultColorSchemeBundle;
    
    private boolean mInstantAppsEnabled = true;
    
    private final Intent mIntent = new Intent(v416f9e89.xbd520268("1540"));
    
    private ArrayList<Bundle> mMenuItems;
    
    private int mShareState = 0;
    
    private Bundle mStartAnimationBundle;
    
    public Builder() {}
    
    public Builder(CustomTabsSession param1CustomTabsSession) {
      if (param1CustomTabsSession != null)
        setSession(param1CustomTabsSession); 
    }
    
    private void setSessionParameters(IBinder param1IBinder, PendingIntent param1PendingIntent) {
      Bundle bundle = new Bundle();
      BundleCompat.putBinder(bundle, v416f9e89.xbd520268("1542"), param1IBinder);
      if (param1PendingIntent != null)
        bundle.putParcelable(v416f9e89.xbd520268("1543"), (Parcelable)param1PendingIntent); 
      this.mIntent.putExtras(bundle);
    }
    
    @Deprecated
    public Builder addDefaultShareMenuItem() {
      setShareState(1);
      return this;
    }
    
    public Builder addMenuItem(String param1String, PendingIntent param1PendingIntent) {
      if (this.mMenuItems == null)
        this.mMenuItems = new ArrayList<Bundle>(); 
      Bundle bundle = new Bundle();
      bundle.putString(v416f9e89.xbd520268("1544"), param1String);
      bundle.putParcelable(v416f9e89.xbd520268("1545"), (Parcelable)param1PendingIntent);
      this.mMenuItems.add(bundle);
      return this;
    }
    
    @Deprecated
    public Builder addToolbarItem(int param1Int, Bitmap param1Bitmap, String param1String, PendingIntent param1PendingIntent) throws IllegalStateException {
      if (this.mActionButtons == null)
        this.mActionButtons = new ArrayList<Bundle>(); 
      if (this.mActionButtons.size() < 5) {
        Bundle bundle = new Bundle();
        bundle.putInt(v416f9e89.xbd520268("1546"), param1Int);
        bundle.putParcelable(v416f9e89.xbd520268("1547"), (Parcelable)param1Bitmap);
        bundle.putString(v416f9e89.xbd520268("1548"), param1String);
        bundle.putParcelable(v416f9e89.xbd520268("1549"), (Parcelable)param1PendingIntent);
        this.mActionButtons.add(bundle);
        return this;
      } 
      throw new IllegalStateException(v416f9e89.xbd520268("1550"));
    }
    
    public CustomTabsIntent build() {
      if (!this.mIntent.hasExtra(v416f9e89.xbd520268("1551")))
        setSessionParameters(null, null); 
      ArrayList<Bundle> arrayList = this.mMenuItems;
      if (arrayList != null)
        this.mIntent.putParcelableArrayListExtra(v416f9e89.xbd520268("1552"), arrayList); 
      arrayList = this.mActionButtons;
      if (arrayList != null)
        this.mIntent.putParcelableArrayListExtra(v416f9e89.xbd520268("1553"), arrayList); 
      Intent intent2 = this.mIntent;
      boolean bool = this.mInstantAppsEnabled;
      intent2.putExtra(v416f9e89.xbd520268("1554"), bool);
      this.mIntent.putExtras(this.mDefaultColorSchemeBuilder.build().toBundle());
      Bundle bundle = this.mDefaultColorSchemeBundle;
      if (bundle != null)
        this.mIntent.putExtras(bundle); 
      if (this.mColorSchemeParamBundles != null) {
        bundle = new Bundle();
        SparseArray<Bundle> sparseArray = this.mColorSchemeParamBundles;
        bundle.putSparseParcelableArray(v416f9e89.xbd520268("1555"), sparseArray);
        this.mIntent.putExtras(bundle);
      } 
      Intent intent1 = this.mIntent;
      int i = this.mShareState;
      intent1.putExtra(v416f9e89.xbd520268("1556"), i);
      return new CustomTabsIntent(this.mIntent, this.mStartAnimationBundle);
    }
    
    @Deprecated
    public Builder enableUrlBarHiding() {
      this.mIntent.putExtra(v416f9e89.xbd520268("1557"), true);
      return this;
    }
    
    public Builder setActionButton(Bitmap param1Bitmap, String param1String, PendingIntent param1PendingIntent) {
      return setActionButton(param1Bitmap, param1String, param1PendingIntent, false);
    }
    
    public Builder setActionButton(Bitmap param1Bitmap, String param1String, PendingIntent param1PendingIntent, boolean param1Boolean) {
      Bundle bundle = new Bundle();
      bundle.putInt(v416f9e89.xbd520268("1558"), 0);
      bundle.putParcelable(v416f9e89.xbd520268("1559"), (Parcelable)param1Bitmap);
      bundle.putString(v416f9e89.xbd520268("1560"), param1String);
      bundle.putParcelable(v416f9e89.xbd520268("1561"), (Parcelable)param1PendingIntent);
      this.mIntent.putExtra(v416f9e89.xbd520268("1562"), bundle);
      this.mIntent.putExtra(v416f9e89.xbd520268("1563"), param1Boolean);
      return this;
    }
    
    public Builder setCloseButtonIcon(Bitmap param1Bitmap) {
      this.mIntent.putExtra(v416f9e89.xbd520268("1564"), (Parcelable)param1Bitmap);
      return this;
    }
    
    public Builder setColorScheme(int param1Int) {
      if (param1Int >= 0 && param1Int <= 2) {
        this.mIntent.putExtra(v416f9e89.xbd520268("1565"), param1Int);
        return this;
      } 
      throw new IllegalArgumentException(v416f9e89.xbd520268("1566"));
    }
    
    public Builder setColorSchemeParams(int param1Int, CustomTabColorSchemeParams param1CustomTabColorSchemeParams) {
      if (param1Int >= 0 && param1Int <= 2 && param1Int != 0) {
        if (this.mColorSchemeParamBundles == null)
          this.mColorSchemeParamBundles = new SparseArray(); 
        this.mColorSchemeParamBundles.put(param1Int, param1CustomTabColorSchemeParams.toBundle());
        return this;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("1567"));
      stringBuilder.append(param1Int);
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public Builder setDefaultColorSchemeParams(CustomTabColorSchemeParams param1CustomTabColorSchemeParams) {
      this.mDefaultColorSchemeBundle = param1CustomTabColorSchemeParams.toBundle();
      return this;
    }
    
    @Deprecated
    public Builder setDefaultShareMenuItemEnabled(boolean param1Boolean) {
      if (param1Boolean) {
        setShareState(1);
        return this;
      } 
      setShareState(2);
      return this;
    }
    
    public Builder setExitAnimations(Context param1Context, int param1Int1, int param1Int2) {
      Bundle bundle = ActivityOptionsCompat.makeCustomAnimation(param1Context, param1Int1, param1Int2).toBundle();
      this.mIntent.putExtra(v416f9e89.xbd520268("1568"), bundle);
      return this;
    }
    
    public Builder setInstantAppsEnabled(boolean param1Boolean) {
      this.mInstantAppsEnabled = param1Boolean;
      return this;
    }
    
    @Deprecated
    public Builder setNavigationBarColor(int param1Int) {
      this.mDefaultColorSchemeBuilder.setNavigationBarColor(param1Int);
      return this;
    }
    
    @Deprecated
    public Builder setNavigationBarDividerColor(int param1Int) {
      this.mDefaultColorSchemeBuilder.setNavigationBarDividerColor(param1Int);
      return this;
    }
    
    public Builder setPendingSession(CustomTabsSession.PendingSession param1PendingSession) {
      setSessionParameters(null, param1PendingSession.getId());
      return this;
    }
    
    @Deprecated
    public Builder setSecondaryToolbarColor(int param1Int) {
      this.mDefaultColorSchemeBuilder.setSecondaryToolbarColor(param1Int);
      return this;
    }
    
    public Builder setSecondaryToolbarViews(RemoteViews param1RemoteViews, int[] param1ArrayOfint, PendingIntent param1PendingIntent) {
      this.mIntent.putExtra(v416f9e89.xbd520268("1569"), (Parcelable)param1RemoteViews);
      this.mIntent.putExtra(v416f9e89.xbd520268("1570"), param1ArrayOfint);
      this.mIntent.putExtra(v416f9e89.xbd520268("1571"), (Parcelable)param1PendingIntent);
      return this;
    }
    
    public Builder setSession(CustomTabsSession param1CustomTabsSession) {
      this.mIntent.setPackage(param1CustomTabsSession.getComponentName().getPackageName());
      setSessionParameters(param1CustomTabsSession.getBinder(), param1CustomTabsSession.getId());
      return this;
    }
    
    public Builder setShareState(int param1Int) {
      if (param1Int >= 0 && param1Int <= 2) {
        this.mShareState = param1Int;
        String str = v416f9e89.xbd520268("1572");
        if (param1Int == 1) {
          this.mIntent.putExtra(str, true);
          return this;
        } 
        if (param1Int == 2) {
          this.mIntent.putExtra(str, false);
          return this;
        } 
        this.mIntent.removeExtra(str);
        return this;
      } 
      throw new IllegalArgumentException(v416f9e89.xbd520268("1573"));
    }
    
    public Builder setShowTitle(boolean param1Boolean) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    public Builder setStartAnimations(Context param1Context, int param1Int1, int param1Int2) {
      this.mStartAnimationBundle = ActivityOptionsCompat.makeCustomAnimation(param1Context, param1Int1, param1Int2).toBundle();
      return this;
    }
    
    @Deprecated
    public Builder setToolbarColor(int param1Int) {
      this.mDefaultColorSchemeBuilder.setToolbarColor(param1Int);
      return this;
    }
    
    public Builder setUrlBarHidingEnabled(boolean param1Boolean) {
      this.mIntent.putExtra(v416f9e89.xbd520268("1575"), param1Boolean);
      return this;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface ColorScheme {}
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface ShareState {}
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\browser\customtabs\CustomTabsIntent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */