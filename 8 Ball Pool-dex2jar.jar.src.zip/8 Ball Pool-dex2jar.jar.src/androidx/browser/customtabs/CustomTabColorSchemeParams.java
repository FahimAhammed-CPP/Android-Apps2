package androidx.browser.customtabs;

import android.os.Bundle;
import h8800e55c.pc41fcc5f.v416f9e89;

public final class CustomTabColorSchemeParams {
  public final Integer navigationBarColor;
  
  public final Integer navigationBarDividerColor;
  
  public final Integer secondaryToolbarColor;
  
  public final Integer toolbarColor;
  
  CustomTabColorSchemeParams(Integer paramInteger1, Integer paramInteger2, Integer paramInteger3, Integer paramInteger4) {
    this.toolbarColor = paramInteger1;
    this.secondaryToolbarColor = paramInteger2;
    this.navigationBarColor = paramInteger3;
    this.navigationBarDividerColor = paramInteger4;
  }
  
  static CustomTabColorSchemeParams fromBundle(Bundle paramBundle) {
    Bundle bundle = paramBundle;
    if (paramBundle == null)
      bundle = new Bundle(0); 
    return new CustomTabColorSchemeParams((Integer)bundle.get(v416f9e89.xbd520268("1485")), (Integer)bundle.get(v416f9e89.xbd520268("1486")), (Integer)bundle.get(v416f9e89.xbd520268("1487")), (Integer)bundle.get(v416f9e89.xbd520268("1488")));
  }
  
  Bundle toBundle() {
    Bundle bundle = new Bundle();
    Integer integer = this.toolbarColor;
    if (integer != null) {
      int i = integer.intValue();
      bundle.putInt(v416f9e89.xbd520268("1489"), i);
    } 
    integer = this.secondaryToolbarColor;
    if (integer != null) {
      int i = integer.intValue();
      bundle.putInt(v416f9e89.xbd520268("1490"), i);
    } 
    integer = this.navigationBarColor;
    if (integer != null) {
      int i = integer.intValue();
      bundle.putInt(v416f9e89.xbd520268("1491"), i);
    } 
    integer = this.navigationBarDividerColor;
    if (integer != null) {
      int i = integer.intValue();
      bundle.putInt(v416f9e89.xbd520268("1492"), i);
    } 
    return bundle;
  }
  
  CustomTabColorSchemeParams withDefaults(CustomTabColorSchemeParams paramCustomTabColorSchemeParams) {
    Integer integer2 = this.toolbarColor;
    Integer integer1 = integer2;
    if (integer2 == null)
      integer1 = paramCustomTabColorSchemeParams.toolbarColor; 
    Integer integer3 = this.secondaryToolbarColor;
    integer2 = integer3;
    if (integer3 == null)
      integer2 = paramCustomTabColorSchemeParams.secondaryToolbarColor; 
    Integer integer4 = this.navigationBarColor;
    integer3 = integer4;
    if (integer4 == null)
      integer3 = paramCustomTabColorSchemeParams.navigationBarColor; 
    Integer integer5 = this.navigationBarDividerColor;
    integer4 = integer5;
    if (integer5 == null)
      integer4 = paramCustomTabColorSchemeParams.navigationBarDividerColor; 
    return new CustomTabColorSchemeParams(integer1, integer2, integer3, integer4);
  }
  
  public static final class Builder {
    private Integer mNavigationBarColor;
    
    private Integer mNavigationBarDividerColor;
    
    private Integer mSecondaryToolbarColor;
    
    private Integer mToolbarColor;
    
    public CustomTabColorSchemeParams build() {
      return new CustomTabColorSchemeParams(this.mToolbarColor, this.mSecondaryToolbarColor, this.mNavigationBarColor, this.mNavigationBarDividerColor);
    }
    
    public Builder setNavigationBarColor(int param1Int) {
      this.mNavigationBarColor = Integer.valueOf(param1Int | 0xFF000000);
      return this;
    }
    
    public Builder setNavigationBarDividerColor(int param1Int) {
      this.mNavigationBarDividerColor = Integer.valueOf(param1Int);
      return this;
    }
    
    public Builder setSecondaryToolbarColor(int param1Int) {
      this.mSecondaryToolbarColor = Integer.valueOf(param1Int);
      return this;
    }
    
    public Builder setToolbarColor(int param1Int) {
      this.mToolbarColor = Integer.valueOf(param1Int | 0xFF000000);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\browser\customtabs\CustomTabColorSchemeParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */