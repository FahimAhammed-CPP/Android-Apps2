package androidx.core.animation;

import android.animation.Animator;
import h8800e55c.pc41fcc5f.v416f9e89;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;

final class Api19Impl {
  public static final Api19Impl INSTANCE = new Api19Impl();
  
  @JvmStatic
  public static final void addPauseListener(Animator paramAnimator, Animator.AnimatorPauseListener paramAnimatorPauseListener) {
    Intrinsics.checkNotNullParameter(paramAnimator, v416f9e89.xbd520268("2919"));
    Intrinsics.checkNotNullParameter(paramAnimatorPauseListener, v416f9e89.xbd520268("2920"));
    paramAnimator.addPauseListener(paramAnimatorPauseListener);
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\core\animation\Api19Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */