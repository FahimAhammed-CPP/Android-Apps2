package androidx.core.animation;

import android.animation.Animator;
import h8800e55c.pc41fcc5f.v416f9e89;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

public final class AnimatorKt {
  public static final Animator.AnimatorListener addListener(Animator paramAnimator, Function1<? super Animator, Unit> paramFunction11, Function1<? super Animator, Unit> paramFunction12, Function1<? super Animator, Unit> paramFunction13, Function1<? super Animator, Unit> paramFunction14) {
    Intrinsics.checkNotNullParameter(paramAnimator, v416f9e89.xbd520268("2892"));
    Intrinsics.checkNotNullParameter(paramFunction11, v416f9e89.xbd520268("2893"));
    Intrinsics.checkNotNullParameter(paramFunction12, v416f9e89.xbd520268("2894"));
    Intrinsics.checkNotNullParameter(paramFunction13, v416f9e89.xbd520268("2895"));
    Intrinsics.checkNotNullParameter(paramFunction14, v416f9e89.xbd520268("2896"));
    AnimatorKt$addListener$listener$1 animatorKt$addListener$listener$1 = new AnimatorKt$addListener$listener$1(paramFunction14, paramFunction11, paramFunction13, paramFunction12);
    paramAnimator.addListener(animatorKt$addListener$listener$1);
    return animatorKt$addListener$listener$1;
  }
  
  public static final Animator.AnimatorPauseListener addPauseListener(Animator paramAnimator, Function1<? super Animator, Unit> paramFunction11, Function1<? super Animator, Unit> paramFunction12) {
    Intrinsics.checkNotNullParameter(paramAnimator, v416f9e89.xbd520268("2902"));
    Intrinsics.checkNotNullParameter(paramFunction11, v416f9e89.xbd520268("2903"));
    Intrinsics.checkNotNullParameter(paramFunction12, v416f9e89.xbd520268("2904"));
    AnimatorKt$addPauseListener$listener$1 animatorKt$addPauseListener$listener$1 = new AnimatorKt$addPauseListener$listener$1(paramFunction12, paramFunction11);
    Api19Impl.addPauseListener(paramAnimator, animatorKt$addPauseListener$listener$1);
    return animatorKt$addPauseListener$listener$1;
  }
  
  public static final Animator.AnimatorListener doOnCancel(Animator paramAnimator, Function1<? super Animator, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramAnimator, v416f9e89.xbd520268("2905"));
    Intrinsics.checkNotNullParameter(paramFunction1, v416f9e89.xbd520268("2906"));
    AnimatorKt$doOnCancel$$inlined$addListener$default$1 animatorKt$doOnCancel$$inlined$addListener$default$1 = new AnimatorKt$doOnCancel$$inlined$addListener$default$1(paramFunction1);
    paramAnimator.addListener(animatorKt$doOnCancel$$inlined$addListener$default$1);
    return animatorKt$doOnCancel$$inlined$addListener$default$1;
  }
  
  public static final Animator.AnimatorListener doOnEnd(Animator paramAnimator, Function1<? super Animator, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramAnimator, v416f9e89.xbd520268("2907"));
    Intrinsics.checkNotNullParameter(paramFunction1, v416f9e89.xbd520268("2908"));
    AnimatorKt$doOnEnd$$inlined$addListener$default$1 animatorKt$doOnEnd$$inlined$addListener$default$1 = new AnimatorKt$doOnEnd$$inlined$addListener$default$1(paramFunction1);
    paramAnimator.addListener(animatorKt$doOnEnd$$inlined$addListener$default$1);
    return animatorKt$doOnEnd$$inlined$addListener$default$1;
  }
  
  public static final Animator.AnimatorPauseListener doOnPause(Animator paramAnimator, Function1<? super Animator, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramAnimator, v416f9e89.xbd520268("2909"));
    Intrinsics.checkNotNullParameter(paramFunction1, v416f9e89.xbd520268("2910"));
    return addPauseListener$default(paramAnimator, null, paramFunction1, 1, null);
  }
  
  public static final Animator.AnimatorListener doOnRepeat(Animator paramAnimator, Function1<? super Animator, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramAnimator, v416f9e89.xbd520268("2911"));
    Intrinsics.checkNotNullParameter(paramFunction1, v416f9e89.xbd520268("2912"));
    AnimatorKt$doOnRepeat$$inlined$addListener$default$1 animatorKt$doOnRepeat$$inlined$addListener$default$1 = new AnimatorKt$doOnRepeat$$inlined$addListener$default$1(paramFunction1);
    paramAnimator.addListener(animatorKt$doOnRepeat$$inlined$addListener$default$1);
    return animatorKt$doOnRepeat$$inlined$addListener$default$1;
  }
  
  public static final Animator.AnimatorPauseListener doOnResume(Animator paramAnimator, Function1<? super Animator, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramAnimator, v416f9e89.xbd520268("2913"));
    Intrinsics.checkNotNullParameter(paramFunction1, v416f9e89.xbd520268("2914"));
    return addPauseListener$default(paramAnimator, paramFunction1, null, 2, null);
  }
  
  public static final Animator.AnimatorListener doOnStart(Animator paramAnimator, Function1<? super Animator, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramAnimator, v416f9e89.xbd520268("2915"));
    Intrinsics.checkNotNullParameter(paramFunction1, v416f9e89.xbd520268("2916"));
    AnimatorKt$doOnStart$$inlined$addListener$default$1 animatorKt$doOnStart$$inlined$addListener$default$1 = new AnimatorKt$doOnStart$$inlined$addListener$default$1(paramFunction1);
    paramAnimator.addListener(animatorKt$doOnStart$$inlined$addListener$default$1);
    return animatorKt$doOnStart$$inlined$addListener$default$1;
  }
  
  public static final class AnimatorKt$addListener$1 extends Lambda implements Function1<Animator, Unit> {
    public static final AnimatorKt$addListener$1 INSTANCE = new AnimatorKt$addListener$1();
    
    public AnimatorKt$addListener$1() {
      super(1);
    }
    
    public final void invoke(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2861"));
    }
  }
  
  public static final class AnimatorKt$addListener$2 extends Lambda implements Function1<Animator, Unit> {
    public static final AnimatorKt$addListener$2 INSTANCE = new AnimatorKt$addListener$2();
    
    public AnimatorKt$addListener$2() {
      super(1);
    }
    
    public final void invoke(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2869"));
    }
  }
  
  public static final class AnimatorKt$addListener$3 extends Lambda implements Function1<Animator, Unit> {
    public static final AnimatorKt$addListener$3 INSTANCE = new AnimatorKt$addListener$3();
    
    public AnimatorKt$addListener$3() {
      super(1);
    }
    
    public final void invoke(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2921"));
    }
  }
  
  public static final class AnimatorKt$addListener$4 extends Lambda implements Function1<Animator, Unit> {
    public static final AnimatorKt$addListener$4 INSTANCE = new AnimatorKt$addListener$4();
    
    public AnimatorKt$addListener$4() {
      super(1);
    }
    
    public final void invoke(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2862"));
    }
  }
  
  public static final class AnimatorKt$addListener$listener$1 implements Animator.AnimatorListener {
    public AnimatorKt$addListener$listener$1(Function1<? super Animator, Unit> param1Function11, Function1<? super Animator, Unit> param1Function12, Function1<? super Animator, Unit> param1Function13, Function1<? super Animator, Unit> param1Function14) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2864"));
      this.$onCancel.invoke(param1Animator);
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2865"));
      this.$onEnd.invoke(param1Animator);
    }
    
    public void onAnimationRepeat(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2866"));
      this.$onRepeat.invoke(param1Animator);
    }
    
    public void onAnimationStart(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2867"));
      this.$onStart.invoke(param1Animator);
    }
  }
  
  static final class AnimatorKt$addPauseListener$1 extends Lambda implements Function1<Animator, Unit> {
    public static final AnimatorKt$addPauseListener$1 INSTANCE = new AnimatorKt$addPauseListener$1();
    
    AnimatorKt$addPauseListener$1() {
      super(1);
    }
    
    public final void invoke(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2868"));
    }
  }
  
  static final class AnimatorKt$addPauseListener$2 extends Lambda implements Function1<Animator, Unit> {
    public static final AnimatorKt$addPauseListener$2 INSTANCE = new AnimatorKt$addPauseListener$2();
    
    AnimatorKt$addPauseListener$2() {
      super(1);
    }
    
    public final void invoke(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2870"));
    }
  }
  
  public static final class AnimatorKt$addPauseListener$listener$1 implements Animator.AnimatorPauseListener {
    AnimatorKt$addPauseListener$listener$1(Function1<? super Animator, Unit> param1Function11, Function1<? super Animator, Unit> param1Function12) {}
    
    public void onAnimationPause(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2871"));
      this.$onPause.invoke(param1Animator);
    }
    
    public void onAnimationResume(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2872"));
      this.$onResume.invoke(param1Animator);
    }
  }
  
  public static final class AnimatorKt$doOnCancel$$inlined$addListener$default$1 implements Animator.AnimatorListener {
    public AnimatorKt$doOnCancel$$inlined$addListener$default$1(Function1 param1Function1) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2922"));
      this.$onCancel.invoke(param1Animator);
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2923"));
    }
    
    public void onAnimationRepeat(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2924"));
    }
    
    public void onAnimationStart(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2925"));
    }
  }
  
  public static final class AnimatorKt$doOnEnd$$inlined$addListener$default$1 implements Animator.AnimatorListener {
    public AnimatorKt$doOnEnd$$inlined$addListener$default$1(Function1 param1Function1) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2873"));
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2874"));
      this.$onEnd.invoke(param1Animator);
    }
    
    public void onAnimationRepeat(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2875"));
    }
    
    public void onAnimationStart(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2876"));
    }
  }
  
  public static final class AnimatorKt$doOnRepeat$$inlined$addListener$default$1 implements Animator.AnimatorListener {
    public AnimatorKt$doOnRepeat$$inlined$addListener$default$1(Function1 param1Function1) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2877"));
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2878"));
    }
    
    public void onAnimationRepeat(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2879"));
      this.$onRepeat.invoke(param1Animator);
    }
    
    public void onAnimationStart(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2880"));
    }
  }
  
  public static final class AnimatorKt$doOnStart$$inlined$addListener$default$1 implements Animator.AnimatorListener {
    public AnimatorKt$doOnStart$$inlined$addListener$default$1(Function1 param1Function1) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2888"));
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2889"));
    }
    
    public void onAnimationRepeat(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2890"));
    }
    
    public void onAnimationStart(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, v416f9e89.xbd520268("2891"));
      this.$onStart.invoke(param1Animator);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\core\animation\AnimatorKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */