package androidx.core.app;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import androidx.collection.SimpleArrayMap;
import androidx.core.os.BuildCompat;
import androidx.core.view.KeyEventDispatcher;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleRegistry;
import androidx.lifecycle.ReportFragment;
import h8800e55c.pc41fcc5f.v416f9e89;

public class ComponentActivity extends Activity implements LifecycleOwner, KeyEventDispatcher.Component {
  private SimpleArrayMap<Class<? extends ExtraData>, ExtraData> mExtraDataMap = new SimpleArrayMap();
  
  private LifecycleRegistry mLifecycleRegistry = new LifecycleRegistry(this);
  
  private static boolean shouldSkipDump(String[] paramArrayOfString) {
    boolean bool3 = false;
    boolean bool4 = false;
    boolean bool2 = false;
    boolean bool1 = bool4;
    if (paramArrayOfString != null) {
      bool1 = bool4;
      if (paramArrayOfString.length > 0) {
        String str = paramArrayOfString[0];
        str.hashCode();
        byte b = -1;
        switch (str.hashCode()) {
          case 1455016274:
            if (!str.equals(v416f9e89.xbd520268("3015")))
              break; 
            b = 4;
            break;
          case 1159329357:
            if (!str.equals(v416f9e89.xbd520268("3016")))
              break; 
            b = 3;
            break;
          case 472614934:
            if (!str.equals(v416f9e89.xbd520268("3017")))
              break; 
            b = 2;
            break;
          case 100470631:
            if (!str.equals(v416f9e89.xbd520268("3018")))
              break; 
            b = 1;
            break;
          case -645125871:
            if (!str.equals(v416f9e89.xbd520268("3019")))
              break; 
            b = 0;
            break;
        } 
        switch (b) {
          default:
            return false;
          case 4:
            bool1 = bool2;
            if (Build.VERSION.SDK_INT >= 26)
              bool1 = true; 
            return bool1;
          case 3:
            bool1 = bool3;
            if (Build.VERSION.SDK_INT >= 29)
              bool1 = true; 
            return bool1;
          case 1:
          case 2:
            return BuildCompat.isAtLeastT();
          case 0:
            break;
        } 
        bool1 = bool4;
        if (Build.VERSION.SDK_INT >= 31)
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && KeyEventDispatcher.dispatchBeforeHierarchy(view, paramKeyEvent)) ? true : KeyEventDispatcher.dispatchKeyEvent(this, view, (Window.Callback)this, paramKeyEvent);
  }
  
  public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && KeyEventDispatcher.dispatchBeforeHierarchy(view, paramKeyEvent)) ? true : super.dispatchKeyShortcutEvent(paramKeyEvent);
  }
  
  @Deprecated
  public <T extends ExtraData> T getExtraData(Class<T> paramClass) {
    return (T)this.mExtraDataMap.get(paramClass);
  }
  
  public Lifecycle getLifecycle() {
    return (Lifecycle)this.mLifecycleRegistry;
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ReportFragment.injectIfNeededIn(this);
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    this.mLifecycleRegistry.markState(Lifecycle.State.CREATED);
    super.onSaveInstanceState(paramBundle);
  }
  
  @Deprecated
  public void putExtraData(ExtraData paramExtraData) {
    this.mExtraDataMap.put(paramExtraData.getClass(), paramExtraData);
  }
  
  protected final boolean shouldDumpInternalState(String[] paramArrayOfString) {
    return shouldSkipDump(paramArrayOfString) ^ true;
  }
  
  public boolean superDispatchKeyEvent(KeyEvent paramKeyEvent) {
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  @Deprecated
  public static class ExtraData {}
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\core\app\ComponentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */