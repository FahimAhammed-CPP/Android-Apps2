package androidx.core.app;

import android.app.NotificationChannel;
import android.app.NotificationChannelGroup;
import android.os.Build;
import androidx.core.util.Preconditions;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class NotificationChannelGroupCompat {
  private boolean mBlocked;
  
  private List<NotificationChannelCompat> mChannels = Collections.emptyList();
  
  String mDescription;
  
  final String mId;
  
  CharSequence mName;
  
  NotificationChannelGroupCompat(NotificationChannelGroup paramNotificationChannelGroup) {
    this(paramNotificationChannelGroup, Collections.emptyList());
  }
  
  NotificationChannelGroupCompat(NotificationChannelGroup paramNotificationChannelGroup, List<NotificationChannel> paramList) {
    this(Api26Impl.getId(paramNotificationChannelGroup));
    this.mName = Api26Impl.getName(paramNotificationChannelGroup);
    if (Build.VERSION.SDK_INT >= 28)
      this.mDescription = Api28Impl.getDescription(paramNotificationChannelGroup); 
    if (Build.VERSION.SDK_INT >= 28) {
      this.mBlocked = Api28Impl.isBlocked(paramNotificationChannelGroup);
      this.mChannels = getChannelsCompat(Api26Impl.getChannels(paramNotificationChannelGroup));
      return;
    } 
    this.mChannels = getChannelsCompat(paramList);
  }
  
  NotificationChannelGroupCompat(String paramString) {
    this.mId = (String)Preconditions.checkNotNull(paramString);
  }
  
  private List<NotificationChannelCompat> getChannelsCompat(List<NotificationChannel> paramList) {
    ArrayList<NotificationChannelCompat> arrayList = new ArrayList();
    for (NotificationChannel notificationChannel : paramList) {
      if (this.mId.equals(Api26Impl.getGroup(notificationChannel)))
        arrayList.add(new NotificationChannelCompat(notificationChannel)); 
    } 
    return arrayList;
  }
  
  public List<NotificationChannelCompat> getChannels() {
    return this.mChannels;
  }
  
  public String getDescription() {
    return this.mDescription;
  }
  
  public String getId() {
    return this.mId;
  }
  
  public CharSequence getName() {
    return this.mName;
  }
  
  NotificationChannelGroup getNotificationChannelGroup() {
    if (Build.VERSION.SDK_INT < 26)
      return null; 
    NotificationChannelGroup notificationChannelGroup = Api26Impl.createNotificationChannelGroup(this.mId, this.mName);
    if (Build.VERSION.SDK_INT >= 28)
      Api28Impl.setDescription(notificationChannelGroup, this.mDescription); 
    return notificationChannelGroup;
  }
  
  public boolean isBlocked() {
    return this.mBlocked;
  }
  
  public Builder toBuilder() {
    return (new Builder(this.mId)).setName(this.mName).setDescription(this.mDescription);
  }
  
  static class Api26Impl {
    static NotificationChannelGroup createNotificationChannelGroup(String param1String, CharSequence param1CharSequence) {
      return new NotificationChannelGroup(param1String, param1CharSequence);
    }
    
    static List<NotificationChannel> getChannels(NotificationChannelGroup param1NotificationChannelGroup) {
      return param1NotificationChannelGroup.getChannels();
    }
    
    static String getGroup(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getGroup();
    }
    
    static String getId(NotificationChannelGroup param1NotificationChannelGroup) {
      return param1NotificationChannelGroup.getId();
    }
    
    static CharSequence getName(NotificationChannelGroup param1NotificationChannelGroup) {
      return param1NotificationChannelGroup.getName();
    }
  }
  
  static class Api28Impl {
    static String getDescription(NotificationChannelGroup param1NotificationChannelGroup) {
      return param1NotificationChannelGroup.getDescription();
    }
    
    static boolean isBlocked(NotificationChannelGroup param1NotificationChannelGroup) {
      return param1NotificationChannelGroup.isBlocked();
    }
    
    static void setDescription(NotificationChannelGroup param1NotificationChannelGroup, String param1String) {
      param1NotificationChannelGroup.setDescription(param1String);
    }
  }
  
  public static class Builder {
    final NotificationChannelGroupCompat mGroup;
    
    public Builder(String param1String) {
      this.mGroup = new NotificationChannelGroupCompat(param1String);
    }
    
    public NotificationChannelGroupCompat build() {
      return this.mGroup;
    }
    
    public Builder setDescription(String param1String) {
      this.mGroup.mDescription = param1String;
      return this;
    }
    
    public Builder setName(CharSequence param1CharSequence) {
      this.mGroup.mName = param1CharSequence;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\core\app\NotificationChannelGroupCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */