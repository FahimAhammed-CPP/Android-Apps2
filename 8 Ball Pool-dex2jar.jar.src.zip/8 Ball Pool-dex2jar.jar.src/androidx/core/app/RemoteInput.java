package androidx.core.app;

import android.content.ClipData;
import android.content.ClipDescription;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class RemoteInput {
  public static final int EDIT_CHOICES_BEFORE_SENDING_AUTO = 0;
  
  public static final int EDIT_CHOICES_BEFORE_SENDING_DISABLED = 1;
  
  public static final int EDIT_CHOICES_BEFORE_SENDING_ENABLED = 2;
  
  private static final String EXTRA_DATA_TYPE_RESULTS_DATA = v416f9e89.xbd520268("3420");
  
  public static final String EXTRA_RESULTS_DATA = v416f9e89.xbd520268("3421");
  
  private static final String EXTRA_RESULTS_SOURCE = v416f9e89.xbd520268("3422");
  
  public static final String RESULTS_CLIP_LABEL = v416f9e89.xbd520268("3423");
  
  public static final int SOURCE_CHOICE = 1;
  
  public static final int SOURCE_FREE_FORM_INPUT = 0;
  
  private final boolean mAllowFreeFormTextInput;
  
  private final Set<String> mAllowedDataTypes;
  
  private final CharSequence[] mChoices;
  
  private final int mEditChoicesBeforeSending;
  
  private final Bundle mExtras;
  
  private final CharSequence mLabel;
  
  private final String mResultKey;
  
  RemoteInput(String paramString, CharSequence paramCharSequence, CharSequence[] paramArrayOfCharSequence, boolean paramBoolean, int paramInt, Bundle paramBundle, Set<String> paramSet) {
    this.mResultKey = paramString;
    this.mLabel = paramCharSequence;
    this.mChoices = paramArrayOfCharSequence;
    this.mAllowFreeFormTextInput = paramBoolean;
    this.mEditChoicesBeforeSending = paramInt;
    this.mExtras = paramBundle;
    this.mAllowedDataTypes = paramSet;
    if (getEditChoicesBeforeSending() == 2) {
      if (getAllowFreeFormInput())
        return; 
      throw new IllegalArgumentException(v416f9e89.xbd520268("3424"));
    } 
  }
  
  public static void addDataResultToIntent(RemoteInput paramRemoteInput, Intent paramIntent, Map<String, Uri> paramMap) {
    if (Build.VERSION.SDK_INT >= 26) {
      Api26Impl.addDataResultToIntent(paramRemoteInput, paramIntent, paramMap);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 16) {
      Intent intent2 = getClipDataIntentFromIntent(paramIntent);
      Intent intent1 = intent2;
      if (intent2 == null)
        intent1 = new Intent(); 
      for (Map.Entry<String, Uri> entry : paramMap.entrySet()) {
        String str = (String)entry.getKey();
        Uri uri = (Uri)entry.getValue();
        if (str == null)
          continue; 
        Bundle bundle2 = intent1.getBundleExtra(getExtraResultsKeyForData(str));
        Bundle bundle1 = bundle2;
        if (bundle2 == null)
          bundle1 = new Bundle(); 
        bundle1.putString(paramRemoteInput.getResultKey(), uri.toString());
        intent1.putExtra(getExtraResultsKeyForData(str), bundle1);
      } 
      Api16Impl.setClipData(paramIntent, ClipData.newIntent(v416f9e89.xbd520268("3425"), intent1));
    } 
  }
  
  public static void addResultsToIntent(RemoteInput[] paramArrayOfRemoteInput, Intent paramIntent, Bundle paramBundle) {
    if (Build.VERSION.SDK_INT >= 26) {
      Api20Impl.addResultsToIntent(fromCompat(paramArrayOfRemoteInput), paramIntent, paramBundle);
      return;
    } 
    int j = Build.VERSION.SDK_INT;
    int i = 0;
    if (j >= 20) {
      Bundle bundle = getResultsFromIntent(paramIntent);
      j = getResultsSource(paramIntent);
      if (bundle != null) {
        bundle.putAll(paramBundle);
        paramBundle = bundle;
      } 
      int k = paramArrayOfRemoteInput.length;
      for (i = 0; i < k; i++) {
        RemoteInput remoteInput = paramArrayOfRemoteInput[i];
        Map<String, Uri> map = getDataResultsFromIntent(paramIntent, remoteInput.getResultKey());
        Api20Impl.addResultsToIntent(fromCompat(new RemoteInput[] { remoteInput }, ), paramIntent, paramBundle);
        if (map != null)
          addDataResultToIntent(remoteInput, paramIntent, map); 
      } 
      setResultsSource(paramIntent, j);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 16) {
      Intent intent2 = getClipDataIntentFromIntent(paramIntent);
      Intent intent1 = intent2;
      if (intent2 == null)
        intent1 = new Intent(); 
      String str = v416f9e89.xbd520268("3426");
      Bundle bundle2 = intent1.getBundleExtra(str);
      Bundle bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      j = paramArrayOfRemoteInput.length;
      while (i < j) {
        RemoteInput remoteInput = paramArrayOfRemoteInput[i];
        Object object = paramBundle.get(remoteInput.getResultKey());
        if (object instanceof CharSequence)
          bundle1.putCharSequence(remoteInput.getResultKey(), (CharSequence)object); 
        i++;
      } 
      intent1.putExtra(str, bundle1);
      Api16Impl.setClipData(paramIntent, ClipData.newIntent(v416f9e89.xbd520268("3427"), intent1));
    } 
  }
  
  static android.app.RemoteInput fromCompat(RemoteInput paramRemoteInput) {
    return Api20Impl.fromCompat(paramRemoteInput);
  }
  
  static android.app.RemoteInput[] fromCompat(RemoteInput[] paramArrayOfRemoteInput) {
    if (paramArrayOfRemoteInput == null)
      return null; 
    android.app.RemoteInput[] arrayOfRemoteInput = new android.app.RemoteInput[paramArrayOfRemoteInput.length];
    for (int i = 0; i < paramArrayOfRemoteInput.length; i++)
      arrayOfRemoteInput[i] = fromCompat(paramArrayOfRemoteInput[i]); 
    return arrayOfRemoteInput;
  }
  
  static RemoteInput fromPlatform(android.app.RemoteInput paramRemoteInput) {
    return Api20Impl.fromPlatform(paramRemoteInput);
  }
  
  private static Intent getClipDataIntentFromIntent(Intent paramIntent) {
    ClipData clipData = Api16Impl.getClipData(paramIntent);
    if (clipData == null)
      return null; 
    ClipDescription clipDescription = clipData.getDescription();
    return !clipDescription.hasMimeType(v416f9e89.xbd520268("3428")) ? null : (!clipDescription.getLabel().toString().contentEquals(v416f9e89.xbd520268("3429")) ? null : clipData.getItemAt(0).getIntent());
  }
  
  public static Map<String, Uri> getDataResultsFromIntent(Intent paramIntent, String paramString) {
    if (Build.VERSION.SDK_INT >= 26)
      return Api26Impl.getDataResultsFromIntent(paramIntent, paramString); 
    int i = Build.VERSION.SDK_INT;
    HashMap<Object, Object> hashMap = null;
    if (i >= 16) {
      paramIntent = getClipDataIntentFromIntent(paramIntent);
      if (paramIntent == null)
        return null; 
      hashMap = new HashMap<Object, Object>();
      for (String str : paramIntent.getExtras().keySet()) {
        if (str.startsWith(v416f9e89.xbd520268("3430"))) {
          String str1 = str.substring(39);
          if (str1.isEmpty())
            continue; 
          str = paramIntent.getBundleExtra(str).getString(paramString);
          if (str == null || str.isEmpty())
            continue; 
          hashMap.put(str1, Uri.parse(str));
        } 
      } 
      if (hashMap.isEmpty())
        return null; 
    } 
    return (Map)hashMap;
  }
  
  private static String getExtraResultsKeyForData(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(v416f9e89.xbd520268("3431"));
    stringBuilder.append(paramString);
    return stringBuilder.toString();
  }
  
  public static Bundle getResultsFromIntent(Intent paramIntent) {
    if (Build.VERSION.SDK_INT >= 20)
      return Api20Impl.getResultsFromIntent(paramIntent); 
    if (Build.VERSION.SDK_INT >= 16) {
      paramIntent = getClipDataIntentFromIntent(paramIntent);
      return (paramIntent == null) ? null : (Bundle)paramIntent.getExtras().getParcelable(v416f9e89.xbd520268("3432"));
    } 
    return null;
  }
  
  public static int getResultsSource(Intent paramIntent) {
    if (Build.VERSION.SDK_INT >= 28)
      return Api28Impl.getResultsSource(paramIntent); 
    if (Build.VERSION.SDK_INT >= 16) {
      paramIntent = getClipDataIntentFromIntent(paramIntent);
      return (paramIntent == null) ? 0 : paramIntent.getExtras().getInt(v416f9e89.xbd520268("3433"), 0);
    } 
    return 0;
  }
  
  public static void setResultsSource(Intent paramIntent, int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      Api28Impl.setResultsSource(paramIntent, paramInt);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 16) {
      Intent intent2 = getClipDataIntentFromIntent(paramIntent);
      Intent intent1 = intent2;
      if (intent2 == null)
        intent1 = new Intent(); 
      intent1.putExtra(v416f9e89.xbd520268("3434"), paramInt);
      Api16Impl.setClipData(paramIntent, ClipData.newIntent(v416f9e89.xbd520268("3435"), intent1));
    } 
  }
  
  public boolean getAllowFreeFormInput() {
    return this.mAllowFreeFormTextInput;
  }
  
  public Set<String> getAllowedDataTypes() {
    return this.mAllowedDataTypes;
  }
  
  public CharSequence[] getChoices() {
    return this.mChoices;
  }
  
  public int getEditChoicesBeforeSending() {
    return this.mEditChoicesBeforeSending;
  }
  
  public Bundle getExtras() {
    return this.mExtras;
  }
  
  public CharSequence getLabel() {
    return this.mLabel;
  }
  
  public String getResultKey() {
    return this.mResultKey;
  }
  
  public boolean isDataOnly() {
    return (!getAllowFreeFormInput() && (getChoices() == null || (getChoices()).length == 0) && getAllowedDataTypes() != null && !getAllowedDataTypes().isEmpty());
  }
  
  static class Api16Impl {
    static ClipData getClipData(Intent param1Intent) {
      return param1Intent.getClipData();
    }
    
    static void setClipData(Intent param1Intent, ClipData param1ClipData) {
      param1Intent.setClipData(param1ClipData);
    }
  }
  
  static class Api20Impl {
    static void addResultsToIntent(Object param1Object, Intent param1Intent, Bundle param1Bundle) {
      android.app.RemoteInput.addResultsToIntent((android.app.RemoteInput[])param1Object, param1Intent, param1Bundle);
    }
    
    public static android.app.RemoteInput fromCompat(RemoteInput param1RemoteInput) {
      android.app.RemoteInput.Builder builder = (new android.app.RemoteInput.Builder(param1RemoteInput.getResultKey())).setLabel(param1RemoteInput.getLabel()).setChoices(param1RemoteInput.getChoices()).setAllowFreeFormInput(param1RemoteInput.getAllowFreeFormInput()).addExtras(param1RemoteInput.getExtras());
      if (Build.VERSION.SDK_INT >= 26) {
        Set<String> set = param1RemoteInput.getAllowedDataTypes();
        if (set != null) {
          Iterator<String> iterator = set.iterator();
          while (iterator.hasNext())
            RemoteInput.Api26Impl.setAllowDataType(builder, iterator.next(), true); 
        } 
      } 
      if (Build.VERSION.SDK_INT >= 29)
        RemoteInput.Api29Impl.setEditChoicesBeforeSending(builder, param1RemoteInput.getEditChoicesBeforeSending()); 
      return builder.build();
    }
    
    static RemoteInput fromPlatform(Object param1Object) {
      param1Object = param1Object;
      RemoteInput.Builder builder = (new RemoteInput.Builder(param1Object.getResultKey())).setLabel(param1Object.getLabel()).setChoices(param1Object.getChoices()).setAllowFreeFormInput(param1Object.getAllowFreeFormInput()).addExtras(param1Object.getExtras());
      if (Build.VERSION.SDK_INT >= 26) {
        Set<String> set = RemoteInput.Api26Impl.getAllowedDataTypes(param1Object);
        if (set != null) {
          Iterator<String> iterator = set.iterator();
          while (iterator.hasNext())
            builder.setAllowDataType(iterator.next(), true); 
        } 
      } 
      if (Build.VERSION.SDK_INT >= 29)
        builder.setEditChoicesBeforeSending(RemoteInput.Api29Impl.getEditChoicesBeforeSending(param1Object)); 
      return builder.build();
    }
    
    static Bundle getResultsFromIntent(Intent param1Intent) {
      return android.app.RemoteInput.getResultsFromIntent(param1Intent);
    }
  }
  
  static class Api26Impl {
    static void addDataResultToIntent(RemoteInput param1RemoteInput, Intent param1Intent, Map<String, Uri> param1Map) {
      android.app.RemoteInput.addDataResultToIntent(RemoteInput.fromCompat(param1RemoteInput), param1Intent, param1Map);
    }
    
    static Set<String> getAllowedDataTypes(Object param1Object) {
      return ((android.app.RemoteInput)param1Object).getAllowedDataTypes();
    }
    
    static Map<String, Uri> getDataResultsFromIntent(Intent param1Intent, String param1String) {
      return android.app.RemoteInput.getDataResultsFromIntent(param1Intent, param1String);
    }
    
    static android.app.RemoteInput.Builder setAllowDataType(android.app.RemoteInput.Builder param1Builder, String param1String, boolean param1Boolean) {
      return param1Builder.setAllowDataType(param1String, param1Boolean);
    }
  }
  
  static class Api28Impl {
    static int getResultsSource(Intent param1Intent) {
      return android.app.RemoteInput.getResultsSource(param1Intent);
    }
    
    static void setResultsSource(Intent param1Intent, int param1Int) {
      android.app.RemoteInput.setResultsSource(param1Intent, param1Int);
    }
  }
  
  static class Api29Impl {
    static int getEditChoicesBeforeSending(Object param1Object) {
      return ((android.app.RemoteInput)param1Object).getEditChoicesBeforeSending();
    }
    
    static android.app.RemoteInput.Builder setEditChoicesBeforeSending(android.app.RemoteInput.Builder param1Builder, int param1Int) {
      return param1Builder.setEditChoicesBeforeSending(param1Int);
    }
  }
  
  public static final class Builder {
    private boolean mAllowFreeFormTextInput = true;
    
    private final Set<String> mAllowedDataTypes = new HashSet<String>();
    
    private CharSequence[] mChoices;
    
    private int mEditChoicesBeforeSending = 0;
    
    private final Bundle mExtras = new Bundle();
    
    private CharSequence mLabel;
    
    private final String mResultKey;
    
    public Builder(String param1String) {
      if (param1String != null) {
        this.mResultKey = param1String;
        return;
      } 
      throw new IllegalArgumentException(v416f9e89.xbd520268("3324"));
    }
    
    public Builder addExtras(Bundle param1Bundle) {
      if (param1Bundle != null)
        this.mExtras.putAll(param1Bundle); 
      return this;
    }
    
    public RemoteInput build() {
      return new RemoteInput(this.mResultKey, this.mLabel, this.mChoices, this.mAllowFreeFormTextInput, this.mEditChoicesBeforeSending, this.mExtras, this.mAllowedDataTypes);
    }
    
    public Bundle getExtras() {
      return this.mExtras;
    }
    
    public Builder setAllowDataType(String param1String, boolean param1Boolean) {
      if (param1Boolean) {
        this.mAllowedDataTypes.add(param1String);
        return this;
      } 
      this.mAllowedDataTypes.remove(param1String);
      return this;
    }
    
    public Builder setAllowFreeFormInput(boolean param1Boolean) {
      this.mAllowFreeFormTextInput = param1Boolean;
      return this;
    }
    
    public Builder setChoices(CharSequence[] param1ArrayOfCharSequence) {
      this.mChoices = param1ArrayOfCharSequence;
      return this;
    }
    
    public Builder setEditChoicesBeforeSending(int param1Int) {
      this.mEditChoicesBeforeSending = param1Int;
      return this;
    }
    
    public Builder setLabel(CharSequence param1CharSequence) {
      this.mLabel = param1CharSequence;
      return this;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface EditChoicesBeforeSending {}
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface Source {}
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\core\app\RemoteInput.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */