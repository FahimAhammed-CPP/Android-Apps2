package androidx.core.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import androidx.core.util.Preconditions;
import h8800e55c.pc41fcc5f.v416f9e89;

public class NotificationChannelCompat {
  public static final String DEFAULT_CHANNEL_ID = v416f9e89.xbd520268("3096");
  
  private static final int DEFAULT_LIGHT_COLOR = 0;
  
  private static final boolean DEFAULT_SHOW_BADGE = true;
  
  AudioAttributes mAudioAttributes;
  
  private boolean mBypassDnd;
  
  private boolean mCanBubble;
  
  String mConversationId;
  
  String mDescription;
  
  String mGroupId;
  
  final String mId;
  
  int mImportance;
  
  private boolean mImportantConversation;
  
  int mLightColor = 0;
  
  boolean mLights;
  
  private int mLockscreenVisibility;
  
  CharSequence mName;
  
  String mParentId;
  
  boolean mShowBadge = true;
  
  Uri mSound = Settings.System.DEFAULT_NOTIFICATION_URI;
  
  boolean mVibrationEnabled;
  
  long[] mVibrationPattern;
  
  NotificationChannelCompat(NotificationChannel paramNotificationChannel) {
    this(Api26Impl.getId(paramNotificationChannel), Api26Impl.getImportance(paramNotificationChannel));
    this.mName = Api26Impl.getName(paramNotificationChannel);
    this.mDescription = Api26Impl.getDescription(paramNotificationChannel);
    this.mGroupId = Api26Impl.getGroup(paramNotificationChannel);
    this.mShowBadge = Api26Impl.canShowBadge(paramNotificationChannel);
    this.mSound = Api26Impl.getSound(paramNotificationChannel);
    this.mAudioAttributes = Api26Impl.getAudioAttributes(paramNotificationChannel);
    this.mLights = Api26Impl.shouldShowLights(paramNotificationChannel);
    this.mLightColor = Api26Impl.getLightColor(paramNotificationChannel);
    this.mVibrationEnabled = Api26Impl.shouldVibrate(paramNotificationChannel);
    this.mVibrationPattern = Api26Impl.getVibrationPattern(paramNotificationChannel);
    if (Build.VERSION.SDK_INT >= 30) {
      this.mParentId = Api30Impl.getParentChannelId(paramNotificationChannel);
      this.mConversationId = Api30Impl.getConversationId(paramNotificationChannel);
    } 
    this.mBypassDnd = Api26Impl.canBypassDnd(paramNotificationChannel);
    this.mLockscreenVisibility = Api26Impl.getLockscreenVisibility(paramNotificationChannel);
    if (Build.VERSION.SDK_INT >= 29)
      this.mCanBubble = Api29Impl.canBubble(paramNotificationChannel); 
    if (Build.VERSION.SDK_INT >= 30)
      this.mImportantConversation = Api30Impl.isImportantConversation(paramNotificationChannel); 
  }
  
  NotificationChannelCompat(String paramString, int paramInt) {
    this.mId = (String)Preconditions.checkNotNull(paramString);
    this.mImportance = paramInt;
    if (Build.VERSION.SDK_INT >= 21)
      this.mAudioAttributes = Notification.AUDIO_ATTRIBUTES_DEFAULT; 
  }
  
  public boolean canBubble() {
    return this.mCanBubble;
  }
  
  public boolean canBypassDnd() {
    return this.mBypassDnd;
  }
  
  public boolean canShowBadge() {
    return this.mShowBadge;
  }
  
  public AudioAttributes getAudioAttributes() {
    return this.mAudioAttributes;
  }
  
  public String getConversationId() {
    return this.mConversationId;
  }
  
  public String getDescription() {
    return this.mDescription;
  }
  
  public String getGroup() {
    return this.mGroupId;
  }
  
  public String getId() {
    return this.mId;
  }
  
  public int getImportance() {
    return this.mImportance;
  }
  
  public int getLightColor() {
    return this.mLightColor;
  }
  
  public int getLockscreenVisibility() {
    return this.mLockscreenVisibility;
  }
  
  public CharSequence getName() {
    return this.mName;
  }
  
  NotificationChannel getNotificationChannel() {
    if (Build.VERSION.SDK_INT < 26)
      return null; 
    NotificationChannel notificationChannel = Api26Impl.createNotificationChannel(this.mId, this.mName, this.mImportance);
    Api26Impl.setDescription(notificationChannel, this.mDescription);
    Api26Impl.setGroup(notificationChannel, this.mGroupId);
    Api26Impl.setShowBadge(notificationChannel, this.mShowBadge);
    Api26Impl.setSound(notificationChannel, this.mSound, this.mAudioAttributes);
    Api26Impl.enableLights(notificationChannel, this.mLights);
    Api26Impl.setLightColor(notificationChannel, this.mLightColor);
    Api26Impl.setVibrationPattern(notificationChannel, this.mVibrationPattern);
    Api26Impl.enableVibration(notificationChannel, this.mVibrationEnabled);
    if (Build.VERSION.SDK_INT >= 30) {
      String str = this.mParentId;
      if (str != null) {
        String str1 = this.mConversationId;
        if (str1 != null)
          Api30Impl.setConversationId(notificationChannel, str, str1); 
      } 
    } 
    return notificationChannel;
  }
  
  public String getParentChannelId() {
    return this.mParentId;
  }
  
  public Uri getSound() {
    return this.mSound;
  }
  
  public long[] getVibrationPattern() {
    return this.mVibrationPattern;
  }
  
  public boolean isImportantConversation() {
    return this.mImportantConversation;
  }
  
  public boolean shouldShowLights() {
    return this.mLights;
  }
  
  public boolean shouldVibrate() {
    return this.mVibrationEnabled;
  }
  
  public Builder toBuilder() {
    return (new Builder(this.mId, this.mImportance)).setName(this.mName).setDescription(this.mDescription).setGroup(this.mGroupId).setShowBadge(this.mShowBadge).setSound(this.mSound, this.mAudioAttributes).setLightsEnabled(this.mLights).setLightColor(this.mLightColor).setVibrationEnabled(this.mVibrationEnabled).setVibrationPattern(this.mVibrationPattern).setConversationId(this.mParentId, this.mConversationId);
  }
  
  static class Api26Impl {
    static boolean canBypassDnd(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.canBypassDnd();
    }
    
    static boolean canShowBadge(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.canShowBadge();
    }
    
    static NotificationChannel createNotificationChannel(String param1String, CharSequence param1CharSequence, int param1Int) {
      return new NotificationChannel(param1String, param1CharSequence, param1Int);
    }
    
    static void enableLights(NotificationChannel param1NotificationChannel, boolean param1Boolean) {
      param1NotificationChannel.enableLights(param1Boolean);
    }
    
    static void enableVibration(NotificationChannel param1NotificationChannel, boolean param1Boolean) {
      param1NotificationChannel.enableVibration(param1Boolean);
    }
    
    static AudioAttributes getAudioAttributes(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getAudioAttributes();
    }
    
    static String getDescription(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getDescription();
    }
    
    static String getGroup(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getGroup();
    }
    
    static String getId(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getId();
    }
    
    static int getImportance(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getImportance();
    }
    
    static int getLightColor(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getLightColor();
    }
    
    static int getLockscreenVisibility(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getLockscreenVisibility();
    }
    
    static CharSequence getName(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getName();
    }
    
    static Uri getSound(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getSound();
    }
    
    static long[] getVibrationPattern(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getVibrationPattern();
    }
    
    static void setDescription(NotificationChannel param1NotificationChannel, String param1String) {
      param1NotificationChannel.setDescription(param1String);
    }
    
    static void setGroup(NotificationChannel param1NotificationChannel, String param1String) {
      param1NotificationChannel.setGroup(param1String);
    }
    
    static void setLightColor(NotificationChannel param1NotificationChannel, int param1Int) {
      param1NotificationChannel.setLightColor(param1Int);
    }
    
    static void setShowBadge(NotificationChannel param1NotificationChannel, boolean param1Boolean) {
      param1NotificationChannel.setShowBadge(param1Boolean);
    }
    
    static void setSound(NotificationChannel param1NotificationChannel, Uri param1Uri, AudioAttributes param1AudioAttributes) {
      param1NotificationChannel.setSound(param1Uri, param1AudioAttributes);
    }
    
    static void setVibrationPattern(NotificationChannel param1NotificationChannel, long[] param1ArrayOflong) {
      param1NotificationChannel.setVibrationPattern(param1ArrayOflong);
    }
    
    static boolean shouldShowLights(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.shouldShowLights();
    }
    
    static boolean shouldVibrate(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.shouldVibrate();
    }
  }
  
  static class Api29Impl {
    static boolean canBubble(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.canBubble();
    }
  }
  
  static class Api30Impl {
    static String getConversationId(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getConversationId();
    }
    
    static String getParentChannelId(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.getParentChannelId();
    }
    
    static boolean isImportantConversation(NotificationChannel param1NotificationChannel) {
      return param1NotificationChannel.isImportantConversation();
    }
    
    static void setConversationId(NotificationChannel param1NotificationChannel, String param1String1, String param1String2) {
      param1NotificationChannel.setConversationId(param1String1, param1String2);
    }
  }
  
  public static class Builder {
    private final NotificationChannelCompat mChannel;
    
    public Builder(String param1String, int param1Int) {
      this.mChannel = new NotificationChannelCompat(param1String, param1Int);
    }
    
    public NotificationChannelCompat build() {
      return this.mChannel;
    }
    
    public Builder setConversationId(String param1String1, String param1String2) {
      if (Build.VERSION.SDK_INT >= 30) {
        this.mChannel.mParentId = param1String1;
        this.mChannel.mConversationId = param1String2;
      } 
      return this;
    }
    
    public Builder setDescription(String param1String) {
      this.mChannel.mDescription = param1String;
      return this;
    }
    
    public Builder setGroup(String param1String) {
      this.mChannel.mGroupId = param1String;
      return this;
    }
    
    public Builder setImportance(int param1Int) {
      this.mChannel.mImportance = param1Int;
      return this;
    }
    
    public Builder setLightColor(int param1Int) {
      this.mChannel.mLightColor = param1Int;
      return this;
    }
    
    public Builder setLightsEnabled(boolean param1Boolean) {
      this.mChannel.mLights = param1Boolean;
      return this;
    }
    
    public Builder setName(CharSequence param1CharSequence) {
      this.mChannel.mName = param1CharSequence;
      return this;
    }
    
    public Builder setShowBadge(boolean param1Boolean) {
      this.mChannel.mShowBadge = param1Boolean;
      return this;
    }
    
    public Builder setSound(Uri param1Uri, AudioAttributes param1AudioAttributes) {
      this.mChannel.mSound = param1Uri;
      this.mChannel.mAudioAttributes = param1AudioAttributes;
      return this;
    }
    
    public Builder setVibrationEnabled(boolean param1Boolean) {
      this.mChannel.mVibrationEnabled = param1Boolean;
      return this;
    }
    
    public Builder setVibrationPattern(long[] param1ArrayOflong) {
      boolean bool;
      NotificationChannelCompat notificationChannelCompat = this.mChannel;
      if (param1ArrayOflong != null && param1ArrayOflong.length > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      notificationChannelCompat.mVibrationEnabled = bool;
      this.mChannel.mVibrationPattern = param1ArrayOflong;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\core\app\NotificationChannelCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */