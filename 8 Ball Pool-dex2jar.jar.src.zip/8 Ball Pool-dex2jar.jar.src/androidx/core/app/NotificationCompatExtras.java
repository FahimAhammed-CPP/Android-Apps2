package androidx.core.app;

import h8800e55c.pc41fcc5f.v416f9e89;

public final class NotificationCompatExtras {
  public static final String EXTRA_ACTION_EXTRAS = v416f9e89.xbd520268("3707");
  
  public static final String EXTRA_GROUP_KEY = v416f9e89.xbd520268("3708");
  
  public static final String EXTRA_GROUP_SUMMARY = v416f9e89.xbd520268("3709");
  
  public static final String EXTRA_LOCAL_ONLY = v416f9e89.xbd520268("3710");
  
  public static final String EXTRA_REMOTE_INPUTS = v416f9e89.xbd520268("3711");
  
  public static final String EXTRA_SORT_KEY = v416f9e89.xbd520268("3712");
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\core\app\NotificationCompatExtras.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */