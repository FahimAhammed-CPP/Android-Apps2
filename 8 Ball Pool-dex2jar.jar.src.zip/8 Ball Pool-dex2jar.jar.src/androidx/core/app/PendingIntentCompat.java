package androidx.core.app;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public final class PendingIntentCompat {
  private static int addMutabilityFlags(boolean paramBoolean, int paramInt) {
    if (paramBoolean) {
      null = paramInt;
      if (Build.VERSION.SDK_INT >= 31) {
        null = 33554432;
      } else {
        return null;
      } 
    } else {
      null = paramInt;
      if (Build.VERSION.SDK_INT >= 23) {
        null = 67108864;
      } else {
        return null;
      } 
    } 
    return paramInt | null;
  }
  
  public static PendingIntent getActivities(Context paramContext, int paramInt1, Intent[] paramArrayOfIntent, int paramInt2, Bundle paramBundle, boolean paramBoolean) {
    return (Build.VERSION.SDK_INT >= 16) ? Api16Impl.getActivities(paramContext, paramInt1, paramArrayOfIntent, addMutabilityFlags(paramBoolean, paramInt2), paramBundle) : PendingIntent.getActivities(paramContext, paramInt1, paramArrayOfIntent, paramInt2);
  }
  
  public static PendingIntent getActivities(Context paramContext, int paramInt1, Intent[] paramArrayOfIntent, int paramInt2, boolean paramBoolean) {
    return PendingIntent.getActivities(paramContext, paramInt1, paramArrayOfIntent, addMutabilityFlags(paramBoolean, paramInt2));
  }
  
  public static PendingIntent getActivity(Context paramContext, int paramInt1, Intent paramIntent, int paramInt2, Bundle paramBundle, boolean paramBoolean) {
    return (Build.VERSION.SDK_INT >= 16) ? Api16Impl.getActivity(paramContext, paramInt1, paramIntent, addMutabilityFlags(paramBoolean, paramInt2), paramBundle) : PendingIntent.getActivity(paramContext, paramInt1, paramIntent, paramInt2);
  }
  
  public static PendingIntent getActivity(Context paramContext, int paramInt1, Intent paramIntent, int paramInt2, boolean paramBoolean) {
    return PendingIntent.getActivity(paramContext, paramInt1, paramIntent, addMutabilityFlags(paramBoolean, paramInt2));
  }
  
  public static PendingIntent getBroadcast(Context paramContext, int paramInt1, Intent paramIntent, int paramInt2, boolean paramBoolean) {
    return PendingIntent.getBroadcast(paramContext, paramInt1, paramIntent, addMutabilityFlags(paramBoolean, paramInt2));
  }
  
  public static PendingIntent getForegroundService(Context paramContext, int paramInt1, Intent paramIntent, int paramInt2, boolean paramBoolean) {
    return Api26Impl.getForegroundService(paramContext, paramInt1, paramIntent, addMutabilityFlags(paramBoolean, paramInt2));
  }
  
  public static PendingIntent getService(Context paramContext, int paramInt1, Intent paramIntent, int paramInt2, boolean paramBoolean) {
    return PendingIntent.getService(paramContext, paramInt1, paramIntent, addMutabilityFlags(paramBoolean, paramInt2));
  }
  
  private static class Api16Impl {
    public static PendingIntent getActivities(Context param1Context, int param1Int1, Intent[] param1ArrayOfIntent, int param1Int2, Bundle param1Bundle) {
      return PendingIntent.getActivities(param1Context, param1Int1, param1ArrayOfIntent, param1Int2, param1Bundle);
    }
    
    public static PendingIntent getActivity(Context param1Context, int param1Int1, Intent param1Intent, int param1Int2, Bundle param1Bundle) {
      return PendingIntent.getActivity(param1Context, param1Int1, param1Intent, param1Int2, param1Bundle);
    }
  }
  
  private static class Api26Impl {
    public static PendingIntent getForegroundService(Context param1Context, int param1Int1, Intent param1Intent, int param1Int2) {
      return PendingIntent.getForegroundService(param1Context, param1Int1, param1Intent, param1Int2);
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface Flags {}
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\core\app\PendingIntentCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */