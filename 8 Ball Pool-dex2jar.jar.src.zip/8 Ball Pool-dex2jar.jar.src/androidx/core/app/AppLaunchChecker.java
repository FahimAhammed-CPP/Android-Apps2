package androidx.core.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import h8800e55c.pc41fcc5f.v416f9e89;

public class AppLaunchChecker {
  private static final String KEY_STARTED_FROM_LAUNCHER = v416f9e89.xbd520268("2991");
  
  private static final String SHARED_PREFS_NAME = v416f9e89.xbd520268("2992");
  
  public static boolean hasStartedFromLauncher(Context paramContext) {
    return paramContext.getSharedPreferences(v416f9e89.xbd520268("2993"), 0).getBoolean(v416f9e89.xbd520268("2994"), false);
  }
  
  public static void onActivityCreate(Activity paramActivity) {
    SharedPreferences sharedPreferences = paramActivity.getSharedPreferences(v416f9e89.xbd520268("2995"), 0);
    String str1 = v416f9e89.xbd520268("2996");
    if (sharedPreferences.getBoolean(str1, false))
      return; 
    Intent intent = paramActivity.getIntent();
    if (intent == null)
      return; 
    String str2 = intent.getAction();
    if (v416f9e89.xbd520268("2997").equals(str2) && (intent.hasCategory(v416f9e89.xbd520268("2998")) || intent.hasCategory(v416f9e89.xbd520268("2999"))))
      sharedPreferences.edit().putBoolean(str1, true).apply(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\core\app\AppLaunchChecker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */