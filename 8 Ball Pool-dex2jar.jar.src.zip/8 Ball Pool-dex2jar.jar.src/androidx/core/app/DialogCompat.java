package androidx.core.app;

import android.app.Dialog;
import android.os.Build;
import android.view.View;
import h8800e55c.pc41fcc5f.v416f9e89;

public class DialogCompat {
  public static View requireViewById(Dialog paramDialog, int paramInt) {
    if (Build.VERSION.SDK_INT >= 28)
      return Api28Impl.<View>requireViewById(paramDialog, paramInt); 
    View view = paramDialog.findViewById(paramInt);
    if (view != null)
      return view; 
    throw new IllegalArgumentException(v416f9e89.xbd520268("3020"));
  }
  
  static class Api28Impl {
    static <T> T requireViewById(Dialog param1Dialog, int param1Int) {
      return (T)param1Dialog.requireViewById(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\core\app\DialogCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */