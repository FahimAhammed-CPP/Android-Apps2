package androidx.core.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.util.SparseArray;
import androidx.core.graphics.drawable.IconCompat;
import h8800e55c.pc41fcc5f.v416f9e89;
import h8800e55c.x78d2f21c.y0bc38925;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

class NotificationCompatJellybean {
  static final String EXTRA_ALLOW_GENERATED_REPLIES = v416f9e89.xbd520268("3721");
  
  static final String EXTRA_DATA_ONLY_REMOTE_INPUTS = v416f9e89.xbd520268("3722");
  
  private static final String KEY_ACTION_INTENT = v416f9e89.xbd520268("3723");
  
  private static final String KEY_ALLOWED_DATA_TYPES = v416f9e89.xbd520268("3724");
  
  private static final String KEY_ALLOW_FREE_FORM_INPUT = v416f9e89.xbd520268("3725");
  
  private static final String KEY_CHOICES = v416f9e89.xbd520268("3726");
  
  private static final String KEY_DATA_ONLY_REMOTE_INPUTS = v416f9e89.xbd520268("3727");
  
  private static final String KEY_EXTRAS = v416f9e89.xbd520268("3728");
  
  private static final String KEY_ICON = v416f9e89.xbd520268("3729");
  
  private static final String KEY_LABEL = v416f9e89.xbd520268("3730");
  
  private static final String KEY_REMOTE_INPUTS = v416f9e89.xbd520268("3731");
  
  private static final String KEY_RESULT_KEY = v416f9e89.xbd520268("3732");
  
  private static final String KEY_SEMANTIC_ACTION = v416f9e89.xbd520268("3733");
  
  private static final String KEY_SHOWS_USER_INTERFACE = v416f9e89.xbd520268("3734");
  
  private static final String KEY_TITLE = v416f9e89.xbd520268("3735");
  
  public static final String TAG = v416f9e89.xbd520268("3736");
  
  private static Field sActionIconField;
  
  private static Field sActionIntentField;
  
  private static Field sActionTitleField;
  
  private static boolean sActionsAccessFailed;
  
  private static Field sActionsField;
  
  private static final Object sActionsLock;
  
  private static Field sExtrasField;
  
  private static boolean sExtrasFieldAccessFailed;
  
  private static final Object sExtrasLock = new Object();
  
  static {
    sActionsLock = new Object();
  }
  
  public static SparseArray<Bundle> buildActionExtrasMap(List<Bundle> paramList) {
    int j = paramList.size();
    SparseArray<Bundle> sparseArray = null;
    int i = 0;
    while (i < j) {
      Bundle bundle = paramList.get(i);
      SparseArray<Bundle> sparseArray1 = sparseArray;
      if (bundle != null) {
        sparseArray1 = sparseArray;
        if (sparseArray == null)
          sparseArray1 = new SparseArray(); 
        sparseArray1.put(i, bundle);
      } 
      i++;
      sparseArray = sparseArray1;
    } 
    return sparseArray;
  }
  
  private static boolean ensureActionReflectionReadyLocked() {
    String str1 = v416f9e89.xbd520268("3737");
    String str2 = v416f9e89.xbd520268("3738");
    if (sActionsAccessFailed)
      return false; 
    try {
      if (sActionsField == null) {
        Class clazz = y0bc38925.classForName(v416f9e89.xbd520268("3739"));
        sActionIconField = clazz.getDeclaredField(v416f9e89.xbd520268("3740"));
        sActionTitleField = clazz.getDeclaredField(v416f9e89.xbd520268("3741"));
        sActionIntentField = clazz.getDeclaredField(v416f9e89.xbd520268("3742"));
        Field field = Notification.class.getDeclaredField(v416f9e89.xbd520268("3743"));
        sActionsField = field;
        field.setAccessible(true);
      } 
    } catch (ClassNotFoundException classNotFoundException) {
      Log.e(str2, str1, classNotFoundException);
      sActionsAccessFailed = true;
    } catch (NoSuchFieldException noSuchFieldException) {
      Log.e(str2, str1, noSuchFieldException);
      sActionsAccessFailed = true;
    } 
    return sActionsAccessFailed ^ true;
  }
  
  private static RemoteInput fromBundle(Bundle paramBundle) {
    ArrayList arrayList = paramBundle.getStringArrayList(v416f9e89.xbd520268("3744"));
    HashSet<String> hashSet = new HashSet();
    if (arrayList != null) {
      Iterator<String> iterator = arrayList.iterator();
      while (iterator.hasNext())
        hashSet.add(iterator.next()); 
    } 
    return new RemoteInput(paramBundle.getString(v416f9e89.xbd520268("3745")), paramBundle.getCharSequence(v416f9e89.xbd520268("3746")), paramBundle.getCharSequenceArray(v416f9e89.xbd520268("3747")), paramBundle.getBoolean(v416f9e89.xbd520268("3748")), 0, paramBundle.getBundle(v416f9e89.xbd520268("3749")), hashSet);
  }
  
  private static RemoteInput[] fromBundleArray(Bundle[] paramArrayOfBundle) {
    if (paramArrayOfBundle == null)
      return null; 
    RemoteInput[] arrayOfRemoteInput = new RemoteInput[paramArrayOfBundle.length];
    for (int i = 0; i < paramArrayOfBundle.length; i++)
      arrayOfRemoteInput[i] = fromBundle(paramArrayOfBundle[i]); 
    return arrayOfRemoteInput;
  }
  
  public static NotificationCompat.Action getAction(Notification paramNotification, int paramInt) {
    // Byte code:
    //   0: getstatic androidx/core/app/NotificationCompatJellybean.sActionsLock : Ljava/lang/Object;
    //   3: astore_2
    //   4: aload_2
    //   5: monitorenter
    //   6: aload_0
    //   7: invokestatic getActionObjectsLocked : (Landroid/app/Notification;)[Ljava/lang/Object;
    //   10: astore_3
    //   11: aload_3
    //   12: ifnull -> 110
    //   15: aload_3
    //   16: iload_1
    //   17: aaload
    //   18: astore_3
    //   19: aload_0
    //   20: invokestatic getExtras : (Landroid/app/Notification;)Landroid/os/Bundle;
    //   23: astore_0
    //   24: aload_0
    //   25: ifnull -> 118
    //   28: aload_0
    //   29: ldc_w '3750'
    //   32: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   35: invokevirtual getSparseParcelableArray : (Ljava/lang/String;)Landroid/util/SparseArray;
    //   38: astore_0
    //   39: aload_0
    //   40: ifnull -> 118
    //   43: aload_0
    //   44: iload_1
    //   45: invokevirtual get : (I)Ljava/lang/Object;
    //   48: checkcast android/os/Bundle
    //   51: astore_0
    //   52: goto -> 55
    //   55: getstatic androidx/core/app/NotificationCompatJellybean.sActionIconField : Ljava/lang/reflect/Field;
    //   58: aload_3
    //   59: invokevirtual getInt : (Ljava/lang/Object;)I
    //   62: getstatic androidx/core/app/NotificationCompatJellybean.sActionTitleField : Ljava/lang/reflect/Field;
    //   65: aload_3
    //   66: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   69: checkcast java/lang/CharSequence
    //   72: getstatic androidx/core/app/NotificationCompatJellybean.sActionIntentField : Ljava/lang/reflect/Field;
    //   75: aload_3
    //   76: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   79: checkcast android/app/PendingIntent
    //   82: aload_0
    //   83: invokestatic readAction : (ILjava/lang/CharSequence;Landroid/app/PendingIntent;Landroid/os/Bundle;)Landroidx/core/app/NotificationCompat$Action;
    //   86: astore_0
    //   87: aload_2
    //   88: monitorexit
    //   89: aload_0
    //   90: areturn
    //   91: astore_0
    //   92: ldc_w 'NotificationCompat'
    //   95: ldc_w '3751'
    //   98: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   101: aload_0
    //   102: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   105: pop
    //   106: iconst_1
    //   107: putstatic androidx/core/app/NotificationCompatJellybean.sActionsAccessFailed : Z
    //   110: aload_2
    //   111: monitorexit
    //   112: aconst_null
    //   113: areturn
    //   114: aload_2
    //   115: monitorexit
    //   116: aload_0
    //   117: athrow
    //   118: aconst_null
    //   119: astore_0
    //   120: goto -> 55
    //   123: astore_0
    //   124: goto -> 114
    // Exception table:
    //   from	to	target	type
    //   6	11	91	java/lang/IllegalAccessException
    //   6	11	123	finally
    //   19	24	91	java/lang/IllegalAccessException
    //   19	24	123	finally
    //   28	39	91	java/lang/IllegalAccessException
    //   28	39	123	finally
    //   43	52	91	java/lang/IllegalAccessException
    //   43	52	123	finally
    //   55	87	91	java/lang/IllegalAccessException
    //   55	87	123	finally
    //   87	89	123	finally
    //   92	110	123	finally
    //   110	112	123	finally
    //   114	116	123	finally
  }
  
  public static int getActionCount(Notification paramNotification) {
    synchronized (sActionsLock) {
      Object[] arrayOfObject = getActionObjectsLocked(paramNotification);
      if (arrayOfObject != null)
        return arrayOfObject.length; 
    } 
    boolean bool = false;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
    return bool;
  }
  
  static NotificationCompat.Action getActionFromBundle(Bundle paramBundle) {
    boolean bool;
    String str = v416f9e89.xbd520268("3752");
    Bundle bundle = paramBundle.getBundle(str);
    if (bundle != null) {
      bool = bundle.getBoolean(v416f9e89.xbd520268("3753"), false);
    } else {
      bool = false;
    } 
    return new NotificationCompat.Action(paramBundle.getInt(v416f9e89.xbd520268("3754")), paramBundle.getCharSequence(v416f9e89.xbd520268("3755")), (PendingIntent)paramBundle.getParcelable(v416f9e89.xbd520268("3756")), paramBundle.getBundle(str), fromBundleArray(getBundleArrayFromBundle(paramBundle, v416f9e89.xbd520268("3757"))), fromBundleArray(getBundleArrayFromBundle(paramBundle, v416f9e89.xbd520268("3758"))), bool, paramBundle.getInt(v416f9e89.xbd520268("3759")), paramBundle.getBoolean(v416f9e89.xbd520268("3760")), false, false);
  }
  
  private static Object[] getActionObjectsLocked(Notification paramNotification) {
    synchronized (sActionsLock) {
      if (!ensureActionReflectionReadyLocked())
        return null; 
      try {
        return (Object[])sActionsField.get(paramNotification);
      } catch (IllegalAccessException illegalAccessException) {
        Log.e(v416f9e89.xbd520268("3761"), v416f9e89.xbd520268("3762"), illegalAccessException);
        sActionsAccessFailed = true;
        return null;
      } 
    } 
  }
  
  private static Bundle[] getBundleArrayFromBundle(Bundle paramBundle, String paramString) {
    Parcelable[] arrayOfParcelable = paramBundle.getParcelableArray(paramString);
    if (arrayOfParcelable instanceof Bundle[] || arrayOfParcelable == null)
      return (Bundle[])arrayOfParcelable; 
    Bundle[] arrayOfBundle = Arrays.<Bundle, Parcelable>copyOf(arrayOfParcelable, arrayOfParcelable.length, Bundle[].class);
    paramBundle.putParcelableArray(paramString, (Parcelable[])arrayOfBundle);
    return arrayOfBundle;
  }
  
  static Bundle getBundleForAction(NotificationCompat.Action paramAction) {
    Bundle bundle1;
    Bundle bundle2 = new Bundle();
    IconCompat iconCompat = paramAction.getIconCompat();
    if (iconCompat != null) {
      i = iconCompat.getResId();
    } else {
      i = 0;
    } 
    bundle2.putInt(v416f9e89.xbd520268("3763"), i);
    CharSequence charSequence = paramAction.getTitle();
    bundle2.putCharSequence(v416f9e89.xbd520268("3764"), charSequence);
    PendingIntent pendingIntent = paramAction.getActionIntent();
    bundle2.putParcelable(v416f9e89.xbd520268("3765"), (Parcelable)pendingIntent);
    if (paramAction.getExtras() != null) {
      bundle1 = new Bundle(paramAction.getExtras());
    } else {
      bundle1 = new Bundle();
    } 
    boolean bool = paramAction.getAllowGeneratedReplies();
    bundle1.putBoolean(v416f9e89.xbd520268("3766"), bool);
    bundle2.putBundle(v416f9e89.xbd520268("3767"), bundle1);
    Bundle[] arrayOfBundle = toBundleArray(paramAction.getRemoteInputs());
    bundle2.putParcelableArray(v416f9e89.xbd520268("3768"), (Parcelable[])arrayOfBundle);
    bool = paramAction.getShowsUserInterface();
    bundle2.putBoolean(v416f9e89.xbd520268("3769"), bool);
    int i = paramAction.getSemanticAction();
    bundle2.putInt(v416f9e89.xbd520268("3770"), i);
    return bundle2;
  }
  
  public static Bundle getExtras(Notification paramNotification) {
    synchronized (sExtrasLock) {
      if (sExtrasFieldAccessFailed)
        return null; 
      try {
        if (sExtrasField == null) {
          Field field = Notification.class.getDeclaredField(v416f9e89.xbd520268("3771"));
          if (!Bundle.class.isAssignableFrom(field.getType())) {
            Log.e("NotificationCompat", v416f9e89.xbd520268("3772"));
            sExtrasFieldAccessFailed = true;
            return null;
          } 
          field.setAccessible(true);
          sExtrasField = field;
        } 
        Bundle bundle2 = (Bundle)sExtrasField.get(paramNotification);
        Bundle bundle1 = bundle2;
        if (bundle2 == null) {
          bundle1 = new Bundle();
          sExtrasField.set(paramNotification, bundle1);
        } 
        return bundle1;
      } catch (IllegalAccessException illegalAccessException) {
        Log.e(v416f9e89.xbd520268("3775"), v416f9e89.xbd520268("3776"), illegalAccessException);
      } catch (NoSuchFieldException noSuchFieldException) {
        Log.e(v416f9e89.xbd520268("3773"), v416f9e89.xbd520268("3774"), noSuchFieldException);
      } 
      sExtrasFieldAccessFailed = true;
      return null;
    } 
  }
  
  public static NotificationCompat.Action readAction(int paramInt, CharSequence paramCharSequence, PendingIntent paramPendingIntent, Bundle paramBundle) {
    boolean bool;
    RemoteInput[] arrayOfRemoteInput1;
    RemoteInput[] arrayOfRemoteInput2;
    if (paramBundle != null) {
      arrayOfRemoteInput1 = fromBundleArray(getBundleArrayFromBundle(paramBundle, v416f9e89.xbd520268("3777")));
      arrayOfRemoteInput2 = fromBundleArray(getBundleArrayFromBundle(paramBundle, v416f9e89.xbd520268("3778")));
      bool = paramBundle.getBoolean(v416f9e89.xbd520268("3779"));
    } else {
      arrayOfRemoteInput1 = null;
      arrayOfRemoteInput2 = arrayOfRemoteInput1;
      bool = false;
    } 
    return new NotificationCompat.Action(paramInt, paramCharSequence, paramPendingIntent, paramBundle, arrayOfRemoteInput1, arrayOfRemoteInput2, bool, 0, true, false, false);
  }
  
  private static Bundle toBundle(RemoteInput paramRemoteInput) {
    Bundle bundle1 = new Bundle();
    String str = paramRemoteInput.getResultKey();
    bundle1.putString(v416f9e89.xbd520268("3780"), str);
    CharSequence charSequence = paramRemoteInput.getLabel();
    bundle1.putCharSequence(v416f9e89.xbd520268("3781"), charSequence);
    CharSequence[] arrayOfCharSequence = paramRemoteInput.getChoices();
    bundle1.putCharSequenceArray(v416f9e89.xbd520268("3782"), arrayOfCharSequence);
    boolean bool = paramRemoteInput.getAllowFreeFormInput();
    bundle1.putBoolean(v416f9e89.xbd520268("3783"), bool);
    Bundle bundle2 = paramRemoteInput.getExtras();
    bundle1.putBundle(v416f9e89.xbd520268("3784"), bundle2);
    Set<String> set = paramRemoteInput.getAllowedDataTypes();
    if (set != null && !set.isEmpty()) {
      ArrayList<String> arrayList = new ArrayList(set.size());
      Iterator<String> iterator = set.iterator();
      while (iterator.hasNext())
        arrayList.add(iterator.next()); 
      bundle1.putStringArrayList(v416f9e89.xbd520268("3785"), arrayList);
    } 
    return bundle1;
  }
  
  private static Bundle[] toBundleArray(RemoteInput[] paramArrayOfRemoteInput) {
    if (paramArrayOfRemoteInput == null)
      return null; 
    Bundle[] arrayOfBundle = new Bundle[paramArrayOfRemoteInput.length];
    for (int i = 0; i < paramArrayOfRemoteInput.length; i++)
      arrayOfBundle[i] = toBundle(paramArrayOfRemoteInput[i]); 
    return arrayOfBundle;
  }
  
  public static Bundle writeActionAndGetExtras(Notification.Builder paramBuilder, NotificationCompat.Action paramAction) {
    boolean bool;
    IconCompat iconCompat = paramAction.getIconCompat();
    if (iconCompat != null) {
      bool = iconCompat.getResId();
    } else {
      bool = false;
    } 
    paramBuilder.addAction(bool, paramAction.getTitle(), paramAction.getActionIntent());
    Bundle bundle = new Bundle(paramAction.getExtras());
    if (paramAction.getRemoteInputs() != null) {
      Bundle[] arrayOfBundle = toBundleArray(paramAction.getRemoteInputs());
      bundle.putParcelableArray(v416f9e89.xbd520268("3786"), (Parcelable[])arrayOfBundle);
    } 
    if (paramAction.getDataOnlyRemoteInputs() != null) {
      Bundle[] arrayOfBundle = toBundleArray(paramAction.getDataOnlyRemoteInputs());
      bundle.putParcelableArray(v416f9e89.xbd520268("3787"), (Parcelable[])arrayOfBundle);
    } 
    boolean bool1 = paramAction.getAllowGeneratedReplies();
    bundle.putBoolean(v416f9e89.xbd520268("3788"), bool1);
    return bundle;
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\core\app\NotificationCompatJellybean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */