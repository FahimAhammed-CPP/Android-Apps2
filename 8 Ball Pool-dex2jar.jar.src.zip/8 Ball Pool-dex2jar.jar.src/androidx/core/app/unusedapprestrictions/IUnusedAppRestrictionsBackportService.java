package androidx.core.app.unusedapprestrictions;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import h8800e55c.pc41fcc5f.v416f9e89;

public interface IUnusedAppRestrictionsBackportService extends IInterface {
  public static final String DESCRIPTOR = v416f9e89.xbd520268("3789").replace('$', '.');
  
  void isPermissionRevocationEnabledForApp(IUnusedAppRestrictionsBackportCallback paramIUnusedAppRestrictionsBackportCallback) throws RemoteException;
  
  public static class Default implements IUnusedAppRestrictionsBackportService {
    public IBinder asBinder() {
      return null;
    }
    
    public void isPermissionRevocationEnabledForApp(IUnusedAppRestrictionsBackportCallback param1IUnusedAppRestrictionsBackportCallback) throws RemoteException {}
  }
  
  public static abstract class Stub extends Binder implements IUnusedAppRestrictionsBackportService {
    static final int TRANSACTION_isPermissionRevocationEnabledForApp = 1;
    
    public Stub() {
      attachInterface(this, DESCRIPTOR);
    }
    
    public static IUnusedAppRestrictionsBackportService asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface(DESCRIPTOR);
      return (iInterface != null && iInterface instanceof IUnusedAppRestrictionsBackportService) ? (IUnusedAppRestrictionsBackportService)iInterface : new Proxy(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      String str = DESCRIPTOR;
      if (param1Int1 >= 1 && param1Int1 <= 16777215)
        param1Parcel1.enforceInterface(str); 
      if (param1Int1 != 1598968902) {
        if (param1Int1 != 1)
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
        isPermissionRevocationEnabledForApp(IUnusedAppRestrictionsBackportCallback.Stub.asInterface(param1Parcel1.readStrongBinder()));
        return true;
      } 
      param1Parcel2.writeString(str);
      return true;
    }
    
    private static class Proxy implements IUnusedAppRestrictionsBackportService {
      private IBinder mRemote;
      
      Proxy(IBinder param2IBinder) {
        this.mRemote = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.mRemote;
      }
      
      public String getInterfaceDescriptor() {
        return DESCRIPTOR;
      }
      
      public void isPermissionRevocationEnabledForApp(IUnusedAppRestrictionsBackportCallback param2IUnusedAppRestrictionsBackportCallback) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken(DESCRIPTOR);
          parcel.writeStrongInterface(param2IUnusedAppRestrictionsBackportCallback);
          this.mRemote.transact(1, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
    }
  }
  
  private static class Proxy implements IUnusedAppRestrictionsBackportService {
    private IBinder mRemote;
    
    Proxy(IBinder param1IBinder) {
      this.mRemote = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.mRemote;
    }
    
    public String getInterfaceDescriptor() {
      return DESCRIPTOR;
    }
    
    public void isPermissionRevocationEnabledForApp(IUnusedAppRestrictionsBackportCallback param1IUnusedAppRestrictionsBackportCallback) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken(DESCRIPTOR);
        parcel.writeStrongInterface(param1IUnusedAppRestrictionsBackportCallback);
        this.mRemote.transact(1, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\core\ap\\unusedapprestrictions\IUnusedAppRestrictionsBackportService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */