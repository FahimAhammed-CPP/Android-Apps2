package androidx.core.app;

import android.content.Intent;
import androidx.core.util.Consumer;

public interface OnNewIntentProvider {
  void addOnNewIntentListener(Consumer<Intent> paramConsumer);
  
  void removeOnNewIntentListener(Consumer<Intent> paramConsumer);
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\core\app\OnNewIntentProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */