package androidx.core.app;

import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import h8800e55c.pc41fcc5f.v416f9e89;
import h8800e55c.x78d2f21c.y0bc38925;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public final class BundleCompat {
  public static IBinder getBinder(Bundle paramBundle, String paramString) {
    return (Build.VERSION.SDK_INT >= 18) ? Api18Impl.getBinder(paramBundle, paramString) : BeforeApi18Impl.getBinder(paramBundle, paramString);
  }
  
  public static void putBinder(Bundle paramBundle, String paramString, IBinder paramIBinder) {
    if (Build.VERSION.SDK_INT >= 18) {
      Api18Impl.putBinder(paramBundle, paramString, paramIBinder);
      return;
    } 
    BeforeApi18Impl.putBinder(paramBundle, paramString, paramIBinder);
  }
  
  static class Api18Impl {
    static IBinder getBinder(Bundle param1Bundle, String param1String) {
      return param1Bundle.getBinder(param1String);
    }
    
    static void putBinder(Bundle param1Bundle, String param1String, IBinder param1IBinder) {
      param1Bundle.putBinder(param1String, param1IBinder);
    }
  }
  
  static class BeforeApi18Impl {
    private static final String TAG = v416f9e89.xbd520268("3006");
    
    private static Method sGetIBinderMethod;
    
    private static boolean sGetIBinderMethodFetched;
    
    private static Method sPutIBinderMethod;
    
    private static boolean sPutIBinderMethodFetched;
    
    public static IBinder getBinder(Bundle param1Bundle, String param1String) {
      boolean bool = sGetIBinderMethodFetched;
      String str = v416f9e89.xbd520268("3007");
      if (!bool) {
        try {
          Method method1 = y0bc38925.getMethod(Bundle.class, v416f9e89.xbd520268("3008"), new Class[] { String.class });
          sGetIBinderMethod = method1;
          method1.setAccessible(true);
        } catch (NoSuchMethodException noSuchMethodException) {
          Log.i(str, v416f9e89.xbd520268("3009"), noSuchMethodException);
        } 
        sGetIBinderMethodFetched = true;
      } 
      Method method = sGetIBinderMethod;
      if (method != null) {
        try {
          return (IBinder)method.invoke(param1Bundle, new Object[] { param1String });
        } catch (InvocationTargetException invocationTargetException) {
        
        } catch (IllegalAccessException illegalAccessException) {
        
        } catch (IllegalArgumentException illegalArgumentException) {}
        Log.i(str, v416f9e89.xbd520268("3010"), illegalArgumentException);
        sGetIBinderMethod = null;
      } 
      return null;
    }
    
    public static void putBinder(Bundle param1Bundle, String param1String, IBinder param1IBinder) {
      boolean bool = sPutIBinderMethodFetched;
      String str = v416f9e89.xbd520268("3011");
      if (!bool) {
        try {
          Method method1 = y0bc38925.getMethod(Bundle.class, v416f9e89.xbd520268("3012"), new Class[] { String.class, IBinder.class });
          sPutIBinderMethod = method1;
          method1.setAccessible(true);
        } catch (NoSuchMethodException noSuchMethodException) {
          Log.i(str, v416f9e89.xbd520268("3013"), noSuchMethodException);
        } 
        sPutIBinderMethodFetched = true;
      } 
      Method method = sPutIBinderMethod;
      if (method != null) {
        try {
          method.invoke(param1Bundle, new Object[] { param1String, param1IBinder });
          return;
        } catch (InvocationTargetException invocationTargetException) {
        
        } catch (IllegalAccessException illegalAccessException) {
        
        } catch (IllegalArgumentException illegalArgumentException) {}
        Log.i(str, v416f9e89.xbd520268("3014"), illegalArgumentException);
        sPutIBinderMethod = null;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\core\app\BundleCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */