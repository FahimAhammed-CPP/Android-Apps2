package androidx.core.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Person;
import android.app.RemoteInput;
import android.content.Context;
import android.content.LocusId;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.SparseArray;
import android.widget.RemoteViews;
import androidx.collection.ArraySet;
import androidx.core.graphics.drawable.IconCompat;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

class NotificationCompatBuilder implements NotificationBuilderWithBuilderAccessor {
  private final List<Bundle> mActionExtrasList;
  
  private RemoteViews mBigContentView;
  
  private final Notification.Builder mBuilder;
  
  private final NotificationCompat.Builder mBuilderCompat;
  
  private RemoteViews mContentView;
  
  private final Context mContext;
  
  private final Bundle mExtras;
  
  private int mGroupAlertBehavior;
  
  private RemoteViews mHeadsUpContentView;
  
  NotificationCompatBuilder(NotificationCompat.Builder paramBuilder) {
    boolean bool;
    this.mActionExtrasList = new ArrayList<Bundle>();
    this.mExtras = new Bundle();
    this.mBuilderCompat = paramBuilder;
    this.mContext = paramBuilder.mContext;
    if (Build.VERSION.SDK_INT >= 26) {
      this.mBuilder = Api26Impl.createBuilder(paramBuilder.mContext, paramBuilder.mChannelId);
    } else {
      this.mBuilder = new Notification.Builder(paramBuilder.mContext);
    } 
    Notification notification = paramBuilder.mNotification;
    Notification.Builder builder = this.mBuilder.setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, paramBuilder.mTickerView).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS);
    if ((notification.flags & 0x2) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOngoing(bool);
    if ((notification.flags & 0x8) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOnlyAlertOnce(bool);
    if ((notification.flags & 0x10) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setAutoCancel(bool).setDefaults(notification.defaults).setContentTitle(paramBuilder.mContentTitle).setContentText(paramBuilder.mContentText).setContentInfo(paramBuilder.mContentInfo).setContentIntent(paramBuilder.mContentIntent).setDeleteIntent(notification.deleteIntent);
    PendingIntent pendingIntent = paramBuilder.mFullScreenIntent;
    if ((notification.flags & 0x80) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder.setFullScreenIntent(pendingIntent, bool).setLargeIcon(paramBuilder.mLargeIcon).setNumber(paramBuilder.mNumber).setProgress(paramBuilder.mProgressMax, paramBuilder.mProgress, paramBuilder.mProgressIndeterminate);
    if (Build.VERSION.SDK_INT < 21)
      this.mBuilder.setSound(notification.sound, notification.audioStreamType); 
    if (Build.VERSION.SDK_INT >= 16) {
      Api16Impl.setPriority(Api16Impl.setUsesChronometer(Api16Impl.setSubText(this.mBuilder, paramBuilder.mSubText), paramBuilder.mUseChronometer), paramBuilder.mPriority);
      Iterator<NotificationCompat.Action> iterator = paramBuilder.mActions.iterator();
      while (iterator.hasNext())
        addAction(iterator.next()); 
      if (paramBuilder.mExtras != null)
        this.mExtras.putAll(paramBuilder.mExtras); 
      if (Build.VERSION.SDK_INT < 20) {
        if (paramBuilder.mLocalOnly)
          this.mExtras.putBoolean(v416f9e89.xbd520268("3694"), true); 
        if (paramBuilder.mGroupKey != null) {
          Bundle bundle = this.mExtras;
          String str = paramBuilder.mGroupKey;
          bundle.putString(v416f9e89.xbd520268("3695"), str);
          if (paramBuilder.mGroupSummary) {
            this.mExtras.putBoolean(v416f9e89.xbd520268("3696"), true);
          } else {
            this.mExtras.putBoolean(v416f9e89.xbd520268("3697"), true);
          } 
        } 
        if (paramBuilder.mSortKey != null) {
          Bundle bundle = this.mExtras;
          String str = paramBuilder.mSortKey;
          bundle.putString(v416f9e89.xbd520268("3698"), str);
        } 
      } 
      this.mContentView = paramBuilder.mContentView;
      this.mBigContentView = paramBuilder.mBigContentView;
    } 
    if (Build.VERSION.SDK_INT >= 17)
      Api17Impl.setShowWhen(this.mBuilder, paramBuilder.mShowWhen); 
    if (Build.VERSION.SDK_INT >= 19 && Build.VERSION.SDK_INT < 21) {
      List<String> list = combineLists(getPeople(paramBuilder.mPersonList), paramBuilder.mPeople);
      if (list != null && !list.isEmpty()) {
        Bundle bundle = this.mExtras;
        String[] arrayOfString = list.<String>toArray(new String[list.size()]);
        bundle.putStringArray(v416f9e89.xbd520268("3699"), arrayOfString);
      } 
    } 
    if (Build.VERSION.SDK_INT >= 20) {
      Api20Impl.setLocalOnly(this.mBuilder, paramBuilder.mLocalOnly);
      Api20Impl.setGroup(this.mBuilder, paramBuilder.mGroupKey);
      Api20Impl.setSortKey(this.mBuilder, paramBuilder.mSortKey);
      Api20Impl.setGroupSummary(this.mBuilder, paramBuilder.mGroupSummary);
      this.mGroupAlertBehavior = paramBuilder.mGroupAlertBehavior;
    } 
    if (Build.VERSION.SDK_INT >= 21) {
      List<String> list;
      Api21Impl.setCategory(this.mBuilder, paramBuilder.mCategory);
      Api21Impl.setColor(this.mBuilder, paramBuilder.mColor);
      Api21Impl.setVisibility(this.mBuilder, paramBuilder.mVisibility);
      Api21Impl.setPublicVersion(this.mBuilder, paramBuilder.mPublicVersion);
      Api21Impl.setSound(this.mBuilder, notification.sound, notification.audioAttributes);
      if (Build.VERSION.SDK_INT < 28) {
        list = combineLists(getPeople(paramBuilder.mPersonList), paramBuilder.mPeople);
      } else {
        list = paramBuilder.mPeople;
      } 
      if (list != null && !list.isEmpty())
        for (String str : list)
          Api21Impl.addPerson(this.mBuilder, str);  
      this.mHeadsUpContentView = paramBuilder.mHeadsUpContentView;
      if (paramBuilder.mInvisibleActions.size() > 0) {
        Bundle bundle1 = paramBuilder.getExtras();
        String str1 = v416f9e89.xbd520268("3700");
        Bundle bundle2 = bundle1.getBundle(str1);
        bundle1 = bundle2;
        if (bundle2 == null)
          bundle1 = new Bundle(); 
        bundle2 = new Bundle(bundle1);
        Bundle bundle3 = new Bundle();
        for (int i = 0; i < paramBuilder.mInvisibleActions.size(); i++)
          bundle3.putBundle(Integer.toString(i), NotificationCompatJellybean.getBundleForAction(paramBuilder.mInvisibleActions.get(i))); 
        String str2 = v416f9e89.xbd520268("3701");
        bundle1.putBundle(str2, bundle3);
        bundle2.putBundle(str2, bundle3);
        paramBuilder.getExtras().putBundle(str1, bundle1);
        this.mExtras.putBundle(str1, bundle2);
      } 
    } 
    if (Build.VERSION.SDK_INT >= 23 && paramBuilder.mSmallIcon != null)
      Api23Impl.setSmallIcon(this.mBuilder, paramBuilder.mSmallIcon); 
    if (Build.VERSION.SDK_INT >= 24) {
      Api19Impl.setExtras(this.mBuilder, paramBuilder.mExtras);
      Api24Impl.setRemoteInputHistory(this.mBuilder, paramBuilder.mRemoteInputHistory);
      if (paramBuilder.mContentView != null)
        Api24Impl.setCustomContentView(this.mBuilder, paramBuilder.mContentView); 
      if (paramBuilder.mBigContentView != null)
        Api24Impl.setCustomBigContentView(this.mBuilder, paramBuilder.mBigContentView); 
      if (paramBuilder.mHeadsUpContentView != null)
        Api24Impl.setCustomHeadsUpContentView(this.mBuilder, paramBuilder.mHeadsUpContentView); 
    } 
    if (Build.VERSION.SDK_INT >= 26) {
      Api26Impl.setBadgeIconType(this.mBuilder, paramBuilder.mBadgeIcon);
      Api26Impl.setSettingsText(this.mBuilder, paramBuilder.mSettingsText);
      Api26Impl.setShortcutId(this.mBuilder, paramBuilder.mShortcutId);
      Api26Impl.setTimeoutAfter(this.mBuilder, paramBuilder.mTimeout);
      Api26Impl.setGroupAlertBehavior(this.mBuilder, paramBuilder.mGroupAlertBehavior);
      if (paramBuilder.mColorizedSet)
        Api26Impl.setColorized(this.mBuilder, paramBuilder.mColorized); 
      if (!TextUtils.isEmpty(paramBuilder.mChannelId))
        this.mBuilder.setSound(null).setDefaults(0).setLights(0, 0, 0).setVibrate(null); 
    } 
    if (Build.VERSION.SDK_INT >= 28)
      for (Person person : paramBuilder.mPersonList)
        Api28Impl.addPerson(this.mBuilder, person.toAndroidPerson());  
    if (Build.VERSION.SDK_INT >= 29) {
      Api29Impl.setAllowSystemGeneratedContextualActions(this.mBuilder, paramBuilder.mAllowSystemGeneratedContextualActions);
      Api29Impl.setBubbleMetadata(this.mBuilder, NotificationCompat.BubbleMetadata.toPlatform(paramBuilder.mBubbleMetadata));
      if (paramBuilder.mLocusId != null)
        Api29Impl.setLocusId(this.mBuilder, paramBuilder.mLocusId.toLocusId()); 
    } 
    if (Build.VERSION.SDK_INT >= 31 && paramBuilder.mFgsDeferBehavior != 0)
      Api31Impl.setForegroundServiceBehavior(this.mBuilder, paramBuilder.mFgsDeferBehavior); 
    if (paramBuilder.mSilent) {
      if (this.mBuilderCompat.mGroupSummary) {
        this.mGroupAlertBehavior = 2;
      } else {
        this.mGroupAlertBehavior = 1;
      } 
      this.mBuilder.setVibrate(null);
      this.mBuilder.setSound(null);
      notification.defaults &= 0xFFFFFFFE;
      notification.defaults &= 0xFFFFFFFD;
      this.mBuilder.setDefaults(notification.defaults);
      if (Build.VERSION.SDK_INT >= 26) {
        if (TextUtils.isEmpty(this.mBuilderCompat.mGroupKey))
          Api20Impl.setGroup(this.mBuilder, v416f9e89.xbd520268("3702")); 
        Api26Impl.setGroupAlertBehavior(this.mBuilder, this.mGroupAlertBehavior);
      } 
    } 
  }
  
  private void addAction(NotificationCompat.Action paramAction) {
    if (Build.VERSION.SDK_INT >= 20) {
      Notification.Action.Builder builder;
      Bundle bundle;
      IconCompat iconCompat = paramAction.getIconCompat();
      int i = Build.VERSION.SDK_INT;
      boolean bool = false;
      if (i >= 23) {
        if (iconCompat != null) {
          Icon icon = iconCompat.toIcon();
        } else {
          iconCompat = null;
        } 
        builder = Api23Impl.createBuilder((Icon)iconCompat, paramAction.getTitle(), paramAction.getActionIntent());
      } else {
        if (builder != null) {
          i = builder.getResId();
        } else {
          i = 0;
        } 
        builder = Api20Impl.createBuilder(i, paramAction.getTitle(), paramAction.getActionIntent());
      } 
      if (paramAction.getRemoteInputs() != null) {
        RemoteInput[] arrayOfRemoteInput = RemoteInput.fromCompat(paramAction.getRemoteInputs());
        int j = arrayOfRemoteInput.length;
        for (i = bool; i < j; i++)
          Api20Impl.addRemoteInput(builder, arrayOfRemoteInput[i]); 
      } 
      if (paramAction.getExtras() != null) {
        bundle = new Bundle(paramAction.getExtras());
      } else {
        bundle = new Bundle();
      } 
      boolean bool1 = paramAction.getAllowGeneratedReplies();
      bundle.putBoolean(v416f9e89.xbd520268("3703"), bool1);
      if (Build.VERSION.SDK_INT >= 24)
        Api24Impl.setAllowGeneratedReplies(builder, paramAction.getAllowGeneratedReplies()); 
      i = paramAction.getSemanticAction();
      bundle.putInt(v416f9e89.xbd520268("3704"), i);
      if (Build.VERSION.SDK_INT >= 28)
        Api28Impl.setSemanticAction(builder, paramAction.getSemanticAction()); 
      if (Build.VERSION.SDK_INT >= 29)
        Api29Impl.setContextual(builder, paramAction.isContextual()); 
      if (Build.VERSION.SDK_INT >= 31)
        Api31Impl.setAuthenticationRequired(builder, paramAction.isAuthenticationRequired()); 
      bool1 = paramAction.getShowsUserInterface();
      bundle.putBoolean(v416f9e89.xbd520268("3705"), bool1);
      Api20Impl.addExtras(builder, bundle);
      Api20Impl.addAction(this.mBuilder, Api20Impl.build(builder));
      return;
    } 
    if (Build.VERSION.SDK_INT >= 16)
      this.mActionExtrasList.add(NotificationCompatJellybean.writeActionAndGetExtras(this.mBuilder, paramAction)); 
  }
  
  private static List<String> combineLists(List<String> paramList1, List<String> paramList2) {
    if (paramList1 == null)
      return paramList2; 
    if (paramList2 == null)
      return paramList1; 
    ArraySet arraySet = new ArraySet(paramList1.size() + paramList2.size());
    arraySet.addAll(paramList1);
    arraySet.addAll(paramList2);
    return new ArrayList<String>((Collection<? extends String>)arraySet);
  }
  
  private static List<String> getPeople(List<Person> paramList) {
    if (paramList == null)
      return null; 
    ArrayList<String> arrayList = new ArrayList(paramList.size());
    Iterator<Person> iterator = paramList.iterator();
    while (iterator.hasNext())
      arrayList.add(((Person)iterator.next()).resolveToLegacyUri()); 
    return arrayList;
  }
  
  private void removeSoundAndVibration(Notification paramNotification) {
    paramNotification.sound = null;
    paramNotification.vibrate = null;
    paramNotification.defaults &= 0xFFFFFFFE;
    paramNotification.defaults &= 0xFFFFFFFD;
  }
  
  public Notification build() {
    RemoteViews remoteViews;
    NotificationCompat.Style style = this.mBuilderCompat.mStyle;
    if (style != null)
      style.apply(this); 
    if (style != null) {
      remoteViews = style.makeContentView(this);
    } else {
      remoteViews = null;
    } 
    Notification notification = buildInternal();
    if (remoteViews != null) {
      notification.contentView = remoteViews;
    } else if (this.mBuilderCompat.mContentView != null) {
      notification.contentView = this.mBuilderCompat.mContentView;
    } 
    if (Build.VERSION.SDK_INT >= 16 && style != null) {
      remoteViews = style.makeBigContentView(this);
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
    } 
    if (Build.VERSION.SDK_INT >= 21 && style != null) {
      remoteViews = this.mBuilderCompat.mStyle.makeHeadsUpContentView(this);
      if (remoteViews != null)
        notification.headsUpContentView = remoteViews; 
    } 
    if (Build.VERSION.SDK_INT >= 16 && style != null) {
      Bundle bundle = NotificationCompat.getExtras(notification);
      if (bundle != null)
        style.addCompatExtras(bundle); 
    } 
    return notification;
  }
  
  protected Notification buildInternal() {
    RemoteViews remoteViews;
    if (Build.VERSION.SDK_INT >= 26)
      return Api16Impl.build(this.mBuilder); 
    if (Build.VERSION.SDK_INT >= 24) {
      Notification notification = Api16Impl.build(this.mBuilder);
      if (this.mGroupAlertBehavior != 0) {
        if (Api20Impl.getGroup(notification) != null && (notification.flags & 0x200) != 0 && this.mGroupAlertBehavior == 2)
          removeSoundAndVibration(notification); 
        if (Api20Impl.getGroup(notification) != null && (notification.flags & 0x200) == 0 && this.mGroupAlertBehavior == 1)
          removeSoundAndVibration(notification); 
      } 
      return notification;
    } 
    if (Build.VERSION.SDK_INT >= 21) {
      Api19Impl.setExtras(this.mBuilder, this.mExtras);
      Notification notification = Api16Impl.build(this.mBuilder);
      remoteViews = this.mContentView;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
      remoteViews = this.mBigContentView;
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
      remoteViews = this.mHeadsUpContentView;
      if (remoteViews != null)
        notification.headsUpContentView = remoteViews; 
      if (this.mGroupAlertBehavior != 0) {
        if (Api20Impl.getGroup(notification) != null && (notification.flags & 0x200) != 0 && this.mGroupAlertBehavior == 2)
          removeSoundAndVibration(notification); 
        if (Api20Impl.getGroup(notification) != null && (notification.flags & 0x200) == 0 && this.mGroupAlertBehavior == 1)
          removeSoundAndVibration(notification); 
      } 
      return notification;
    } 
    if (Build.VERSION.SDK_INT >= 20) {
      Api19Impl.setExtras(this.mBuilder, this.mExtras);
      Notification notification = Api16Impl.build(this.mBuilder);
      remoteViews = this.mContentView;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
      remoteViews = this.mBigContentView;
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
      if (this.mGroupAlertBehavior != 0) {
        if (Api20Impl.getGroup(notification) != null && (notification.flags & 0x200) != 0 && this.mGroupAlertBehavior == 2)
          removeSoundAndVibration(notification); 
        if (Api20Impl.getGroup(notification) != null && (notification.flags & 0x200) == 0 && this.mGroupAlertBehavior == 1)
          removeSoundAndVibration(notification); 
      } 
      return notification;
    } 
    int i = Build.VERSION.SDK_INT;
    String str = v416f9e89.xbd520268("3706");
    if (i >= 19) {
      SparseArray<Bundle> sparseArray = NotificationCompatJellybean.buildActionExtrasMap(this.mActionExtrasList);
      if (sparseArray != null)
        this.mExtras.putSparseParcelableArray(str, sparseArray); 
      Api19Impl.setExtras(this.mBuilder, this.mExtras);
      Notification notification = Api16Impl.build(this.mBuilder);
      remoteViews = this.mContentView;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
      remoteViews = this.mBigContentView;
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
      return notification;
    } 
    if (Build.VERSION.SDK_INT >= 16) {
      Notification notification = Api16Impl.build(this.mBuilder);
      Bundle bundle1 = NotificationCompat.getExtras(notification);
      Bundle bundle2 = new Bundle(this.mExtras);
      for (String str1 : this.mExtras.keySet()) {
        if (bundle1.containsKey(str1))
          bundle2.remove(str1); 
      } 
      bundle1.putAll(bundle2);
      SparseArray<Bundle> sparseArray = NotificationCompatJellybean.buildActionExtrasMap(this.mActionExtrasList);
      if (sparseArray != null)
        NotificationCompat.getExtras(notification).putSparseParcelableArray((String)remoteViews, sparseArray); 
      remoteViews = this.mContentView;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
      remoteViews = this.mBigContentView;
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
      return notification;
    } 
    return this.mBuilder.getNotification();
  }
  
  public Notification.Builder getBuilder() {
    return this.mBuilder;
  }
  
  Context getContext() {
    return this.mContext;
  }
  
  static class Api16Impl {
    static Notification build(Notification.Builder param1Builder) {
      return param1Builder.build();
    }
    
    static Notification.Builder setPriority(Notification.Builder param1Builder, int param1Int) {
      return param1Builder.setPriority(param1Int);
    }
    
    static Notification.Builder setSubText(Notification.Builder param1Builder, CharSequence param1CharSequence) {
      return param1Builder.setSubText(param1CharSequence);
    }
    
    static Notification.Builder setUsesChronometer(Notification.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setUsesChronometer(param1Boolean);
    }
  }
  
  static class Api17Impl {
    static Notification.Builder setShowWhen(Notification.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setShowWhen(param1Boolean);
    }
  }
  
  static class Api19Impl {
    static Notification.Builder setExtras(Notification.Builder param1Builder, Bundle param1Bundle) {
      return param1Builder.setExtras(param1Bundle);
    }
  }
  
  static class Api20Impl {
    static Notification.Builder addAction(Notification.Builder param1Builder, Notification.Action param1Action) {
      return param1Builder.addAction(param1Action);
    }
    
    static Notification.Action.Builder addExtras(Notification.Action.Builder param1Builder, Bundle param1Bundle) {
      return param1Builder.addExtras(param1Bundle);
    }
    
    static Notification.Action.Builder addRemoteInput(Notification.Action.Builder param1Builder, RemoteInput param1RemoteInput) {
      return param1Builder.addRemoteInput(param1RemoteInput);
    }
    
    static Notification.Action build(Notification.Action.Builder param1Builder) {
      return param1Builder.build();
    }
    
    static Notification.Action.Builder createBuilder(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      return new Notification.Action.Builder(param1Int, param1CharSequence, param1PendingIntent);
    }
    
    static String getGroup(Notification param1Notification) {
      return param1Notification.getGroup();
    }
    
    static Notification.Builder setGroup(Notification.Builder param1Builder, String param1String) {
      return param1Builder.setGroup(param1String);
    }
    
    static Notification.Builder setGroupSummary(Notification.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setGroupSummary(param1Boolean);
    }
    
    static Notification.Builder setLocalOnly(Notification.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setLocalOnly(param1Boolean);
    }
    
    static Notification.Builder setSortKey(Notification.Builder param1Builder, String param1String) {
      return param1Builder.setSortKey(param1String);
    }
  }
  
  static class Api21Impl {
    static Notification.Builder addPerson(Notification.Builder param1Builder, String param1String) {
      return param1Builder.addPerson(param1String);
    }
    
    static Notification.Builder setCategory(Notification.Builder param1Builder, String param1String) {
      return param1Builder.setCategory(param1String);
    }
    
    static Notification.Builder setColor(Notification.Builder param1Builder, int param1Int) {
      return param1Builder.setColor(param1Int);
    }
    
    static Notification.Builder setPublicVersion(Notification.Builder param1Builder, Notification param1Notification) {
      return param1Builder.setPublicVersion(param1Notification);
    }
    
    static Notification.Builder setSound(Notification.Builder param1Builder, Uri param1Uri, Object param1Object) {
      return param1Builder.setSound(param1Uri, (AudioAttributes)param1Object);
    }
    
    static Notification.Builder setVisibility(Notification.Builder param1Builder, int param1Int) {
      return param1Builder.setVisibility(param1Int);
    }
  }
  
  static class Api23Impl {
    static Notification.Action.Builder createBuilder(Icon param1Icon, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      return new Notification.Action.Builder(param1Icon, param1CharSequence, param1PendingIntent);
    }
    
    static Notification.Builder setSmallIcon(Notification.Builder param1Builder, Object param1Object) {
      return param1Builder.setSmallIcon((Icon)param1Object);
    }
  }
  
  static class Api24Impl {
    static Notification.Action.Builder setAllowGeneratedReplies(Notification.Action.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setAllowGeneratedReplies(param1Boolean);
    }
    
    static Notification.Builder setCustomBigContentView(Notification.Builder param1Builder, RemoteViews param1RemoteViews) {
      return param1Builder.setCustomBigContentView(param1RemoteViews);
    }
    
    static Notification.Builder setCustomContentView(Notification.Builder param1Builder, RemoteViews param1RemoteViews) {
      return param1Builder.setCustomContentView(param1RemoteViews);
    }
    
    static Notification.Builder setCustomHeadsUpContentView(Notification.Builder param1Builder, RemoteViews param1RemoteViews) {
      return param1Builder.setCustomHeadsUpContentView(param1RemoteViews);
    }
    
    static Notification.Builder setRemoteInputHistory(Notification.Builder param1Builder, CharSequence[] param1ArrayOfCharSequence) {
      return param1Builder.setRemoteInputHistory(param1ArrayOfCharSequence);
    }
  }
  
  static class Api26Impl {
    static Notification.Builder createBuilder(Context param1Context, String param1String) {
      return new Notification.Builder(param1Context, param1String);
    }
    
    static Notification.Builder setBadgeIconType(Notification.Builder param1Builder, int param1Int) {
      return param1Builder.setBadgeIconType(param1Int);
    }
    
    static Notification.Builder setColorized(Notification.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setColorized(param1Boolean);
    }
    
    static Notification.Builder setGroupAlertBehavior(Notification.Builder param1Builder, int param1Int) {
      return param1Builder.setGroupAlertBehavior(param1Int);
    }
    
    static Notification.Builder setSettingsText(Notification.Builder param1Builder, CharSequence param1CharSequence) {
      return param1Builder.setSettingsText(param1CharSequence);
    }
    
    static Notification.Builder setShortcutId(Notification.Builder param1Builder, String param1String) {
      return param1Builder.setShortcutId(param1String);
    }
    
    static Notification.Builder setTimeoutAfter(Notification.Builder param1Builder, long param1Long) {
      return param1Builder.setTimeoutAfter(param1Long);
    }
  }
  
  static class Api28Impl {
    static Notification.Builder addPerson(Notification.Builder param1Builder, Person param1Person) {
      return param1Builder.addPerson(param1Person);
    }
    
    static Notification.Action.Builder setSemanticAction(Notification.Action.Builder param1Builder, int param1Int) {
      return param1Builder.setSemanticAction(param1Int);
    }
  }
  
  static class Api29Impl {
    static Notification.Builder setAllowSystemGeneratedContextualActions(Notification.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setAllowSystemGeneratedContextualActions(param1Boolean);
    }
    
    static Notification.Builder setBubbleMetadata(Notification.Builder param1Builder, Notification.BubbleMetadata param1BubbleMetadata) {
      return param1Builder.setBubbleMetadata(param1BubbleMetadata);
    }
    
    static Notification.Action.Builder setContextual(Notification.Action.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setContextual(param1Boolean);
    }
    
    static Notification.Builder setLocusId(Notification.Builder param1Builder, Object param1Object) {
      return param1Builder.setLocusId((LocusId)param1Object);
    }
  }
  
  static class Api31Impl {
    static Notification.Action.Builder setAuthenticationRequired(Notification.Action.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setAuthenticationRequired(param1Boolean);
    }
    
    static Notification.Builder setForegroundServiceBehavior(Notification.Builder param1Builder, int param1Int) {
      return param1Builder.setForegroundServiceBehavior(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\core\app\NotificationCompatBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */