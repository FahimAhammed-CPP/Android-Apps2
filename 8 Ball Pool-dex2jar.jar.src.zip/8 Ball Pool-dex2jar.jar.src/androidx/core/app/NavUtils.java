package androidx.core.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;
import h8800e55c.pc41fcc5f.v416f9e89;

public final class NavUtils {
  public static final String PARENT_ACTIVITY = v416f9e89.xbd520268("3036");
  
  private static final String TAG = v416f9e89.xbd520268("3037");
  
  public static Intent getParentActivityIntent(Activity paramActivity) {
    if (Build.VERSION.SDK_INT >= 16) {
      Intent intent = Api16Impl.getParentActivityIntent(paramActivity);
      if (intent != null)
        return intent; 
    } 
    String str = getParentActivityName(paramActivity);
    if (str == null)
      return null; 
    ComponentName componentName = new ComponentName((Context)paramActivity, str);
    try {
      return (getParentActivityName((Context)paramActivity, componentName) == null) ? Intent.makeMainActivity(componentName) : (new Intent()).setComponent(componentName);
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("3038"));
      stringBuilder.append(str);
      stringBuilder.append(v416f9e89.xbd520268("3039"));
      String str1 = stringBuilder.toString();
      Log.e(v416f9e89.xbd520268("3040"), str1);
      return null;
    } 
  }
  
  public static Intent getParentActivityIntent(Context paramContext, ComponentName paramComponentName) throws PackageManager.NameNotFoundException {
    String str = getParentActivityName(paramContext, paramComponentName);
    if (str == null)
      return null; 
    paramComponentName = new ComponentName(paramComponentName.getPackageName(), str);
    return (getParentActivityName(paramContext, paramComponentName) == null) ? Intent.makeMainActivity(paramComponentName) : (new Intent()).setComponent(paramComponentName);
  }
  
  public static Intent getParentActivityIntent(Context paramContext, Class<?> paramClass) throws PackageManager.NameNotFoundException {
    String str = getParentActivityName(paramContext, new ComponentName(paramContext, paramClass));
    if (str == null)
      return null; 
    ComponentName componentName = new ComponentName(paramContext, str);
    return (getParentActivityName(paramContext, componentName) == null) ? Intent.makeMainActivity(componentName) : (new Intent()).setComponent(componentName);
  }
  
  public static String getParentActivityName(Activity paramActivity) {
    try {
      return getParentActivityName((Context)paramActivity, paramActivity.getComponentName());
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      throw new IllegalArgumentException(nameNotFoundException);
    } 
  }
  
  public static String getParentActivityName(Context paramContext, ComponentName paramComponentName) throws PackageManager.NameNotFoundException {
    PackageManager packageManager = paramContext.getPackageManager();
    int i = Build.VERSION.SDK_INT;
    i = 640;
    if (Build.VERSION.SDK_INT >= 29) {
      i = 269222528;
    } else if (Build.VERSION.SDK_INT >= 24) {
      i = 787072;
    } 
    ActivityInfo activityInfo = packageManager.getActivityInfo(paramComponentName, i);
    if (Build.VERSION.SDK_INT >= 16) {
      String str = activityInfo.parentActivityName;
      if (str != null)
        return str; 
    } 
    if (activityInfo.metaData == null)
      return null; 
    String str2 = activityInfo.metaData.getString(v416f9e89.xbd520268("3041"));
    if (str2 == null)
      return null; 
    String str1 = str2;
    if (str2.charAt(0) == '.') {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramContext.getPackageName());
      stringBuilder.append(str2);
      str1 = stringBuilder.toString();
    } 
    return str1;
  }
  
  public static void navigateUpFromSameTask(Activity paramActivity) {
    Intent intent = getParentActivityIntent(paramActivity);
    if (intent != null) {
      navigateUpTo(paramActivity, intent);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(v416f9e89.xbd520268("3042"));
    stringBuilder.append(paramActivity.getClass().getSimpleName());
    stringBuilder.append(v416f9e89.xbd520268("3043"));
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public static void navigateUpTo(Activity paramActivity, Intent paramIntent) {
    if (Build.VERSION.SDK_INT >= 16) {
      Api16Impl.navigateUpTo(paramActivity, paramIntent);
      return;
    } 
    paramIntent.addFlags(67108864);
    paramActivity.startActivity(paramIntent);
    paramActivity.finish();
  }
  
  public static boolean shouldUpRecreateTask(Activity paramActivity, Intent paramIntent) {
    if (Build.VERSION.SDK_INT >= 16)
      return Api16Impl.shouldUpRecreateTask(paramActivity, paramIntent); 
    String str = paramActivity.getIntent().getAction();
    return (str != null && !str.equals(v416f9e89.xbd520268("3044")));
  }
  
  static class Api16Impl {
    static Intent getParentActivityIntent(Activity param1Activity) {
      return param1Activity.getParentActivityIntent();
    }
    
    static boolean navigateUpTo(Activity param1Activity, Intent param1Intent) {
      return param1Activity.navigateUpTo(param1Intent);
    }
    
    static boolean shouldUpRecreateTask(Activity param1Activity, Intent param1Intent) {
      return param1Activity.shouldUpRecreateTask(param1Intent);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\core\app\NavUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */