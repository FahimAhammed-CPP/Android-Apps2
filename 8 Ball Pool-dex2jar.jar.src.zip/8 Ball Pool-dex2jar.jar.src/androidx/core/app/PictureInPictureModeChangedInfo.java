package androidx.core.app;

import android.content.res.Configuration;
import h8800e55c.pc41fcc5f.v416f9e89;

public final class PictureInPictureModeChangedInfo {
  private final boolean mIsInPictureInPictureMode;
  
  private final Configuration mNewConfig;
  
  public PictureInPictureModeChangedInfo(boolean paramBoolean) {
    this.mIsInPictureInPictureMode = paramBoolean;
    this.mNewConfig = null;
  }
  
  public PictureInPictureModeChangedInfo(boolean paramBoolean, Configuration paramConfiguration) {
    this.mIsInPictureInPictureMode = paramBoolean;
    this.mNewConfig = paramConfiguration;
  }
  
  public Configuration getNewConfig() {
    Configuration configuration = this.mNewConfig;
    if (configuration != null)
      return configuration; 
    throw new IllegalStateException(v416f9e89.xbd520268("3971"));
  }
  
  public boolean isInPictureInPictureMode() {
    return this.mIsInPictureInPictureMode;
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\core\app\PictureInPictureModeChangedInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */