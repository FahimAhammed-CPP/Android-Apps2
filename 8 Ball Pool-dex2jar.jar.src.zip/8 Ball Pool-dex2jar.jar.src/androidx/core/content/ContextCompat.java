package androidx.core.content;

import android.accounts.AccountManager;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.AppOpsManager;
import android.app.DownloadManager;
import android.app.KeyguardManager;
import android.app.NotificationManager;
import android.app.SearchManager;
import android.app.UiModeManager;
import android.app.WallpaperManager;
import android.app.admin.DevicePolicyManager;
import android.app.job.JobScheduler;
import android.app.usage.UsageStatsManager;
import android.appwidget.AppWidgetManager;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.RestrictionsManager;
import android.content.pm.LauncherApps;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.hardware.ConsumerIrManager;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraManager;
import android.hardware.display.DisplayManager;
import android.hardware.input.InputManager;
import android.hardware.usb.UsbManager;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.MediaRouter;
import android.media.projection.MediaProjectionManager;
import android.media.session.MediaSessionManager;
import android.media.tv.TvInputManager;
import android.net.ConnectivityManager;
import android.net.nsd.NsdManager;
import android.net.wifi.WifiManager;
import android.net.wifi.p2p.WifiP2pManager;
import android.nfc.NfcManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.DropBoxManager;
import android.os.Handler;
import android.os.PowerManager;
import android.os.Process;
import android.os.UserManager;
import android.os.Vibrator;
import android.os.storage.StorageManager;
import android.print.PrintManager;
import android.telecom.TelecomManager;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.CaptioningManager;
import android.view.inputmethod.InputMethodManager;
import android.view.textservice.TextServicesManager;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.os.BuildCompat;
import androidx.core.os.ExecutorCompat;
import androidx.core.util.ObjectsCompat;
import h8800e55c.i2482f27b.i570d159d;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.io.File;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.HashMap;
import java.util.concurrent.Executor;

public class ContextCompat {
  private static final String DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION_SUFFIX = v416f9e89.xbd520268("3938");
  
  public static final int RECEIVER_EXPORTED = 2;
  
  public static final int RECEIVER_NOT_EXPORTED = 4;
  
  public static final int RECEIVER_VISIBLE_TO_INSTANT_APPS = 1;
  
  private static final String TAG = v416f9e89.xbd520268("3939");
  
  private static final Object sLock = new Object();
  
  private static final Object sSync = new Object();
  
  private static TypedValue sTempValue;
  
  public static int checkSelfPermission(Context paramContext, String paramString) {
    ObjectsCompat.requireNonNull(paramString, v416f9e89.xbd520268("3940"));
    return (!BuildCompat.isAtLeastT() && TextUtils.equals(v416f9e89.xbd520268("3941"), paramString)) ? (NotificationManagerCompat.from(paramContext).areNotificationsEnabled() ? 0 : -1) : paramContext.checkPermission(paramString, Process.myPid(), Process.myUid());
  }
  
  public static Context createDeviceProtectedStorageContext(Context paramContext) {
    return (Build.VERSION.SDK_INT >= 24) ? Api24Impl.createDeviceProtectedStorageContext(paramContext) : null;
  }
  
  private static File createFilesDir(File paramFile) {
    synchronized (sSync) {
      if (!paramFile.exists()) {
        if (paramFile.mkdirs())
          return paramFile; 
        String str = v416f9e89.xbd520268("3942");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(v416f9e89.xbd520268("3943"));
        stringBuilder.append(paramFile.getPath());
        Log.w(str, stringBuilder.toString());
      } 
      return paramFile;
    } 
  }
  
  public static String getAttributionTag(Context paramContext) {
    return (Build.VERSION.SDK_INT >= 30) ? Api30Impl.getAttributionTag(paramContext) : null;
  }
  
  public static File getCodeCacheDir(Context paramContext) {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.getCodeCacheDir(paramContext) : createFilesDir(new File((paramContext.getApplicationInfo()).dataDir, v416f9e89.xbd520268("3944")));
  }
  
  public static int getColor(Context paramContext, int paramInt) {
    return (Build.VERSION.SDK_INT >= 23) ? Api23Impl.getColor(paramContext, paramInt) : paramContext.getResources().getColor(paramInt);
  }
  
  public static ColorStateList getColorStateList(Context paramContext, int paramInt) {
    return ResourcesCompat.getColorStateList(paramContext.getResources(), paramInt, paramContext.getTheme());
  }
  
  public static File getDataDir(Context paramContext) {
    if (Build.VERSION.SDK_INT >= 24)
      return Api24Impl.getDataDir(paramContext); 
    String str = (paramContext.getApplicationInfo()).dataDir;
    return (str != null) ? new File(str) : null;
  }
  
  public static Drawable getDrawable(Context paramContext, int paramInt) {
    if (Build.VERSION.SDK_INT >= 21)
      return Api21Impl.getDrawable(paramContext, paramInt); 
    if (Build.VERSION.SDK_INT >= 16)
      return paramContext.getResources().getDrawable(paramInt); 
    synchronized (sLock) {
      if (sTempValue == null)
        sTempValue = new TypedValue(); 
      paramContext.getResources().getValue(paramInt, sTempValue, true);
      paramInt = sTempValue.resourceId;
      return paramContext.getResources().getDrawable(paramInt);
    } 
  }
  
  public static File[] getExternalCacheDirs(Context paramContext) {
    return (Build.VERSION.SDK_INT >= 19) ? Api19Impl.getExternalCacheDirs(paramContext) : new File[] { paramContext.getExternalCacheDir() };
  }
  
  public static File[] getExternalFilesDirs(Context paramContext, String paramString) {
    return (Build.VERSION.SDK_INT >= 19) ? Api19Impl.getExternalFilesDirs(paramContext, paramString) : new File[] { paramContext.getExternalFilesDir(paramString) };
  }
  
  public static Executor getMainExecutor(Context paramContext) {
    return (Build.VERSION.SDK_INT >= 28) ? Api28Impl.getMainExecutor(paramContext) : ExecutorCompat.create(new Handler(paramContext.getMainLooper()));
  }
  
  public static File getNoBackupFilesDir(Context paramContext) {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.getNoBackupFilesDir(paramContext) : createFilesDir(new File((paramContext.getApplicationInfo()).dataDir, v416f9e89.xbd520268("3945")));
  }
  
  public static File[] getObbDirs(Context paramContext) {
    return (Build.VERSION.SDK_INT >= 19) ? Api19Impl.getObbDirs(paramContext) : new File[] { paramContext.getObbDir() };
  }
  
  public static <T> T getSystemService(Context paramContext, Class<T> paramClass) {
    if (Build.VERSION.SDK_INT >= 23)
      return Api23Impl.getSystemService(paramContext, paramClass); 
    String str = getSystemServiceName(paramContext, paramClass);
    return (T)((str != null) ? paramContext.getSystemService(str) : null);
  }
  
  public static String getSystemServiceName(Context paramContext, Class<?> paramClass) {
    return (Build.VERSION.SDK_INT >= 23) ? Api23Impl.getSystemServiceName(paramContext, paramClass) : LegacyServiceMapHolder.SERVICES.get(paramClass);
  }
  
  public static boolean isDeviceProtectedStorage(Context paramContext) {
    return (Build.VERSION.SDK_INT >= 24) ? Api24Impl.isDeviceProtectedStorage(paramContext) : false;
  }
  
  static String obtainAndCheckReceiverPermission(Context paramContext) {
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramContext.getPackageName());
    stringBuilder2.append(v416f9e89.xbd520268("3946"));
    String str = stringBuilder2.toString();
    if (PermissionChecker.checkSelfPermission(paramContext, str) == 0)
      return str; 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(v416f9e89.xbd520268("3947"));
    stringBuilder1.append(str);
    stringBuilder1.append(v416f9e89.xbd520268("3948"));
    throw new RuntimeException(stringBuilder1.toString());
  }
  
  public static Intent registerReceiver(Context paramContext, BroadcastReceiver paramBroadcastReceiver, IntentFilter paramIntentFilter, int paramInt) {
    return registerReceiver(paramContext, paramBroadcastReceiver, paramIntentFilter, null, null, paramInt);
  }
  
  public static Intent registerReceiver(Context paramContext, BroadcastReceiver paramBroadcastReceiver, IntentFilter paramIntentFilter, String paramString, Handler paramHandler, int paramInt) {
    int i = paramInt & 0x1;
    if (i == 0 || (paramInt & 0x4) == 0) {
      int j = paramInt;
      if (i != 0)
        j = paramInt | 0x2; 
      paramInt = j & 0x2;
      if (paramInt != 0 || (j & 0x4) != 0) {
        if (paramInt == 0 || (j & 0x4) == 0)
          return BuildCompat.isAtLeastT() ? Api33Impl.registerReceiver(paramContext, paramBroadcastReceiver, paramIntentFilter, paramString, paramHandler, j) : ((Build.VERSION.SDK_INT >= 26) ? Api26Impl.registerReceiver(paramContext, paramBroadcastReceiver, paramIntentFilter, paramString, paramHandler, j) : (((j & 0x4) != 0 && paramString == null) ? i570d159d.registerReceiver(paramContext, paramBroadcastReceiver, paramIntentFilter, obtainAndCheckReceiverPermission(paramContext), paramHandler) : i570d159d.registerReceiver(paramContext, paramBroadcastReceiver, paramIntentFilter, paramString, paramHandler))); 
        throw new IllegalArgumentException(v416f9e89.xbd520268("3951"));
      } 
      throw new IllegalArgumentException(v416f9e89.xbd520268("3950"));
    } 
    throw new IllegalArgumentException(v416f9e89.xbd520268("3949"));
  }
  
  public static boolean startActivities(Context paramContext, Intent[] paramArrayOfIntent) {
    return startActivities(paramContext, paramArrayOfIntent, null);
  }
  
  public static boolean startActivities(Context paramContext, Intent[] paramArrayOfIntent, Bundle paramBundle) {
    if (Build.VERSION.SDK_INT >= 16) {
      Api16Impl.startActivities(paramContext, paramArrayOfIntent, paramBundle);
    } else {
      paramContext.startActivities(paramArrayOfIntent);
    } 
    return true;
  }
  
  public static void startActivity(Context paramContext, Intent paramIntent, Bundle paramBundle) {
    if (Build.VERSION.SDK_INT >= 16) {
      Api16Impl.startActivity(paramContext, paramIntent, paramBundle);
      return;
    } 
    paramContext.startActivity(paramIntent);
  }
  
  public static void startForegroundService(Context paramContext, Intent paramIntent) {
    if (Build.VERSION.SDK_INT >= 26) {
      Api26Impl.startForegroundService(paramContext, paramIntent);
      return;
    } 
    paramContext.startService(paramIntent);
  }
  
  static class Api16Impl {
    static void startActivities(Context param1Context, Intent[] param1ArrayOfIntent, Bundle param1Bundle) {
      param1Context.startActivities(param1ArrayOfIntent, param1Bundle);
    }
    
    static void startActivity(Context param1Context, Intent param1Intent, Bundle param1Bundle) {
      param1Context.startActivity(param1Intent, param1Bundle);
    }
  }
  
  static class Api19Impl {
    static File[] getExternalCacheDirs(Context param1Context) {
      return param1Context.getExternalCacheDirs();
    }
    
    static File[] getExternalFilesDirs(Context param1Context, String param1String) {
      return param1Context.getExternalFilesDirs(param1String);
    }
    
    static File[] getObbDirs(Context param1Context) {
      return param1Context.getObbDirs();
    }
  }
  
  static class Api21Impl {
    static File getCodeCacheDir(Context param1Context) {
      return param1Context.getCodeCacheDir();
    }
    
    static Drawable getDrawable(Context param1Context, int param1Int) {
      return param1Context.getDrawable(param1Int);
    }
    
    static File getNoBackupFilesDir(Context param1Context) {
      return param1Context.getNoBackupFilesDir();
    }
  }
  
  static class Api23Impl {
    static int getColor(Context param1Context, int param1Int) {
      return param1Context.getColor(param1Int);
    }
    
    static <T> T getSystemService(Context param1Context, Class<T> param1Class) {
      return (T)param1Context.getSystemService(param1Class);
    }
    
    static String getSystemServiceName(Context param1Context, Class<?> param1Class) {
      return param1Context.getSystemServiceName(param1Class);
    }
  }
  
  static class Api24Impl {
    static Context createDeviceProtectedStorageContext(Context param1Context) {
      return param1Context.createDeviceProtectedStorageContext();
    }
    
    static File getDataDir(Context param1Context) {
      return param1Context.getDataDir();
    }
    
    static boolean isDeviceProtectedStorage(Context param1Context) {
      return param1Context.isDeviceProtectedStorage();
    }
  }
  
  static class Api26Impl {
    static Intent registerReceiver(Context param1Context, BroadcastReceiver param1BroadcastReceiver, IntentFilter param1IntentFilter, String param1String, Handler param1Handler, int param1Int) {
      return ((param1Int & 0x4) != 0 && param1String == null) ? i570d159d.registerReceiver(param1Context, param1BroadcastReceiver, param1IntentFilter, ContextCompat.obtainAndCheckReceiverPermission(param1Context), param1Handler) : i570d159d.registerReceiver(param1Context, param1BroadcastReceiver, param1IntentFilter, param1String, param1Handler, param1Int & 0x1);
    }
    
    static ComponentName startForegroundService(Context param1Context, Intent param1Intent) {
      return param1Context.startForegroundService(param1Intent);
    }
  }
  
  static class Api28Impl {
    static Executor getMainExecutor(Context param1Context) {
      return param1Context.getMainExecutor();
    }
  }
  
  static class Api30Impl {
    static String getAttributionTag(Context param1Context) {
      return param1Context.getAttributionTag();
    }
  }
  
  static class Api33Impl {
    static Intent registerReceiver(Context param1Context, BroadcastReceiver param1BroadcastReceiver, IntentFilter param1IntentFilter, String param1String, Handler param1Handler, int param1Int) {
      return i570d159d.registerReceiver(param1Context, param1BroadcastReceiver, param1IntentFilter, param1String, param1Handler, param1Int);
    }
  }
  
  private static final class LegacyServiceMapHolder {
    static final HashMap<Class<?>, String> SERVICES;
    
    static {
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      SERVICES = (HashMap)hashMap;
      if (Build.VERSION.SDK_INT >= 22) {
        hashMap.put(SubscriptionManager.class, v416f9e89.xbd520268("3874"));
        hashMap.put(UsageStatsManager.class, v416f9e89.xbd520268("3875"));
      } 
      if (Build.VERSION.SDK_INT >= 21) {
        hashMap.put(AppWidgetManager.class, v416f9e89.xbd520268("3876"));
        hashMap.put(BatteryManager.class, v416f9e89.xbd520268("3877"));
        hashMap.put(CameraManager.class, v416f9e89.xbd520268("3878"));
        hashMap.put(JobScheduler.class, v416f9e89.xbd520268("3879"));
        hashMap.put(LauncherApps.class, v416f9e89.xbd520268("3880"));
        hashMap.put(MediaProjectionManager.class, v416f9e89.xbd520268("3881"));
        hashMap.put(MediaSessionManager.class, v416f9e89.xbd520268("3882"));
        hashMap.put(RestrictionsManager.class, v416f9e89.xbd520268("3883"));
        hashMap.put(TelecomManager.class, v416f9e89.xbd520268("3884"));
        hashMap.put(TvInputManager.class, v416f9e89.xbd520268("3885"));
      } 
      if (Build.VERSION.SDK_INT >= 19) {
        hashMap.put(AppOpsManager.class, v416f9e89.xbd520268("3886"));
        hashMap.put(CaptioningManager.class, v416f9e89.xbd520268("3887"));
        hashMap.put(ConsumerIrManager.class, v416f9e89.xbd520268("3888"));
        hashMap.put(PrintManager.class, v416f9e89.xbd520268("3889"));
      } 
      if (Build.VERSION.SDK_INT >= 18)
        hashMap.put(BluetoothManager.class, v416f9e89.xbd520268("3890")); 
      if (Build.VERSION.SDK_INT >= 17) {
        hashMap.put(DisplayManager.class, v416f9e89.xbd520268("3891"));
        hashMap.put(UserManager.class, v416f9e89.xbd520268("3892"));
      } 
      if (Build.VERSION.SDK_INT >= 16) {
        hashMap.put(InputManager.class, v416f9e89.xbd520268("3893"));
        hashMap.put(MediaRouter.class, v416f9e89.xbd520268("3894"));
        hashMap.put(NsdManager.class, v416f9e89.xbd520268("3895"));
      } 
      hashMap.put(AccessibilityManager.class, v416f9e89.xbd520268("3896"));
      hashMap.put(AccountManager.class, v416f9e89.xbd520268("3897"));
      hashMap.put(ActivityManager.class, v416f9e89.xbd520268("3898"));
      hashMap.put(AlarmManager.class, v416f9e89.xbd520268("3899"));
      hashMap.put(AudioManager.class, v416f9e89.xbd520268("3900"));
      hashMap.put(ClipboardManager.class, v416f9e89.xbd520268("3901"));
      hashMap.put(ConnectivityManager.class, v416f9e89.xbd520268("3902"));
      hashMap.put(DevicePolicyManager.class, v416f9e89.xbd520268("3903"));
      hashMap.put(DownloadManager.class, v416f9e89.xbd520268("3904"));
      hashMap.put(DropBoxManager.class, v416f9e89.xbd520268("3905"));
      hashMap.put(InputMethodManager.class, v416f9e89.xbd520268("3906"));
      hashMap.put(KeyguardManager.class, v416f9e89.xbd520268("3907"));
      hashMap.put(LayoutInflater.class, v416f9e89.xbd520268("3908"));
      hashMap.put(LocationManager.class, v416f9e89.xbd520268("3909"));
      hashMap.put(NfcManager.class, v416f9e89.xbd520268("3910"));
      hashMap.put(NotificationManager.class, v416f9e89.xbd520268("3911"));
      hashMap.put(PowerManager.class, v416f9e89.xbd520268("3912"));
      hashMap.put(SearchManager.class, v416f9e89.xbd520268("3913"));
      hashMap.put(SensorManager.class, v416f9e89.xbd520268("3914"));
      hashMap.put(StorageManager.class, v416f9e89.xbd520268("3915"));
      hashMap.put(TelephonyManager.class, v416f9e89.xbd520268("3916"));
      hashMap.put(TextServicesManager.class, v416f9e89.xbd520268("3917"));
      hashMap.put(UiModeManager.class, v416f9e89.xbd520268("3918"));
      hashMap.put(UsbManager.class, v416f9e89.xbd520268("3919"));
      hashMap.put(Vibrator.class, v416f9e89.xbd520268("3920"));
      hashMap.put(WallpaperManager.class, v416f9e89.xbd520268("3921"));
      hashMap.put(WifiP2pManager.class, v416f9e89.xbd520268("3922"));
      hashMap.put(WifiManager.class, v416f9e89.xbd520268("3923"));
      hashMap.put(WindowManager.class, v416f9e89.xbd520268("3924"));
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface RegisterReceiverFlags {}
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\core\content\ContextCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */