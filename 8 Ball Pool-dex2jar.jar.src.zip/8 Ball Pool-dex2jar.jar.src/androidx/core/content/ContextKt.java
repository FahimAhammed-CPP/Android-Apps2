package androidx.core.content;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import h8800e55c.pc41fcc5f.v416f9e89;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

public final class ContextKt {
  public static final void withStyledAttributes(Context paramContext, int paramInt, int[] paramArrayOfint, Function1<? super TypedArray, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramContext, v416f9e89.xbd520268("3994"));
    Intrinsics.checkNotNullParameter(paramArrayOfint, v416f9e89.xbd520268("3995"));
    Intrinsics.checkNotNullParameter(paramFunction1, v416f9e89.xbd520268("3996"));
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramInt, paramArrayOfint);
    Intrinsics.checkNotNullExpressionValue(typedArray, v416f9e89.xbd520268("3997"));
    paramFunction1.invoke(typedArray);
    typedArray.recycle();
  }
  
  public static final void withStyledAttributes(Context paramContext, AttributeSet paramAttributeSet, int[] paramArrayOfint, int paramInt1, int paramInt2, Function1<? super TypedArray, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramContext, v416f9e89.xbd520268("3998"));
    Intrinsics.checkNotNullParameter(paramArrayOfint, v416f9e89.xbd520268("3999"));
    Intrinsics.checkNotNullParameter(paramFunction1, v416f9e89.xbd520268("4000"));
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, paramArrayOfint, paramInt1, paramInt2);
    Intrinsics.checkNotNullExpressionValue(typedArray, v416f9e89.xbd520268("4001"));
    paramFunction1.invoke(typedArray);
    typedArray.recycle();
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\core\content\ContextKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */