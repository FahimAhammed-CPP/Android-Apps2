package androidx.core.content;

import android.content.ContentValues;
import h8800e55c.pc41fcc5f.v416f9e89;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;

public final class ContentValuesKt {
  public static final ContentValues contentValuesOf(Pair<String, ? extends Object>... paramVarArgs) {
    StringBuilder stringBuilder;
    Intrinsics.checkNotNullParameter(paramVarArgs, v416f9e89.xbd520268("3791"));
    ContentValues contentValues = new ContentValues(paramVarArgs.length);
    int j = paramVarArgs.length;
    for (int i = 0; i < j; i++) {
      Pair<String, ? extends Object> pair = paramVarArgs[i];
      String str = (String)pair.component1();
      Object object = pair.component2();
      if (object == null) {
        contentValues.putNull(str);
      } else if (object instanceof String) {
        contentValues.put(str, (String)object);
      } else if (object instanceof Integer) {
        contentValues.put(str, (Integer)object);
      } else if (object instanceof Long) {
        contentValues.put(str, (Long)object);
      } else if (object instanceof Boolean) {
        contentValues.put(str, (Boolean)object);
      } else if (object instanceof Float) {
        contentValues.put(str, (Float)object);
      } else if (object instanceof Double) {
        contentValues.put(str, (Double)object);
      } else if (object instanceof byte[]) {
        contentValues.put(str, (byte[])object);
      } else if (object instanceof Byte) {
        contentValues.put(str, (Byte)object);
      } else if (object instanceof Short) {
        contentValues.put(str, (Short)object);
      } else {
        String str1 = object.getClass().getCanonicalName();
        stringBuilder = new StringBuilder();
        stringBuilder.append(v416f9e89.xbd520268("3792"));
        stringBuilder.append(str1);
        stringBuilder.append(v416f9e89.xbd520268("3793"));
        stringBuilder.append(str);
        stringBuilder.append('"');
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
    } 
    return (ContentValues)stringBuilder;
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\core\content\ContentValuesKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */