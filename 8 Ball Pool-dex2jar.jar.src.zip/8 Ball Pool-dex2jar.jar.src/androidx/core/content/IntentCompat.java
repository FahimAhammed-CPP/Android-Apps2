package androidx.core.content;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;
import androidx.core.os.BuildCompat;
import androidx.core.util.Preconditions;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.util.ArrayList;

public final class IntentCompat {
  public static final String ACTION_CREATE_REMINDER = v416f9e89.xbd520268("4113");
  
  public static final String CATEGORY_LEANBACK_LAUNCHER = v416f9e89.xbd520268("4114");
  
  public static final String EXTRA_HTML_TEXT = v416f9e89.xbd520268("4115");
  
  public static final String EXTRA_START_PLAYBACK = v416f9e89.xbd520268("4116");
  
  public static final String EXTRA_TIME = v416f9e89.xbd520268("4117");
  
  public static Intent createManageUnusedAppRestrictionsIntent(Context paramContext, String paramString) {
    if (PackageManagerCompat.areUnusedAppRestrictionsAvailable(paramContext.getPackageManager())) {
      int i = Build.VERSION.SDK_INT;
      String str = v416f9e89.xbd520268("4118");
      if (i >= 31)
        return (new Intent(v416f9e89.xbd520268("4119"))).setData(Uri.fromParts(str, paramString, null)); 
      Intent intent = (new Intent(v416f9e89.xbd520268("4120"))).setData(Uri.fromParts(str, paramString, null));
      return (Build.VERSION.SDK_INT >= 30) ? intent : intent.setPackage((String)Preconditions.checkNotNull(PackageManagerCompat.getPermissionRevocationVerifierApp(paramContext.getPackageManager())));
    } 
    throw new UnsupportedOperationException(v416f9e89.xbd520268("4121"));
  }
  
  public static Parcelable[] getParcelableArrayExtra(Intent paramIntent, String paramString, Class<? extends Parcelable> paramClass) {
    return BuildCompat.isAtLeastU() ? Api33Impl.<Parcelable>getParcelableArrayExtra(paramIntent, paramString, (Class)paramClass) : paramIntent.getParcelableArrayExtra(paramString);
  }
  
  public static <T> ArrayList<T> getParcelableArrayListExtra(Intent paramIntent, String paramString, Class<? extends T> paramClass) {
    return BuildCompat.isAtLeastU() ? Api33Impl.getParcelableArrayListExtra(paramIntent, paramString, paramClass) : paramIntent.getParcelableArrayListExtra(paramString);
  }
  
  public static <T> T getParcelableExtra(Intent paramIntent, String paramString, Class<T> paramClass) {
    if (BuildCompat.isAtLeastU())
      return Api33Impl.getParcelableExtra(paramIntent, paramString, paramClass); 
    Parcelable parcelable = paramIntent.getParcelableExtra(paramString);
    return (T)(paramClass.isInstance(parcelable) ? parcelable : null);
  }
  
  public static Intent makeMainSelectorActivity(String paramString1, String paramString2) {
    if (Build.VERSION.SDK_INT >= 15)
      return Api15Impl.makeMainSelectorActivity(paramString1, paramString2); 
    Intent intent = new Intent(paramString1);
    intent.addCategory(paramString2);
    return intent;
  }
  
  static class Api15Impl {
    static Intent makeMainSelectorActivity(String param1String1, String param1String2) {
      return Intent.makeMainSelectorActivity(param1String1, param1String2);
    }
  }
  
  static class Api33Impl {
    static <T> T[] getParcelableArrayExtra(Intent param1Intent, String param1String, Class<T> param1Class) {
      return (T[])param1Intent.getParcelableArrayExtra(param1String, param1Class);
    }
    
    static <T> ArrayList<T> getParcelableArrayListExtra(Intent param1Intent, String param1String, Class<? extends T> param1Class) {
      return param1Intent.getParcelableArrayListExtra(param1String, param1Class);
    }
    
    static <T> T getParcelableExtra(Intent param1Intent, String param1String, Class<T> param1Class) {
      return (T)param1Intent.getParcelableExtra(param1String, param1Class);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\core\content\IntentCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */