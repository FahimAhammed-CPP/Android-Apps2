package androidx.appcompat.widget;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.database.DataSetObservable;
import android.os.AsyncTask;
import android.text.TextUtils;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class ActivityChooserModel extends DataSetObservable {
  static final String ATTRIBUTE_ACTIVITY = v416f9e89.xbd520268("1115");
  
  static final String ATTRIBUTE_TIME = v416f9e89.xbd520268("1116");
  
  static final String ATTRIBUTE_WEIGHT = v416f9e89.xbd520268("1117");
  
  static final boolean DEBUG = false;
  
  private static final int DEFAULT_ACTIVITY_INFLATION = 5;
  
  private static final float DEFAULT_HISTORICAL_RECORD_WEIGHT = 1.0F;
  
  public static final String DEFAULT_HISTORY_FILE_NAME = v416f9e89.xbd520268("1118");
  
  public static final int DEFAULT_HISTORY_MAX_LENGTH = 50;
  
  private static final String HISTORY_FILE_EXTENSION = v416f9e89.xbd520268("1119");
  
  private static final int INVALID_INDEX = -1;
  
  static final String LOG_TAG = v416f9e89.xbd520268("1120");
  
  static final String TAG_HISTORICAL_RECORD = v416f9e89.xbd520268("1121");
  
  static final String TAG_HISTORICAL_RECORDS = v416f9e89.xbd520268("1122");
  
  private static final Map<String, ActivityChooserModel> sDataModelRegistry;
  
  private static final Object sRegistryLock = new Object();
  
  private final List<ActivityResolveInfo> mActivities = new ArrayList<ActivityResolveInfo>();
  
  private OnChooseActivityListener mActivityChoserModelPolicy;
  
  private ActivitySorter mActivitySorter = new DefaultSorter();
  
  boolean mCanReadHistoricalData = true;
  
  final Context mContext;
  
  private final List<HistoricalRecord> mHistoricalRecords = new ArrayList<HistoricalRecord>();
  
  private boolean mHistoricalRecordsChanged = true;
  
  final String mHistoryFileName;
  
  private int mHistoryMaxSize = 50;
  
  private final Object mInstanceLock = new Object();
  
  private Intent mIntent;
  
  private boolean mReadShareHistoryCalled = false;
  
  private boolean mReloadActivities = false;
  
  static {
    sDataModelRegistry = new HashMap<String, ActivityChooserModel>();
  }
  
  private ActivityChooserModel(Context paramContext, String paramString) {
    this.mContext = paramContext.getApplicationContext();
    if (!TextUtils.isEmpty(paramString)) {
      String str = v416f9e89.xbd520268("1123");
      if (!paramString.endsWith(str)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(paramString);
        stringBuilder.append(str);
        this.mHistoryFileName = stringBuilder.toString();
        return;
      } 
    } 
    this.mHistoryFileName = paramString;
  }
  
  private boolean addHistoricalRecord(HistoricalRecord paramHistoricalRecord) {
    boolean bool = this.mHistoricalRecords.add(paramHistoricalRecord);
    if (bool) {
      this.mHistoricalRecordsChanged = true;
      pruneExcessiveHistoricalRecordsIfNeeded();
      persistHistoricalDataIfNeeded();
      sortActivitiesIfNeeded();
      notifyChanged();
    } 
    return bool;
  }
  
  private void ensureConsistentState() {
    boolean bool1 = loadActivitiesIfNeeded();
    boolean bool2 = readHistoricalDataIfNeeded();
    pruneExcessiveHistoricalRecordsIfNeeded();
    if (bool1 | bool2) {
      sortActivitiesIfNeeded();
      notifyChanged();
    } 
  }
  
  public static ActivityChooserModel get(Context paramContext, String paramString) {
    synchronized (sRegistryLock) {
      Map<String, ActivityChooserModel> map = sDataModelRegistry;
      ActivityChooserModel activityChooserModel2 = map.get(paramString);
      ActivityChooserModel activityChooserModel1 = activityChooserModel2;
      if (activityChooserModel2 == null) {
        activityChooserModel1 = new ActivityChooserModel(paramContext, paramString);
        map.put(paramString, activityChooserModel1);
      } 
      return activityChooserModel1;
    } 
  }
  
  private boolean loadActivitiesIfNeeded() {
    boolean bool = this.mReloadActivities;
    int i = 0;
    if (bool && this.mIntent != null) {
      this.mReloadActivities = false;
      this.mActivities.clear();
      List<ResolveInfo> list = this.mContext.getPackageManager().queryIntentActivities(this.mIntent, 0);
      int j = list.size();
      while (i < j) {
        ResolveInfo resolveInfo = list.get(i);
        this.mActivities.add(new ActivityResolveInfo(resolveInfo));
        i++;
      } 
      return true;
    } 
    return false;
  }
  
  private void persistHistoricalDataIfNeeded() {
    if (this.mReadShareHistoryCalled) {
      if (!this.mHistoricalRecordsChanged)
        return; 
      this.mHistoricalRecordsChanged = false;
      if (!TextUtils.isEmpty(this.mHistoryFileName))
        (new PersistHistoryAsyncTask()).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Object[] { new ArrayList<HistoricalRecord>(this.mHistoricalRecords), this.mHistoryFileName }); 
      return;
    } 
    throw new IllegalStateException(v416f9e89.xbd520268("1124"));
  }
  
  private void pruneExcessiveHistoricalRecordsIfNeeded() {
    int j = this.mHistoricalRecords.size() - this.mHistoryMaxSize;
    if (j <= 0)
      return; 
    this.mHistoricalRecordsChanged = true;
    for (int i = 0; i < j; i++)
      HistoricalRecord historicalRecord = this.mHistoricalRecords.remove(0); 
  }
  
  private boolean readHistoricalDataIfNeeded() {
    if (this.mCanReadHistoricalData && this.mHistoricalRecordsChanged && !TextUtils.isEmpty(this.mHistoryFileName)) {
      this.mCanReadHistoricalData = false;
      this.mReadShareHistoryCalled = true;
      readHistoricalDataImpl();
      return true;
    } 
    return false;
  }
  
  private void readHistoricalDataImpl() {
    // Byte code:
    //   0: ldc_w '1125'
    //   3: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   6: astore_3
    //   7: aload_0
    //   8: getfield mContext : Landroid/content/Context;
    //   11: aload_0
    //   12: getfield mHistoryFileName : Ljava/lang/String;
    //   15: invokevirtual openFileInput : (Ljava/lang/String;)Ljava/io/FileInputStream;
    //   18: astore_2
    //   19: invokestatic newPullParser : ()Lorg/xmlpull/v1/XmlPullParser;
    //   22: astore #4
    //   24: aload #4
    //   26: aload_2
    //   27: ldc_w '1126'
    //   30: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   33: invokeinterface setInput : (Ljava/io/InputStream;Ljava/lang/String;)V
    //   38: iconst_0
    //   39: istore_1
    //   40: iload_1
    //   41: iconst_1
    //   42: if_icmpeq -> 61
    //   45: iload_1
    //   46: iconst_2
    //   47: if_icmpeq -> 61
    //   50: aload #4
    //   52: invokeinterface next : ()I
    //   57: istore_1
    //   58: goto -> 40
    //   61: ldc_w '1127'
    //   64: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   67: aload #4
    //   69: invokeinterface getName : ()Ljava/lang/String;
    //   74: invokevirtual equals : (Ljava/lang/Object;)Z
    //   77: ifeq -> 231
    //   80: aload_0
    //   81: getfield mHistoricalRecords : Ljava/util/List;
    //   84: astore #5
    //   86: aload #5
    //   88: invokeinterface clear : ()V
    //   93: aload #4
    //   95: invokeinterface next : ()I
    //   100: istore_1
    //   101: iload_1
    //   102: iconst_1
    //   103: if_icmpne -> 115
    //   106: aload_2
    //   107: ifnull -> 355
    //   110: aload_2
    //   111: invokevirtual close : ()V
    //   114: return
    //   115: iload_1
    //   116: iconst_3
    //   117: if_icmpeq -> 93
    //   120: iload_1
    //   121: iconst_4
    //   122: if_icmpne -> 128
    //   125: goto -> 93
    //   128: aload #4
    //   130: invokeinterface getName : ()Ljava/lang/String;
    //   135: astore #6
    //   137: ldc_w '1128'
    //   140: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   143: aload #6
    //   145: invokevirtual equals : (Ljava/lang/Object;)Z
    //   148: ifeq -> 217
    //   151: aload #5
    //   153: new androidx/appcompat/widget/ActivityChooserModel$HistoricalRecord
    //   156: dup
    //   157: aload #4
    //   159: aconst_null
    //   160: ldc_w '1129'
    //   163: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   166: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   171: aload #4
    //   173: aconst_null
    //   174: ldc_w '1130'
    //   177: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   180: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   185: invokestatic parseLong : (Ljava/lang/String;)J
    //   188: aload #4
    //   190: aconst_null
    //   191: ldc_w '1131'
    //   194: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   197: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   202: invokestatic parseFloat : (Ljava/lang/String;)F
    //   205: invokespecial <init> : (Ljava/lang/String;JF)V
    //   208: invokeinterface add : (Ljava/lang/Object;)Z
    //   213: pop
    //   214: goto -> 93
    //   217: new org/xmlpull/v1/XmlPullParserException
    //   220: dup
    //   221: ldc_w '1132'
    //   224: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   227: invokespecial <init> : (Ljava/lang/String;)V
    //   230: athrow
    //   231: new org/xmlpull/v1/XmlPullParserException
    //   234: dup
    //   235: ldc_w '1133'
    //   238: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   241: invokespecial <init> : (Ljava/lang/String;)V
    //   244: athrow
    //   245: astore_3
    //   246: goto -> 356
    //   249: astore #4
    //   251: getstatic androidx/appcompat/widget/ActivityChooserModel.LOG_TAG : Ljava/lang/String;
    //   254: astore #5
    //   256: new java/lang/StringBuilder
    //   259: dup
    //   260: invokespecial <init> : ()V
    //   263: astore #6
    //   265: aload #6
    //   267: aload_3
    //   268: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   271: pop
    //   272: aload #6
    //   274: aload_0
    //   275: getfield mHistoryFileName : Ljava/lang/String;
    //   278: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   281: pop
    //   282: aload #5
    //   284: aload #6
    //   286: invokevirtual toString : ()Ljava/lang/String;
    //   289: aload #4
    //   291: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   294: pop
    //   295: aload_2
    //   296: ifnull -> 355
    //   299: goto -> 110
    //   302: astore #4
    //   304: getstatic androidx/appcompat/widget/ActivityChooserModel.LOG_TAG : Ljava/lang/String;
    //   307: astore #5
    //   309: new java/lang/StringBuilder
    //   312: dup
    //   313: invokespecial <init> : ()V
    //   316: astore #6
    //   318: aload #6
    //   320: aload_3
    //   321: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   324: pop
    //   325: aload #6
    //   327: aload_0
    //   328: getfield mHistoryFileName : Ljava/lang/String;
    //   331: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   334: pop
    //   335: aload #5
    //   337: aload #6
    //   339: invokevirtual toString : ()Ljava/lang/String;
    //   342: aload #4
    //   344: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   347: pop
    //   348: aload_2
    //   349: ifnull -> 355
    //   352: goto -> 110
    //   355: return
    //   356: aload_2
    //   357: ifnull -> 364
    //   360: aload_2
    //   361: invokevirtual close : ()V
    //   364: aload_3
    //   365: athrow
    //   366: astore_2
    //   367: return
    //   368: astore_2
    //   369: return
    //   370: astore_2
    //   371: goto -> 364
    // Exception table:
    //   from	to	target	type
    //   7	19	366	java/io/FileNotFoundException
    //   19	38	302	org/xmlpull/v1/XmlPullParserException
    //   19	38	249	java/io/IOException
    //   19	38	245	finally
    //   50	58	302	org/xmlpull/v1/XmlPullParserException
    //   50	58	249	java/io/IOException
    //   50	58	245	finally
    //   61	93	302	org/xmlpull/v1/XmlPullParserException
    //   61	93	249	java/io/IOException
    //   61	93	245	finally
    //   93	101	302	org/xmlpull/v1/XmlPullParserException
    //   93	101	249	java/io/IOException
    //   93	101	245	finally
    //   110	114	368	java/io/IOException
    //   128	214	302	org/xmlpull/v1/XmlPullParserException
    //   128	214	249	java/io/IOException
    //   128	214	245	finally
    //   217	231	302	org/xmlpull/v1/XmlPullParserException
    //   217	231	249	java/io/IOException
    //   217	231	245	finally
    //   231	245	302	org/xmlpull/v1/XmlPullParserException
    //   231	245	249	java/io/IOException
    //   231	245	245	finally
    //   251	295	245	finally
    //   304	348	245	finally
    //   360	364	370	java/io/IOException
  }
  
  private boolean sortActivitiesIfNeeded() {
    if (this.mActivitySorter != null && this.mIntent != null && !this.mActivities.isEmpty() && !this.mHistoricalRecords.isEmpty()) {
      this.mActivitySorter.sort(this.mIntent, this.mActivities, Collections.unmodifiableList(this.mHistoricalRecords));
      return true;
    } 
    return false;
  }
  
  public Intent chooseActivity(int paramInt) {
    synchronized (this.mInstanceLock) {
      if (this.mIntent == null)
        return null; 
      ensureConsistentState();
      ActivityResolveInfo activityResolveInfo = this.mActivities.get(paramInt);
      ComponentName componentName = new ComponentName(activityResolveInfo.resolveInfo.activityInfo.packageName, activityResolveInfo.resolveInfo.activityInfo.name);
      Intent intent = new Intent(this.mIntent);
      intent.setComponent(componentName);
      if (this.mActivityChoserModelPolicy != null) {
        Intent intent1 = new Intent(intent);
        if (this.mActivityChoserModelPolicy.onChooseActivity(this, intent1))
          return null; 
      } 
      addHistoricalRecord(new HistoricalRecord(componentName, System.currentTimeMillis(), 1.0F));
      return intent;
    } 
  }
  
  public ResolveInfo getActivity(int paramInt) {
    synchronized (this.mInstanceLock) {
      ensureConsistentState();
      return ((ActivityResolveInfo)this.mActivities.get(paramInt)).resolveInfo;
    } 
  }
  
  public int getActivityCount() {
    synchronized (this.mInstanceLock) {
      ensureConsistentState();
      return this.mActivities.size();
    } 
  }
  
  public int getActivityIndex(ResolveInfo paramResolveInfo) {
    synchronized (this.mInstanceLock) {
      ensureConsistentState();
      List<ActivityResolveInfo> list = this.mActivities;
      int j = list.size();
      for (int i = 0;; i++) {
        if (i < j) {
          if (((ActivityResolveInfo)list.get(i)).resolveInfo == paramResolveInfo)
            return i; 
        } else {
          return -1;
        } 
      } 
    } 
  }
  
  public ResolveInfo getDefaultActivity() {
    synchronized (this.mInstanceLock) {
      ensureConsistentState();
      if (!this.mActivities.isEmpty())
        return ((ActivityResolveInfo)this.mActivities.get(0)).resolveInfo; 
      return null;
    } 
  }
  
  public int getHistoryMaxSize() {
    synchronized (this.mInstanceLock) {
      return this.mHistoryMaxSize;
    } 
  }
  
  public int getHistorySize() {
    synchronized (this.mInstanceLock) {
      ensureConsistentState();
      return this.mHistoricalRecords.size();
    } 
  }
  
  public Intent getIntent() {
    synchronized (this.mInstanceLock) {
      return this.mIntent;
    } 
  }
  
  public void setActivitySorter(ActivitySorter paramActivitySorter) {
    synchronized (this.mInstanceLock) {
      if (this.mActivitySorter == paramActivitySorter)
        return; 
      this.mActivitySorter = paramActivitySorter;
      if (sortActivitiesIfNeeded())
        notifyChanged(); 
      return;
    } 
  }
  
  public void setDefaultActivity(int paramInt) {
    synchronized (this.mInstanceLock) {
      float f;
      ensureConsistentState();
      ActivityResolveInfo activityResolveInfo1 = this.mActivities.get(paramInt);
      ActivityResolveInfo activityResolveInfo2 = this.mActivities.get(0);
      if (activityResolveInfo2 != null) {
        f = activityResolveInfo2.weight - activityResolveInfo1.weight + 5.0F;
      } else {
        f = 1.0F;
      } 
      addHistoricalRecord(new HistoricalRecord(new ComponentName(activityResolveInfo1.resolveInfo.activityInfo.packageName, activityResolveInfo1.resolveInfo.activityInfo.name), System.currentTimeMillis(), f));
      return;
    } 
  }
  
  public void setHistoryMaxSize(int paramInt) {
    synchronized (this.mInstanceLock) {
      if (this.mHistoryMaxSize == paramInt)
        return; 
      this.mHistoryMaxSize = paramInt;
      pruneExcessiveHistoricalRecordsIfNeeded();
      if (sortActivitiesIfNeeded())
        notifyChanged(); 
      return;
    } 
  }
  
  public void setIntent(Intent paramIntent) {
    synchronized (this.mInstanceLock) {
      if (this.mIntent == paramIntent)
        return; 
      this.mIntent = paramIntent;
      this.mReloadActivities = true;
      ensureConsistentState();
      return;
    } 
  }
  
  public void setOnChooseActivityListener(OnChooseActivityListener paramOnChooseActivityListener) {
    synchronized (this.mInstanceLock) {
      this.mActivityChoserModelPolicy = paramOnChooseActivityListener;
      return;
    } 
  }
  
  public static interface ActivityChooserModelClient {
    void setActivityChooserModel(ActivityChooserModel param1ActivityChooserModel);
  }
  
  public static final class ActivityResolveInfo implements Comparable<ActivityResolveInfo> {
    public final ResolveInfo resolveInfo;
    
    public float weight;
    
    public ActivityResolveInfo(ResolveInfo param1ResolveInfo) {
      this.resolveInfo = param1ResolveInfo;
    }
    
    public int compareTo(ActivityResolveInfo param1ActivityResolveInfo) {
      return Float.floatToIntBits(param1ActivityResolveInfo.weight) - Float.floatToIntBits(this.weight);
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object == null)
        return false; 
      if (getClass() != param1Object.getClass())
        return false; 
      param1Object = param1Object;
      return !(Float.floatToIntBits(this.weight) != Float.floatToIntBits(((ActivityResolveInfo)param1Object).weight));
    }
    
    public int hashCode() {
      return Float.floatToIntBits(this.weight) + 31;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("1078"));
      stringBuilder.append(v416f9e89.xbd520268("1079"));
      stringBuilder.append(this.resolveInfo.toString());
      stringBuilder.append(v416f9e89.xbd520268("1080"));
      stringBuilder.append(new BigDecimal(this.weight));
      stringBuilder.append(v416f9e89.xbd520268("1081"));
      return stringBuilder.toString();
    }
  }
  
  public static interface ActivitySorter {
    void sort(Intent param1Intent, List<ActivityChooserModel.ActivityResolveInfo> param1List, List<ActivityChooserModel.HistoricalRecord> param1List1);
  }
  
  private static final class DefaultSorter implements ActivitySorter {
    private static final float WEIGHT_DECAY_COEFFICIENT = 0.95F;
    
    private final Map<ComponentName, ActivityChooserModel.ActivityResolveInfo> mPackageNameToActivityMap = new HashMap<ComponentName, ActivityChooserModel.ActivityResolveInfo>();
    
    public void sort(Intent param1Intent, List<ActivityChooserModel.ActivityResolveInfo> param1List, List<ActivityChooserModel.HistoricalRecord> param1List1) {
      Map<ComponentName, ActivityChooserModel.ActivityResolveInfo> map = this.mPackageNameToActivityMap;
      map.clear();
      int j = param1List.size();
      int i;
      for (i = 0; i < j; i++) {
        ActivityChooserModel.ActivityResolveInfo activityResolveInfo = param1List.get(i);
        activityResolveInfo.weight = 0.0F;
        map.put(new ComponentName(activityResolveInfo.resolveInfo.activityInfo.packageName, activityResolveInfo.resolveInfo.activityInfo.name), activityResolveInfo);
      } 
      i = param1List1.size() - 1;
      float f;
      for (f = 1.0F; i >= 0; f = f1) {
        ActivityChooserModel.HistoricalRecord historicalRecord = param1List1.get(i);
        ActivityChooserModel.ActivityResolveInfo activityResolveInfo = map.get(historicalRecord.activity);
        float f1 = f;
        if (activityResolveInfo != null) {
          activityResolveInfo.weight += historicalRecord.weight * f;
          f1 = f * 0.95F;
        } 
        i--;
      } 
      Collections.sort(param1List);
    }
  }
  
  public static final class HistoricalRecord {
    public final ComponentName activity;
    
    public final long time;
    
    public final float weight;
    
    public HistoricalRecord(ComponentName param1ComponentName, long param1Long, float param1Float) {
      this.activity = param1ComponentName;
      this.time = param1Long;
      this.weight = param1Float;
    }
    
    public HistoricalRecord(String param1String, long param1Long, float param1Float) {
      this(ComponentName.unflattenFromString(param1String), param1Long, param1Float);
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object == null)
        return false; 
      if (getClass() != param1Object.getClass())
        return false; 
      param1Object = param1Object;
      ComponentName componentName = this.activity;
      if (componentName == null) {
        if (((HistoricalRecord)param1Object).activity != null)
          return false; 
      } else if (!componentName.equals(((HistoricalRecord)param1Object).activity)) {
        return false;
      } 
      return (this.time != ((HistoricalRecord)param1Object).time) ? false : (!(Float.floatToIntBits(this.weight) != Float.floatToIntBits(((HistoricalRecord)param1Object).weight)));
    }
    
    public int hashCode() {
      int i;
      ComponentName componentName = this.activity;
      if (componentName == null) {
        i = 0;
      } else {
        i = componentName.hashCode();
      } 
      long l = this.time;
      return ((i + 31) * 31 + (int)(l ^ l >>> 32L)) * 31 + Float.floatToIntBits(this.weight);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("1072"));
      stringBuilder.append(v416f9e89.xbd520268("1073"));
      stringBuilder.append(this.activity);
      stringBuilder.append(v416f9e89.xbd520268("1074"));
      stringBuilder.append(this.time);
      stringBuilder.append(v416f9e89.xbd520268("1075"));
      stringBuilder.append(new BigDecimal(this.weight));
      stringBuilder.append(v416f9e89.xbd520268("1076"));
      return stringBuilder.toString();
    }
  }
  
  public static interface OnChooseActivityListener {
    boolean onChooseActivity(ActivityChooserModel param1ActivityChooserModel, Intent param1Intent);
  }
  
  private final class PersistHistoryAsyncTask extends AsyncTask<Object, Void, Void> {
    public Void doInBackground(Object... param1VarArgs) {
      // Byte code:
      //   0: ldc '1104'
      //   2: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
      //   5: astore #5
      //   7: ldc '1105'
      //   9: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
      //   12: astore #6
      //   14: ldc '1106'
      //   16: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
      //   19: astore #4
      //   21: aload_1
      //   22: iconst_0
      //   23: aaload
      //   24: checkcast java/util/List
      //   27: astore #7
      //   29: aload_1
      //   30: iconst_1
      //   31: aaload
      //   32: checkcast java/lang/String
      //   35: astore #8
      //   37: aload_0
      //   38: getfield this$0 : Landroidx/appcompat/widget/ActivityChooserModel;
      //   41: getfield mContext : Landroid/content/Context;
      //   44: aload #8
      //   46: iconst_0
      //   47: invokevirtual openFileOutput : (Ljava/lang/String;I)Ljava/io/FileOutputStream;
      //   50: astore_1
      //   51: invokestatic newSerializer : ()Lorg/xmlpull/v1/XmlSerializer;
      //   54: astore #8
      //   56: aload #8
      //   58: aload_1
      //   59: aconst_null
      //   60: invokeinterface setOutput : (Ljava/io/OutputStream;Ljava/lang/String;)V
      //   65: aload #8
      //   67: ldc '1107'
      //   69: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
      //   72: iconst_1
      //   73: invokestatic valueOf : (Z)Ljava/lang/Boolean;
      //   76: invokeinterface startDocument : (Ljava/lang/String;Ljava/lang/Boolean;)V
      //   81: aload #8
      //   83: aconst_null
      //   84: aload #6
      //   86: invokeinterface startTag : (Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
      //   91: pop
      //   92: aload #7
      //   94: invokeinterface size : ()I
      //   99: istore_3
      //   100: iconst_0
      //   101: istore_2
      //   102: iload_2
      //   103: iload_3
      //   104: if_icmpge -> 215
      //   107: aload #7
      //   109: iconst_0
      //   110: invokeinterface remove : (I)Ljava/lang/Object;
      //   115: checkcast androidx/appcompat/widget/ActivityChooserModel$HistoricalRecord
      //   118: astore #9
      //   120: aload #8
      //   122: aconst_null
      //   123: aload #5
      //   125: invokeinterface startTag : (Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
      //   130: pop
      //   131: aload #8
      //   133: aconst_null
      //   134: ldc '1108'
      //   136: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
      //   139: aload #9
      //   141: getfield activity : Landroid/content/ComponentName;
      //   144: invokevirtual flattenToString : ()Ljava/lang/String;
      //   147: invokeinterface attribute : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
      //   152: pop
      //   153: aload #8
      //   155: aconst_null
      //   156: ldc '1109'
      //   158: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
      //   161: aload #9
      //   163: getfield time : J
      //   166: invokestatic valueOf : (J)Ljava/lang/String;
      //   169: invokeinterface attribute : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
      //   174: pop
      //   175: aload #8
      //   177: aconst_null
      //   178: ldc '1110'
      //   180: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
      //   183: aload #9
      //   185: getfield weight : F
      //   188: invokestatic valueOf : (F)Ljava/lang/String;
      //   191: invokeinterface attribute : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
      //   196: pop
      //   197: aload #8
      //   199: aconst_null
      //   200: aload #5
      //   202: invokeinterface endTag : (Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
      //   207: pop
      //   208: iload_2
      //   209: iconst_1
      //   210: iadd
      //   211: istore_2
      //   212: goto -> 102
      //   215: aload #8
      //   217: aconst_null
      //   218: aload #6
      //   220: invokeinterface endTag : (Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
      //   225: pop
      //   226: aload #8
      //   228: invokeinterface endDocument : ()V
      //   233: aload_0
      //   234: getfield this$0 : Landroidx/appcompat/widget/ActivityChooserModel;
      //   237: iconst_1
      //   238: putfield mCanReadHistoricalData : Z
      //   241: aload_1
      //   242: ifnull -> 451
      //   245: aload_1
      //   246: invokevirtual close : ()V
      //   249: aconst_null
      //   250: areturn
      //   251: astore #4
      //   253: goto -> 453
      //   256: astore #5
      //   258: getstatic androidx/appcompat/widget/ActivityChooserModel.LOG_TAG : Ljava/lang/String;
      //   261: astore #6
      //   263: new java/lang/StringBuilder
      //   266: dup
      //   267: invokespecial <init> : ()V
      //   270: astore #7
      //   272: aload #7
      //   274: aload #4
      //   276: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   279: pop
      //   280: aload #7
      //   282: aload_0
      //   283: getfield this$0 : Landroidx/appcompat/widget/ActivityChooserModel;
      //   286: getfield mHistoryFileName : Ljava/lang/String;
      //   289: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   292: pop
      //   293: aload #6
      //   295: aload #7
      //   297: invokevirtual toString : ()Ljava/lang/String;
      //   300: aload #5
      //   302: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   305: pop
      //   306: aload_0
      //   307: getfield this$0 : Landroidx/appcompat/widget/ActivityChooserModel;
      //   310: iconst_1
      //   311: putfield mCanReadHistoricalData : Z
      //   314: aload_1
      //   315: ifnull -> 451
      //   318: goto -> 245
      //   321: astore #5
      //   323: getstatic androidx/appcompat/widget/ActivityChooserModel.LOG_TAG : Ljava/lang/String;
      //   326: astore #6
      //   328: new java/lang/StringBuilder
      //   331: dup
      //   332: invokespecial <init> : ()V
      //   335: astore #7
      //   337: aload #7
      //   339: aload #4
      //   341: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   344: pop
      //   345: aload #7
      //   347: aload_0
      //   348: getfield this$0 : Landroidx/appcompat/widget/ActivityChooserModel;
      //   351: getfield mHistoryFileName : Ljava/lang/String;
      //   354: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   357: pop
      //   358: aload #6
      //   360: aload #7
      //   362: invokevirtual toString : ()Ljava/lang/String;
      //   365: aload #5
      //   367: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   370: pop
      //   371: aload_0
      //   372: getfield this$0 : Landroidx/appcompat/widget/ActivityChooserModel;
      //   375: iconst_1
      //   376: putfield mCanReadHistoricalData : Z
      //   379: aload_1
      //   380: ifnull -> 451
      //   383: goto -> 245
      //   386: astore #5
      //   388: getstatic androidx/appcompat/widget/ActivityChooserModel.LOG_TAG : Ljava/lang/String;
      //   391: astore #6
      //   393: new java/lang/StringBuilder
      //   396: dup
      //   397: invokespecial <init> : ()V
      //   400: astore #7
      //   402: aload #7
      //   404: aload #4
      //   406: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   409: pop
      //   410: aload #7
      //   412: aload_0
      //   413: getfield this$0 : Landroidx/appcompat/widget/ActivityChooserModel;
      //   416: getfield mHistoryFileName : Ljava/lang/String;
      //   419: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   422: pop
      //   423: aload #6
      //   425: aload #7
      //   427: invokevirtual toString : ()Ljava/lang/String;
      //   430: aload #5
      //   432: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   435: pop
      //   436: aload_0
      //   437: getfield this$0 : Landroidx/appcompat/widget/ActivityChooserModel;
      //   440: iconst_1
      //   441: putfield mCanReadHistoricalData : Z
      //   444: aload_1
      //   445: ifnull -> 451
      //   448: goto -> 245
      //   451: aconst_null
      //   452: areturn
      //   453: aload_0
      //   454: getfield this$0 : Landroidx/appcompat/widget/ActivityChooserModel;
      //   457: iconst_1
      //   458: putfield mCanReadHistoricalData : Z
      //   461: aload_1
      //   462: ifnull -> 469
      //   465: aload_1
      //   466: invokevirtual close : ()V
      //   469: aload #4
      //   471: athrow
      //   472: astore_1
      //   473: getstatic androidx/appcompat/widget/ActivityChooserModel.LOG_TAG : Ljava/lang/String;
      //   476: astore #5
      //   478: new java/lang/StringBuilder
      //   481: dup
      //   482: invokespecial <init> : ()V
      //   485: astore #6
      //   487: aload #6
      //   489: aload #4
      //   491: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   494: pop
      //   495: aload #6
      //   497: aload #8
      //   499: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   502: pop
      //   503: aload #5
      //   505: aload #6
      //   507: invokevirtual toString : ()Ljava/lang/String;
      //   510: aload_1
      //   511: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   514: pop
      //   515: aconst_null
      //   516: areturn
      //   517: astore_1
      //   518: aconst_null
      //   519: areturn
      //   520: astore_1
      //   521: goto -> 469
      // Exception table:
      //   from	to	target	type
      //   37	51	472	java/io/FileNotFoundException
      //   56	100	386	java/lang/IllegalArgumentException
      //   56	100	321	java/lang/IllegalStateException
      //   56	100	256	java/io/IOException
      //   56	100	251	finally
      //   107	208	386	java/lang/IllegalArgumentException
      //   107	208	321	java/lang/IllegalStateException
      //   107	208	256	java/io/IOException
      //   107	208	251	finally
      //   215	233	386	java/lang/IllegalArgumentException
      //   215	233	321	java/lang/IllegalStateException
      //   215	233	256	java/io/IOException
      //   215	233	251	finally
      //   245	249	517	java/io/IOException
      //   258	306	251	finally
      //   323	371	251	finally
      //   388	436	251	finally
      //   465	469	520	java/io/IOException
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\appcompat\widget\ActivityChooserModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */