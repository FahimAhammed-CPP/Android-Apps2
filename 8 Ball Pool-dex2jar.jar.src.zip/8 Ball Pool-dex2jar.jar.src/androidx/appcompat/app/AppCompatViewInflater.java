package androidx.appcompat.app;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.InflateException;
import android.view.View;
import androidx.appcompat.R;
import androidx.appcompat.view.ContextThemeWrapper;
import androidx.appcompat.widget.AppCompatAutoCompleteTextView;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.appcompat.widget.AppCompatCheckedTextView;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatMultiAutoCompleteTextView;
import androidx.appcompat.widget.AppCompatRadioButton;
import androidx.appcompat.widget.AppCompatRatingBar;
import androidx.appcompat.widget.AppCompatSeekBar;
import androidx.appcompat.widget.AppCompatSpinner;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.appcompat.widget.AppCompatToggleButton;
import androidx.collection.SimpleArrayMap;
import androidx.core.view.ViewCompat;
import h8800e55c.pc41fcc5f.v416f9e89;
import h8800e55c.x78d2f21c.y0bc38925;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class AppCompatViewInflater {
  private static final String LOG_TAG = v416f9e89.xbd520268("1035");
  
  private static final String[] sClassPrefixList;
  
  private static final SimpleArrayMap<String, Constructor<? extends View>> sConstructorMap;
  
  private static final Class<?>[] sConstructorSignature = new Class[] { Context.class, AttributeSet.class };
  
  private static final int[] sOnClickAttrs = new int[] { 16843375 };
  
  private final Object[] mConstructorArgs = new Object[2];
  
  static {
    sClassPrefixList = new String[] { v416f9e89.xbd520268("1036"), v416f9e89.xbd520268("1037"), v416f9e89.xbd520268("1038") };
    sConstructorMap = new SimpleArrayMap();
  }
  
  private void checkOnClickListener(View paramView, AttributeSet paramAttributeSet) {
    Context context = paramView.getContext();
    if (context instanceof ContextWrapper) {
      if (Build.VERSION.SDK_INT >= 15 && !ViewCompat.hasOnClickListeners(paramView))
        return; 
      TypedArray typedArray = context.obtainStyledAttributes(paramAttributeSet, sOnClickAttrs);
      String str = typedArray.getString(0);
      if (str != null)
        paramView.setOnClickListener(new DeclaredOnClickListener(paramView, str)); 
      typedArray.recycle();
    } 
  }
  
  private View createViewByPrefix(Context paramContext, String paramString1, String paramString2) throws ClassNotFoundException, InflateException {
    SimpleArrayMap<String, Constructor<? extends View>> simpleArrayMap = sConstructorMap;
    Constructor constructor1 = (Constructor)simpleArrayMap.get(paramString1);
    Constructor<View> constructor = constructor1;
    if (constructor1 == null) {
      if (paramString2 != null)
        try {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramString2);
          stringBuilder.append(paramString1);
          paramString2 = stringBuilder.toString();
          constructor = y0bc38925.classForName(paramString2, false, paramContext.getClassLoader()).asSubclass(View.class).getConstructor(sConstructorSignature);
          simpleArrayMap.put(paramString1, constructor);
          constructor.setAccessible(true);
          return constructor.newInstance(this.mConstructorArgs);
        } catch (Exception exception) {
          return null;
        }  
    } else {
      constructor.setAccessible(true);
      return constructor.newInstance(this.mConstructorArgs);
    } 
    paramString2 = paramString1;
    constructor = y0bc38925.classForName(paramString2, false, paramContext.getClassLoader()).asSubclass(View.class).getConstructor(sConstructorSignature);
    simpleArrayMap.put(paramString1, constructor);
    constructor.setAccessible(true);
    return constructor.newInstance(this.mConstructorArgs);
  }
  
  private View createViewFromTag(Context paramContext, String paramString, AttributeSet paramAttributeSet) {
    String str = paramString;
    if (paramString.equals(v416f9e89.xbd520268("1039")))
      str = paramAttributeSet.getAttributeValue(null, v416f9e89.xbd520268("1040")); 
    try {
      Object[] arrayOfObject1;
      Object[] arrayOfObject2 = this.mConstructorArgs;
      arrayOfObject2[0] = paramContext;
      arrayOfObject2[1] = paramAttributeSet;
      if (-1 == str.indexOf('.')) {
        int i = 0;
        while (true) {
          String[] arrayOfString = sClassPrefixList;
          if (i < arrayOfString.length) {
            View view = createViewByPrefix(paramContext, str, arrayOfString[i]);
            if (view != null)
              return view; 
            i++;
            continue;
          } 
          return null;
        } 
      } 
      return createViewByPrefix((Context)arrayOfObject1, str, null);
    } catch (Exception exception) {
      return null;
    } finally {
      Object[] arrayOfObject = this.mConstructorArgs;
      arrayOfObject[0] = null;
      arrayOfObject[1] = null;
    } 
  }
  
  private static Context themifyContext(Context paramContext, AttributeSet paramAttributeSet, boolean paramBoolean1, boolean paramBoolean2) {
    int i;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.View, 0, 0);
    if (paramBoolean1) {
      i = typedArray.getResourceId(R.styleable.View_android_theme, 0);
    } else {
      i = 0;
    } 
    int j = i;
    if (paramBoolean2) {
      j = i;
      if (!i) {
        i = typedArray.getResourceId(R.styleable.View_theme, 0);
        j = i;
        if (i != 0) {
          Log.i(v416f9e89.xbd520268("1041"), v416f9e89.xbd520268("1042"));
          j = i;
        } 
      } 
    } 
    typedArray.recycle();
    Context context = paramContext;
    if (j != 0) {
      if (paramContext instanceof ContextThemeWrapper) {
        context = paramContext;
        return (Context)((((ContextThemeWrapper)paramContext).getThemeResId() != j) ? new ContextThemeWrapper(paramContext, j) : context);
      } 
    } else {
      return context;
    } 
    return (Context)new ContextThemeWrapper(paramContext, j);
  }
  
  private void verifyNotNull(View paramView, String paramString) {
    if (paramView != null)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getName());
    stringBuilder.append(v416f9e89.xbd520268("1043"));
    stringBuilder.append(paramString);
    stringBuilder.append(v416f9e89.xbd520268("1044"));
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  protected AppCompatAutoCompleteTextView createAutoCompleteTextView(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatAutoCompleteTextView(paramContext, paramAttributeSet);
  }
  
  protected AppCompatButton createButton(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatButton(paramContext, paramAttributeSet);
  }
  
  protected AppCompatCheckBox createCheckBox(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatCheckBox(paramContext, paramAttributeSet);
  }
  
  protected AppCompatCheckedTextView createCheckedTextView(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatCheckedTextView(paramContext, paramAttributeSet);
  }
  
  protected AppCompatEditText createEditText(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatEditText(paramContext, paramAttributeSet);
  }
  
  protected AppCompatImageButton createImageButton(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatImageButton(paramContext, paramAttributeSet);
  }
  
  protected AppCompatImageView createImageView(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatImageView(paramContext, paramAttributeSet);
  }
  
  protected AppCompatMultiAutoCompleteTextView createMultiAutoCompleteTextView(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatMultiAutoCompleteTextView(paramContext, paramAttributeSet);
  }
  
  protected AppCompatRadioButton createRadioButton(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatRadioButton(paramContext, paramAttributeSet);
  }
  
  protected AppCompatRatingBar createRatingBar(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatRatingBar(paramContext, paramAttributeSet);
  }
  
  protected AppCompatSeekBar createSeekBar(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatSeekBar(paramContext, paramAttributeSet);
  }
  
  protected AppCompatSpinner createSpinner(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatSpinner(paramContext, paramAttributeSet);
  }
  
  protected AppCompatTextView createTextView(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatTextView(paramContext, paramAttributeSet);
  }
  
  protected AppCompatToggleButton createToggleButton(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatToggleButton(paramContext, paramAttributeSet);
  }
  
  protected View createView(Context paramContext, String paramString, AttributeSet paramAttributeSet) {
    return null;
  }
  
  final View createView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    // Byte code:
    //   0: iload #5
    //   2: ifeq -> 18
    //   5: aload_1
    //   6: ifnull -> 18
    //   9: aload_1
    //   10: invokevirtual getContext : ()Landroid/content/Context;
    //   13: astore #10
    //   15: goto -> 21
    //   18: aload_3
    //   19: astore #10
    //   21: iload #6
    //   23: ifne -> 34
    //   26: aload #10
    //   28: astore_1
    //   29: iload #7
    //   31: ifeq -> 46
    //   34: aload #10
    //   36: aload #4
    //   38: iload #6
    //   40: iload #7
    //   42: invokestatic themifyContext : (Landroid/content/Context;Landroid/util/AttributeSet;ZZ)Landroid/content/Context;
    //   45: astore_1
    //   46: aload_1
    //   47: astore #10
    //   49: iload #8
    //   51: ifeq -> 60
    //   54: aload_1
    //   55: invokestatic wrap : (Landroid/content/Context;)Landroid/content/Context;
    //   58: astore #10
    //   60: aload_2
    //   61: invokevirtual hashCode : ()I
    //   64: pop
    //   65: iconst_m1
    //   66: istore #9
    //   68: aload_2
    //   69: invokevirtual hashCode : ()I
    //   72: lookupswitch default -> 196, -1946472170 -> 493, -1455429095 -> 471, -1346021293 -> 449, -938935918 -> 427, -937446323 -> 405, -658531749 -> 383, -339785223 -> 360, 776382189 -> 337, 799298502 -> 314, 1125864064 -> 291, 1413872058 -> 268, 1601505219 -> 245, 1666676343 -> 222, 2001146706 -> 199
    //   196: goto -> 512
    //   199: aload_2
    //   200: ldc_w '1045'
    //   203: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   206: invokevirtual equals : (Ljava/lang/Object;)Z
    //   209: ifne -> 215
    //   212: goto -> 512
    //   215: bipush #13
    //   217: istore #9
    //   219: goto -> 512
    //   222: aload_2
    //   223: ldc_w '1046'
    //   226: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   229: invokevirtual equals : (Ljava/lang/Object;)Z
    //   232: ifne -> 238
    //   235: goto -> 512
    //   238: bipush #12
    //   240: istore #9
    //   242: goto -> 512
    //   245: aload_2
    //   246: ldc_w '1047'
    //   249: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   252: invokevirtual equals : (Ljava/lang/Object;)Z
    //   255: ifne -> 261
    //   258: goto -> 512
    //   261: bipush #11
    //   263: istore #9
    //   265: goto -> 512
    //   268: aload_2
    //   269: ldc_w '1048'
    //   272: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   275: invokevirtual equals : (Ljava/lang/Object;)Z
    //   278: ifne -> 284
    //   281: goto -> 512
    //   284: bipush #10
    //   286: istore #9
    //   288: goto -> 512
    //   291: aload_2
    //   292: ldc_w '1049'
    //   295: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   298: invokevirtual equals : (Ljava/lang/Object;)Z
    //   301: ifne -> 307
    //   304: goto -> 512
    //   307: bipush #9
    //   309: istore #9
    //   311: goto -> 512
    //   314: aload_2
    //   315: ldc_w '1050'
    //   318: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   321: invokevirtual equals : (Ljava/lang/Object;)Z
    //   324: ifne -> 330
    //   327: goto -> 512
    //   330: bipush #8
    //   332: istore #9
    //   334: goto -> 512
    //   337: aload_2
    //   338: ldc_w '1051'
    //   341: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   344: invokevirtual equals : (Ljava/lang/Object;)Z
    //   347: ifne -> 353
    //   350: goto -> 512
    //   353: bipush #7
    //   355: istore #9
    //   357: goto -> 512
    //   360: aload_2
    //   361: ldc_w '1052'
    //   364: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   367: invokevirtual equals : (Ljava/lang/Object;)Z
    //   370: ifne -> 376
    //   373: goto -> 512
    //   376: bipush #6
    //   378: istore #9
    //   380: goto -> 512
    //   383: aload_2
    //   384: ldc_w '1053'
    //   387: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   390: invokevirtual equals : (Ljava/lang/Object;)Z
    //   393: ifne -> 399
    //   396: goto -> 512
    //   399: iconst_5
    //   400: istore #9
    //   402: goto -> 512
    //   405: aload_2
    //   406: ldc_w '1054'
    //   409: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   412: invokevirtual equals : (Ljava/lang/Object;)Z
    //   415: ifne -> 421
    //   418: goto -> 512
    //   421: iconst_4
    //   422: istore #9
    //   424: goto -> 512
    //   427: aload_2
    //   428: ldc_w '1055'
    //   431: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   434: invokevirtual equals : (Ljava/lang/Object;)Z
    //   437: ifne -> 443
    //   440: goto -> 512
    //   443: iconst_3
    //   444: istore #9
    //   446: goto -> 512
    //   449: aload_2
    //   450: ldc_w '1056'
    //   453: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   456: invokevirtual equals : (Ljava/lang/Object;)Z
    //   459: ifne -> 465
    //   462: goto -> 512
    //   465: iconst_2
    //   466: istore #9
    //   468: goto -> 512
    //   471: aload_2
    //   472: ldc_w '1057'
    //   475: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   478: invokevirtual equals : (Ljava/lang/Object;)Z
    //   481: ifne -> 487
    //   484: goto -> 512
    //   487: iconst_1
    //   488: istore #9
    //   490: goto -> 512
    //   493: aload_2
    //   494: ldc_w '1058'
    //   497: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   500: invokevirtual equals : (Ljava/lang/Object;)Z
    //   503: ifne -> 509
    //   506: goto -> 512
    //   509: iconst_0
    //   510: istore #9
    //   512: iload #9
    //   514: tableswitch default -> 584, 0 -> 831, 1 -> 813, 2 -> 795, 3 -> 777, 4 -> 759, 5 -> 741, 6 -> 723, 7 -> 705, 8 -> 687, 9 -> 669, 10 -> 651, 11 -> 633, 12 -> 615, 13 -> 597
    //   584: aload_0
    //   585: aload #10
    //   587: aload_2
    //   588: aload #4
    //   590: invokevirtual createView : (Landroid/content/Context;Ljava/lang/String;Landroid/util/AttributeSet;)Landroid/view/View;
    //   593: astore_1
    //   594: goto -> 846
    //   597: aload_0
    //   598: aload #10
    //   600: aload #4
    //   602: invokevirtual createButton : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatButton;
    //   605: astore_1
    //   606: aload_0
    //   607: aload_1
    //   608: aload_2
    //   609: invokespecial verifyNotNull : (Landroid/view/View;Ljava/lang/String;)V
    //   612: goto -> 846
    //   615: aload_0
    //   616: aload #10
    //   618: aload #4
    //   620: invokevirtual createEditText : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatEditText;
    //   623: astore_1
    //   624: aload_0
    //   625: aload_1
    //   626: aload_2
    //   627: invokespecial verifyNotNull : (Landroid/view/View;Ljava/lang/String;)V
    //   630: goto -> 846
    //   633: aload_0
    //   634: aload #10
    //   636: aload #4
    //   638: invokevirtual createCheckBox : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatCheckBox;
    //   641: astore_1
    //   642: aload_0
    //   643: aload_1
    //   644: aload_2
    //   645: invokespecial verifyNotNull : (Landroid/view/View;Ljava/lang/String;)V
    //   648: goto -> 846
    //   651: aload_0
    //   652: aload #10
    //   654: aload #4
    //   656: invokevirtual createAutoCompleteTextView : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatAutoCompleteTextView;
    //   659: astore_1
    //   660: aload_0
    //   661: aload_1
    //   662: aload_2
    //   663: invokespecial verifyNotNull : (Landroid/view/View;Ljava/lang/String;)V
    //   666: goto -> 846
    //   669: aload_0
    //   670: aload #10
    //   672: aload #4
    //   674: invokevirtual createImageView : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatImageView;
    //   677: astore_1
    //   678: aload_0
    //   679: aload_1
    //   680: aload_2
    //   681: invokespecial verifyNotNull : (Landroid/view/View;Ljava/lang/String;)V
    //   684: goto -> 846
    //   687: aload_0
    //   688: aload #10
    //   690: aload #4
    //   692: invokevirtual createToggleButton : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatToggleButton;
    //   695: astore_1
    //   696: aload_0
    //   697: aload_1
    //   698: aload_2
    //   699: invokespecial verifyNotNull : (Landroid/view/View;Ljava/lang/String;)V
    //   702: goto -> 846
    //   705: aload_0
    //   706: aload #10
    //   708: aload #4
    //   710: invokevirtual createRadioButton : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatRadioButton;
    //   713: astore_1
    //   714: aload_0
    //   715: aload_1
    //   716: aload_2
    //   717: invokespecial verifyNotNull : (Landroid/view/View;Ljava/lang/String;)V
    //   720: goto -> 846
    //   723: aload_0
    //   724: aload #10
    //   726: aload #4
    //   728: invokevirtual createSpinner : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatSpinner;
    //   731: astore_1
    //   732: aload_0
    //   733: aload_1
    //   734: aload_2
    //   735: invokespecial verifyNotNull : (Landroid/view/View;Ljava/lang/String;)V
    //   738: goto -> 846
    //   741: aload_0
    //   742: aload #10
    //   744: aload #4
    //   746: invokevirtual createSeekBar : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatSeekBar;
    //   749: astore_1
    //   750: aload_0
    //   751: aload_1
    //   752: aload_2
    //   753: invokespecial verifyNotNull : (Landroid/view/View;Ljava/lang/String;)V
    //   756: goto -> 846
    //   759: aload_0
    //   760: aload #10
    //   762: aload #4
    //   764: invokevirtual createImageButton : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatImageButton;
    //   767: astore_1
    //   768: aload_0
    //   769: aload_1
    //   770: aload_2
    //   771: invokespecial verifyNotNull : (Landroid/view/View;Ljava/lang/String;)V
    //   774: goto -> 846
    //   777: aload_0
    //   778: aload #10
    //   780: aload #4
    //   782: invokevirtual createTextView : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatTextView;
    //   785: astore_1
    //   786: aload_0
    //   787: aload_1
    //   788: aload_2
    //   789: invokespecial verifyNotNull : (Landroid/view/View;Ljava/lang/String;)V
    //   792: goto -> 846
    //   795: aload_0
    //   796: aload #10
    //   798: aload #4
    //   800: invokevirtual createMultiAutoCompleteTextView : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatMultiAutoCompleteTextView;
    //   803: astore_1
    //   804: aload_0
    //   805: aload_1
    //   806: aload_2
    //   807: invokespecial verifyNotNull : (Landroid/view/View;Ljava/lang/String;)V
    //   810: goto -> 846
    //   813: aload_0
    //   814: aload #10
    //   816: aload #4
    //   818: invokevirtual createCheckedTextView : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatCheckedTextView;
    //   821: astore_1
    //   822: aload_0
    //   823: aload_1
    //   824: aload_2
    //   825: invokespecial verifyNotNull : (Landroid/view/View;Ljava/lang/String;)V
    //   828: goto -> 846
    //   831: aload_0
    //   832: aload #10
    //   834: aload #4
    //   836: invokevirtual createRatingBar : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatRatingBar;
    //   839: astore_1
    //   840: aload_0
    //   841: aload_1
    //   842: aload_2
    //   843: invokespecial verifyNotNull : (Landroid/view/View;Ljava/lang/String;)V
    //   846: aload_1
    //   847: astore #11
    //   849: aload_1
    //   850: ifnonnull -> 873
    //   853: aload_1
    //   854: astore #11
    //   856: aload_3
    //   857: aload #10
    //   859: if_acmpeq -> 873
    //   862: aload_0
    //   863: aload #10
    //   865: aload_2
    //   866: aload #4
    //   868: invokespecial createViewFromTag : (Landroid/content/Context;Ljava/lang/String;Landroid/util/AttributeSet;)Landroid/view/View;
    //   871: astore #11
    //   873: aload #11
    //   875: ifnull -> 886
    //   878: aload_0
    //   879: aload #11
    //   881: aload #4
    //   883: invokespecial checkOnClickListener : (Landroid/view/View;Landroid/util/AttributeSet;)V
    //   886: aload #11
    //   888: areturn
  }
  
  private static class DeclaredOnClickListener implements View.OnClickListener {
    private final View mHostView;
    
    private final String mMethodName;
    
    private Context mResolvedContext;
    
    private Method mResolvedMethod;
    
    public DeclaredOnClickListener(View param1View, String param1String) {
      this.mHostView = param1View;
      this.mMethodName = param1String;
    }
    
    private void resolveMethod(Context param1Context) {
      while (true) {
        String str;
        if (param1Context != null) {
          try {
            if (!param1Context.isRestricted()) {
              Method method = y0bc38925.getMethod(param1Context.getClass(), this.mMethodName, new Class[] { View.class });
              if (method != null) {
                this.mResolvedMethod = method;
                this.mResolvedContext = param1Context;
                return;
              } 
            } 
          } catch (NoSuchMethodException noSuchMethodException) {}
          if (param1Context instanceof ContextWrapper) {
            param1Context = ((ContextWrapper)param1Context).getBaseContext();
            continue;
          } 
          param1Context = null;
          continue;
        } 
        int i = this.mHostView.getId();
        if (i == -1) {
          str = v416f9e89.xbd520268("1008");
        } else {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(v416f9e89.xbd520268("1009"));
          stringBuilder1.append(this.mHostView.getContext().getResources().getResourceEntryName(i));
          stringBuilder1.append(v416f9e89.xbd520268("1010"));
          str = stringBuilder1.toString();
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(v416f9e89.xbd520268("1011"));
        stringBuilder.append(this.mMethodName);
        stringBuilder.append(v416f9e89.xbd520268("1012"));
        stringBuilder.append(this.mHostView.getClass());
        stringBuilder.append(str);
        throw new IllegalStateException(stringBuilder.toString());
      } 
    }
    
    public void onClick(View param1View) {
      if (this.mResolvedMethod == null)
        resolveMethod(this.mHostView.getContext()); 
      try {
        this.mResolvedMethod.invoke(this.mResolvedContext, new Object[] { param1View });
        return;
      } catch (IllegalAccessException illegalAccessException) {
        throw new IllegalStateException(v416f9e89.xbd520268("1014"), illegalAccessException);
      } catch (InvocationTargetException invocationTargetException) {
        throw new IllegalStateException(v416f9e89.xbd520268("1013"), invocationTargetException);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\appcompat\app\AppCompatViewInflater.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */